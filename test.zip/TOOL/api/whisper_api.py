#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB - WHISPER API ROUTER (TƯƠNG THÍCH PYTHON 3.14 + ANDROID/PC)
==============================================================================
"""

from typing import Optional, Dict, Any
from pathlib import Path
from TOOL.engines.whisper_engine import WhisperEngine
from TOOL.services.file_service import FileService
from TOOL.services.task_service import job_manager
from TOOL.services.whisper_model_service import WhisperModelService

try:
    from pydantic import BaseModel
except ImportError:
    class BaseModel:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

try:
    from fastapi import APIRouter, UploadFile, File, Form, HTTPException
    router = APIRouter(prefix="/api/whisper", tags=["Whisper Operations"])
    HAS_FASTAPI = True
except ImportError:
    router = None
    HAS_FASTAPI = False

class ModelDownloadRequest(BaseModel):
    model_id: str

def handle_whisper_models() -> Dict[str, Any]:
    """Trả về danh sách model thực tế đã tải, model lỗi, model không hỗ trợ và model mặc định."""
    return WhisperModelService.scan_models()

def handle_download_whisper_model(model_id: str) -> Dict[str, Any]:
    """Kích hoạt tiến trình tải model Whisper trong background."""
    if not model_id:
        raise ValueError("Chưa cung cấp mã model_id cần tải.")
    return WhisperModelService.start_download_model(model_id)

def handle_whisper_transcribe(
    saved_path: Path,
    filename: str,
    model_size: str = "large-v3-turbo",
    beam_size: int = 5,
    language: str = "zh",
    max_words: int = 20,
    max_duration: float = 6.0,
    silence_threshold: float = 0.3
) -> Dict[str, Any]:
                                                                  
    scan_res = WhisperModelService.scan_models()
    if not scan_res["available"] or not scan_res["models"]:
        raise ValueError(
            "Whisper AI chưa sẵn sàng: Chưa tìm thấy Whisper AI Model trong DATA/models/. "
            "Vui lòng tải Whisper AI Model để sử dụng chức năng này."
        )

    valid_ids = [m["id"] for m in scan_res["models"]]
    if model_size not in valid_ids and not any(m.get("folder_name") == model_size for m in scan_res["models"]):
        raise ValueError(
            f"Model '{model_size}' chưa được tải hoặc không hợp lệ. "
            f"Các model hợp lệ hiện có: {', '.join(valid_ids)}"
        )

    job_id = job_manager.create_job("whisper_transcribe", {
        "filename": filename,
        "model_size": model_size,
        "language": language,
        "upload_path": str(saved_path)
    })

    def _task(jid):
        WhisperEngine.transcribe_audio_to_srt(
            saved_path,
            model_size=model_size,
            beam_size=beam_size,
            language=language,
            max_words=max_words,
            max_duration=max_duration,
            silence_threshold=silence_threshold,
            job_id=jid
        )

    job_manager.run_in_background(job_id, _task)
    return {
        "job_id": job_id,
        "status": "queued",
        "message": f"Đã bắt đầu trích xuất phụ đề tiếng Trung cho '{filename}' (Model: {model_size})."
    }

if HAS_FASTAPI and router:
    @router.get("/models")
    def get_whisper_models():
        return handle_whisper_models()

    @router.post("/models/download")
    def download_whisper_model_endpoint(req: ModelDownloadRequest):
        try:
            return handle_download_whisper_model(req.model_id)
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    @router.post("/models/scan")
    def scan_whisper_models_endpoint():
        return handle_whisper_models()

    @router.post("/transcribe")
    async def transcribe_endpoint(
        file: UploadFile = File(...),
        model_size: str = Form("large-v3-turbo"),
        beam_size: int = Form(5),
        language: str = Form("zh"),
        max_words: int = Form(20),
        max_duration: float = Form(6.0),
        silence_threshold: float = Form(0.3)
    ):
        try:
            contents = await file.read()
            saved_path = FileService.save_upload(contents, file.filename)
            return handle_whisper_transcribe(
                saved_path=saved_path,
                filename=file.filename,
                model_size=model_size,
                beam_size=beam_size,
                language=language,
                max_words=max_words,
                max_duration=max_duration,
                silence_threshold=silence_threshold
            )
        except ValueError as ve:
            raise HTTPException(status_code=400, detail=str(ve))
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Lỗi nhận diện Whisper: {str(e)}")
