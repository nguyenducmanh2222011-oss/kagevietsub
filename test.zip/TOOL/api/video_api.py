#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
DSUB LOCAL - VIDEO API ROUTER (TƯƠNG THÍCH PYTHON 3.14 + ANDROID/PC)
==============================================================================
"""

from typing import List, Optional, Dict, Any
from pathlib import Path
from TOOL.engines.video_engine import VideoEngine
from TOOL.services.file_service import FileService
from TOOL.services.ffmpeg_service import FFmpegService
from TOOL.services.task_service import job_manager

try:
    from fastapi import APIRouter, UploadFile, File, Form, HTTPException
    router = APIRouter(prefix="/api/video", tags=["Video Operations"])
    HAS_FASTAPI = True
except ImportError:
    router = None
    HAS_FASTAPI = False

def handle_video_cut(video_path: Path, filename: str, segment_minutes: int = 5, mode: str = "copy") -> Dict[str, Any]:
    job_id = job_manager.create_job("video_cut", {"filename": filename, "segment_minutes": segment_minutes, "upload_path": str(video_path)})

    def _task(jid):
        VideoEngine.cut_video_segments(
            video_path,
            segment_minutes=segment_minutes,
            mode=mode,
            job_id=jid
        )

    job_manager.run_in_background(job_id, _task)
    return {
        "job_id": job_id,
        "status": "queued",
        "message": f"Đang chuẩn bị cắt video '{filename}' thành từng đoạn {segment_minutes} phút."
    }

def handle_video_merge(
    saved_paths: List[Path],
    output_filename: str = "merged_video.mp4",
    mode: str = "lossless",
    caption: Optional[str] = None,
    font_size: int = 24,
    font_color: str = "white",
    caption_position: str = "bottom",
    sort_mode: str = "natural"
) -> Dict[str, Any]:
    if len(saved_paths) < 2:
        raise ValueError("Vui lòng cung cấp ít nhất 2 video để ghép.")

    job_id = job_manager.create_job("video_merge", {"files_count": len(saved_paths), "mode": mode, "upload_paths": [str(p) for p in saved_paths]})

    def _task(jid):
        VideoEngine.merge_video_files(
            saved_paths,
            output_filename=output_filename,
            mode=mode,
            caption=caption,
            font_size=font_size,
            font_color=font_color,
            caption_position=caption_position,
            sort_mode=sort_mode,
            job_id=jid
        )

    job_manager.run_in_background(job_id, _task)
    return {
        "job_id": job_id,
        "status": "queued",
        "message": f"Đã đưa {len(saved_paths)} video vào hàng đợi ghép."
    }

def handle_video_compress(
    video_path: Path,
    filename: str,
    crf: int = 18,
    preset: str = "slow",
    codec: str = "libx264"
) -> Dict[str, Any]:
    job_id = job_manager.create_job("video_compress", {"filename": filename, "crf": crf, "upload_path": str(video_path)})

    def _task(jid):
        VideoEngine.compress_video_file(
            video_path,
            crf=crf,
            preset=preset,
            codec=codec,
            job_id=jid
        )

    job_manager.run_in_background(job_id, _task)
    return {
        "job_id": job_id,
        "status": "queued",
        "message": f"Đã đưa video '{filename}' vào hàng đợi nén (CRF={crf})."
    }

if HAS_FASTAPI and router:
    @router.post("/cut")
    async def cut_video_endpoint(
        file: UploadFile = File(...),
        segment_minutes: int = Form(5),
        mode: str = Form("copy")
    ):
        contents = await file.read()
        video_path = FileService.save_upload(contents, file.filename)
        return handle_video_cut(video_path, file.filename, segment_minutes, mode)

    @router.post("/merge")
    async def merge_video_endpoint(
        files: List[UploadFile] = File(...),
        output_filename: str = Form("merged_video.mp4"),
        mode: str = Form("lossless"),
        caption: Optional[str] = Form(None),
        font_size: int = Form(24),
        font_color: str = Form("white"),
        caption_position: str = Form("bottom"),
        sort_mode: str = Form("natural")
    ):
        if len(files) < 2:
            raise HTTPException(status_code=400, detail="Vui lòng cung cấp ít nhất 2 video để ghép.")

        saved_paths = []
        for f in files:
            contents = await f.read()
            p = FileService.save_upload(contents, f.filename)
            saved_paths.append(p)

        try:
            return handle_video_merge(
                saved_paths,
                output_filename=output_filename,
                mode=mode,
                caption=caption,
                font_size=font_size,
                font_color=font_color,
                caption_position=caption_position,
                sort_mode=sort_mode
            )
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    @router.post("/compress")
    async def compress_video_endpoint(
        file: UploadFile = File(...),
        crf: int = Form(18),
        preset: str = Form("slow"),
        codec: str = Form("libx264")
    ):
        contents = await file.read()
        video_path = FileService.save_upload(contents, file.filename)
        return handle_video_compress(video_path, file.filename, crf, preset, codec)

    @router.post("/info")
    async def video_info_endpoint(file: UploadFile = File(...)):
        contents = await file.read()
        temp_path = FileService.save_upload(contents, file.filename)
        info = FFmpegService.get_media_info(temp_path)
        return {"filename": file.filename, "info": info}
