#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
DSUB LOCAL - AUDIO API ROUTER (TƯƠNG THÍCH PYTHON 3.14 + ANDROID/PC)
==============================================================================
"""

from typing import List, Optional, Dict, Any
from pathlib import Path
from TOOL.engines.audio_engine import AudioEngine
from TOOL.services.file_service import FileService
from TOOL.services.task_service import job_manager

try:
    from fastapi import APIRouter, UploadFile, File, Form, HTTPException
    router = APIRouter(prefix="/api/audio", tags=["Audio Operations"])
    HAS_FASTAPI = True
except ImportError:
    router = None
    HAS_FASTAPI = False

def handle_audio_merge(
    saved_paths: List[Path],
    output_filename: str = "combined.mp3",
    sort_mode: str = "natural",
    expected_count: Optional[int] = None
) -> Dict[str, Any]:
    if len(saved_paths) < 2:
        raise ValueError("Vui lòng cung cấp ít nhất 2 file âm thanh để ghép.")

    job_id = job_manager.create_job(
        "audio_merge",
        {"files_count": len(saved_paths), "upload_paths": [str(p) for p in saved_paths]}
    )

    def _task(jid):
        AudioEngine.merge_audio_files(
            saved_paths,
            output_filename=output_filename,
            sort_mode=sort_mode,
            expected_count=expected_count,
            job_id=jid
        )

    job_manager.run_in_background(job_id, _task)
    return {
        "job_id": job_id,
        "status": "queued",
        "message": f"Đã đưa {len(saved_paths)} file vào hàng đợi ghép MP3."
    }

if HAS_FASTAPI and router:
    @router.post("/merge")
    async def merge_audio_endpoint(
        files: List[UploadFile] = File(...),
        output_filename: str = Form("combined.mp3"),
        sort_mode: str = Form("natural"),
        expected_count: Optional[int] = Form(None)
    ):
        if len(files) < 2:
            raise HTTPException(status_code=400, detail="Vui lòng cung cấp ít nhất 2 file âm thanh để ghép.")

        saved_paths = []
        for f in files:
            contents = await f.read()
            p = FileService.save_upload(contents, f.filename)
            saved_paths.append(p)

        try:
            return handle_audio_merge(saved_paths, output_filename, sort_mode=sort_mode, expected_count=expected_count)
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))
