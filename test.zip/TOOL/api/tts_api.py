#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB - TTS API ROUTER (TƯƠNG THÍCH PYTHON 3.14 + ANDROID/PC)
==============================================================================
API tạo giọng đọc TTS CapCut cho phụ đề SRT:
- Lấy danh mục giọng đọc (GET /api/tts/voices)
- Phân tích & kiểm tra tính hợp lệ của file SRT (POST /api/tts/parse-srt)
- Khởi tạo tiến trình tạo TTS đa luồng (POST /api/tts/create-job)
- Thử lại từng câu phụ đề bị lỗi (POST /api/tts/retry)
- Ghép nối audio hoàn chỉnh theo mốc thời gian SRT (POST /api/tts/merge)
- Truy vấn trạng thái job (GET /api/tts/job/{job_id})
==============================================================================
"""

import os
import time
import re
from typing import Optional, Dict, Any, List
from pathlib import Path
from TOOL.config import TEMP_DIR
from TOOL.engines.tts_engine import TTSEngine
from TOOL.engines.srt_engine import SrtEngine
from TOOL.services.task_service import job_manager

try:
    from pydantic import BaseModel
except ImportError:
    class BaseModel:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

try:
    from fastapi import APIRouter, HTTPException, Body
    router = APIRouter(prefix="/api/tts", tags=["CapCut TTS Operations"])
    HAS_FASTAPI = True
except ImportError:
    router = None
    HAS_FASTAPI = False

class TTSCreateJobRequest(BaseModel):
    srt_content: str
    voice: str = "BV421_vivn_streaming"
    speed: float = 1.0
    threads: int = 5
    audio_format: str = "mp3"
    output_filename: Optional[str] = None

class TTSRetryRequest(BaseModel):
    job_id: str
    subtitle_index: int
    voice: Optional[str] = None
    speed: Optional[float] = None

class TTSMergeRequest(BaseModel):
    job_id: str
    audio_format: Optional[str] = None
    output_filename: Optional[str] = None

def handle_tts_voices() -> Dict[str, Any]:
    """Trả về danh sách giọng đọc tiếng Việt khả dụng từ VoiceService chính thức (Voice.json trên GitHub)."""
    try:
        from TOOL.services.voice_service import VoiceService
        voices = VoiceService.get_vietnamese_voices()
        return {
            "success": True,
            "status": "ok",
            "source": "github",
            "language": "vi-VN",
            "voices": voices,
            "total": len(voices)
        }
    except Exception as e:
        return {
            "success": False,
            "status": "error",
            "error": str(e),
            "source": "github",
            "language": "vi-VN",
            "voices": [],
            "total": 0
        }

def handle_tts_parse_srt(srt_content: str) -> Dict[str, Any]:
    """
    Phân tích nội dung SRT, kiểm tra tính hợp lệ của timestamp và block:
    - Kiểm tra số thứ tự
    - Kiểm tra mốc thời gian start / end
    - Kiểm tra block rỗng
    """
    if not srt_content or not srt_content.strip():
        raise ValueError("Nội dung file SRT rỗng.")

    blocks = SrtEngine.parse_srt(srt_content)
    if not blocks:
        raise ValueError("Không tìm thấy khối phụ đề SRT hợp lệ. Vui lòng kiểm tra định dạng file .srt.")

    subtitles = []
    for idx, b in enumerate(blocks, 1):
        s_ms = SrtEngine.time_to_ms(b["start"])
        e_ms = SrtEngine.time_to_ms(b["end"])
        if e_ms <= s_ms:
                                                                  
            e_ms = s_ms + 1000
            b["end"] = SrtEngine.ms_to_time(e_ms)

        subtitles.append({
            "index": idx,
            "id": f"{idx:04d}",
            "start": b["start"],
            "end": b["end"],
            "start_ms": s_ms,
            "end_ms": e_ms,
            "text": b["text"].strip(),
            "status": "PENDING"
        })

    return {
        "status": "ok",
        "total": len(subtitles),
        "subtitles": subtitles
    }

def handle_tts_create_job(
    srt_content: str,
    voice: str = "BV421_vivn_streaming",
    speed: float = 1.0,
    threads: int = 5,
    audio_format: str = "mp3",
    output_filename: Optional[str] = None
) -> Dict[str, Any]:
    """Khởi tạo job tạo TTS với đa luồng thực tế và định dạng audio MP3 / WAV."""
                  
    parse_res = handle_tts_parse_srt(srt_content)
    subtitles = parse_res["subtitles"]
    if not subtitles:
        raise ValueError("Không có câu phụ đề nào để tạo giọng đọc.")

    threads = max(1, min(30, int(threads)))
    speed = max(0.25, min(4.0, float(speed)))
    
    audio_format = str(audio_format).lower().strip() if audio_format else "mp3"
    if audio_format not in ["mp3", "wav"]:
        audio_format = "mp3"

    voice_info = TTSEngine.validate_vietnamese_voice(voice)
    if not voice_info:
        default_voices = TTSEngine.get_voices()
        voice = default_voices[0]["voice_type"] if default_voices else "BV421_vivn_streaming"
    else:
        voice = voice_info["voice_type"]

    if not output_filename:
        output_filename = f"tts_final_audio.{audio_format}"
    else:
        if audio_format == "wav":
            if not output_filename.lower().endswith(".wav"):
                if output_filename.lower().endswith(".mp3"):
                    output_filename = output_filename[:-4] + ".wav"
                else:
                    output_filename += ".wav"
        else:
            if not output_filename.lower().endswith(".mp3"):
                if output_filename.lower().endswith(".wav"):
                    output_filename = output_filename[:-4] + ".mp3"
                else:
                    output_filename += ".mp3"

    job_id = job_manager.create_job("tts_generation", {
        "voice": voice,
        "speed": speed,
        "threads": threads,
        "audio_format": audio_format,
        "total_subtitles": len(subtitles),
        "output_filename": output_filename
    })

    def _task(jid):
        TTSEngine.process_tts_job(
            job_id=jid,
            subtitles=subtitles,
            voice=voice,
            speed=speed,
            threads=threads,
            audio_format=audio_format
        )

    job_manager.run_in_background(job_id, _task)

    return {
        "status": "ok",
        "job_id": job_id,
        "message": f"Đã khởi tạo tiến trình tạo TTS ({audio_format.upper()}) cho {len(subtitles)} câu phụ đề ({threads} luồng).",
        "total": len(subtitles),
        "threads": threads,
        "voice": voice,
        "speed": speed,
        "audio_format": audio_format,
        "output_filename": output_filename
    }

def handle_tts_retry(
    job_id: str,
    subtitle_index: int,
    voice: Optional[str] = None,
    speed: Optional[float] = None
) -> Dict[str, Any]:
    """Thử lại tạo TTS cho 1 câu phụ đề cụ thể."""
    return TTSEngine.retry_subtitle(job_id, subtitle_index, voice, speed)

def handle_tts_retry_failed(
    job_id: str,
    voice: Optional[str] = None,
    speed: Optional[float] = None,
    threads: Optional[int] = None
) -> Dict[str, Any]:
    """Thử lại tất cả các câu phụ đề bị lỗi hoặc thiếu trong job TTS với đa luồng thực tế."""
    return TTSEngine.retry_failed_subtitles(job_id, voice, speed, threads)

def handle_tts_merge(
    job_id: str,
    output_filename: Optional[str] = None,
    audio_format: Optional[str] = None
) -> Dict[str, Any]:
    """Ghép nối audio theo mốc thời gian SRT trong background."""
    job = job_manager.get_job(job_id)
    if not job:
        job = TTSEngine.recover_job_from_disk(job_id)
    job_meta = (job.get("metadata", {}) if job else {})
    job_res = (job.get("result", {}) if job else {})

    if not audio_format:
        audio_format = job_res.get("audio_format") or job_meta.get("audio_format", "mp3")
    audio_format = str(audio_format).lower().strip()
    if audio_format not in ["mp3", "wav"]:
        audio_format = "mp3"

    if not output_filename:
        output_filename = job_meta.get("output_filename") or f"tts_final_audio.{audio_format}"

    if audio_format == "wav":
        if not output_filename.lower().endswith(".wav"):
            if output_filename.lower().endswith(".mp3"):
                output_filename = output_filename[:-4] + ".wav"
            else:
                output_filename += ".wav"
    else:
        if not output_filename.lower().endswith(".mp3"):
            if output_filename.lower().endswith(".wav"):
                output_filename = output_filename[:-4] + ".mp3"
            else:
                output_filename += ".mp3"

    from TOOL.services.storage_service import StorageService
    out_dir = StorageService.get_output_dir()
    existing_file = out_dir / output_filename
    saved_loc_existing = f"Download/KAGEVIETSUB/{output_filename}"

    # Check if job is already merged and valid output file exists
    if job and (job.get("status") == "merged" or job.get("merge_status") == "completed") and existing_file.exists() and existing_file.stat().st_size > 0:
        file_size = existing_file.stat().st_size
        size_mb = round(file_size / (1024 * 1024), 2)
        success_msg = f"✓ File audio {audio_format.upper()} đã được ghép xong trước đó ({size_mb} MB). File lưu tại: Download/KAGEVIETSUB/{output_filename}"
        job_manager.update_job(
            job_id,
            status="merged",
            merge_status="completed",
            tts_status="completed",
            tts_progress=100,
            merge_progress=100,
            merge_stage="Hoàn tất ghép audio",
            merge_speed="Hoàn tất",
            merge_eta=0,
            overall_progress=100,
            progress=100,
            message=success_msg,
            filename=output_filename,
            output_filename=output_filename,
            saved_path=str(existing_file.resolve()),
            output_path=str(existing_file.resolve()),
            saved_location=saved_loc_existing,
            output_size=file_size,
            verified=True,
            download_url=f"/api/download/{urllib.parse.quote(output_filename)}"
        )
        return {
            "status": "ok",
            "job_id": job_id,
            "audio_format": audio_format,
            "output_filename": output_filename,
            "already_merged": True,
            "saved_location": saved_loc_existing,
            "message": success_msg
        }

    job_manager.update_job(job_id, status="merging", merge_status="merging", progress=10, message=f"Bắt đầu ghép nối audio ({audio_format.upper()}) theo SRT...")

    def _merge_task(jid):
        try:
            TTSEngine.merge_tts_audio_by_srt(jid, output_filename=output_filename, audio_format=audio_format)
        except Exception as ex:
            logger.exception(f"Lỗi ngoài dự kiến khi ghép audio job '{jid}': {ex}")
            job_manager.update_job(
                jid,
                status="tts_completed",
                merge_status="failed",
                merge_error=str(ex),
                error=str(ex),
                message=f"❌ Lỗi ghép audio: {ex}. Dữ liệu giọng đọc TTS vẫn đầy đủ 100%, bạn có thể bấm 'Ghép Audio' để thử lại."
            )

    job_manager.run_in_background(job_id, _merge_task)
    return {
        "status": "ok",
        "job_id": job_id,
        "audio_format": audio_format,
        "output_filename": output_filename,
        "message": f"Đã bắt đầu ghép nối audio ({audio_format.upper()}) theo mốc thời gian SRT."
    }

def handle_tts_get_status(job_id: str, include_subtitles: bool = False) -> Dict[str, Any]:
    """
    Trả về metadata trạng thái chuẩn cho polling hiệu năng cao:
    - Source of truth duy nhất từ Backend
    - Monotonic revision chống rollback dữ liệu
    - Trả về các chỉ số phân biệt rõ ràng: completed, processing, finalizing, pending, failed, retrying, final_failed
    - Thông số Throughput/phút và ETA dự kiến
    - Hạn chế payload: không trả danh sách subtitles nếu include_subtitles=False
    - Tự động khôi phục từ Checkpoint và Reconcile thực tế đĩa cứng (Crash Recovery) nếu server vừa khởi động lại
    """
    job = job_manager.get_job(job_id)
    if not job:
        job = TTSEngine.recover_job_from_disk(job_id)
        if not job:
            raise ValueError(f"Không tìm thấy job '{job_id}'.")

    res = job.get("result") or {}
    total = res.get("total") or job.get("metadata", {}).get("total_subtitles", 0)
    completed = res.get("completed", 0)
    failed = res.get("failed", 0)
    processing = res.get("processing", 0)
    finalizing = res.get("finalizing", 0)
    retrying = res.get("retrying", 0)
    final_failed = res.get("final_failed", 0)
    pending = res.get("pending", max(0, total - (completed + failed + processing + finalizing + retrying)))
    progress = job.get("progress", res.get("progress", 0))
    revision = res.get("revision", 1)
    throughput = res.get("throughput_per_min", 0.0)

    eta_sec = job.get("eta_seconds")
    if eta_sec is None:
        eta_sec = res.get("eta_seconds")
    remaining = max(0, total - completed - failed)
    if eta_sec is None and throughput >= 1.0 and completed >= 2 and remaining > 0:
        eta_sec = int((remaining / throughput) * 60)

    raw_status = str(job.get("status", "unknown")).lower()
    merge_status = job.get("merge_status") or res.get("merge_status")

    saved_loc = job.get("saved_location") or res.get("saved_location")
    out_path_str = job.get("output_path") or job.get("saved_path") or res.get("output_path") or res.get("saved_path")
    if not saved_loc and out_path_str:
        out_p = Path(out_path_str)
        if out_p.exists() and out_p.stat().st_size > 0:
            saved_loc = f"Download/KAGEVIETSUB/{out_p.name}"

    if not merge_status:
        if saved_loc or raw_status == "merged":
            merge_status = "completed"
        elif raw_status == "merging":
            merge_status = "merging"
        else:
            merge_status = "idle"

    if raw_status in ["merged"] or merge_status == "completed" or (raw_status == "completed" and saved_loc):
        norm_status = "merged"
        merge_status = "completed"
    elif raw_status in ["tts_completed", "completed_with_errors"] or (raw_status == "completed" and not saved_loc):
        norm_status = "tts_completed"
    elif raw_status in ["merging"]:
        norm_status = "merging"
    elif raw_status in ["paused"]:
        norm_status = "paused"
    elif raw_status in ["processing", "generating", "creating"]:
        norm_status = "creating"
    elif raw_status in ["failed", "error"]:
        norm_status = "error"
    elif raw_status in ["idle"]:
        norm_status = "idle"
    else:
        norm_status = raw_status

    can_merge = (norm_status in ["tts_completed", "completed_with_errors", "completed", "merged"]) or (completed > 0 and (completed + failed) == total and total > 0)

    out_file_name = job.get("filename") or job.get("output_filename") or (Path(saved_loc).name if saved_loc else None) or "tts_final_audio.mp3"

    status_data: Dict[str, Any] = {
        "job_id": job_id,
        "type": "tts",
        "status": norm_status,
        "raw_status": raw_status,
        "tts_status": job.get("tts_status") or ("completed" if (completed + failed) == total and total > 0 else "creating"),
        "tts_progress": job.get("tts_progress") if job.get("tts_progress") is not None else (100 if total > 0 and completed == total else min(100, int((completed + failed) / max(1, total) * 100))),
        "merge_status": merge_status,
        "merge_progress": 100 if norm_status == "merged" else (job.get("merge_progress") if job.get("merge_progress") is not None else (0 if merge_status == "idle" else progress)),
        "merge_stage": "Hoàn tất ghép audio" if norm_status == "merged" else (job.get("merge_stage") or job.get("stage", "")),
        "merge_speed": "Hoàn tất" if norm_status == "merged" else (job.get("merge_speed") or job.get("speed", "")),
        "merge_eta": 0 if norm_status == "merged" else (job.get("merge_eta") if job.get("merge_eta") is not None else (eta_sec if norm_status == "merging" else None)),
        "merge_elapsed": job.get("merge_elapsed", 0.0),
        "merge_error": job.get("merge_error") or job.get("error", ""),
        "overall_progress": 100 if norm_status == "merged" else (job.get("overall_progress") if job.get("overall_progress") is not None else (int(70 + (job.get("merge_progress", 0) * 0.30)) if norm_status == "merging" else progress)),
        "progress": 100 if norm_status == "merged" else progress,
        "can_merge": can_merge,
        "saved_location": saved_loc,
        "output_file": saved_loc or out_file_name,
        "filename": out_file_name,
        "output_filename": out_file_name,
        "output_path": out_path_str or (str((StorageService.get_output_dir() / out_file_name).resolve()) if saved_loc else None),
        "saved_path": out_path_str or (str((StorageService.get_output_dir() / out_file_name).resolve()) if saved_loc else None),
        "download_url": job.get("download_url") or (f"/api/download/{urllib.parse.quote(out_file_name)}" if saved_loc or norm_status == "merged" else None),
        "output_size": job.get("output_size"),
        "duration": job.get("duration"),
        "verified": job.get("verified", norm_status == "merged"),
        "updated_at": job.get("updated_at", time.time()),
        "revision": revision,
        "total": total,
        "completed": completed,
        "processing": processing,
        "finalizing": finalizing,
        "pending": pending,
        "failed": failed,
        "retrying": retrying,
        "final_failed": final_failed,
        "progress": progress,
        "throughput_per_min": throughput,
        "eta_seconds": eta_sec,
        "workers": res.get("requested_workers", job.get("metadata", {}).get("threads", 5)),
        "actual_workers": res.get("actual_workers", job.get("metadata", {}).get("threads", 5)),
        "tts_workers": res.get("tts_workers", job.get("metadata", {}).get("tts_workers", res.get("actual_workers", 5))),
        "speed_workers": res.get("speed_workers", job.get("metadata", {}).get("speed_workers", 4)),
        "active_workers": res.get("active_workers", 0),
        "speed": job.get("merge_speed") if norm_status == "merging" else (job.get("speed") or res.get("speed", job.get("metadata", {}).get("speed", 1.0))),
        "processing_rate": job.get("merge_speed") if norm_status == "merging" else (job.get("processing_rate") or job.get("speed") or ""),
        "stage": job.get("merge_stage") or job.get("stage", ""),
        "chunks_total": job.get("chunks_total", 0),
        "chunks_completed": job.get("chunks_completed", 0),
        "error": job.get("merge_error") or job.get("error", ""),
        "voice": res.get("voice", job.get("metadata", {}).get("voice", "")),
        "audio_format": res.get("audio_format") or job.get("metadata", {}).get("audio_format", "mp3"),
        "retry_pass": res.get("retry_pass", 0),
        "failed_indices": res.get("failed_indices", []),
        "message": job.get("message", ""),
        "saved_location": job.get("saved_location", None),
        "download_url": job.get("download_url", None),
        "result": job.get("result")
    }

    if include_subtitles:
        status_data["subtitles"] = res.get("subtitles", [])

    return status_data

def handle_tts_get_job(job_id: str) -> Dict[str, Any]:
    """Lấy trạng thái chi tiết của job TTS (kèm Crash Recovery nếu cần)."""
    job = job_manager.get_job(job_id)
    if not job:
        job = TTSEngine.recover_job_from_disk(job_id)
        if not job:
            raise ValueError(f"Không tìm thấy job '{job_id}'.")
    return job

def handle_tts_pause(job_id: str) -> Dict[str, Any]:
    """Tạm dừng job TTS."""
    return TTSEngine.pause_job(job_id)

def handle_tts_resume(job_id: str) -> Dict[str, Any]:
    """Tiếp tục job TTS."""
    return TTSEngine.resume_job(job_id)

def handle_tts_stop(job_id: str) -> Dict[str, Any]:
    """Dừng hẳn job TTS."""
    return TTSEngine.stop_job(job_id)

def handle_tts_preview(job_id: str, subtitle_index: int) -> Path:
    """Lấy đường dẫn file audio của 1 câu phụ đề cụ thể để phát nghe thử (.mp3 hoặc .wav)."""
    from TOOL.config import TEMP_DIR
    job_dir = TEMP_DIR / "tts" / f"job_{job_id}"
    for ext in ["mp3", "wav"]:
        audio_file = job_dir / f"{subtitle_index:04d}.{ext}"
        if audio_file.exists() and audio_file.stat().st_size > 0:
            return audio_file
    raise FileNotFoundError(f"Chưa có file audio nghe thử cho câu số {subtitle_index}.")

def handle_tts_merge_recovery_folders() -> Dict[str, Any]:
    """
    Quét danh sách các thư mục chứa file audio con (.mp3 / .wav) trong DATA/temp (bao gồm cả TEMP_DIR và TEMP_DIR/tts).
    Trả về danh sách các thư mục hợp lệ kèm số lượng file audio con và thời gian sửa đổi gần nhất.
    """
    import logging
    logger = logging.getLogger("tts_api")
    folders_found = []
    seen_paths = set()

    search_roots = [
        TEMP_DIR,
        TEMP_DIR / "tts"
    ]

    for root_dir in search_roots:
        if not root_dir.exists():
            continue
        try:
            for item in root_dir.iterdir():
                if item.is_dir() and item.resolve() not in seen_paths:
                    seen_paths.add(item.resolve())
                    audio_mp3 = [f for f in item.glob("*.mp3") if f.is_file() and f.stat().st_size > 0]
                    audio_wav = [f for f in item.glob("*.wav") if f.is_file() and f.stat().st_size > 0]
                    detected_format = "wav" if len(audio_wav) > len(audio_mp3) else "mp3"
                    audio_files = audio_wav if detected_format == "wav" else audio_mp3
                    if not audio_files and (audio_mp3 or audio_wav):
                        audio_files = audio_mp3 or audio_wav
                    
                    if audio_files:
                        sample_names = sorted([f.name for f in audio_files[:3]])
                        mtime = item.stat().st_mtime
                        folders_found.append({
                            "folder_name": item.name,
                            "folder_path": str(item.resolve()),
                            "file_count": len(audio_files),
                            "detected_format": detected_format,
                            "sample_files": sample_names,
                            "modified_at": mtime
                        })
        except Exception as e:
            logger.warning(f"Lỗi khi quét thư mục temp {root_dir}: {e}")

    folders_found.sort(key=lambda x: x["modified_at"], reverse=True)

    return {
        "ok": True,
        "folders": folders_found,
        "count": len(folders_found)
    }

def handle_tts_merge_recovery_start(
    folder_path: str,
    srt_content: str,
    output_filename: str = "tts_recovered_audio.mp3",
    audio_format: Optional[str] = None
) -> Dict[str, Any]:
    """
    Tạo job ghép audio riêng từ thư mục audio con có sẵn trong DATA/temp và file SRT tương ứng.
    Sử dụng chính TaskService và TimelineAudioMerger của KAGEVIETSUB để giữ 100% tính nhất quán.
    Hỗ trợ định dạng đầu ra MP3 / WAV.
    """
    import logging
    logger = logging.getLogger("tts_api")

    if not folder_path or not folder_path.strip():
        raise ValueError("Đường dẫn thư mục nguồn (folder_path) không được để trống.")

    folder = Path(folder_path).resolve()
    temp_dir_resolved = TEMP_DIR.resolve()
    
    # Kiểm tra thư mục phải nằm trong DATA/temp
    if not (folder == temp_dir_resolved or temp_dir_resolved in folder.parents):
        raise ValueError(f"Thư mục '{folder_path}' nằm ngoài phạm vi DATA/temp cho phép.")

    if not folder.exists() or not folder.is_dir():
        raise FileNotFoundError(f"Thư mục '{folder_path}' không tồn tại trong DATA/temp.")

    if not srt_content or not srt_content.strip():
        raise ValueError("Nội dung phụ đề SRT không được để trống.")

    # Chuẩn hóa format
    if audio_format:
        audio_format = audio_format.lower().strip().replace(".", "")
        if audio_format not in ["mp3", "wav"]:
            audio_format = "mp3"
    else:
        if output_filename.lower().endswith(".wav"):
            audio_format = "wav"
        else:
            audio_format = "mp3"

    if output_filename:
        out_path = Path(output_filename)
        if audio_format == "wav" and out_path.suffix.lower() != ".wav":
            output_filename = f"{out_path.stem}.wav"
        elif audio_format == "mp3" and out_path.suffix.lower() != ".mp3":
            output_filename = f"{out_path.stem}.mp3"
    else:
        output_filename = f"tts_recovered_audio.{audio_format}"

    try:
        parsed_subtitles = SrtEngine.parse(srt_content)
    except Exception as e:
        raise ValueError(f"SRT không hợp lệ: {e}")

    if not parsed_subtitles:
        raise ValueError("File SRT không có câu phụ đề nào hợp lệ.")

    sub_states = []
    missing_indices = []

    for sub in parsed_subtitles:
        if isinstance(sub, dict):
            idx_raw = sub.get("index", "0")
            try:
                idx = int(idx_raw)
            except Exception:
                idx = 0
            start_str = sub.get("start", "00:00:00,000")
            end_str = sub.get("end", "00:00:00,000")
            start_ms = SrtEngine.time_to_ms(start_str)
            end_ms = SrtEngine.time_to_ms(end_str)
            text = sub.get("text", "")
        else:
            idx = getattr(sub, "index", 0)
            if isinstance(idx, str) and idx.isdigit():
                idx = int(idx)
            start_ms = getattr(sub, "start_ms", 0) or SrtEngine.time_to_ms(getattr(sub, "start", "00:00:00,000"))
            end_ms = getattr(sub, "end_ms", 0) or SrtEngine.time_to_ms(getattr(sub, "end", "00:00:00,000"))
            text = getattr(sub, "text", "")

        possible_names = [
            f"{idx:04d}.{audio_format}",
            f"{idx:03d}.{audio_format}",
            f"{idx}.{audio_format}",
            f"{idx:04d}.mp3",
            f"{idx:03d}.mp3",
            f"{idx}.mp3",
            f"{idx:04d}.wav",
            f"{idx:03d}.wav",
            f"{idx}.wav"
        ]
        found_audio = None
        for p_name in possible_names:
            candidate = folder / p_name
            if candidate.exists() and candidate.is_file() and candidate.stat().st_size > 0:
                found_audio = candidate
                break

        if not found_audio:
            for af in list(folder.glob("*.mp3")) + list(folder.glob("*.wav")):
                num_match = re.match(r"^0*(\d+)", af.stem)
                if num_match and int(num_match.group(1)) == idx and af.is_file() and af.stat().st_size > 0:
                    found_audio = af
                    break

        if not found_audio:
            missing_indices.append(idx)
        else:
            sub_states.append({
                "index": idx,
                "start_ms": start_ms,
                "end_ms": end_ms,
                "text": text,
                "status": "READY_FOR_MERGE",
                "audio_filename": found_audio.name,
                "audio_path": str(found_audio.resolve())
            })

    if missing_indices:
        missing_str = ", ".join(str(i) for i in missing_indices[:10])
        if len(missing_indices) > 10:
            missing_str += f"... (+{len(missing_indices) - 10} câu nữa)"
        raise ValueError(f"Thiếu file audio cho các câu phụ đề index: [{missing_str}] trong thư mục '{folder.name}'.")

    job_id = job_manager.create_job(
        "tts_merge_recovery",
        metadata={
            "total_subtitles": len(sub_states),
            "output_filename": output_filename,
            "audio_format": audio_format,
            "folder_path": str(folder)
        },
        custom_job_id=f"recovery_{int(time.time())}"
    )

    job_manager.update_job(
        job_id,
        status="merging",
        merge_status="merging",
        progress=0,
        message="Đang bắt đầu ghép audio từ thư mục recovery...",
        audio_format=audio_format,
        output_filename=output_filename
    )

    def _run_merge_recovery_bg(jid: str):
        try:
            from TOOL.engines.timeline_merger import TimelineAudioMerger
            from TOOL.services.ffmpeg_service import FFmpegService
            import urllib.parse
            import os

            def _progress_cb(percent: int, msg: str, extra: Optional[Dict[str, Any]] = None):
                update_kwargs = {
                    "status": "merging",
                    "merge_status": "merging",
                    "progress": percent,
                    "merge_progress": percent,
                    "message": msg
                }
                if extra:
                    if "eta_seconds" in extra:
                        update_kwargs["merge_eta"] = extra["eta_seconds"]
                    if "speed" in extra:
                        update_kwargs["merge_speed"] = str(extra["speed"])
                    if "stage" in extra:
                        update_kwargs["merge_stage"] = str(extra["stage"])
                job_manager.update_job(jid, **update_kwargs)

            ok, msg, out_path = TimelineAudioMerger.merge(
                job_id=jid,
                sub_states=sub_states,
                job_dir=folder,
                output_filename=output_filename,
                progress_callback=_progress_cb,
                keep_source=True,
                audio_format=audio_format
            )

            if ok and out_path and out_path.exists() and os.path.getsize(out_path) > 0:
                file_size = os.path.getsize(out_path)
                size_mb = round(file_size / (1024 * 1024), 2)
                media_info = FFmpegService.get_media_info(out_path)
                dur_sec = float(media_info.get("duration", 0.0))
                abs_path_str = str(out_path.resolve())
                saved_loc = f"Download/KAGEVIETSUB/{out_path.name}"
                success_msg = f"✓ Đã ghép audio {audio_format.upper()} khôi phục thành công ({size_mb} MB). File đã lưu vào: {abs_path_str}"

                result_data = {
                    "status": "COMPLETED",
                    "audio_format": audio_format,
                    "output_path": abs_path_str,
                    "output_filename": out_path.name,
                    "output_size": file_size,
                    "duration": dur_sec,
                    "verified": True,
                    "saved_location": saved_loc
                }

                job_manager.update_job(
                    jid,
                    status="merged",
                    merge_status="completed",
                    progress=100,
                    message=success_msg,
                    filename=out_path.name,
                    output_filename=out_path.name,
                    saved_path=abs_path_str,
                    output_path=abs_path_str,
                    saved_location=saved_loc,
                    output_size=file_size,
                    duration=dur_sec,
                    audio_format=audio_format,
                    verified=True,
                    download_url=f"/api/download/{urllib.parse.quote(out_path.name)}",
                    result=result_data
                )
            else:
                job_manager.update_job(
                    jid,
                    status="tts_completed",
                    merge_status="failed",
                    error=msg,
                    message=f"❌ Lỗi ghép audio: {msg}. Dữ liệu giọng đọc đã được lưu đầy đủ (100%), bạn có thể bấm Ghép Audio để thử lại."
                )
        except Exception as ex:
            logger.exception(f"Lỗi ngoài dự kiến trong merge recovery job {jid}")
            job_manager.update_job(
                jid,
                status="tts_completed",
                merge_status="failed",
                error=str(ex),
                message=f"❌ Lỗi hệ thống khi ghép audio: {ex}. Dữ liệu giọng đọc vẫn được giữ nguyên."
            )

    job_manager.run_in_background(job_id, _run_merge_recovery_bg)

    return {
        "ok": True,
        "job_id": job_id,
        "total_items": len(sub_states),
        "message": f"Đã bắt đầu ghép {len(sub_states)} câu audio từ thư mục recovery."
    }

if HAS_FASTAPI and router is not None:
    from fastapi.responses import FileResponse

    @router.get("/merge-recovery/folders")
    @router.get("/merge-recovery/sources")
    def api_tts_merge_recovery_folders():
        try:
            return handle_tts_merge_recovery_folders()
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    @router.post("/merge-recovery/start")
    def api_tts_merge_recovery_start(payload: Dict[str, Any] = Body(...)):
        folder_path = payload.get("folder_path", "") or payload.get("source_id", "")
        srt_content = payload.get("srt_content", "")
        output_filename = payload.get("output_filename", "tts_recovered_audio.mp3")
        audio_format = payload.get("audio_format")
        try:
            return handle_tts_merge_recovery_start(
                folder_path=folder_path,
                srt_content=srt_content,
                output_filename=output_filename,
                audio_format=audio_format
            )
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    @router.get("/merge-recovery/status/{job_id}")
    def api_tts_merge_recovery_status(job_id: str):
        try:
            return handle_tts_get_status(job_id)
        except Exception as e:
            raise HTTPException(status_code=404, detail=str(e))

    @router.post("/merge-recovery/cancel/{job_id}")
    def api_tts_merge_recovery_cancel_by_id(job_id: str):
        try:
            return handle_tts_stop(job_id)
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    @router.post("/merge-recovery/cancel")
    def api_tts_merge_recovery_cancel(payload: Dict[str, Any] = Body(...)):
        job_id = payload.get("job_id", "")
        try:
            return handle_tts_stop(job_id)
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    @router.get("/voices")
    def api_tts_voices():
        return handle_tts_voices()

    @router.post("/parse-srt")
    def api_tts_parse(payload: Dict[str, Any] = Body(...)):
        content = payload.get("srt_content") or payload.get("content") or ""
        try:
            return handle_tts_parse_srt(content)
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    @router.post("/create-job")
    def api_tts_create(req: TTSCreateJobRequest):
        try:
            return handle_tts_create_job(
                srt_content=req.srt_content,
                voice=req.voice,
                speed=req.speed,
                threads=req.threads,
                audio_format=req.audio_format,
                output_filename=req.output_filename
            )
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    @router.post("/retry")
    def api_tts_retry(req: TTSRetryRequest):
        try:
            return handle_tts_retry(req.job_id, req.subtitle_index, req.voice, req.speed)
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    @router.post("/merge")
    def api_tts_merge(req: TTSMergeRequest):
        try:
            return handle_tts_merge(req.job_id, req.output_filename, req.audio_format)
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    @router.post("/pause")
    def api_tts_pause(payload: Dict[str, Any] = Body(...)):
        job_id = payload.get("job_id", "")
        try:
            return handle_tts_pause(job_id)
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    @router.post("/{job_id}/pause")
    def api_tts_pause_by_id(job_id: str):
        try:
            return handle_tts_pause(job_id)
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    @router.post("/resume")
    def api_tts_resume(payload: Dict[str, Any] = Body(...)):
        job_id = payload.get("job_id", "")
        try:
            return handle_tts_resume(job_id)
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    @router.post("/{job_id}/resume")
    def api_tts_resume_by_id(job_id: str):
        try:
            return handle_tts_resume(job_id)
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    @router.post("/{job_id}/merge")
    def api_tts_merge_by_id(job_id: str, payload: Optional[Dict[str, Any]] = Body(None)):
        output_filename = (payload or {}).get("output_filename") if payload else None
        audio_format = (payload or {}).get("audio_format") if payload else None
        try:
            return handle_tts_merge(job_id, output_filename, audio_format)
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    @router.post("/stop")
    def api_tts_stop(payload: Dict[str, Any] = Body(...)):
        job_id = payload.get("job_id", "")
        try:
            return handle_tts_stop(job_id)
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    @router.get("/job/{job_id}")
    def api_tts_job_detail(job_id: str):
        try:
            return handle_tts_get_job(job_id)
        except Exception as e:
            raise HTTPException(status_code=404, detail=str(e))

    @router.get("/status/{job_id}")
    def api_tts_status(job_id: str, include_subtitles: bool = False):
        try:
            return handle_tts_get_status(job_id, include_subtitles=include_subtitles)
        except Exception as e:
            raise HTTPException(status_code=404, detail=str(e))

    @router.get("/preview/{job_id}/{subtitle_index}")
    def api_tts_preview(job_id: str, subtitle_index: int):
        try:
            audio_path = handle_tts_preview(job_id, subtitle_index)
            media_type = "audio/wav" if audio_path.suffix.lower() == ".wav" else "audio/mpeg"
            return FileResponse(
                path=str(audio_path),
                media_type=media_type,
                filename=audio_path.name
            )
        except Exception as e:
            raise HTTPException(status_code=404, detail=str(e))
