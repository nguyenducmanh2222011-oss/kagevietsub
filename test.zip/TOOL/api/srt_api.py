#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
DSUB LOCAL - SRT API ROUTER (TƯƠNG THÍCH PYTHON 3.14 + ANDROID/PC)
==============================================================================
"""

from typing import Optional, List, Dict, Any
from pathlib import Path
from TOOL.engines.srt_engine import SrtEngine
from TOOL.services.file_service import FileService

try:
    from pydantic import BaseModel
except ImportError:
    class BaseModel:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

try:
    from fastapi import APIRouter, HTTPException
    router = APIRouter(prefix="/api/srt", tags=["SRT Operations"])
    HAS_FASTAPI = True
except ImportError:
    router = None
    HAS_FASTAPI = False

class SrtProcessRequest(BaseModel):
    content: str
    rules: Optional[str] = None
    filename: Optional[str] = "edited.srt"

class SrtSplitRequest(BaseModel):
    content: str
    sentences_per_file: int = 10
    base_name: Optional[str] = "subtitle"

def handle_parse_srt(content: str) -> Dict[str, Any]:
    blocks = SrtEngine.parse_srt(content)
    return {"blocks": blocks, "total": len(blocks)}

def handle_remove_trailing_punct(content: str) -> Dict[str, Any]:
    result, count = SrtEngine.remove_trailing_punctuation(content)
    return {"content": result, "changed_lines": count}

def handle_remove_leading_ellipsis(content: str) -> Dict[str, Any]:
    result, count = SrtEngine.remove_leading_ellipsis(content)
    return {"content": result, "changed_lines": count}

def handle_replace_rules(content: str, rules: Optional[str] = None) -> Dict[str, Any]:
    r = rules or "... -> ,\n. -> ,\n! -> ,\nvi -> Vi\nxi -> Xi\n\" -> "
    result, count = SrtEngine.apply_sequential_replace(content, r)
    return {"content": result, "total_replacements": count}

def handle_avoid_overlap(content: str) -> Dict[str, Any]:
    result, count = SrtEngine.avoid_overlap(content)
    return {"content": result, "adjusted_sentences": count}

def handle_purple_sequence(content: str, rules: Optional[str] = None) -> Dict[str, Any]:
    result, stats = SrtEngine.run_purple_sequence(content, rules)
    return {"content": result, "stats": stats}

def handle_fix_repeat_2_3(content: str) -> Dict[str, Any]:
    result, count = SrtEngine.fix_repeated_words_2_3(content)
    return {"content": result, "merged_count": count}

def handle_fix_repeat_4_5(content: str) -> Dict[str, Any]:
    result, count = SrtEngine.fix_repeated_words_4_5(content)
    return {"content": result, "merged_count": count}

def handle_merge_short(content: str) -> Dict[str, Any]:
    res1, c1 = SrtEngine.merge_short_blocks_3_tiers(content)
    res2, c2 = SrtEngine.merge_short_previous(res1)
    return {"content": res2, "total_merged": c1 + c2}

def handle_all_steps(content: str, rules: Optional[str] = None) -> Dict[str, Any]:
    result, stats = SrtEngine.run_all_sequence(content, rules)
    return {"content": result, "stats": stats}

def handle_uppercase(content: str) -> Dict[str, Any]:
    result = SrtEngine.uppercase_srt(content)
    return {"content": result}

def handle_split_srt(content: str, sentences_per_file: int = 10, base_name: str = "subtitle") -> Dict[str, Any]:
    files_info, file_paths = SrtEngine.split_srt(content, sentences_per_file, base_name or "subtitle")
    return {
        "status": "success",
        "files": files_info,
        "total_files": len(files_info),
        "saved_location": "Download/KAGEVIETSUB/",
        "message": f"✓ Đã chia thành {len(files_info)} file SRT và lưu trực tiếp vào Download/KAGEVIETSUB/"
    }

def handle_save_srt(content: str, filename: str = "edited.srt") -> Dict[str, Any]:
    from TOOL.config import KAGE_DOWNLOAD_DIR, get_safe_unique_filepath
    safe_name = Path(filename).name if filename else "edited.srt"
    if not safe_name.lower().endswith(".srt"):
        safe_name = f"{safe_name}.srt"
    save_path = get_safe_unique_filepath(KAGE_DOWNLOAD_DIR, safe_name)
    save_path.write_text(content, encoding="utf-8")
    return {
        "status": "saved",
        "filename": save_path.name,
        "saved_path": str(save_path),
        "saved_location": f"KAGEVIETSUB/{save_path.name}",
        "message": f"Đã lưu vào: KAGEVIETSUB/{save_path.name}"
    }

def handle_get_translate_providers() -> Dict[str, Any]:
    from TOOL.services.ai_translation_service import PROVIDER_MODELS, DEFAULT_PROMPTS
    return {
        "status": "ok",
        "providers": PROVIDER_MODELS,
        "default_prompts": DEFAULT_PROMPTS
    }

def handle_check_api_key(provider: str, api_key: str, model: str) -> Dict[str, Any]:
    from TOOL.services.ai_translation_service import create_provider
    if not api_key or not api_key.strip():
        return {"valid": False, "status": "INVALID_API_KEY", "message": "✕ Vui lòng nhập API key"}
    p_obj = create_provider(provider, api_key, model)
    return p_obj.validate_api()

def handle_start_translation(
    content: str,
    filename: Optional[str] = "subtitle.srt",
    api_pool: Optional[List[Dict[str, Any]]] = None,
    source_lang: str = "zh",
    target_lang: str = "vi",
    batch_size: int = 20,
    user_prompt: Optional[str] = None
) -> Dict[str, Any]:
    from TOOL.services.ai_translation_service import translation_job_manager
    if not content or not content.strip():
        return {"status": "error", "message": "Vui lòng nhập hoặc tải file SRT trước"}
    if not api_pool or len(api_pool) == 0:
        return {"status": "error", "message": "Vui lòng thêm ít nhất 1 API key khả dụng vào API Pool"}

    job_id = translation_job_manager.create_job(
        srt_content=content,
        filename=filename or "subtitle.srt",
        api_pool=api_pool,
        source_lang=source_lang,
        target_lang=target_lang,
        batch_size=batch_size,
        user_prompt=user_prompt
    )
    return {
        "status": "ok",
        "job_id": job_id,
        "message": "Đã khởi tạo công việc dịch phụ đề AI"
    }

def handle_get_translation_status(job_id: str) -> Dict[str, Any]:
    from TOOL.services.ai_translation_service import translation_job_manager
    job_info = translation_job_manager.get_job(job_id)
    if not job_info:
        return {"status": "error", "message": "Không tìm thấy công việc dịch SRT."}
    return job_info

def handle_pause_translation(job_id: str) -> Dict[str, Any]:
    from TOOL.services.ai_translation_service import translation_job_manager
    return translation_job_manager.pause_job(job_id)

def handle_resume_translation(job_id: str) -> Dict[str, Any]:
    from TOOL.services.ai_translation_service import translation_job_manager
    return translation_job_manager.resume_job(job_id)

def handle_stop_translation(job_id: str) -> Dict[str, Any]:
    from TOOL.services.ai_translation_service import translation_job_manager
    return translation_job_manager.stop_job(job_id)

def handle_retry_translation(job_id: str) -> Dict[str, Any]:
    from TOOL.services.ai_translation_service import translation_job_manager
    return translation_job_manager.retry_job(job_id)

if HAS_FASTAPI and router:
    @router.get("/translate/providers")
    def get_providers_endpoint():
        return handle_get_translate_providers()

    @router.post("/translate/check-api")
    def check_api_endpoint(req: Dict[str, Any]):
        return handle_check_api_key(
            req.get("provider", "deepseek"),
            req.get("api_key", ""),
            req.get("model", "deepseek-chat")
        )

    @router.post("/translate/start")
    def start_translation_endpoint(req: Dict[str, Any]):
        return handle_start_translation(
            content=req.get("content", ""),
            filename=req.get("filename", "subtitle.srt"),
            api_pool=req.get("api_pool", []),
            source_lang=req.get("source_lang", "zh"),
            target_lang=req.get("target_lang", "vi"),
            batch_size=int(req.get("batch_size", 20)),
            user_prompt=req.get("user_prompt")
        )

    @router.get("/translate/status/{job_id}")
    def translation_status_endpoint(job_id: str):
        return handle_get_translation_status(job_id)

    @router.post("/translate/pause/{job_id}")
    def translation_pause_endpoint(job_id: str):
        return handle_pause_translation(job_id)

    @router.post("/translate/resume/{job_id}")
    def translation_resume_endpoint(job_id: str):
        return handle_resume_translation(job_id)

    @router.post("/translate/stop/{job_id}")
    def translation_stop_endpoint(job_id: str):
        return handle_stop_translation(job_id)

    @router.post("/translate/retry/{job_id}")
    def translation_retry_endpoint(job_id: str):
        return handle_retry_translation(job_id)

    @router.post("/parse")
    def parse_srt(req: SrtProcessRequest):
        return handle_parse_srt(req.content)

    @router.post("/remove-trailing-punctuation")
    def remove_trailing_punct(req: SrtProcessRequest):
        return handle_remove_trailing_punct(req.content)

    @router.post("/remove-leading-ellipsis")
    def remove_leading_dots(req: SrtProcessRequest):
        return handle_remove_leading_ellipsis(req.content)

    @router.post("/replace")
    def replace_rules(req: SrtProcessRequest):
        return handle_replace_rules(req.content, req.rules)

    @router.post("/avoid-overlap")
    def avoid_overlap_endpoint(req: SrtProcessRequest):
        return handle_avoid_overlap(req.content)

    @router.post("/purple-sequence")
    def purple_sequence_endpoint(req: SrtProcessRequest):
        return handle_purple_sequence(req.content, req.rules)

    @router.post("/fix-repeat-2-3")
    def fix_repeat_2_3_endpoint(req: SrtProcessRequest):
        return handle_fix_repeat_2_3(req.content)

    @router.post("/fix-repeat-4-5")
    def fix_repeat_4_5_endpoint(req: SrtProcessRequest):
        return handle_fix_repeat_4_5(req.content)

    @router.post("/merge-short")
    def merge_short_endpoint(req: SrtProcessRequest):
        return handle_merge_short(req.content)

    @router.post("/all-steps")
    def all_steps_endpoint(req: SrtProcessRequest):
        return handle_all_steps(req.content, req.rules)

    @router.post("/uppercase")
    def uppercase_endpoint(req: SrtProcessRequest):
        return handle_uppercase(req.content)

    @router.post("/split")
    def split_endpoint(req: SrtSplitRequest):
        try:
            return handle_split_srt(req.content, req.sentences_per_file, req.base_name or "subtitle")
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))
