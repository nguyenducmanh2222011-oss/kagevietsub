"""
DSUB LOCAL - Core Tool Package
"""
__version__ = "1.0.0"
