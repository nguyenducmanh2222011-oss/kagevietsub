/**
 * ==============================================================================
 * KAGEVIETSUB - LOCALHOST FRONTEND CONTROLLER (VANILLA JS • 100% PREVIEW PARITY)
 * ==============================================================================
 */

document.addEventListener("DOMContentLoaded", () => {
    const ICONS = {
        check: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`,
        copy: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>`,
        loader: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="animate-spin"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>`,
        checkCircle: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/></svg>`,
        alertCircle: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/></svg>`,
        download: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>`,
        trash: `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/></svg>`,
        chevronDown: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m6 9 6 6 6-6"/></svg>`,
        chevronUp: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m18 15-6-6-6 6"/></svg>`
    };

    const mobileDrawer = document.getElementById("mobile-drawer");
    const mobileDrawerOverlay = document.getElementById("mobile-drawer-overlay");

    function openMobileDrawer() {
        if (mobileDrawer && mobileDrawerOverlay) {
            mobileDrawer.classList.add("open");
            mobileDrawerOverlay.classList.add("open");
            document.body.classList.add("drawer-open");
        }
    }

    function closeMobileDrawer() {
        if (mobileDrawer && mobileDrawerOverlay) {
            mobileDrawer.classList.remove("open");
            mobileDrawerOverlay.classList.remove("open");
            document.body.classList.remove("drawer-open");
        }
    }

    document.getElementById("btn-open-drawer")?.addEventListener("click", openMobileDrawer);
    document.getElementById("btn-close-drawer")?.addEventListener("click", closeMobileDrawer);
    mobileDrawerOverlay?.addEventListener("click", closeMobileDrawer);

    function switchMainTab(mainTabId, subTabId) {
        document.querySelectorAll(".tab-pane").forEach(pane => {
            pane.classList.toggle("active", pane.id === `main-tab-${mainTabId}`);
        });

        document.querySelectorAll("[data-main-tab]").forEach(btn => {
            btn.classList.toggle("active", btn.getAttribute("data-main-tab") === mainTabId);
        });

        document.querySelectorAll("[data-drawer-tab]").forEach(btn => {
            btn.classList.toggle("active", btn.getAttribute("data-drawer-tab") === mainTabId);
        });

        closeMobileDrawer();

        if (subTabId) {
            switchSubTab(subTabId);
        } else if (mainTabId === "srt-translate") {
            if (typeof initSrtTranslateController === "function") {
                initSrtTranslateController();
            }
        } else if (mainTabId === "downloader") {
            if (typeof fetchDownloaderStatus === "function") {
                fetchDownloaderStatus();
            }
            if (typeof checkDownloaderReadiness === "function") {
                checkDownloaderReadiness();
            }
        } else if (mainTabId === "audio") {
            if (typeof fetchWhisperModels === "function") {
                fetchWhisperModels(true);
            }
        } else if (mainTabId === "tts") {
            const curJob = ttsCurrentJobId || sessionStorage.getItem("kage_current_tts_job_id");
            if (curJob && typeof loadTTSJob === "function") {
                loadTTSJob(curJob);
            }
        } else if (mainTabId === "logs") {
            if (typeof fetchRealtimeLogs === "function") {
                fetchRealtimeLogs(true);
            }
        }

        window.scrollTo({ top: 0, behavior: "smooth" });
    }

    function switchSubTab(subTabId) {
        if (subTabId === "srt-translate") {
            switchMainTab("srt-translate");
            return;
        }

        let prefix = "srt";
        if (subTabId.startsWith("audio")) prefix = "audio";
        else if (subTabId.startsWith("video")) prefix = "video";
        else if (subTabId.startsWith("tts")) prefix = "tts";

        const section = document.getElementById(`main-tab-${prefix}`);
        if (!section) return;

        section.querySelectorAll(".sub-pane").forEach(p => {
            p.classList.toggle("active", p.id === `sub-pane-${subTabId}`);
        });

        section.querySelectorAll("[data-sub-tab]").forEach(btn => {
            btn.classList.toggle("active", btn.getAttribute("data-sub-tab") === subTabId);
        });

        if (subTabId === "audio-whisper") {
            if (typeof fetchWhisperModels === "function") {
                fetchWhisperModels(true);
            }
        } else if (subTabId === "tts-merge") {
            if (typeof fetchTTSRecoveryFolders === "function") {
                fetchTTSRecoveryFolders();
            }
        }
    }

    document.querySelectorAll("[data-main-tab]").forEach(btn => {
        btn.addEventListener("click", () => {
            const tab = btn.getAttribute("data-main-tab");
            switchMainTab(tab);
        });
    });

    document.querySelectorAll("[data-drawer-tab]").forEach(btn => {
        btn.addEventListener("click", () => {
            const tab = btn.getAttribute("data-drawer-tab");
            switchMainTab(tab);
        });
    });

    document.querySelectorAll("[data-sub-tab]").forEach(btn => {
        btn.addEventListener("click", () => {
            const subTab = btn.getAttribute("data-sub-tab");
            switchSubTab(subTab);
        });
    });

    document.getElementById("brand-logo")?.addEventListener("click", () => switchMainTab("home"));

    document.getElementById("btn-header-settings")?.addEventListener("click", () => {
        switchMainTab("settings");
    });

    document.getElementById("btn-home-check-health")?.addEventListener("click", () => {
        switchMainTab("settings");
        checkHealth();
    });

    document.querySelectorAll(".action-card[data-action]").forEach(card => {
        card.addEventListener("click", () => {
            const action = card.getAttribute("data-action");
            switch (action) {
                case "downloader":
                    switchMainTab("downloader");
                    break;
                case "srt-translate":
                    switchMainTab("srt-translate");
                    break;
                case "srt":
                    switchMainTab("srt", "srt-editor");
                    break;
                case "tts":
                    switchMainTab("tts", "tts-create");
                    break;
                case "tts-merge":
                    switchMainTab("tts", "tts-merge");
                    break;
                case "whisper":
                    switchMainTab("audio", "audio-whisper");
                    break;
                case "audio-merge":
                    switchMainTab("audio", "audio-merge");
                    break;
                case "video-cut":
                    switchMainTab("video", "video-cut");
                    break;
                case "video-merge":
                    switchMainTab("video", "video-merge");
                    break;
                case "video-compress":
                    switchMainTab("video", "video-compress");
                    break;
                case "srt-split":
                    switchMainTab("srt", "srt-split");
                    break;
                case "srt-upper":
                    switchMainTab("srt", "srt-upper");
                    break;
            }
        });
    });


    function renderJobCardHTML(job) {
        const status = (job.status || "processing").toLowerCase();
        const progress = job.progress !== undefined ? job.progress : 0;
        const isCompleted = status === "completed" || status === "merged" || status === "tts_completed" || status === "completed_with_errors";
        const isFailed = status === "failed" || status === "error" || status === "cancelled";
        const isProcessing = !isCompleted && !isFailed;

        let iconBoxClass = "processing";
        let iconSvg = ICONS.loader;
        let percentClass = "processing";
        let barClass = "processing";

        if (isCompleted) {
            iconBoxClass = "completed";
            iconSvg = ICONS.checkCircle;
            percentClass = "completed";
            barClass = "completed";
        } else if (isFailed) {
            iconBoxClass = "failed";
            iconSvg = ICONS.alertCircle;
            percentClass = "failed";
            barClass = "failed";
        }

        const typeLabels = {
            "tts": "Tạo Giọng Đọc TTS",
            "tts_create": "Tạo Giọng Đọc TTS",
            "tts_generation": "Tạo Giọng Đọc TTS",
            "tts_merge": "Ghép Audio TTS",
            "tts_merge_recovery": "Ghép Audio Riêng",
            "downloader": "Tải Video & Âm Thanh",
            "whisper_transcribe": "Trích xuất Whisper AI",
            "audio_merge": "Ghép File Audio",
            "video_cut": "Cắt Đoạn Video",
            "video_merge": "Ghép Video & Caption",
            "video_compress": "Nén Video"
        };
        const title = typeLabels[job.type] || (job.job_id && job.job_id.startsWith("tts_") ? "Tạo Giọng Đọc TTS" : (job.type || "Tác vụ hệ thống"));
        const filename = job.filename ? `File: ${job.filename}` : "";
        const shortId = job.job_id ? job.job_id.substring(0, 8) : "";

        return `
            <div class="job-progress-card" id="job-card-${job.job_id}" style="cursor:pointer;" onclick="window.handleGlobalJobCardClick && window.handleGlobalJobCardClick('${job.job_id}', '${job.type || ''}')" title="Nhấp để mở tác vụ này">
                <div class="job-card-header">
                    <div class="job-card-left">
                        <div class="job-icon-box ${iconBoxClass}">${iconSvg}</div>
                        <div>
                            <div class="job-title">${title}</div>
                            <div class="job-meta">ID: ${shortId} ${filename ? `• ${filename}` : ""}</div>
                        </div>
                    </div>
                    <span class="job-percent ${percentClass}">${progress}%</span>
                </div>

                <div class="progress-track">
                    <div class="progress-bar ${barClass}" style="width: ${progress}%"></div>
                </div>

                <div style="font-size: 11px; color: ${isFailed ? "#fb7185" : "#94a3b8"}; display: flex; align-items: center; justify-content: space-between;">
                    <span>${job.message || (isCompleted ? "Xử lý thành công!" : "Đang xử lý...")}</span>
                    <span style="text-transform: capitalize; font-weight: 600;">${status}</span>
                </div>

                ${isCompleted ? `
                    <div class="job-card-footer" style="display:flex; flex-wrap:wrap; align-items:center; justify-content:space-between; gap:8px;">
                        <div style="display:flex; align-items:center; gap:6px; font-size:12px; color:#34d399; font-weight:600;">
                            ${ICONS.checkCircle}
                            <span>✓ Đã xử lý xong</span>
                        </div>
                        <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
                            ${(job.download_url || job.filename || job.saved_location || job.output_path || job.job_id) ? `
                                <button type="button" class="btn btn-emerald" style="min-height:28px; padding:2px 10px; font-size:11px;" onclick="event.stopPropagation(); window.triggerSafeFileDownload('${(job.download_url || job.filename || job.saved_location || job.output_path || job.job_id).replace(/'/g, "\\'")}', '${(job.filename || (job.saved_location ? job.saved_location.replace(/^.*[\\/]/, '') : 'result')).replace(/'/g, "\\'")}')">
                                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>
                                    <span>Tải file</span>
                                </button>
                            ` : ""}
                            <div style="display:flex; align-items:center; gap:6px; padding:4px 10px; background:#0e1322; border:1px solid rgba(16,185,129,0.25); border-radius:10px; font-size:11px; font-family:var(--font-mono); color:#cbd5e1;">
                                <span style="color:#64748b;">📁 Đã lưu vào:</span>
                                <strong style="color:#6ee7b7;">${job.saved_location || (job.filename ? `KAGEVIETSUB/${job.filename}` : "KAGEVIETSUB/")}</strong>
                            </div>
                        </div>
                    </div>
                ` : ""}

                ${isFailed && job.error ? `
                    <div style="padding: 8px 12px; background: rgba(244,63,94,0.1); border: 1px solid rgba(244,63,94,0.25); border-radius: 8px; font-size: 11px; color: #fb7185;">
                        <b>Lỗi:</b> ${job.error}
                    </div>
                ` : ""}
            </div>
        `;
    }

    async function pollJob(jobId, targetContainer, onComplete) {
        if (!targetContainer) return;
        targetContainer.style.display = "block";
        targetContainer.innerHTML = renderJobCardHTML({ job_id: jobId, status: "processing", progress: 5, message: "Khởi tạo tác vụ..." });

        const interval = setInterval(async () => {
            try {
                const res = await fetch(`/api/jobs/${jobId}`);
                if (!res.ok) throw new Error("Không thể kết nối tác vụ");
                const job = await res.json();

                targetContainer.innerHTML = renderJobCardHTML(job);
                updateGlobalActiveJobs();

                if (job.status === "completed") {
                    clearInterval(interval);
                    if (onComplete) onComplete(job);
                } else if (job.status === "failed") {
                    clearInterval(interval);
                }
            } catch (err) {
                targetContainer.innerHTML = `
                    <div class="status-toast error">
                        <span>Lỗi kiểm tra tiến trình: ${err.message}</span>
                    </div>
                `;
                clearInterval(interval);
            }
        }, 1000);
    }

    let lastJobsHash = "";

    async function updateGlobalActiveJobs() {
        try {
            const res = await fetch("/api/jobs");
            if (!res.ok) return;
            const data = await res.json();
            const jobs = data.jobs || [];

            jobs.sort((a, b) => (b.created_at || 0) - (a.created_at || 0));

            const currentHash = JSON.stringify(jobs.slice(0, 10).map(j => ({ id: j.job_id || j.id, s: j.status, p: j.progress, m: j.message })));
            if (currentHash === lastJobsHash) return;
            lastJobsHash = currentHash;

            const runningJobs = jobs.filter(j => 
                j.status === "processing" || 
                j.status === "queued" || 
                j.status === "generating" || 
                j.status === "creating" ||
                j.status === "merging" || 
                j.status === "downloading" ||
                j.status === "translating" ||
                j.status === "paused"
            );

            const statusArea = document.getElementById("header-status-area");
            if (statusArea) {
                if (runningJobs.length > 0) {
                    statusArea.innerHTML = `
                        <div class="header-job-pill" onclick="document.querySelector('[data-main-tab=home]').click();">
                            ${ICONS.loader}
                            <span>${runningJobs.length} Tác vụ đang chạy</span>
                        </div>
                    `;
                } else {
                    statusArea.innerHTML = `
                        <div class="header-status-pill">
                            <span class="pulse-dot"></span>
                            <span>127.0.0.1:8000 Online</span>
                        </div>
                    `;
                }
            }

            const homeSection = document.getElementById("home-jobs-section");
            const homeList = document.getElementById("home-jobs-list");
            if (homeSection && homeList) {
                if (jobs.length > 0) {
                    homeSection.style.display = "block";
                    homeList.innerHTML = jobs.slice(0, 6).map(j => renderJobCardHTML(j)).join("");
                } else {
                    homeSection.style.display = "none";
                }
            }

            const settingsList = document.getElementById("settings-jobs-list");
            if (settingsList) {
                if (jobs.length > 0) {
                    settingsList.innerHTML = jobs.slice(0, 10).map(j => renderJobCardHTML(j)).join("");
                } else {
                    settingsList.innerHTML = `<div style="font-size:12px; color:#64748b;">Chưa có tác vụ nào được thực thi.</div>`;
                }
            }
        } catch (e) {
        }
    }

    document.getElementById("btn-home-refresh-jobs")?.addEventListener("click", () => {
        lastJobsHash = "";
        updateGlobalActiveJobs();
    });
    setInterval(updateGlobalActiveJobs, 5000);
    updateGlobalActiveJobs();


    const srtEditor = document.getElementById("srt-editor-textarea");
    const srtLineCount = document.getElementById("srt-line-count");
    const srtCharCount = document.getElementById("srt-char-count");
    const srtFileInput = document.getElementById("srt-file-input");
    const srtFilenameInput = document.getElementById("srt-filename-input");
    const srtStatusBanner = document.getElementById("srt-status-banner");
    const srtLogConsole = document.getElementById("srt-log-console");
    const btnRulesToggle = document.getElementById("btn-toggle-rules");
    const srtRulesAccordion = document.getElementById("srt-rules-accordion");
    const rulesChevron = document.getElementById("rules-chevron");
    const srtRulesInput = document.getElementById("srt-rules-input");

    const SAMPLE_SRT = `1\n00:00:01,000 --> 00:00:03,500\n...Chào mừng bạn đến với KAGEVIETSUB.\n\n2\n00:00:03,500 --> 00:00:05,200\nỨng dụng chỉnh sửa phụ đề tự động trên điện thoại!\n\n3\n00:00:05,200 --> 00:00:07,000\nvi sao lai khong thu ngay?`;
    const DEFAULT_RULES = `... -> ,\n. -> ,\n! -> ,\nvi -> Vi\nxi -> Xi\n" -> `;

    if (srtEditor && !srtEditor.value.trim()) {
        srtEditor.value = SAMPLE_SRT;
    }
    if (srtRulesInput && !srtRulesInput.value.trim()) {
        srtRulesInput.value = DEFAULT_RULES;
    }

    function updateSrtStats() {
        if (!srtEditor) return;
        const val = srtEditor.value;
        const lines = val ? val.split("\n").length : 0;
        const chars = val.length;
        if (srtLineCount) srtLineCount.textContent = lines;
        if (srtCharCount) srtCharCount.textContent = chars;
    }
    srtEditor?.addEventListener("input", updateSrtStats);
    updateSrtStats();

    const btnCopy = document.getElementById("btn-copy-srt");
    btnCopy?.addEventListener("click", () => {
        if (!srtEditor || !srtEditor.value) return;
        navigator.clipboard.writeText(srtEditor.value).then(() => {
            btnCopy.innerHTML = `${ICONS.check} <span>Đã sao chép!</span>`;
            setTimeout(() => {
                btnCopy.innerHTML = `${ICONS.copy} <span>Sao chép</span>`;
            }, 2000);
            logSrt("Đã sao chép nội dung SRT vào bộ nhớ tạm.", "success");
        });
    });

    srtFileInput?.addEventListener("change", (e) => {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (evt) => {
            srtEditor.value = evt.target.result;
            updateSrtStats();
            if (srtFilenameInput) {
                srtFilenameInput.value = file.name;
            }
            logSrt(`Đã mở file: ${file.name} (${file.size} bytes)`, "success");
            setSrtStatus(`Đã tải file ${file.name}`, "success");
        };
        reader.readAsText(file, "utf-8");
    });

    document.getElementById("btn-download-srt")?.addEventListener("click", async () => {
        const content = srtEditor.value;
        if (!content.trim()) {
            setSrtStatus("Nội dung SRT trống!", "warn");
            return;
        }
        let fname = srtFilenameInput.value.trim() || "edited_subtitles.srt";
        if (!fname.toLowerCase().endsWith(".srt")) fname += ".srt";

        setSrtStatus("Đang lưu & tải file...", "info");
        try {
            const res = await fetch("/api/srt/save", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ content, filename: fname })
            });
            const data = await res.json();

            // Trigger browser download directly
            const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
            const blobUrl = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = blobUrl;
            a.download = fname;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(blobUrl);

            if (data.status === "saved") {
                const loc = data.saved_location || `KAGEVIETSUB/${fname}`;
                logSrt(`Đã lưu file thành công vào: ${loc}`, "success");
                setSrtStatus(`✓ Đã lưu & tải file ${fname} thành công!`, "success");
                const resContainer = document.getElementById("srt-save-result-container");
                if (resContainer) {
                    resContainer.style.display = "block";
                    resContainer.innerHTML = `
                        <div style="display:flex; flex-wrap:wrap; align-items:center; justify-content:space-between; gap:8px; padding:10px 14px; background:#0d1017; border:1px solid rgba(16,185,129,0.3); border-radius:12px; margin-top:8px;">
                            <div style="display:flex; align-items:center; gap:6px; font-size:12px; color:#34d399; font-weight:600;">
                                ${ICONS.checkCircle}
                                <span>✓ Đã lưu & tải file thành công</span>
                            </div>
                            <div style="display:flex; align-items:center; gap:8px;">
                                <div style="display:flex; align-items:center; gap:6px; padding:4px 10px; background:#0e1322; border:1px solid rgba(16,185,129,0.25); border-radius:10px; font-size:11px; font-family:var(--font-mono); color:#cbd5e1;">
                                    <span style="color:#64748b;">📁 Đã lưu vào:</span>
                                    <strong style="color:#6ee7b7;">${loc}</strong>
                                </div>
                                <button type="button" class="btn btn-emerald" style="min-height:28px; padding:2px 10px; font-size:11px;" onclick="window.triggerSafeFileDownload('${fname}', '${fname}')">
                                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>
                                    <span>Tải lại file</span>
                                </button>
                            </div>
                        </div>
                    `;
                }
            } else {
                setSrtStatus(data.detail || "Không thể lưu file trên máy chủ, nhưng đã tải file về trình duyệt.", "warn");
            }
        } catch (err) {
            setSrtStatus(`Lỗi lưu file: ${err.message}`, "error");
        }
    });

    btnRulesToggle?.addEventListener("click", () => {
        if (!srtRulesAccordion) return;
        const isHidden = srtRulesAccordion.style.display === "none";
        srtRulesAccordion.style.display = isHidden ? "block" : "none";
        if (rulesChevron) {
            rulesChevron.innerHTML = isHidden ? `<path d="m18 15-6-6-6 6"/>` : `<path d="m6 9 6 6 6-6"/>`;
        }
    });

    function setSrtStatus(msg, type = "info") {
        if (!srtStatusBanner) return;
        srtStatusBanner.className = `status-toast ${type}`;
        srtStatusBanner.innerHTML = `<span>${msg}</span>`;
    }

    function logSrt(text, type = "info") {
        if (!srtLogConsole) return;
        const time = new Date().toLocaleTimeString("vi-VN", { hour12: false });
        const line = document.createElement("div");
        line.className = `log-line ${type}`;
        line.textContent = `[${time}] ${text}`;
        srtLogConsole.appendChild(line);
        srtLogConsole.scrollTop = srtLogConsole.scrollHeight;
    }

    async function handleSrtAction(endpoint, extraPayload = {}, successMsgFn) {
        const content = srtEditor.value;
        if (!content.trim()) {
            setSrtStatus("Vui lòng dán hoặc mở file SRT trước khi xử lý!", "warn");
            return;
        }

        setSrtStatus("Đang xử lý phụ đề...", "info");
        try {
            const res = await fetch(endpoint, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ content, ...extraPayload })
            });
            if (!res.ok) {
                const errData = await res.json().catch(() => ({}));
                throw new Error(errData.detail || `Lỗi máy chủ (${res.status})`);
            }
            const data = await res.json();
            if (data.content) {
                srtEditor.value = data.content;
                updateSrtStats();
            }
            const msg = successMsgFn ? successMsgFn(data) : "Xử lý thành công!";
            setSrtStatus(msg, "success");
            logSrt(msg, "success");
        } catch (err) {
            setSrtStatus(`Lỗi: ${err.message}`, "error");
            logSrt(`Lỗi: ${err.message}`, "error");
        }
    }

    document.getElementById("btn-purple-seq")?.addEventListener("click", () => {
        const rules = srtRulesInput.value;
        handleSrtAction(
            "/api/srt/purple-sequence",
            { rules },
            d => `Hoàn thành 3 Bước (Tím)! (Xóa ...: ${d.stats?.leading_ellipsis_removed || 0}, Dấu cuối: ${d.stats?.trailing_punctuation_removed || 0}, Thay thế: ${d.stats?.replacements_applied || 0})`
        );
    });

    document.getElementById("btn-all-seq")?.addEventListener("click", () => {
        const rules = srtRulesInput.value;
        handleSrtAction(
            "/api/srt/all-steps",
            { rules },
            d => `Hoàn thành tuần tự tất cả 7 bước chuẩn hoá SRT!`
        );
    });

    document.getElementById("btn-remove-punct")?.addEventListener("click", () => {
        handleSrtAction(
            "/api/srt/remove-trailing-punctuation",
            {},
            d => `Đã xóa dấu câu cuối cho ${d.changed_lines || 0} dòng (giữ lại dấu ?).`
        );
    });

    document.getElementById("btn-remove-ellipsis")?.addEventListener("click", () => {
        handleSrtAction(
            "/api/srt/remove-leading-ellipsis",
            {},
            d => `Đã xóa '...' ở đầu câu cho ${d.changed_lines || 0} dòng.`
        );
    });

    document.getElementById("btn-avoid-overlap")?.addEventListener("click", () => {
        handleSrtAction(
            "/api/srt/avoid-overlap",
            {},
            d => `Đã điều chỉnh mốc thời gian tránh đè chữ cho ${d.adjusted_sentences || 0} câu.`
        );
    });

    document.getElementById("btn-merge-short")?.addEventListener("click", () => {
        handleSrtAction(
            "/api/srt/merge-short",
            {},
            d => `Đã gộp ${d.total_merged || 0} câu phụ đề ngắn (<0.4s).`
        );
    });

    document.getElementById("btn-fix-repeat-23")?.addEventListener("click", () => {
        handleSrtAction(
            "/api/srt/fix-repeat-2-3",
            {},
            d => `Đã sửa và gộp lặp 2-3 từ (${d.merged_count || 0} vị trí).`
        );
    });

    document.getElementById("btn-fix-repeat-45")?.addEventListener("click", () => {
        handleSrtAction(
            "/api/srt/fix-repeat-4-5",
            {},
            d => `Đã sửa và gộp lặp 4-5 từ (${d.merged_count || 0} vị trí).`
        );
    });

    document.getElementById("btn-apply-replace")?.addEventListener("click", () => {
        const rules = srtRulesInput.value;
        handleSrtAction(
            "/api/srt/replace",
            { rules },
            d => `Đã áp dụng quy tắc thay thế cho ${d.total_replacements || 0} từ/dấu.`
        );
    });


    let srtSplitFileObj = null;
    const srtSplitDrop = document.getElementById("srt-split-dropzone");
    const srtSplitInput = document.getElementById("srt-split-file");
    const srtSplitBadge = document.getElementById("srt-split-selected-file");

    srtSplitDrop?.addEventListener("click", () => srtSplitInput?.click());
    srtSplitInput?.addEventListener("change", (e) => {
        srtSplitFileObj = e.target.files[0];
        if (srtSplitFileObj && srtSplitBadge) {
            srtSplitBadge.style.display = "inline-flex";
            srtSplitBadge.textContent = `File đã chọn: ${srtSplitFileObj.name} (${(srtSplitFileObj.size / 1024).toFixed(1)} KB)`;
        }
    });

    document.getElementById("btn-run-srt-split")?.addEventListener("click", async () => {
        let content = srtEditor ? srtEditor.value : "";
        if (srtSplitFileObj) {
            content = await srtSplitFileObj.text();
        }
        if (!content.trim()) {
            alert("Vui lòng chọn file SRT hoặc nhập nội dung vào trình sửa!");
            return;
        }

        const count = parseInt(document.getElementById("srt-split-count")?.value || 10);
        const prefix = document.getElementById("srt-split-prefix")?.value || "split_srt";
        const resBox = document.getElementById("srt-split-result");
        if (resBox) {
            resBox.style.display = "block";
            resBox.innerHTML = `<div class="status-toast info">${ICONS.loader} <span>Đang chia nhỏ phụ đề...</span></div>`;
        }

        try {
            const res = await fetch("/api/srt/split", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ content, sentences_per_file: count, base_name: prefix })
            });
            const data = await res.json();
            if (resBox) {
                if (data.status === "success" && data.files) {
                    const filesListHtml = data.files.map(f => `
                        <div style="display:flex; justify-content:space-between; align-items:center; background:rgba(255,255,255,0.04); padding:6px 12px; border-radius:6px; margin-bottom:6px; font-size:12px; border:1px solid rgba(255,255,255,0.06);">
                            <span style="color:#67e8f9; font-family:monospace;">${f.filename}</span>
                            <span style="color:#94a3b8;">${f.sentences} câu</span>
                        </div>
                    `).join("");

                    resBox.innerHTML = `
                        <div class="status-toast success" style="margin-bottom:12px;">
                            <span>✓ Đã tách thành công ${data.files.length} file và lưu vào <strong>Download/KAGEVIETSUB/</strong></span>
                        </div>
                        <div style="max-height:180px; overflow-y:auto; padding-right:4px;">
                            ${filesListHtml}
                        </div>
                    `;
                } else {
                    resBox.innerHTML = `<div class="status-toast error"><span>Lỗi: ${data.detail || "Không thể tách file"}</span></div>`;
                }
            }
        } catch (err) {
            if (resBox) resBox.innerHTML = `<div class="status-toast error"><span>Lỗi kết nối: ${err.message}</span></div>`;
        }
    });


    let srtUpperFileObj = null;
    const srtUpperDrop = document.getElementById("srt-upper-dropzone");
    const srtUpperInput = document.getElementById("srt-upper-file");
    const srtUpperBadge = document.getElementById("srt-upper-selected-file");

    srtUpperDrop?.addEventListener("click", () => srtUpperInput?.click());
    srtUpperInput?.addEventListener("change", (e) => {
        srtUpperFileObj = e.target.files[0];
        if (srtUpperFileObj && srtUpperBadge) {
            srtUpperBadge.style.display = "inline-flex";
            srtUpperBadge.textContent = `File đã chọn: ${srtUpperFileObj.name}`;
        }
    });

    document.getElementById("btn-run-srt-upper")?.addEventListener("click", async () => {
        let content = srtEditor ? srtEditor.value : "";
        let fname = "uppercase.srt";
        if (srtUpperFileObj) {
            content = await srtUpperFileObj.text();
            fname = srtUpperFileObj.name.replace(/\.srt$/i, "") + "_UPPER.srt";
        }
        if (!content.trim()) {
            alert("Vui lòng chọn file hoặc nhập phụ đề!");
            return;
        }

        const resBox = document.getElementById("srt-upper-result");
        if (resBox) {
            resBox.style.display = "block";
            resBox.innerHTML = `<div class="status-toast info">${ICONS.loader} <span>Đang chuyển sang chữ HOA...</span></div>`;
        }

        try {
            const res = await fetch("/api/srt/uppercase", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ content })
            });
            const data = await res.json();
            if (resBox && data.content) {
                const blob = new Blob([data.content], { type: "text/plain;charset=utf-8" });
                const url = URL.createObjectURL(blob);
                resBox.innerHTML = `
                    <div class="status-toast success">
                        <span>Chuyển đổi hoàn tất thành chữ in HOA!</span>
                    </div>
                    <div style="margin-top:10px;">
                        <a href="${url}" download="${fname}" class="btn btn-emerald" style="width:100%;">
                            ${ICONS.download}
                            <span>Tải file '${fname}'</span>
                        </a>
                    </div>
                `;
            }
        } catch (err) {
            if (resBox) resBox.innerHTML = `<div class="status-toast error"><span>Lỗi: ${err.message}</span></div>`;
        }
    });


    let whisperFileObj = null;
    const whisperDrop = document.getElementById("whisper-dropzone");
    const whisperInput = document.getElementById("whisper-file");
    const whisperBadge = document.getElementById("whisper-selected");

    whisperDrop?.addEventListener("click", () => whisperInput?.click());
    whisperInput?.addEventListener("change", (e) => {
        whisperFileObj = e.target.files[0];
        if (whisperFileObj && whisperBadge) {
            whisperBadge.style.display = "inline-flex";
            whisperBadge.textContent = `File: ${whisperFileObj.name} (${(whisperFileObj.size / 1024 / 1024).toFixed(1)} MB)`;
        }
    });

    let currentWhisperModelsData = null;
    const modelDownloadStates = {};

    const WHISPER_SUPPORTED_SPECS = [
        { id: "large-v3-turbo", name: "Large v3 Turbo (Chuẩn Studio)", size_mb: 1600, min_ram: "4GB RAM", speed: "Nhanh & Tối ưu", rec: true, desc: "Khuyên dùng cho PC / Laptop (Tối ưu tốc độ & chuẩn phòng thu)" },
        { id: "large-v3", name: "Large v3 (Chính xác tối đa)", size_mb: 3100, min_ram: "8GB RAM", speed: "Chậm", rec: false, desc: "Chính xác cao nhất cho thoại khó nhưng yêu cầu cấu hình mạnh" },
        { id: "medium", name: "Medium (Chính xác cao)", size_mb: 1500, min_ram: "4GB RAM", speed: "Trung bình", rec: false, desc: "Cân bằng tốc độ và độ chính xác, thích hợp máy trung bình" },
        { id: "small", name: "Small (Cân bằng & Nhanh)", size_mb: 461, min_ram: "2GB RAM", speed: "Nhanh", rec: true, desc: "Rất nhẹ, tối ưu cho Android (Termux) & máy tính phổ thông" },
        { id: "base", name: "Base (Nhẹ)", size_mb: 145, min_ram: "1GB RAM", speed: "Rất nhanh", rec: false, desc: "Siêu nhẹ, tải nhanh, phù hợp thiết bị cấu hình cơ bản" },
        { id: "tiny", name: "Tiny (Siêu nhẹ)", size_mb: 75, min_ram: "512MB RAM", speed: "Cực nhanh", rec: false, desc: "Nhẹ nhất nhưng độ chính xác tiếng Trung ở mức cơ bản" }
    ];

    function requireWhisper() {
        if (!currentWhisperModelsData || !currentWhisperModelsData.available || !currentWhisperModelsData.models || currentWhisperModelsData.models.length === 0) {
            openWhisperModal("prompt");
            return false;
        }
        return true;
    }

    function openWhisperModal(view = "prompt") {
        const modal = document.getElementById("whisper-model-modal");
        const viewPrompt = document.getElementById("whisper-modal-view-prompt");
        const viewDownloader = document.getElementById("whisper-modal-view-downloader");
        const titleEl = document.getElementById("whisper-modal-title");
        const readyCloseBtn = document.getElementById("btn-modal-ready-close");
        const promptCloseBtn = document.getElementById("btn-modal-prompt-close");

        if (!modal) return;
        modal.style.display = "flex";

        if (view === "prompt") {
            if (viewPrompt) viewPrompt.style.display = "block";
            if (viewDownloader) viewDownloader.style.display = "none";
            if (titleEl) titleEl.textContent = "Whisper AI chưa sẵn sàng";
            if (promptCloseBtn) {
                promptCloseBtn.style.display = "block";
            }
        } else {
            if (viewPrompt) viewPrompt.style.display = "none";
            if (viewDownloader) viewDownloader.style.display = "block";
            if (titleEl) titleEl.textContent = "Quản Lý & Tải Whisper AI Models";
            if (readyCloseBtn) {
                readyCloseBtn.style.display = "inline-flex";
            }
            renderWhisperSpecsList();
        }
    }

    function closeWhisperModal() {
        const modal = document.getElementById("whisper-model-modal");
        if (modal) modal.style.display = "none";
    }

    function renderWhisperModelStatus(data) {
        const statusContainer = document.getElementById("whisper-model-status-container");
        const modelSelect = document.getElementById("whisper-model");
        const validNote = document.getElementById("whisper-model-valid-note");
        const modelCountEl = document.getElementById("whisper-model-count");
        const btnRun = document.getElementById("btn-run-whisper");
        const btnRunText = document.getElementById("btn-run-whisper-text");

        const dirEl = document.getElementById("whisper-modal-dir");
        const promptPathEl = document.getElementById("whisper-modal-prompt-path") || document.getElementById("modal-prompt-models-dir");
        const manualDirEl = document.getElementById("whisper-manual-dir-code");
        const dirPath = data.models_dir || "DATA/models/";
        if (dirEl) dirEl.textContent = dirPath;
        if (promptPathEl) promptPathEl.textContent = dirPath;
        if (manualDirEl) manualDirEl.textContent = dirPath;

        if (modelCountEl) modelCountEl.textContent = data.total_valid_count || 0;

        if (data.available && data.models && data.models.length > 0) {
            const currentSelected = modelSelect?.value;
            let activeModel = data.models.find(m => m.id === currentSelected);
            if (!activeModel) {
                const defId = data.default_model || data.models[0].id;
                activeModel = data.models.find(m => m.id === defId) || data.models[0];
            }

            if (statusContainer) {
                statusContainer.innerHTML = `
                    <div class="status-badge-ready">
                        <div style="display:flex; align-items:center; gap:8px;">
                            <span class="pulse-dot" style="background:#10b981;"></span>
                            <strong style="color:#ffffff;">Whisper AI:</strong>
                            <span style="color:#34d399; font-weight:700;">● Sẵn sàng</span>
                            <span style="color:#64748b;">•</span>
                            <span style="color:#cbd5e1;">Model: <strong style="color:#c084fc;">${escapeHtml(activeModel.name)}</strong></span>
                        </div>
                        <div style="font-size:11px; color:#34d399; display:inline-flex; align-items:center; gap:4px; font-weight:600;">
                            <span>✓ Đã tải (${escapeHtml(activeModel.path)})</span>
                        </div>
                    </div>
                `;
            }

            if (modelSelect) {
                modelSelect.innerHTML = "";
                data.models.forEach(m => {
                    const opt = document.createElement("option");
                    opt.value = m.id;
                    opt.textContent = `✓ ${m.name} (~${m.size_mb} MB • ${m.min_ram} • ${m.speed})`;
                    if (m.id === activeModel.id) opt.selected = true;
                    modelSelect.appendChild(opt);
                });
            }

            if (validNote) {
                validNote.innerHTML = `<span style="color:#34d399; font-weight:600;">✓ Có ${data.total_valid_count} model hợp lệ</span>`;
            }

            if (btnRun) {
                btnRun.disabled = false;
                btnRun.style.opacity = "1";
                btnRun.style.cursor = "pointer";
            }
            if (btnRunText) {
                btnRunText.textContent = "🎙 Bắt Đầu Nhận Diện Phụ Đề Whisper";
            }

            const modal = document.getElementById("whisper-model-modal");
            const viewPrompt = document.getElementById("whisper-modal-view-prompt");
            if (modal && modal.style.display === "flex" && viewPrompt?.style.display === "block") {
                closeWhisperModal();
            }
        } else {
            if (statusContainer) {
                statusContainer.innerHTML = `
                    <div class="status-badge-locked">
                        <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:10px;">
                            <div>
                                <div style="font-weight:700; color:#fbbf24; font-size:13px; display:flex; align-items:center; gap:6px;">
                                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#fbbf24" stroke-width="2"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                                    <span>Whisper AI chưa sẵn sàng</span>
                                </div>
                                <div style="color:#cbd5e1; font-size:12px; margin-top:4px; line-height:1.4;">
                                    Chưa tìm thấy Whisper AI Model trong <code style="padding:2px 6px; background:#0b0e17; border-radius:4px; color:#c084fc; font-family:monospace; font-size:11px; border:1px solid rgba(168,85,247,0.2);">${escapeHtml(dirPath)}</code>. Chức năng Whisper đang bị tạm khóa.
                                </div>
                            </div>
                            <button class="btn btn-purple-gradient" id="btn-status-go-download" type="button" style="padding:6px 14px; font-size:12px;">
                                Đi đến tải Model
                            </button>
                        </div>
                    </div>
                `;
                document.getElementById("btn-status-go-download")?.addEventListener("click", () => {
                    openWhisperModal("downloader");
                });
            }

            if (modelSelect) {
                modelSelect.innerHTML = `<option value="" disabled selected>⚠ Chưa có model nào trong DATA/models/</option>`;
            }

            if (validNote) {
                validNote.innerHTML = `<span style="color:#fbbf24; font-weight:600;">⚠ Chưa có model hợp lệ</span>`;
            }

            if (btnRun) {
                btnRun.disabled = false;
                btnRun.style.opacity = "0.6";
                btnRun.style.cursor = "pointer";
            }
            if (btnRunText) {
                btnRunText.textContent = "⚠ Whisper AI chưa sẵn sàng (Bấm để mở popup)";
            }
        }
    }

    function renderWhisperSpecsList() {
        const listEl = document.getElementById("whisper-specs-list");
        const countTag = document.getElementById("modal-downloaded-count-badge") || document.getElementById("whisper-valid-count-tag");
        const unsupportedSec = document.getElementById("whisper-unsupported-section");

        if (!listEl) return;
        const validModels = currentWhisperModelsData?.models || [];
        const specs = (currentWhisperModelsData?.supported_specs && currentWhisperModelsData.supported_specs.length > 0)
            ? currentWhisperModelsData.supported_specs
            : WHISPER_SUPPORTED_SPECS;

        if (countTag) {
            countTag.textContent = `${validModels.length} / ${specs.length} model đã tải`;
        }

        listEl.innerHTML = "";
        specs.forEach(spec => {
            const id = spec.id;
            const state = modelDownloadStates[id] || { status: 'NOT_DOWNLOADED', progress: 0 };
            const card = document.createElement("div");

            let cardClass = "model-spec-card";
            if (state.status === "DOWNLOADED") cardClass += " downloaded";
            else if (state.status === "DOWNLOADING") cardClass += " downloading";
            else if (state.status === "ERROR") cardClass += " error";
            card.className = cardClass;
            card.id = `model-card-${id}`;

            let actionHtml = "";
            let progressHtml = "";
            let errorHtml = "";

            if (state.status === "DOWNLOADED") {
                actionHtml = `
                    <div class="spec-badge-ready" id="badge-ready-${id}">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#34d399" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
                        <span>✓ ĐÃ TẢI</span>
                    </div>
                `;
            } else if (state.status === "DOWNLOADING") {
                actionHtml = `
                    <button class="spec-btn-downloading" id="btn-dl-${id}" disabled>
                        <svg class="spin-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 2a10 10 0 0 1 10 10"/></svg>
                        <span>Đang tải...</span>
                    </button>
                `;
                progressHtml = `
                    <div class="model-spec-progress-box" id="prog-box-${id}">
                        <div class="model-spec-progress-header">
                            <span style="color:#c084fc; font-weight:600; font-size:11px;" id="prog-msg-${id}">${escapeHtml(state.message || 'Đang tải model...')}</span>
                            <span style="color:#ffffff; font-weight:700; font-size:11px;" id="prog-pct-${id}">${state.progress || 0}%</span>
                        </div>
                        <div class="model-spec-progress-bar-bg">
                            <div class="model-spec-progress-bar-fill" id="prog-bar-${id}" style="width: ${state.progress || 0}%;"></div>
                        </div>
                    </div>
                `;
            } else if (state.status === "ERROR") {
                actionHtml = `
                    <button class="spec-btn-retry" id="btn-dl-${id}" data-dl-model="${id}">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg>
                        <span>Thử lại (~${spec.size_mb} MB)</span>
                    </button>
                `;
                errorHtml = `
                    <div class="model-spec-error-box" id="err-box-${id}">
                        <div style="font-weight:700; color:#ef4444; display:flex; align-items:center; gap:4px;">
                            <span>⚠ TẢI THẤT BẠI:</span>
                        </div>
                        <div style="color:#fca5a5; margin-top:2px; font-size:11px; line-height:1.4;">
                            ${escapeHtml(state.error || 'Không thể tải model. Vui lòng thử lại.')}
                        </div>
                    </div>
                `;
            } else {
                actionHtml = `
                    <button class="spec-btn-download" id="btn-dl-${id}" data-dl-model="${id}">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>
                        <span>Tải (~${spec.size_mb} MB)</span>
                    </button>
                `;
            }

            card.innerHTML = `
                <div style="flex:1;">
                    <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
                        <span style="font-weight:700; font-size:13px; color:#ffffff;">${escapeHtml(spec.name || id)}</span>
                        ${spec.rec || spec.recommended ? `<span class="spec-badge-rec">KHUYÊN DÙNG</span>` : ""}
                    </div>
                    <div class="spec-meta">
                        <span>Dung lượng: <strong style="color:#cbd5e1;">~${spec.size_mb} MB</strong></span>
                        <span>•</span>
                        <span>Yêu cầu: <strong style="color:#cbd5e1;">${escapeHtml(spec.min_ram || '')}</strong></span>
                        <span>•</span>
                        <span>Tốc độ: <strong style="color:#cbd5e1;">${escapeHtml(spec.speed || '')}</strong></span>
                    </div>
                    <div style="font-size:11px; color:#94a3b8; margin-top:3px; line-height:1.4;">
                        ${escapeHtml(spec.description || spec.desc || "")}
                    </div>
                    ${progressHtml}
                    ${errorHtml}
                </div>
                <div style="display:flex; align-items:center;">
                    ${actionHtml}
                </div>
            `;
            listEl.appendChild(card);
        });

        listEl.querySelectorAll("[data-dl-model]").forEach(btn => {
            btn.addEventListener("click", () => {
                const modelId = btn.getAttribute("data-dl-model");
                startDownloadWhisperModel(modelId);
            });
        });

        if (unsupportedSec) {
            const unsupportedModels = currentWhisperModelsData?.unsupported_models || [];
            if (unsupportedModels.length > 0) {
                unsupportedSec.style.display = "block";
                unsupportedSec.innerHTML = `
                    <div style="font-weight:700; color:#94a3b8; font-size:12px; margin-bottom:4px;">
                        ℹ Thư mục lạ không thuộc Whisper (bị bỏ qua):
                    </div>
                    <div style="display:flex; flex-direction:column; gap:4px; font-size:11px; color:#94a3b8;">
                        ${unsupportedModels.map(u => `<div>• <strong>${escapeHtml(u.folder_name)}</strong>: ${escapeHtml(u.reason)}</div>`).join("")}
                    </div>
                `;
            } else {
                unsupportedSec.style.display = "none";
            }
        }
    }

    async function fetchWhisperModels(triggerPopupIfMissing = false, isScan = false) {
        try {
            const endpoint = isScan ? "/api/whisper/models/scan" : "/api/whisper/models";
            const res = await fetch(endpoint);
            const data = await res.json();
            currentWhisperModelsData = data;

            const validIds = new Set((data.models || []).map(m => m.id));
            const activeDl = data.active_downloads || {};
            const invalidMap = {};
            (data.invalid_models || []).forEach(inv => {
                if (inv.id) invalidMap[inv.id] = inv;
                if (inv.folder_name) invalidMap[inv.folder_name] = inv;
            });

            const specs = (data.supported_specs && data.supported_specs.length > 0)
                ? data.supported_specs
                : WHISPER_SUPPORTED_SPECS;

            specs.forEach(spec => {
                const id = spec.id;
                const curState = modelDownloadStates[id];

                if (validIds.has(id)) {
                    if (curState?.pollInterval) clearInterval(curState.pollInterval);
                    modelDownloadStates[id] = {
                        status: 'DOWNLOADED',
                        progress: 100,
                        message: 'Model đã sẵn sàng sử dụng',
                        error: null,
                        jobId: null,
                        pollInterval: null
                    };
                } else if (activeDl[id]) {
                    const act = activeDl[id];
                    const existingJobId = curState?.jobId;
                    if (!curState || curState.status !== 'DOWNLOADING' || existingJobId !== act.job_id) {
                        modelDownloadStates[id] = {
                            status: 'DOWNLOADING',
                            progress: act.progress || 0,
                            message: act.message || 'Đang tải model...',
                            error: null,
                            jobId: act.job_id,
                            pollInterval: null
                        };
                        pollModelDownloadJob(id, act.job_id);
                    }
                } else if (curState?.status === 'DOWNLOADING') {
                } else if (curState?.status === 'ERROR') {
                } else if (invalidMap[id]) {
                    modelDownloadStates[id] = {
                        status: 'ERROR',
                        progress: 0,
                        message: null,
                        error: invalidMap[id].reason || 'Model bị lỗi hoặc thiếu file',
                        jobId: null,
                        pollInterval: null
                    };
                } else {
                    modelDownloadStates[id] = {
                        status: 'NOT_DOWNLOADED',
                        progress: 0,
                        message: null,
                        error: null,
                        jobId: null,
                        pollInterval: null
                    };
                }
            });

            renderWhisperModelStatus(data);

            if (!data.available) {
                if (triggerPopupIfMissing) {
                    openWhisperModal("prompt");
                }
            } else {
                const readyCloseBtn = document.getElementById("btn-modal-ready-close");
                if (readyCloseBtn) readyCloseBtn.style.display = "inline-flex";
            }

            const viewDownloader = document.getElementById("whisper-modal-view-downloader");
            if (viewDownloader && viewDownloader.style.display === "block") {
                renderWhisperSpecsList();
            }
        } catch (err) {
            console.error("Lỗi quét Whisper models:", err);
        }
    }

    async function startDownloadWhisperModel(modelId) {
        if (!modelId) return;

        if (modelDownloadStates[modelId]?.status === 'DOWNLOADING') {
            return;
        }

        modelDownloadStates[modelId] = {
            status: 'DOWNLOADING',
            progress: 2,
            message: `Bắt đầu kết nối tải model ${modelId}...`,
            error: null,
            jobId: null,
            pollInterval: null
        };

        renderWhisperSpecsList();

        try {
            const res = await fetch("/api/whisper/models/download", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ model_id: modelId })
            });
            const resData = await res.json();
            if (!res.ok) {
                throw new Error(resData.detail || "Không thể khởi tạo tiến trình tải.");
            }

            const jobId = resData.job_id;
            if (modelDownloadStates[modelId]) {
                modelDownloadStates[modelId].jobId = jobId;
                pollModelDownloadJob(modelId, jobId);
            }
        } catch (err) {
            if (modelDownloadStates[modelId]) {
                modelDownloadStates[modelId] = {
                    status: 'ERROR',
                    error: err.message || 'Lỗi khi gửi yêu cầu tải model',
                    progress: 0,
                    jobId: null,
                    pollInterval: null
                };
            }
            renderWhisperSpecsList();
        }
    }

    function pollModelDownloadJob(modelId, jobId) {
        if (!modelId || !jobId) return;

        if (modelDownloadStates[modelId]?.pollInterval) {
            clearInterval(modelDownloadStates[modelId].pollInterval);
        }

        const interval = setInterval(async () => {
            try {
                const jRes = await fetch(`/api/jobs/${jobId}`);
                if (!jRes.ok) return;
                const job = await jRes.json();

                if (job.status === "completed") {
                    clearInterval(interval);
                    if (modelDownloadStates[modelId]) {
                        modelDownloadStates[modelId] = {
                            status: 'DOWNLOADED',
                            progress: 100,
                            message: `✓ Đã tải xong model ${modelId}!`,
                            error: null,
                            jobId: null,
                            pollInterval: null
                        };
                    }
                    await fetchWhisperModels(false, true);
                    renderWhisperSpecsList();
                } else if (job.status === "failed") {
                    clearInterval(interval);
                    if (modelDownloadStates[modelId]) {
                        modelDownloadStates[modelId] = {
                            status: 'ERROR',
                            error: job.error || job.message || "Tải model thất bại.",
                            progress: job.progress || 0,
                            jobId: null,
                            pollInterval: null
                        };
                    }
                    renderWhisperSpecsList();
                } else {
                    const pct = job.progress || 0;
                    const msg = job.message || `Đang tải model ${modelId}...`;
                    if (modelDownloadStates[modelId]) {
                        modelDownloadStates[modelId].progress = pct;
                        modelDownloadStates[modelId].message = msg;
                    }

                    const msgEl = document.getElementById(`prog-msg-${modelId}`);
                    const pctEl = document.getElementById(`prog-pct-${modelId}`);
                    const barEl = document.getElementById(`prog-bar-${modelId}`);
                    if (msgEl) msgEl.textContent = msg;
                    if (pctEl) pctEl.textContent = `${pct}%`;
                    if (barEl) barEl.style.width = `${pct}%`;
                }
            } catch (e) {
                console.error(`Lỗi thăm dò tiến trình download model ${modelId}:`, e);
            }
        }, 800);

        if (modelDownloadStates[modelId]) {
            modelDownloadStates[modelId].pollInterval = interval;
        }
    }

    document.getElementById("btn-open-whisper-modal")?.addEventListener("click", () => {
        openWhisperModal("downloader");
    });
    document.getElementById("btn-modal-close")?.addEventListener("click", closeWhisperModal);
    document.getElementById("btn-modal-prompt-close")?.addEventListener("click", closeWhisperModal);
    document.getElementById("btn-modal-ready-close")?.addEventListener("click", closeWhisperModal);
    document.getElementById("btn-modal-go-download")?.addEventListener("click", () => {
        openWhisperModal("downloader");
    });
    document.getElementById("btn-modal-switch-download")?.addEventListener("click", () => {
        openWhisperModal("downloader");
    });
    document.getElementById("btn-modal-back-to-prompt")?.addEventListener("click", () => {
        openWhisperModal("prompt");
    });
    document.getElementById("btn-modal-refresh-models")?.addEventListener("click", () => {
        fetchWhisperModels(false, true);
    });
    document.getElementById("btn-modal-refresh")?.addEventListener("click", () => {
        fetchWhisperModels(false, true);
    });

    document.getElementById("whisper-model-modal")?.addEventListener("click", (e) => {
        if (e.target.id === "whisper-model-modal") {
            closeWhisperModal();
        }
    });

    document.getElementById("btn-modal-close")?.addEventListener("click", closeWhisperModal);

    document.getElementById("btn-run-whisper")?.addEventListener("click", async () => {
        if (!requireWhisper()) {
            return;
        }

        if (!whisperFileObj) {
            alert("Vui lòng chọn file âm thanh hoặc video!");
            return;
        }

        const selectedModel = document.getElementById("whisper-model").value;
        if (!selectedModel) {
            alert("Vui lòng chọn một model Whisper hợp lệ đã tải!");
            return;
        }

        const formData = new FormData();
        formData.append("file", whisperFileObj);
        formData.append("model_size", selectedModel);
        formData.append("max_words", document.getElementById("whisper-max-words").value);
        formData.append("max_duration", document.getElementById("whisper-max-dur").value);

        const progContainer = document.getElementById("whisper-progress");
        const resBox = document.getElementById("whisper-result-box");
        if (resBox) resBox.style.display = "none";

        try {
            const res = await fetch("/api/whisper/transcribe", { method: "POST", body: formData });
            const data = await res.json();
            if (!res.ok) {
                throw new Error(data.detail || "Không thể khởi tạo phiên nhận diện giọng nói.");
            }
            if (data.job_id) {
                pollJob(data.job_id, progContainer, (job) => {
                    if (resBox) resBox.style.display = "block";
                    const result = job.result || {};
                    const stats = result.stats || {};
                    const statsEl = document.getElementById("whisper-stats");
                    if (statsEl) {
                        statsEl.innerHTML = `
                            <span>${result.segments_count || 0} câu • Lọc Watermark: ${stats.watermark_filtered || 0} • Lọc Anh: ${stats.english_filtered || 0} • Lọc Thở/Cười: ${(stats.sigh_removed || 0) + (stats.laugh_removed || 0)}</span>
                        `;
                    }
                    const textEl = document.getElementById("whisper-preview-text");
                    if (textEl) textEl.textContent = result.content || "";

                    const btnDl = document.getElementById("btn-download-whisper-srt");
                    if (btnDl) {
                        btnDl.onclick = () => { triggerSafeFileDownload(job.download_url || job.filename || "whisper_subtitles.srt", job.filename || "whisper_subtitles.srt"); };
                    }
                    const btnSend = document.getElementById("btn-send-whisper-to-editor");
                    if (btnSend) {
                        btnSend.onclick = () => {
                            if (srtEditor) {
                                srtEditor.value = result.content || "";
                                updateSrtStats();
                            }
                            switchMainTab("srt", "srt-editor");
                            logSrt("Đã nạp phụ đề từ Whisper vào Trình Sửa Phụ Đề.", "success");
                        };
                    }
                });
            }
        } catch (err) {
            alert(`Lỗi khởi tạo: ${err.message}`);
        }
    });

    fetchWhisperModels(false);


    let audioFileList = [];
    const audioDrop = document.getElementById("audio-dropzone");
    const audioInput = document.getElementById("audio-files-input");
    const audioListEl = document.getElementById("audio-file-list");
    const audioCountEl = document.getElementById("audio-count");

    audioDrop?.addEventListener("click", () => audioInput.click());
    audioInput?.addEventListener("change", (e) => {
        for (const file of e.target.files) {
            audioFileList.push(file);
        }
        renderAudioList();
    });

    document.getElementById("btn-clear-audio-list")?.addEventListener("click", () => {
        audioFileList = [];
        renderAudioList();
    });

    function renderAudioList() {
        if (!audioListEl) return;
        audioListEl.innerHTML = "";
        if (audioCountEl) audioCountEl.textContent = audioFileList.length;
        audioFileList.forEach((f, idx) => {
            const item = document.createElement("div");
            item.className = "file-list-item";
            item.innerHTML = `
                <div style="display:flex; align-items:center; gap:8px;">
                    <span style="color:#64748b; font-family:var(--font-mono);">${idx + 1}.</span>
                    <span>${f.name}</span>
                </div>
                <div style="display:flex; align-items:center; gap:8px;">
                    <span style="color:#64748b; font-size:11px;">${(f.size / 1024 / 1024).toFixed(2)} MB</span>
                    <button class="file-list-remove" data-idx="${idx}">${ICONS.trash}</button>
                </div>
            `;
            item.querySelector(".file-list-remove")?.addEventListener("click", () => {
                audioFileList.splice(idx, 1);
                renderAudioList();
            });
            audioListEl.appendChild(item);
        });
    }

    document.getElementById("btn-run-audio-merge")?.addEventListener("click", async () => {
        if (audioFileList.length < 2) {
            alert("Vui lòng chọn ít nhất 2 file âm thanh!");
            return;
        }

        const formData = new FormData();
        audioFileList.forEach(f => formData.append("files", f));
        formData.append("output_filename", document.getElementById("audio-output-name").value || "combined.mp3");
        formData.append("sort_alphabetical", document.getElementById("audio-sort-alpha").checked);

        const prog = document.getElementById("audio-job-progress");
        try {
            const res = await fetch("/api/audio/merge", { method: "POST", body: formData });
            const data = await res.json();
            if (data.job_id) {
                pollJob(data.job_id, prog);
            }
        } catch (err) {
            alert(`Lỗi: ${err.message}`);
        }
    });


    let videoCutFileObj = null;
    const videoCutDrop = document.getElementById("video-cut-dropzone");
    const videoCutInput = document.getElementById("video-cut-file");
    const videoCutBadge = document.getElementById("video-cut-selected");

    videoCutDrop?.addEventListener("click", () => videoCutInput.click());
    videoCutInput?.addEventListener("change", (e) => {
        videoCutFileObj = e.target.files[0];
        if (videoCutFileObj) {
            videoCutBadge.style.display = "inline-flex";
            videoCutBadge.textContent = `Video: ${videoCutFileObj.name} (${(videoCutFileObj.size / 1024 / 1024).toFixed(1)} MB)`;
        }
    });

    document.getElementById("btn-run-video-cut")?.addEventListener("click", async () => {
        if (!videoCutFileObj) {
            alert("Vui lòng chọn file video!");
            return;
        }

        const formData = new FormData();
        formData.append("file", videoCutFileObj);
        formData.append("segment_minutes", document.getElementById("video-cut-minutes").value || 5);
        formData.append("mode", document.getElementById("video-cut-mode").value || "copy");

        const prog = document.getElementById("video-cut-progress");
        try {
            const res = await fetch("/api/video/cut", { method: "POST", body: formData });
            const data = await res.json();
            if (data.job_id) {
                pollJob(data.job_id, prog);
            }
        } catch (err) {
            alert(`Lỗi: ${err.message}`);
        }
    });


    let videoMergeFiles = [];
    const videoMergeDrop = document.getElementById("video-merge-dropzone");
    const videoMergeInput = document.getElementById("video-merge-files");
    const videoMergeList = document.getElementById("video-merge-list");
    const captionCheckbox = document.getElementById("video-enable-caption");
    const captionBox = document.getElementById("caption-settings");

    videoMergeDrop?.addEventListener("click", () => videoMergeInput.click());
    videoMergeInput?.addEventListener("change", (e) => {
        for (const f of e.target.files) videoMergeFiles.push(f);
        renderVideoMergeList();
    });

    captionCheckbox?.addEventListener("change", (e) => {
        if (captionBox) captionBox.style.display = e.target.checked ? "block" : "none";
    });

    function renderVideoMergeList() {
        if (!videoMergeList) return;
        videoMergeList.innerHTML = "";
        videoMergeFiles.forEach((f, idx) => {
            const item = document.createElement("div");
            item.className = "file-list-item";
            item.innerHTML = `
                <div style="display:flex; align-items:center; gap:8px;">
                    <span style="color:#64748b; font-family:var(--font-mono);">${idx + 1}.</span>
                    <span>${f.name}</span>
                </div>
                <div style="display:flex; align-items:center; gap:8px;">
                    <span style="color:#64748b; font-size:11px;">${(f.size / 1024 / 1024).toFixed(1)} MB</span>
                    <button class="file-list-remove" data-idx="${idx}">${ICONS.trash}</button>
                </div>
            `;
            item.querySelector(".file-list-remove")?.addEventListener("click", () => {
                videoMergeFiles.splice(idx, 1);
                renderVideoMergeList();
            });
            videoMergeList.appendChild(item);
        });
    }

    document.getElementById("btn-run-video-merge")?.addEventListener("click", async () => {
        if (videoMergeFiles.length < 2) {
            alert("Vui lòng chọn ít nhất 2 video để ghép!");
            return;
        }

        const formData = new FormData();
        videoMergeFiles.forEach(f => formData.append("files", f));
        formData.append("output_filename", document.getElementById("video-merge-output").value || "merged_video.mp4");
        formData.append("mode", document.getElementById("video-merge-mode").value);

        if (captionCheckbox?.checked) {
            formData.append("caption", document.getElementById("video-caption-text").value);
            formData.append("font_size", document.getElementById("video-caption-size").value);
            formData.append("font_color", document.getElementById("video-caption-color").value);
            formData.append("caption_position", document.getElementById("video-caption-pos").value);
        }

        const prog = document.getElementById("video-merge-progress");
        try {
            const res = await fetch("/api/video/merge", { method: "POST", body: formData });
            const data = await res.json();
            if (data.job_id) {
                pollJob(data.job_id, prog);
            }
        } catch (err) {
            alert(`Lỗi: ${err.message}`);
        }
    });


    let videoCompressFile = null;
    const videoCompDrop = document.getElementById("video-compress-dropzone");
    const videoCompInput = document.getElementById("video-compress-file");
    const videoCompBadge = document.getElementById("video-compress-selected");

    videoCompDrop?.addEventListener("click", () => videoCompInput.click());
    videoCompInput?.addEventListener("change", (e) => {
        videoCompressFile = e.target.files[0];
        if (videoCompressFile) {
            videoCompBadge.style.display = "inline-flex";
            videoCompBadge.textContent = `Video: ${videoCompressFile.name} (${(videoCompressFile.size / 1024 / 1024).toFixed(1)} MB)`;
        }
    });

    document.getElementById("btn-run-video-compress")?.addEventListener("click", async () => {
        if (!videoCompressFile) {
            alert("Vui lòng chọn video cần nén!");
            return;
        }

        const formData = new FormData();
        formData.append("file", videoCompressFile);
        formData.append("crf", document.getElementById("video-compress-crf").value);
        formData.append("preset", document.getElementById("video-compress-preset").value);
        formData.append("codec", document.getElementById("video-compress-codec").value);

        const prog = document.getElementById("video-compress-progress");
        try {
            const res = await fetch("/api/video/compress", { method: "POST", body: formData });
            const data = await res.json();
            if (data.job_id) {
                pollJob(data.job_id, prog);
            }
        } catch (err) {
            alert(`Lỗi: ${err.message}`);
        }
    });


    async function fetchAppVersion() {
        const verEl = document.getElementById("lbl-app-version");
        try {
            const res = await fetch("/api/version");
            if (!res.ok) return;
            const data = await res.json();
            if (data.version && verEl) {
                verEl.textContent = `v${data.version.replace(/^v/, "")}`;
            }
        } catch (e) {
        }
    }

    async function checkHealth() {
        const sysEl = document.getElementById("health-sys-info");
        const ffmpegEl = document.getElementById("health-ffmpeg-info");
        const dataEl = document.getElementById("health-data-info");

        if (sysEl) sysEl.innerHTML = `<div style="color:#94a3b8; font-size:11px;">Đang kiểm tra...</div>`;

        try {
            const res = await fetch("/api/health");
            if (!res.ok) throw new Error("Máy chủ phản hồi lỗi");
            const data = await res.json();

            if (sysEl) {
                sysEl.innerHTML = `
                    <div class="status-tile-row"><span class="status-tile-label">Hệ điều hành:</span> <span>${data.system?.platform || "Linux"}</span></div>
                    <div class="status-tile-row"><span class="status-tile-label">Python:</span> <span>${data.system?.python_version || "3.10"}</span></div>
                    <div class="status-tile-row"><span class="status-tile-label">Trạng thái:</span> <span style="color:#34d399; font-weight:600;">Sẵn sàng</span></div>
                `;
            }

            if (ffmpegEl) {
                ffmpegEl.innerHTML = `
                    <div class="status-tile-row"><span class="status-tile-label">FFmpeg:</span> <span style="color:#34d399;">${data.components?.ffmpeg?.status}</span></div>
                    <div class="status-tile-row"><span class="status-tile-label">FFprobe:</span> <span style="color:#34d399;">${data.components?.ffprobe?.status}</span></div>
                    <div class="status-tile-row"><span class="status-tile-label">GPU NVENC:</span> <span>${data.components?.nvenc_gpu?.status}</span></div>
                `;
            }

            if (dataEl) {
                dataEl.innerHTML = `
                    <div class="status-tile-row"><span class="status-tile-label">Thư mục DATA:</span> <span style="font-family:var(--font-mono); font-size:11px;">${data.directories?.DATA}</span></div>
                    <div class="status-tile-row"><span class="status-tile-label">File tạm (temp):</span> <span>${data.directories?.temp_files} files</span></div>
                    <div class="status-tile-row"><span class="status-tile-label">File xuất (out):</span> <span>${data.directories?.output_files} files</span></div>
                `;
            }
        } catch (err) {
            if (sysEl) sysEl.innerHTML = `<div style="color:#fb7185; font-size:11px;">Không kết nối được server Python: ${err.message}</div>`;
        }
    }

    document.getElementById("btn-refresh-health")?.addEventListener("click", checkHealth);

    document.getElementById("btn-cleanup-temp")?.addEventListener("click", async () => {
        try {
            const res = await fetch("/api/cleanup", { method: "POST" });
            const data = await res.json();
            alert(`Đã dọn dẹp ${data.cleaned_files || 0} file tạm thời (giải phóng ${data.freed_mb || 0} MB bộ nhớ).`);
            checkHealth();
        } catch (err) {
            alert(`Lỗi dọn dẹp: ${err.message}`);
        }
    });

    let ttsCurrentJobId = null;
    let ttsCurrentJobStatus = "idle";
    let ttsPollTimeoutId = null;
    let isTTSPolling = false;
    let ttsSrtContent = "";
    let ttsSubtitlesList = [];
    let ttsFilterMode = "all"; // 'all' | 'error'
    let currentPreviewAudio = null;
    let isMergingActive = false;
    let ttsMergePopupShown = false;
    let ttsLastRevision = 0;
    let ttsLastRevisionJobId = null;

    function getSubStatusBadgeHTML(sub) {
        if (!sub) return `<span class="tts-badge tts-badge-pending">⏳ Chờ tạo</span>`;
        if (sub.status === "DONE" || sub.status === "READY_FOR_MERGE" || sub.status === "COMPLETED") {
            const durVal = typeof sub.duration === "number" ? sub.duration : parseFloat(sub.duration || 0);
            const durStr = (durVal && !isNaN(durVal) && durVal > 0) ? `${durVal.toFixed(1)}s` : "";
            return `<span class="tts-badge tts-badge-done">${ICONS.check} Đã tạo ${durStr}</span>`;
        } else if (sub.status === "TTS_PROCESSING") {
            return `<span class="tts-badge tts-badge-generating"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="animate-spin-slow"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg> Đang tạo TTS 1.0x...</span>`;
        } else if (sub.status === "TTS_COMPLETED") {
            return `<span class="tts-badge tts-badge-generating"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="animate-spin-slow"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg> Chờ tăng tốc...</span>`;
        } else if (sub.status === "SPEED_PROCESSING") {
            return `<span class="tts-badge tts-badge-generating"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="animate-spin-slow"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg> Đang tăng tốc...</span>`;
        } else if (sub.status === "RETRYING") {
            const passNum = sub.retry_count || 1;
            return `<span class="tts-badge" style="background:rgba(234,179,8,0.2); color:#facc15; border:1px solid rgba(234,179,8,0.4);"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="animate-spin-slow"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg> 🔄 Đang retry (${passNum}/3)...</span>`;
        } else if (sub.status === "GENERATING") {
            return `<span class="tts-badge tts-badge-generating"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="animate-spin-slow"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg> Đang tạo...</span>`;
        } else if (sub.status === "FAILED") {
            return `<span class="tts-badge" style="background:rgba(245,158,11,0.2); color:#fbbf24; border:1px solid rgba(245,158,11,0.4);" title="${escapeHtml(sub.error || 'Đang chờ retry sau khi hết lượt chính')}">⚠️ Chờ retry</span>`;
        } else if (sub.status === "FINAL_FAILED" || sub.status === "ERROR") {
            return `<span class="tts-badge tts-badge-error" title="${escapeHtml(sub.error || 'Lỗi không thể tạo audio sau 3 lần thử')}">❌ Lỗi (đã thử 3/3)</span>`;
        } else {
            return `<span class="tts-badge tts-badge-pending">⏳ Chờ tạo</span>`;
        }
    }

    function getSubActionButtonHTML(sub) {
        if (!sub) return "";
        if (sub.status === "DONE" || sub.status === "READY_FOR_MERGE" || sub.status === "COMPLETED") {
            return `<button type="button" class="btn-tts-preview-sub" data-sub-idx="${sub.index}">▶ Nghe thử</button>`;
        } else if (sub.status === "ERROR" || sub.status === "FAILED" || sub.status === "FINAL_FAILED") {
            return `<button type="button" class="btn-tts-retry-sub" data-sub-idx="${sub.index}">Thử lại</button>`;
        }
        return "";
    }

    function renderSingleSubItemHTML(sub) {
        const itemClass = sub.status ? sub.status.toLowerCase() : "pending";
        const statusBadge = getSubStatusBadgeHTML(sub);
        const actionBtn = getSubActionButtonHTML(sub);

        return `
            <div id="tts-sub-item-${sub.index}" class="tts-sub-item ${itemClass}" data-sub-idx="${sub.index}" data-sub-status="${sub.status || 'PENDING'}">
                <div class="tts-sub-item-header">
                    <div style="display:flex; align-items:center; gap:6px;">
                        <span class="tts-sub-idx">#${String(sub.index).padStart(3, "0")}</span>
                        <span class="tts-sub-time">${escapeHtml(sub.start || '00:00:00,000')}</span>
                    </div>
                    <div class="tts-sub-status" id="tts-sub-status-${sub.index}">${statusBadge}</div>
                </div>
                <div class="tts-sub-text">${escapeHtml(sub.text || '')}</div>
                <div class="tts-sub-actions-row" id="tts-sub-action-${sub.index}" style="${actionBtn ? '' : 'display:none;'}">
                    <span></span>${actionBtn}
                </div>
            </div>
        `;
    }

    let ttsLastRenderedCount = 0;
    let ttsLastFilterMode = "all";

    function renderTTSSubtitlesList(subs, forceFull = false) {
        const container = document.getElementById("tts-subtitle-items");
        if (!container) return;

        let filtered = subs || [];
        if (ttsFilterMode === "error") {
            filtered = filtered.filter(s => s.status === "ERROR" || s.status === "FAILED" || s.status === "FINAL_FAILED" || s.status === "RETRYING");
        }

        if (filtered.length === 0) {
            container.innerHTML = `<div style="padding:16px; text-align:center; color:#64748b; font-size:12px;">Không có câu phụ đề nào để hiển thị.</div>`;
            ttsLastRenderedCount = 0;
            return;
        }

        container.innerHTML = filtered.map(sub => renderSingleSubItemHTML(sub)).join("");
        ttsLastRenderedCount = filtered.length;
        ttsLastFilterMode = ttsFilterMode;
    }

    function updateTTSSubtitlesDOM(subs) {
        const container = document.getElementById("tts-subtitle-items");
        if (!container) return;

        if (ttsLastFilterMode !== ttsFilterMode || ttsLastRenderedCount === 0 || !container.children.length) {
            renderTTSSubtitlesList(subs);
            return;
        }

        for (const sub of subs) {
            const el = document.getElementById(`tts-sub-item-${sub.index}`);
            if (!el) continue;

            const prevStatus = el.getAttribute("data-sub-status");
            if (prevStatus !== sub.status) {
                el.setAttribute("data-sub-status", sub.status || "PENDING");
                el.className = `tts-sub-item ${(sub.status || 'pending').toLowerCase()}`;

                const statusEl = document.getElementById(`tts-sub-status-${sub.index}`);
                if (statusEl) statusEl.innerHTML = getSubStatusBadgeHTML(sub);

                const actionEl = document.getElementById(`tts-sub-action-${sub.index}`);
                if (actionEl) {
                    const btnHtml = getSubActionButtonHTML(sub);
                    if (btnHtml) {
                        actionEl.style.display = "flex";
                        actionEl.innerHTML = `<span></span>${btnHtml}`;
                    } else {
                        actionEl.style.display = "none";
                        actionEl.innerHTML = "";
                    }
                }
            }
        }
    }

    let activePreviewButton = null;

    function playSubPreview(idx, btnElement = null) {
        if (!ttsCurrentJobId) return;

        if (currentPreviewAudio) {
            currentPreviewAudio.pause();
            currentPreviewAudio = null;
            if (activePreviewButton) {
                activePreviewButton.textContent = "▶ Nghe thử";
                activePreviewButton.disabled = false;
                activePreviewButton = null;
            }
        }

        const audioUrl = `/api/tts/preview/${ttsCurrentJobId}/${idx}?t=${Date.now()}`;
        if (btnElement) {
            activePreviewButton = btnElement;
            btnElement.textContent = "🔊 Đang phát...";
        }

        currentPreviewAudio = new Audio(audioUrl);
        currentPreviewAudio.onended = () => {
            if (activePreviewButton) {
                activePreviewButton.textContent = "▶ Nghe thử";
                activePreviewButton = null;
            }
        };
        currentPreviewAudio.onerror = (err) => {
            if (activePreviewButton) {
                activePreviewButton.textContent = "▶ Nghe thử";
                activePreviewButton = null;
            }
            alert(`Không thể nghe thử câu #${idx}. Hãy đảm bảo file đã được tạo.`);
        };
        currentPreviewAudio.play().catch(e => {
            if (activePreviewButton) {
                activePreviewButton.textContent = "▶ Nghe thử";
                activePreviewButton = null;
            }
        });
    }

    async function retrySingleTTSSubtitle(idx) {
        if (!ttsCurrentJobId) {
            alert("Chưa có job TTS đang chạy.");
            return;
        }

        const voice = document.getElementById("tts-voice-select")?.value || "BV421_vivn_streaming";
        const speed = parseFloat(document.getElementById("tts-speed-select")?.value || 1.0);

        try {
            const sub = ttsSubtitlesList.find(s => s.index === idx);
            if (sub) {
                sub.status = "GENERATING";
                renderTTSSubtitlesList(ttsSubtitlesList);
            }

            const res = await fetch("/api/tts/retry", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    job_id: ttsCurrentJobId,
                    subtitle_index: idx,
                    voice: voice,
                    speed: speed
                })
            });

            const data = await res.json();
            if (!res.ok) throw new Error(data.detail || "Thử lại thất bại");

            startTTSPolling(ttsCurrentJobId);
        } catch (err) {
            alert(`Lỗi khi thử lại câu ${idx}: ${err.message}`);
            startTTSPolling(ttsCurrentJobId);
        }
    }

    async function fetchTTSVoices() {
        const select = document.getElementById("tts-voice-select");
        if (!select) return;

        try {
            const res = await fetch("/api/tts/voices");
            if (!res.ok) throw new Error("Không thể tải danh sách giọng");
            const data = await res.json();
            const voices = data.voices || [];

            if (voices.length === 0) {
                select.innerHTML = `<option value="BV421_vivn_streaming">Giọng Nữ Việt Mặc Định (BV421_vivn_streaming)</option>`;
                return;
            }

            select.innerHTML = voices.map(v => {
                const isSelected = (v.voice_type === "BV421_vivn_streaming" || v.voice_type.includes("BV421")) ? "selected" : "";
                const tag = v.is_vip ? " [VIP]" : "";
                return `<option value="${escapeHtml(v.voice_type)}" data-resource-id="${escapeHtml(v.resource_id || '')}" ${isSelected}>
                    ${escapeHtml(v.name || v.voice_type)}${tag} (${escapeHtml(v.voice_type)})
                </option>`;
            }).join("");

        } catch (err) {
            console.error("Lỗi fetch giọng TTS:", err);
            select.innerHTML = `
                <option value="BV421_vivn_streaming" selected>Cô Gái Miền Bắc (BV421_vivn_streaming)</option>
                <option value="BV422_vivn_streaming">Chàng Trai Miền Bắc (BV422_vivn_streaming)</option>
                <option value="BV423_vivn_streaming">Cô Gái Sài Gòn (BV423_vivn_streaming)</option>
                <option value="BV424_vivn_streaming">Chàng Trai Sài Gòn (BV424_vivn_streaming)</option>
            `;
        }
    }

    async function parseAndLoadTTS_SRT(rawContent, filename = "phu_de.srt") {
        if (!rawContent || !rawContent.trim()) {
            alert("Nội dung SRT rỗng.");
            return;
        }

        const badge = document.getElementById("tts-selected-file-badge");
        if (badge) {
            badge.style.display = "flex";
            badge.innerHTML = `<span>⏳ Đang phân tích file <strong>${escapeHtml(filename)}</strong>...</span>`;
        }

        try {
            const res = await fetch("/api/tts/parse-srt", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ srt_content: rawContent })
            });

            const data = await res.json();
            if (!res.ok) throw new Error(data.detail || "Không thể phân tích file SRT");

            ttsSrtContent = rawContent;
            ttsSubtitlesList = data.subtitles || [];

            if (badge) {
                badge.innerHTML = `
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/></svg>
                    <span>Đã nạp <strong>${escapeHtml(filename)}</strong> (${data.total || ttsSubtitlesList.length} câu)</span>
                `;
            }

            const progContainer = document.getElementById("tts-progress-container");
            if (progContainer) progContainer.style.display = "block";

            const statTotal = document.getElementById("tts-stat-total");
            if (statTotal) statTotal.textContent = data.total || ttsSubtitlesList.length;
            const statDone = document.getElementById("tts-stat-done");
            if (statDone) statDone.textContent = "0";
            const statFailed = document.getElementById("tts-stat-failed");
            if (statFailed) statFailed.textContent = "0";
            const statRem = document.getElementById("tts-stat-remaining");
            if (statRem) statRem.textContent = data.total || ttsSubtitlesList.length;
            const progPct = document.getElementById("tts-progress-percent");
            if (progPct) progPct.textContent = "0%";
            const progBar = document.getElementById("tts-progress-bar-fill");
            if (progBar) progBar.style.width = "0%";

            const banner = document.getElementById("tts-message-banner");
            if (banner) {
                banner.className = "status-toast info";
                banner.textContent = `Đã phân tích thành công ${data.total || ttsSubtitlesList.length} câu phụ đề. Sẵn sàng tạo giọng đọc.`;
            }

            renderTTSSubtitlesList(ttsSubtitlesList, true);

            const nameInput = document.getElementById("tts-output-filename");
            if (nameInput && filename) {
                const base = filename.replace(/\.[^/.]+$/, "");
                const curFmt = document.getElementById("tts-audio-format-input")?.value || "mp3";
                nameInput.value = `${base}_tts.${curFmt}`;
            }

            if (ttsCurrentJobStatus !== "creating" && ttsCurrentJobStatus !== "merging") {
                updateTTSButtonState("idle");
            }

        } catch (err) {
            if (badge) {
                badge.style.display = "flex";
                badge.innerHTML = `<span style="color:#f87171;">❌ Lỗi: ${escapeHtml(err.message)}</span>`;
            }
            alert(`Lỗi phân tích phụ đề SRT: ${err.message}`);
        }
    }

    let lastMergedJobData = null;

    function updateTTSButtonState(status, job = null) {
        const btn = document.getElementById("btn-start-tts");
        const btnText = document.getElementById("btn-start-tts-text");
        if (!btn) return;

        ttsCurrentJobStatus = status;

        switch (status) {
            case "idle":
                btn.disabled = false;
                btn.className = "btn btn-primary";
                btn.style.background = "";
                if (btnText) btnText.textContent = "Tạo TTS";
                break;
            case "creating":
                btn.disabled = false;
                btn.className = "btn btn-primary";
                btn.style.background = "";
                if (btnText) btnText.textContent = "Tạm dừng";
                break;
            case "paused":
                btn.disabled = false;
                btn.className = "btn btn-primary";
                btn.style.background = "";
                if (btnText) btnText.textContent = "Tiếp tục TTS";
                break;
            case "tts_completed":
                btn.disabled = false;
                btn.className = "btn btn-emerald";
                btn.style.background = "#10b981";
                if (btnText) btnText.textContent = "Ghép Audio";
                break;
            case "merging":
                btn.disabled = true;
                btn.className = "btn btn-emerald";
                btn.style.background = "#059669";
                if (btnText) btnText.textContent = "Đang ghép Audio...";
                break;
            case "merged":
                btn.disabled = false;
                btn.className = "btn btn-emerald";
                btn.style.background = "#059669";
                if (btnText) btnText.textContent = "Xem File Ghép";
                break;
            case "error":
            case "failed":
                btn.disabled = false;
                btn.className = "btn btn-primary";
                btn.style.background = "";
                if (btnText) btnText.textContent = "Thử lại TTS";
                break;
            default:
                btn.disabled = false;
                btn.className = "btn btn-primary";
                btn.style.background = "";
                if (btnText) btnText.textContent = "Tạo TTS";
                break;
        }
    }

    function showTTSMergeSuccessPopup(data) {
        const popup = document.getElementById("tts-merge-success-popup");
        const nameEl = document.getElementById("tts-merge-success-filename");
        const pathEl = document.getElementById("tts-merge-success-path");
        const dlBtn = document.getElementById("btn-download-tts-popup-audio");

        const filename = data?.filename || (data?.saved_location ? data.saved_location.replace(/^.*[\/\\]/, "") : "tts_final_audio.mp3");
        if (nameEl) nameEl.textContent = filename;
        if (pathEl) pathEl.textContent = `Download/KAGEVIETSUB/${filename}`;

        if (dlBtn) {
            dlBtn.onclick = () => {
                window.triggerSafeFileDownload(filename, filename);
            };
        }

        if (popup) popup.style.display = "flex";
    }

    function stopTTSPolling() {
        if (ttsPollTimeoutId) {
            clearTimeout(ttsPollTimeoutId);
            ttsPollTimeoutId = null;
        }
    }

    function startTTSPolling(jobId) {
        if (!jobId) return;
        ttsCurrentJobId = jobId;
        sessionStorage.setItem("kage_current_tts_job_id", jobId);
        stopTTSPolling();
        pollTTSJob(jobId);
    }

    function resetTTSFormToIdle() {
        ttsCurrentJobId = null;
        sessionStorage.removeItem("kage_current_tts_job_id");
        ttsCurrentJobStatus = "idle";
        stopTTSPolling();
        updateTTSButtonState("idle");
        const banner = document.getElementById("tts-message-banner");
        if (banner) {
            banner.textContent = "Sẵn sàng tạo giọng đọc TTS.";
            banner.className = "status-toast info";
        }
    }
    window.resetTTSFormToIdle = resetTTSFormToIdle;

    let ttsPollCounter = 0;

    async function pollTTSJob(jobId) {
        if (!jobId) return;
        if (isTTSPolling) return;

        isTTSPolling = true;
        let shouldScheduleNext = false;
        let nextDelay = 1500;

        try {
            ttsPollCounter++;
            const needSubtitles = (ttsSubtitlesList.length === 0) || (ttsPollCounter % 3 === 0);
            const cacheBuster = `_t=${Date.now()}`;
            let res = await fetch(`/api/tts/status/${encodeURIComponent(jobId)}?include_subtitles=${needSubtitles ? "true" : "false"}&${cacheBuster}`, {
                headers: { "Cache-Control": "no-cache", "Pragma": "no-cache" }
            });
            if (!res.ok) {
                res = await fetch(`/api/tts/job/${encodeURIComponent(jobId)}?${cacheBuster}`, {
                    headers: { "Cache-Control": "no-cache", "Pragma": "no-cache" }
                });
            }
            if (!res.ok) {
                res = await fetch(`/api/jobs/${encodeURIComponent(jobId)}?${cacheBuster}`, {
                    headers: { "Cache-Control": "no-cache", "Pragma": "no-cache" }
                });
            }

            if (!res.ok) {
                shouldScheduleNext = true;
                nextDelay = 1200;
                return;
            }

            const job = await res.json();
            if (!job || typeof job !== "object") {
                shouldScheduleNext = true;
                nextDelay = 1200;
                return;
            }

            if (ttsLastRevisionJobId !== jobId) {
                ttsLastRevisionJobId = jobId;
                ttsLastRevision = 0;
            }
            if (job.revision !== undefined && typeof job.revision === "number") {
                if (job.revision < ttsLastRevision) {
                    shouldScheduleNext = true;
                    return;
                }
                ttsLastRevision = job.revision;
            }

            const resData = job.result || job;
            const jobFmt = (job.audio_format || resData.audio_format || (job.metadata && job.metadata.audio_format) || "").toLowerCase();
            if (jobFmt === "mp3" || jobFmt === "wav") {
                setTTSAudioFormat(jobFmt, false);
            }

            const subs = job.subtitles || resData.subtitles || [];
            if (Array.isArray(subs) && subs.length > 0) {
                ttsSubtitlesList = subs;
            }

            const total = job.total !== undefined ? job.total : (resData.total || ttsSubtitlesList.length);
            const done = job.completed !== undefined ? job.completed : (resData.completed || 0);
            const failed = job.failed !== undefined ? job.failed : (resData.failed || 0);
            const processing = job.processing !== undefined ? job.processing : (resData.processing || 0);
            const finalizing = job.finalizing !== undefined ? job.finalizing : (resData.finalizing || 0);
            const remaining = job.pending !== undefined ? job.pending : (resData.pending !== undefined ? resData.pending : Math.max(0, total - done - failed));
            const threads = job.workers || resData.requested_workers || resData.threads || 5;
            const actW = job.actual_workers || resData.actual_workers || threads;
            const actRunning = job.active_workers !== undefined ? job.active_workers : (resData.active_workers !== undefined ? resData.active_workers : actW);
            const rawStatus = (job.status || "idle").toLowerCase();
            const rawMergeStatus = (job.merge_status || "").toLowerCase();
            let effectiveStatus = rawStatus;

            if (rawStatus === "merged" || rawMergeStatus === "completed" || (rawStatus === "completed" && job.saved_location)) {
                effectiveStatus = "merged";
            } else if (rawStatus === "merging" || rawMergeStatus === "merging") {
                effectiveStatus = "merging";
            } else if (rawStatus === "completed" || rawStatus === "tts_completed" || rawStatus === "completed_with_errors") {
                effectiveStatus = "tts_completed";
            } else if (rawStatus === "processing" || rawStatus === "generating" || rawStatus === "creating" || rawStatus === "queued") {
                effectiveStatus = "creating";
            } else if (rawStatus === "paused") {
                effectiveStatus = "paused";
            }

            if (effectiveStatus === "merged") {
                isMergingActive = false;
            }

            const isMergingPhase = (isMergingActive || effectiveStatus === "merging") && effectiveStatus !== "merged";
            const throughput = job.throughput_per_min !== undefined ? job.throughput_per_min : (resData.throughput_per_min || 0);
            const etaSec = job.eta_seconds !== undefined ? job.eta_seconds : (resData.eta_seconds !== undefined ? resData.eta_seconds : null);
            const ttsPct = job.tts_progress !== undefined ? job.tts_progress : Math.min(100, Math.round((done + failed) / (total || 1) * 100));
            const mergePct = effectiveStatus === "merged" ? 100 : (job.merge_progress !== undefined ? job.merge_progress : (isMergingPhase ? (job.progress || 0) : 0));
            const mergeEta = effectiveStatus === "merged" ? 0 : (job.merge_eta !== undefined && job.merge_eta !== null ? job.merge_eta : (isMergingPhase ? etaSec : null));
            const mergeSpeed = effectiveStatus === "merged" ? "Hoàn tất" : (job.merge_speed || job.speed || (job.chunks_total > 0 ? `Chunk ${job.chunks_completed || 0}/${job.chunks_total}` : ""));

            const safeSetText = (id, val) => {
                const el = document.getElementById(id);
                if (el) el.textContent = val;
            };
            const safeSetStyle = (id, prop, val) => {
                const el = document.getElementById(id);
                if (el) el.style[prop] = val;
            };

            safeSetText("tts-stat-total", total);
            safeSetText("tts-stat-done", done);
            safeSetText("tts-stat-failed", failed);
            
            const curPass = job.retry_pass !== undefined ? job.retry_pass : (resData.retry_pass || 0);
            safeSetText("tts-stat-retry", `${curPass}/3`);
            safeSetText("tts-stat-remaining", (isMergingPhase || effectiveStatus === "merged") ? 0 : remaining);

            const statThr = document.getElementById("tts-stat-threads");
            if (statThr) {
                if (effectiveStatus === "merged") {
                    statThr.textContent = `Hoàn tất`;
                } else if (job.status === "paused") {
                    statThr.textContent = `${actW}/${actW} luồng (Tạm dừng)`;
                } else if (isMergingPhase) {
                    statThr.textContent = `1 luồng FFmpeg`;
                } else {
                    statThr.textContent = `${actRunning}/${actW} luồng`;
                }
                statThr.title = `Yêu cầu: ${threads} luồng | Đã tạo thực tế: ${actW} luồng | Đang chạy: ${actRunning} luồng | Gối đầu: ${processing} xử lý API, ${finalizing} lưu audio`;
            }

            const thrLabel = document.getElementById("tts-stat-throughput-label");

            if (effectiveStatus === "merged") {
                if (thrLabel) thrLabel.textContent = "Trạng thái";
                safeSetText("tts-stat-throughput", "Hoàn tất");

                const statEta = document.getElementById("tts-stat-eta");
                if (statEta) statEta.textContent = "0s";

                safeSetText("tts-progress-percent", "Hoàn tất (100%)");
                safeSetStyle("tts-progress-bar-fill", "width", "100%");
            } else if (isMergingPhase) {
                if (thrLabel) thrLabel.textContent = "Tốc độ ghép";
                safeSetText("tts-stat-throughput", mergeSpeed || "Đang ghép");

                const statEta = document.getElementById("tts-stat-eta");
                if (statEta) {
                    if (mergeEta !== null && mergeEta !== undefined && mergeEta >= 0) {
                        statEta.textContent = mergeEta > 60 ? `${Math.floor(mergeEta / 60)}p ${mergeEta % 60}s` : (mergeEta === 0 ? "Gần xong" : `${mergeEta}s`);
                    } else {
                        statEta.textContent = "Đang tính...";
                    }
                }

                safeSetText("tts-progress-percent", `Ghép Audio: ${mergePct}%`);
                safeSetStyle("tts-progress-bar-fill", "width", `${mergePct}%`);
            } else {
                if (thrLabel) thrLabel.textContent = "Tốc độ tạo";
                safeSetText("tts-stat-throughput", `${throughput} câu/p`);

                const statEta = document.getElementById("tts-stat-eta");
                if (statEta) {
                    if (job.status === "paused") {
                        statEta.textContent = "Đang tạm dừng";
                    } else if (job.status === "merged" || job.merge_status === "completed" || job.status === "tts_completed") {
                        statEta.textContent = "0s";
                    } else if (etaSec !== null && etaSec !== undefined && etaSec >= 0) {
                        statEta.textContent = etaSec > 60 ? `${Math.floor(etaSec / 60)}p ${etaSec % 60}s` : (etaSec === 0 ? "Gần xong" : `${etaSec}s`);
                    } else {
                        statEta.textContent = "Đang tính...";
                    }
                }

                safeSetText("tts-progress-percent", `${ttsPct}%`);
                safeSetStyle("tts-progress-bar-fill", "width", `${ttsPct}%`);
            }

            safeSetText("tts-err-filter-count", failed);

            const banner = document.getElementById("tts-message-banner");
            if (banner) {
                banner.textContent = job.message || "Đang xử lý...";
                if (effectiveStatus === "merged" || job.status === "tts_completed" || job.status === "completed") banner.className = "status-toast success";
                else if (job.status === "failed" || job.status === "error" || job.merge_status === "failed") banner.className = "status-toast error";
                else if (job.status === "completed_with_errors") banner.className = "status-toast warn";
                else if (job.status === "paused") banner.className = "status-toast warn";
                else banner.className = "status-toast info";
            }

            const progContainer = document.getElementById("tts-progress-container");
            if (progContainer) progContainer.style.display = "block";

            if (ttsSubtitlesList && ttsSubtitlesList.length > 0) {
                updateTTSSubtitlesDOM(ttsSubtitlesList);
            }

            ttsCurrentJobStatus = effectiveStatus;
            updateTTSButtonState(effectiveStatus, job);

            const retryAllBtn = document.getElementById("btn-tts-retry-all-failed");
            if (retryAllBtn) {
                retryAllBtn.style.display = (failed > 0 && effectiveStatus === "tts_completed") ? "inline-flex" : "none";
            }

            if (job.merge_status === "failed" || job.status === "failed" || job.status === "error") {
                isMergingActive = false;
                if (banner) {
                    banner.textContent = job.message || job.error || job.merge_error || "Ghép audio thất bại. Bạn có thể bấm 'GHÉP AUDIO' để thử lại.";
                    banner.className = "status-toast error";
                }
                updateTTSButtonState("tts_completed", job);
                shouldScheduleNext = false;
            } else if (effectiveStatus === "merged" || (job.saved_location && isMergingActive) || job.merge_status === "completed") {
                isMergingActive = false;
                const filename = job.filename || job.output_filename || (job.saved_location ? job.saved_location.replace(/^.*[\/\\]/, "") : "tts_final_audio.mp3");
                lastMergedJobData = {
                    filename: filename,
                    saved_location: job.saved_location || `Download/KAGEVIETSUB/${filename}`
                };

                if (!ttsMergePopupShown) {
                    ttsMergePopupShown = true;
                    showTTSMergeSuccessPopup(lastMergedJobData);
                }
                shouldScheduleNext = false;
            } else if (effectiveStatus === "tts_completed") {
                if (isMergingActive || job.merge_status === "merging") {
                    shouldScheduleNext = true;
                    nextDelay = 800;
                } else {
                    shouldScheduleNext = false;
                }
            } else if (effectiveStatus === "failed" || effectiveStatus === "error" || effectiveStatus === "stopped") {
                shouldScheduleNext = false;
            } else {
                shouldScheduleNext = true;
                nextDelay = 750;
            }

        } catch (e) {
            console.warn("Lỗi polling TTS job:", e);
            shouldScheduleNext = true;
            nextDelay = 1200;
        } finally {
            isTTSPolling = false;
            if (shouldScheduleNext && ttsCurrentJobId === jobId) {
                stopTTSPolling();
                ttsPollTimeoutId = setTimeout(() => pollTTSJob(jobId), nextDelay);
            }
        }
    }

    async function pauseCurrentTTSJob() {
        if (!ttsCurrentJobId) return;
        const btn = document.getElementById("btn-start-tts");
        const btnText = document.getElementById("btn-start-tts-text");
        if (btnText) btnText.textContent = "⏳ Đang tạm dừng...";
        if (btn) btn.disabled = true;

        try {
            const res = await fetch(`/api/tts/${encodeURIComponent(ttsCurrentJobId)}/pause`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ job_id: ttsCurrentJobId })
            });
            if (!res.ok) throw new Error("Không thể tạm dừng job");
            startTTSPolling(ttsCurrentJobId);
        } catch (e) {
            alert(`Lỗi tạm dừng: ${e.message}`);
            startTTSPolling(ttsCurrentJobId);
        }
    }

    async function resumeCurrentTTSJob() {
        if (!ttsCurrentJobId) return;
        const btn = document.getElementById("btn-start-tts");
        const btnText = document.getElementById("btn-start-tts-text");
        if (btnText) btnText.textContent = "⏳ Đang tiếp tục...";
        if (btn) btn.disabled = true;

        try {
            const res = await fetch(`/api/tts/${encodeURIComponent(ttsCurrentJobId)}/resume`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ job_id: ttsCurrentJobId })
            });
            if (!res.ok) throw new Error("Không thể tiếp tục job");
            startTTSPolling(ttsCurrentJobId);
        } catch (e) {
            alert(`Lỗi tiếp tục: ${e.message}`);
            startTTSPolling(ttsCurrentJobId);
        }
    }

    async function mergeCurrentTTSJob() {
        if (!ttsCurrentJobId) {
            alert("Chưa có tiến trình TTS hoàn thành để ghép audio.");
            return;
        }

        if (ttsCurrentJobStatus === "merged" && lastMergedJobData) {
            showTTSMergeSuccessPopup(lastMergedJobData);
            return;
        }

        isMergingActive = true;
        ttsMergePopupShown = false;
        updateTTSButtonState("merging");

        const outFilename = document.getElementById("tts-output-filename")?.value || "tts_final_audio.mp3";
        const audioFormat = document.getElementById("tts-audio-format-input")?.value || "mp3";

        try {
            const res = await fetch(`/api/tts/${encodeURIComponent(ttsCurrentJobId)}/merge`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    job_id: ttsCurrentJobId,
                    output_filename: outFilename,
                    audio_format: audioFormat
                })
            });

            const data = await res.json();
            if (!res.ok) throw new Error(data.detail || "Lỗi ghép audio");

            if (data.already_merged) {
                isMergingActive = false;
                const filename = data.output_filename || outFilename;
                lastMergedJobData = {
                    filename: filename,
                    saved_location: data.saved_location || `Download/KAGEVIETSUB/${filename}`
                };
                ttsCurrentJobStatus = "merged";
                updateTTSButtonState("merged");
                showTTSMergeSuccessPopup(lastMergedJobData);
                return;
            }

            startTTSPolling(ttsCurrentJobId);

        } catch (err) {
            isMergingActive = false;
            updateTTSButtonState("tts_completed");
            alert(`Lỗi ghép audio: ${err.message}`);
        }
    }

    async function startNewTTSJob() {
        isMergingActive = false;
        ttsMergePopupShown = false;

        if (!ttsSrtContent || ttsSubtitlesList.length === 0) {
            alert("Vui lòng chọn hoặc kéo thả file .SRT vào trước khi bắt đầu.");
            return;
        }

        const voice = document.getElementById("tts-voice-select")?.value || "BV421_vivn_streaming";
        const speed = parseFloat(document.getElementById("tts-speed-select")?.value || 1.0);
        let threads = parseInt(document.getElementById("tts-threads-input")?.value || 5);
        threads = Math.max(1, Math.min(30, threads));
        const outFilename = document.getElementById("tts-output-filename")?.value || "tts_final_audio.mp3";
        const audioFormat = document.getElementById("tts-audio-format-input")?.value || "mp3";

        const btn = document.getElementById("btn-start-tts");
        if (btn) btn.disabled = true;
        const btnText = document.getElementById("btn-start-tts-text");
        if (btnText) btnText.textContent = "⏳ Đang khởi chạy...";

        const progressContainer = document.getElementById("tts-progress-container");
        if (progressContainer) progressContainer.style.display = "block";

        try {
            const res = await fetch("/api/tts/create-job", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    srt_content: ttsSrtContent,
                    voice: voice,
                    speed: speed,
                    threads: threads,
                    output_filename: outFilename,
                    audio_format: audioFormat
                })
            });

            const data = await res.json();
            if (!res.ok) throw new Error(data.detail || "Không thể tạo job TTS");

            ttsCurrentJobId = data.job_id;
            sessionStorage.setItem("kage_current_tts_job_id", ttsCurrentJobId);
            ttsLastRevision = 0;
            ttsLastRevisionJobId = ttsCurrentJobId;

            startTTSPolling(ttsCurrentJobId);

        } catch (err) {
            updateTTSButtonState("idle");
            alert(`Lỗi khởi chạy TTS: ${err.message}`);
        }
    }

    async function loadTTSJob(jobId) {
        if (!jobId) return;
        ttsCurrentJobId = jobId;
        sessionStorage.setItem("kage_current_tts_job_id", jobId);

        const progressContainer = document.getElementById("tts-progress-container");
        if (progressContainer) progressContainer.style.display = "block";

        startTTSPolling(jobId);
    }
    window.loadTTSJob = loadTTSJob;

    document.addEventListener("visibilitychange", () => {
        if (document.visibilityState === "visible") {
            const curJob = ttsCurrentJobId || sessionStorage.getItem("kage_current_tts_job_id");
            if (curJob) {
                startTTSPolling(curJob);
            }
        }
    });

    window.handleGlobalJobCardClick = function(jobId, jobType) {
        if (!jobId) return;

        try {
            const url = new URL(window.location.href);
            url.searchParams.set("job_id", jobId);
            if (jobType) url.searchParams.set("type", jobType);
            window.history.pushState({}, "", url.toString());
        } catch (e) {}

        if (jobType === "downloader" || jobId.startsWith("dl_")) {
            switchMainTab("downloader");
            setTimeout(() => {
                const card = document.querySelector(`.downloader-video-card[data-job-id="${jobId}"]`);
                if (card) {
                    card.scrollIntoView({ behavior: "smooth", block: "center" });
                    card.classList.add("expanded");
                }
            }, 200);
        } else if (jobType === "tts_merge_recovery" || jobId.startsWith("tts_merge_recovery_") || jobId.includes("recovery")) {
            switchMainTab("tts", "tts-merge");
        } else if (jobType === "tts" || jobType === "tts_generation" || jobId.startsWith("tts_") || jobId.startsWith("tts-")) {
            switchMainTab("tts", "tts-create");
            if (typeof loadTTSJob === "function") {
                loadTTSJob(jobId);
            }
        } else if (jobType === "whisper_transcribe" || jobId.startsWith("whisper_") || jobId.startsWith("wh_")) {
            switchMainTab("audio", "audio-whisper");
        } else if (jobType === "audio_merge" || jobId.startsWith("audio_merge_")) {
            switchMainTab("audio", "audio-merge");
        } else if (jobType === "video_cut" || jobId.startsWith("video_cut_")) {
            switchMainTab("video", "video-cut");
        } else if (jobType === "video_merge" || jobId.startsWith("video_merge_")) {
            switchMainTab("video", "video-merge");
        } else if (jobType === "video_compress" || jobId.startsWith("video_compress_")) {
            switchMainTab("video", "video-compress");
        } else {
            if (jobId.startsWith("dl_")) {
                switchMainTab("downloader");
            } else {
                switchMainTab("tts", "tts-create");
                if (typeof loadTTSJob === "function") {
                    loadTTSJob(jobId);
                }
            }
        }
    };

    function setTTSAudioFormat(format, updateFilename = true) {
        const fmt = (format || "mp3").toLowerCase() === "wav" ? "wav" : "mp3";
        const input = document.getElementById("tts-audio-format-input");
        const badge = document.getElementById("tts-audio-format-badge");
        const btnMp3 = document.getElementById("btn-tts-format-mp3");
        const btnWav = document.getElementById("btn-tts-format-wav");
        const nameInput = document.getElementById("tts-output-filename");

        if (input) input.value = fmt;
        if (badge) {
            badge.textContent = fmt.toUpperCase();
            badge.style.color = fmt === "wav" ? "#38bdf8" : "#818cf8";
        }
        if (btnMp3 && btnWav) {
            btnMp3.classList.toggle("active", fmt === "mp3");
            btnWav.classList.toggle("active", fmt === "wav");
        }

        if (updateFilename && nameInput && nameInput.value) {
            const currentVal = nameInput.value.trim();
            if (fmt === "wav") {
                if (/\.mp3$/i.test(currentVal)) {
                    nameInput.value = currentVal.replace(/\.mp3$/i, ".wav");
                } else if (!/\.wav$/i.test(currentVal)) {
                    nameInput.value = currentVal.replace(/\.[^/.]+$/, "") + ".wav";
                }
            } else {
                if (/\.wav$/i.test(currentVal)) {
                    nameInput.value = currentVal.replace(/\.wav$/i, ".mp3");
                } else if (!/\.mp3$/i.test(currentVal)) {
                    nameInput.value = currentVal.replace(/\.[^/.]+$/, "") + ".mp3";
                }
            }
        }
    }

    function initTTSController() {
        fetchTTSVoices();

        // Audio format switch [ MP3 ] [ WAV ]
        document.getElementById("btn-tts-format-mp3")?.addEventListener("click", () => setTTSAudioFormat("mp3", true));
        document.getElementById("btn-tts-format-wav")?.addEventListener("click", () => setTTSAudioFormat("wav", true));

        const threadInput = document.getElementById("tts-threads-input");
        const threadLabel = document.getElementById("tts-threads-label");

        if (threadInput && threadLabel) {
            threadInput.addEventListener("input", () => {
                let v = parseInt(threadInput.value);
                if (isNaN(v)) v = 5;
                if (v < 1) v = 1;
                if (v > 30) v = 30;
                threadLabel.textContent = `${v} luồng`;
            });
        }

        const dropzone = document.getElementById("tts-dropzone");
        const fileInput = document.getElementById("tts-file-input");

        if (dropzone && fileInput) {
            dropzone.addEventListener("click", () => fileInput.click());
            dropzone.addEventListener("dragover", (e) => {
                e.preventDefault();
                dropzone.classList.add("dragover");
            });
            dropzone.addEventListener("dragleave", () => dropzone.classList.remove("dragover"));
            dropzone.addEventListener("drop", (e) => {
                e.preventDefault();
                dropzone.classList.remove("dragover");
                if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                    const f = e.dataTransfer.files[0];
                    const reader = new FileReader();
                    reader.onload = (evt) => parseAndLoadTTS_SRT(evt.target.result, f.name);
                    reader.readAsText(f, "utf-8");
                }
            });

            fileInput.addEventListener("change", (e) => {
                if (fileInput.files && fileInput.files.length > 0) {
                    const f = fileInput.files[0];
                    const reader = new FileReader();
                    reader.onload = (evt) => parseAndLoadTTS_SRT(evt.target.result, f.name);
                    reader.readAsText(f, "utf-8");
                }
            });
        }

        document.getElementById("btn-tts-use-editor-srt")?.addEventListener("click", () => {
            const editorText = document.getElementById("srt-editor-textarea")?.value || "";
            if (!editorText.trim()) {
                alert("Trình Sửa Phụ Đề hiện tại đang rỗng. Hãy dán nội dung SRT hoặc tải file lên trước.");
                return;
            }
            parseAndLoadTTS_SRT(editorText, "Trình_Sửa_Phụ_Đề.srt");
        });

        const startBtnWrapper = document.getElementById("btn-start-tts-wrapper");
        if (startBtnWrapper) {
            startBtnWrapper.addEventListener("click", () => {
                const btn = document.getElementById("btn-start-tts");
                if (btn && btn.disabled && ttsCurrentJobStatus === "merged") {
                    showTTSMergeSuccessPopup(lastMergedJobData);
                }
            });
        }

        document.getElementById("btn-start-tts")?.addEventListener("click", async () => {
            if (ttsCurrentJobStatus === "creating") {
                await pauseCurrentTTSJob();
                return;
            }
            if (ttsCurrentJobStatus === "paused") {
                await resumeCurrentTTSJob();
                return;
            }
            if (ttsCurrentJobStatus === "tts_completed") {
                await mergeCurrentTTSJob();
                return;
            }
            if (ttsCurrentJobStatus === "merged") {
                if (lastMergedJobData) {
                    showTTSMergeSuccessPopup(lastMergedJobData);
                }
                return;
            }
            if (ttsCurrentJobStatus === "merging") {
                return;
            }

            if (ttsCurrentJobId && (ttsCurrentJobStatus === "creating" || ttsCurrentJobStatus === "merging")) {
                const runningModal = document.getElementById("tts-job-running-popup");
                if (runningModal) runningModal.style.display = "flex";
                return;
            }

            await startNewTTSJob();
        });

        document.getElementById("btn-running-popup-home")?.addEventListener("click", () => {
            const popup = document.getElementById("tts-job-running-popup");
            if (popup) popup.style.display = "none";
            switchMainTab("home");
        });
        document.getElementById("btn-running-popup-close")?.addEventListener("click", () => {
            const popup = document.getElementById("tts-job-running-popup");
            if (popup) popup.style.display = "none";
        });
        document.getElementById("tts-job-running-popup")?.addEventListener("click", (e) => {
            if (e.target.id === "tts-job-running-popup") {
                const popup = document.getElementById("tts-job-running-popup");
                if (popup) popup.style.display = "none";
            }
        });

        document.getElementById("btn-close-tts-merge-popup")?.addEventListener("click", () => {
            const popup = document.getElementById("tts-merge-success-popup");
            if (popup) popup.style.display = "none";
        });

        document.getElementById("tts-merge-success-popup")?.addEventListener("click", (e) => {
            if (e.target.id === "tts-merge-success-popup") {
                const popup = document.getElementById("tts-merge-success-popup");
                if (popup) popup.style.display = "none";
            }
        });

        document.getElementById("btn-tts-retry-all-failed")?.addEventListener("click", async () => {
            if (!ttsCurrentJobId) return;
            const failedSubs = ttsSubtitlesList.filter(s => s.status === "ERROR" || s.status === "FAILED" || s.status === "FINAL_FAILED");
            if (failedSubs.length === 0) {
                alert("Không có câu nào bị lỗi.");
                return;
            }

            const voice = document.getElementById("tts-voice-select")?.value || "BV421_vivn_streaming";
            const speed = parseFloat(document.getElementById("tts-speed-select")?.value || 1.0);
            let threads = parseInt(document.getElementById("tts-threads-input")?.value || 5);
            threads = Math.max(1, Math.min(30, threads));

            for (const sub of failedSubs) {
                sub.status = "TTS_PROCESSING";
            }
            renderTTSSubtitlesList(ttsSubtitlesList);

            const btnRetry = document.getElementById("btn-tts-retry-all-failed");
            if (btnRetry) btnRetry.disabled = true;

            try {
                const res = await fetch("/api/tts/retry-failed", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        job_id: ttsCurrentJobId,
                        voice: voice,
                        speed: speed,
                        threads: threads
                    })
                });
                const data = await res.json();
                if (!res.ok) throw new Error(data.detail || "Không thể tạo lại các câu lỗi");

                ttsCurrentJobStatus = "creating";
                updateTTSButtonState("creating");
                startTTSPolling(ttsCurrentJobId);
            } catch (e) {
                alert(`Lỗi khi yêu cầu tạo lại câu lỗi: ${e.message}`);
                if (btnRetry) btnRetry.disabled = false;
                startTTSPolling(ttsCurrentJobId);
            }
        });

        document.getElementById("btn-tts-filter-all")?.addEventListener("click", () => {
            ttsFilterMode = "all";
            document.getElementById("btn-tts-filter-all").classList.add("active");
            document.getElementById("btn-tts-filter-err").classList.remove("active");
            renderTTSSubtitlesList(ttsSubtitlesList);
        });

        document.getElementById("btn-tts-filter-err")?.addEventListener("click", () => {
            ttsFilterMode = "error";
            document.getElementById("btn-tts-filter-err").classList.add("active");
            document.getElementById("btn-tts-filter-all").classList.remove("active");
            renderTTSSubtitlesList(ttsSubtitlesList);
        });

        const subContainer = document.getElementById("tts-subtitle-items");
        if (subContainer) {
            subContainer.addEventListener("click", async (e) => {
                const retryBtn = e.target.closest(".btn-tts-retry-sub");
                if (retryBtn) {
                    e.stopPropagation();
                    const idx = parseInt(retryBtn.getAttribute("data-sub-idx"));
                    if (!isNaN(idx)) await retrySingleTTSSubtitle(idx);
                    return;
                }

                const previewBtn = e.target.closest(".btn-tts-preview-sub");
                if (previewBtn) {
                    e.stopPropagation();
                    const idx = parseInt(previewBtn.getAttribute("data-sub-idx"));
                    if (!isNaN(idx)) playSubPreview(idx, previewBtn);
                    return;
                }
            });
        }

        const savedJobId = sessionStorage.getItem("kage_current_tts_job_id");
        if (savedJobId) {
            loadTTSJob(savedJobId);
        } else {
            updateTTSButtonState("idle");
        }
    }

    let ttsRecoverySrtContent = "";
    let ttsRecoveryPollTimer = null;
    let currentRecoveryFolders = [];

    function setTTSRecoveryAudioFormat(format, updateFilename = true) {
        const fmt = (format || "mp3").toLowerCase() === "wav" ? "wav" : "mp3";
        const input = document.getElementById("tts-recovery-format-input");
        const badge = document.getElementById("tts-recovery-format-badge");
        const btnMp3 = document.getElementById("btn-tts-recovery-format-mp3");
        const btnWav = document.getElementById("btn-tts-recovery-format-wav");
        const nameInput = document.getElementById("tts-recovery-output-filename");

        if (input) input.value = fmt;
        if (badge) {
            badge.textContent = fmt.toUpperCase();
            badge.style.color = fmt === "wav" ? "#38bdf8" : "#818cf8";
        }
        if (btnMp3 && btnWav) {
            btnMp3.classList.toggle("active", fmt === "mp3");
            btnWav.classList.toggle("active", fmt === "wav");
        }

        if (updateFilename && nameInput && nameInput.value) {
            const currentVal = nameInput.value.trim();
            if (fmt === "wav") {
                if (/\.mp3$/i.test(currentVal)) {
                    nameInput.value = currentVal.replace(/\.mp3$/i, ".wav");
                } else if (!/\.wav$/i.test(currentVal)) {
                    nameInput.value = currentVal.replace(/\.[^/.]+$/, "") + ".wav";
                }
            } else {
                if (/\.wav$/i.test(currentVal)) {
                    nameInput.value = currentVal.replace(/\.wav$/i, ".mp3");
                } else if (!/\.mp3$/i.test(currentVal)) {
                    nameInput.value = currentVal.replace(/\.[^/.]+$/, "") + ".mp3";
                }
            }
        }
    }

    async function fetchTTSRecoveryFolders() {
        const select = document.getElementById("tts-recovery-folder-select");
        const info = document.getElementById("tts-recovery-folder-info");
        if (!select) return;

        select.innerHTML = `<option value="">⌛ Đang quét các thư mục trong DATA/temp...</option>`;
        if (info) info.style.display = "none";

        try {
            const res = await fetch("/api/tts/merge-recovery/folders");
            if (!res.ok) throw new Error("Không thể quét thư mục DATA/temp");
            const data = await res.json();
            const folders = data.folders || [];
            currentRecoveryFolders = folders;

            if (folders.length === 0) {
                select.innerHTML = `<option value="">(Không tìm thấy thư mục audio con nào trong DATA/temp)</option>`;
                if (info) {
                    info.style.display = "block";
                    info.innerHTML = `⚠️ Không tìm thấy thư mục chứa file audio con (.mp3 / .wav) nào trong <code>DATA/temp</code>.`;
                }
                return;
            }

            select.innerHTML = `<option value="">-- Chọn một thư mục audio con --</option>` + folders.map(f => {
                const folderPath = f.folder_path || f.path || "";
                const folderName = f.folder_name || f.name || "";
                const fileCount = f.file_count !== undefined ? f.file_count : (f.audio_count || 0);
                const detFmt = (f.detected_format || "mp3").toUpperCase();
                return `<option value="${escapeHtml(folderPath)}">📁 ${escapeHtml(folderName)} (${fileCount} file ${detFmt})</option>`;
            }).join("");

            if (info) {
                info.style.display = "block";
                info.innerHTML = `Tìm thấy <strong>${folders.length}</strong> thư mục audio con sẵn có trong <code>DATA/temp</code>.`;
            }
        } catch (err) {
            console.error("Lỗi quét thư mục recovery:", err);
            select.innerHTML = `<option value="">❌ Lỗi: ${escapeHtml(err.message)}</option>`;
        }
    }

    function initTTSRecoveryController() {
        // Audio format switch [ MP3 ] [ WAV ] for recovery merge
        document.getElementById("btn-tts-recovery-format-mp3")?.addEventListener("click", () => setTTSRecoveryAudioFormat("mp3", true));
        document.getElementById("btn-tts-recovery-format-wav")?.addEventListener("click", () => setTTSRecoveryAudioFormat("wav", true));

        const folderSelect = document.getElementById("tts-recovery-folder-select");
        if (folderSelect) {
            folderSelect.addEventListener("change", () => {
                const selectedPath = folderSelect.value;
                const found = currentRecoveryFolders.find(f => (f.folder_path || f.path) === selectedPath);
                if (found && found.detected_format) {
                    setTTSRecoveryAudioFormat(found.detected_format, true);
                }
            });
        }

        const refreshBtn = document.getElementById("btn-tts-recovery-refresh");
        if (refreshBtn) {
            refreshBtn.addEventListener("click", () => fetchTTSRecoveryFolders());
        }

        const dropzone = document.getElementById("tts-recovery-dropzone");
        const fileInput = document.getElementById("tts-recovery-file-input");
        const badge = document.getElementById("tts-recovery-selected-file-badge");

        if (dropzone && fileInput) {
            dropzone.addEventListener("click", () => fileInput.click());
            dropzone.addEventListener("dragover", (e) => {
                e.preventDefault();
                dropzone.classList.add("dragover");
            });
            dropzone.addEventListener("dragleave", () => dropzone.classList.remove("dragover"));
            dropzone.addEventListener("drop", (e) => {
                e.preventDefault();
                dropzone.classList.remove("dragover");
                if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                    const f = e.dataTransfer.files[0];
                    const reader = new FileReader();
                    reader.onload = (evt) => {
                        ttsRecoverySrtContent = evt.target.result;
                        if (badge) {
                            badge.style.display = "flex";
                            badge.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/></svg> <span>Đã nạp file SRT: <strong>${escapeHtml(f.name)}</strong></span>`;
                        }
                    };
                    reader.readAsText(f, "utf-8");
                }
            });

            fileInput.addEventListener("change", () => {
                if (fileInput.files && fileInput.files.length > 0) {
                    const f = fileInput.files[0];
                    const reader = new FileReader();
                    reader.onload = (evt) => {
                        ttsRecoverySrtContent = evt.target.result;
                        if (badge) {
                            badge.style.display = "flex";
                            badge.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/></svg> <span>Đã nạp file SRT: <strong>${escapeHtml(f.name)}</strong></span>`;
                        }
                    };
                    reader.readAsText(f, "utf-8");
                }
            });
        }

        document.getElementById("btn-tts-recovery-use-editor-srt")?.addEventListener("click", () => {
            const editorText = document.getElementById("srt-editor-textarea")?.value || "";
            if (!editorText.trim()) {
                alert("Trình Sửa Phụ Đề hiện tại đang rỗng. Hãy dán nội dung SRT hoặc tải file lên trước.");
                return;
            }
            ttsRecoverySrtContent = editorText;
            if (badge) {
                badge.style.display = "flex";
                badge.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/></svg> <span>Đã nạp SRT từ Trình Sửa Phụ Đề</span>`;
            }
        });

        document.getElementById("btn-start-tts-recovery")?.addEventListener("click", async () => {
            const folderPath = document.getElementById("tts-recovery-folder-select")?.value || "";
            const outFilename = document.getElementById("tts-recovery-output-filename")?.value || "tts_recovered_audio.mp3";
            const audioFormat = document.getElementById("tts-recovery-format-input")?.value || "mp3";

            if (!folderPath) {
                alert("Vui lòng chọn thư mục chứa audio con trong bước 1.");
                return;
            }
            if (!ttsRecoverySrtContent || !ttsRecoverySrtContent.trim()) {
                alert("Vui lòng nạp file SRT tương ứng trong bước 2.");
                return;
            }

            const btn = document.getElementById("btn-start-tts-recovery");
            const btnText = document.getElementById("btn-start-tts-recovery-text");
            if (btn) btn.disabled = true;
            if (btnText) btnText.textContent = "⏳ Đang ghép audio...";

            const progContainer = document.getElementById("tts-recovery-progress-container");
            const progPercent = document.getElementById("tts-recovery-progress-percent");
            const progBar = document.getElementById("tts-recovery-progress-bar-fill");
            const banner = document.getElementById("tts-recovery-message-banner");
            const resBox = document.getElementById("tts-recovery-result-box");

            if (progContainer) progContainer.style.display = "block";
            if (progPercent) progPercent.textContent = "0%";
            if (progBar) progBar.style.width = "0%";
            if (banner) {
                banner.className = "status-toast info";
                banner.textContent = "Khởi chạy quy trình ghép audio khôi phục...";
            }
            if (resBox) resBox.style.display = "none";

            try {
                const res = await fetch("/api/tts/merge-recovery/start", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        folder_path: folderPath,
                        srt_content: ttsRecoverySrtContent,
                        output_filename: outFilename,
                        audio_format: audioFormat
                    })
                });

                const data = await res.json();
                if (!res.ok) throw new Error(data.detail || "Lỗi khởi chạy ghép audio khôi phục");

                const jobId = data.job_id;

                if (ttsRecoveryPollTimer) clearInterval(ttsRecoveryPollTimer);

                ttsRecoveryPollTimer = setInterval(async () => {
                    try {
                        const stRes = await fetch(`/api/tts/status/${encodeURIComponent(jobId)}?_t=${Date.now()}`);
                        if (!stRes.ok) return;
                        const jobData = await stRes.json();
                        const st = (jobData.status || "").toLowerCase();
                        const pct = jobData.progress || 0;

                        if (progPercent) progPercent.textContent = `${pct}%`;
                        if (progBar) progBar.style.width = `${pct}%`;
                        if (banner) {
                            banner.textContent = jobData.message || "Đang ghép audio...";
                        }

                        if (st === "merged" || st === "completed" || jobData.saved_location) {
                            clearInterval(ttsRecoveryPollTimer);
                            if (btn) btn.disabled = false;
                            if (btnText) btnText.textContent = "Ghép Audio Riêng";
                            if (progPercent) progPercent.textContent = "100%";
                            if (progBar) progBar.style.width = "100%";
                            if (banner) {
                                banner.className = "status-toast success";
                                banner.textContent = `🎉 Ghép audio khôi phục thành công!`;
                            }
                            const finalFn = jobData.filename || outFilename;
                            if (resBox) {
                                resBox.style.display = "block";
                                resBox.innerHTML = `
                                    <div style="background:rgba(16,185,129,0.1); border:1px solid rgba(16,185,129,0.3); border-radius:8px; padding:12px; margin-top:8px;">
                                        <div style="font-weight:700; color:#34d399; margin-bottom:4px;">✅ Đã lưu file audio ghép thành công!</div>
                                        <div style="font-size:12px; color:#e2e8f0; font-family:monospace;">📁 Download/KAGEVIETSUB/${escapeHtml(finalFn)}</div>
                                    </div>
                                `;
                            }
                        } else if (st === "failed" || st === "error") {
                            clearInterval(ttsRecoveryPollTimer);
                            if (btn) btn.disabled = false;
                            if (btnText) btnText.textContent = "Thử Lại Ghép Audio";
                            if (banner) {
                                banner.className = "status-toast error";
                                banner.textContent = `❌ Lỗi: ${jobData.message || "Ghép audio thất bại"}`;
                            }
                        }
                    } catch (e) {
                        console.warn("Lỗi poll recovery job:", e);
                    }
                }, 800);

            } catch (err) {
                if (btn) btn.disabled = false;
                if (btnText) btnText.textContent = "Thử Lại Ghép Audio";
                if (banner) {
                    banner.className = "status-toast error";
                    banner.textContent = `❌ Lỗi: ${err.message}`;
                }
            }
        });
    }

    let downloaderJobs = [];
    let downloaderFilter = "all";
    let downloaderPollInterval = null;

    async function checkDownloaderReadiness() {
        const alertBox = document.getElementById("downloader-alert-box");
        if (!alertBox) return;

        try {
            const res = await fetch("/api/downloader/ready");
            if (!res.ok) return;
            const data = await res.json();

            if (!data.ready) {
                let msg = `<div style="font-weight:700; margin-bottom:4px; color:#f87171;">⚠️ Cảnh báo: Hệ thống chưa sẵn sàng tải video</div>`;
                if (!data.ytdlp_available) {
                    msg += `<div style="color:#cbd5e1; margin-bottom:4px;">• <b>yt-dlp</b> chưa được cài đặt trong môi trường. Cài đặt nhanh: <code>pip install -U yt-dlp</code> hoặc <code>pkg install python-pip && pip install yt-dlp</code> trên Termux.</div>`;
                }
                if (!data.ffmpeg_available) {
                    msg += `<div style="color:#cbd5e1; margin-bottom:4px;">• <b>FFmpeg / ffprobe</b> chưa có sẵn để ghép video + audio và kiểm tra file. Cài đặt: <code>pkg install ffmpeg</code> (Termux) hoặc cài FFmpeg vào PATH hệ điều hành.</div>`;
                }
                alertBox.innerHTML = msg;
                alertBox.style.display = "block";
                alertBox.style.background = "rgba(239, 68, 68, 0.12)";
                alertBox.style.border = "1px solid rgba(239, 68, 68, 0.3)";
            } else {
                alertBox.style.display = "none";
            }
        } catch (e) {
            console.warn("checkDownloaderReadiness error:", e);
        }
    }

    async function fetchDownloaderStatus() {
        try {
            const res = await fetch("/api/downloader/status");
            if (!res.ok) return;
            const data = await res.json();
            downloaderJobs = data.jobs || [];
            renderDownloaderJobs();

            const hasActive = downloaderJobs.some(j => j.status === "DOWNLOADING" || j.status === "CHECKING" || j.status === "QUEUED");
            if (hasActive) {
                if (!downloaderPollInterval) {
                    downloaderPollInterval = setInterval(fetchDownloaderStatus, 1200);
                }
            } else {
                if (downloaderPollInterval) {
                    clearInterval(downloaderPollInterval);
                    downloaderPollInterval = null;
                }
            }
        } catch (e) {
            console.warn("fetchDownloaderStatus error:", e);
        }
    }

    function formatBytes(bytes) {
        if (!bytes || bytes === 0) return "0 B";
        const k = 1024;
        const dm = 1;
        const sizes = ["B", "KB", "MB", "GB", "TB"];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + " " + sizes[i];
    }

    function formatSpeed(bytesPerSec) {
        if (!bytesPerSec || bytesPerSec === 0) return "0 KB/s";
        return formatBytes(bytesPerSec) + "/s";
    }

    function formatDuration(sec) {
        if (!sec || isNaN(sec) || sec <= 0) return "";
        const m = Math.floor(sec / 60);
        const s = Math.floor(sec % 60);
        return `${m}:${s < 10 ? "0" : ""}${s}`;
    }

    function getPlatformBadge(platform) {
        const p = (platform || "OTHER").toUpperCase();
        if (p === "BILIBILI") return `<span class="dl-platform-tag bilibili">Bilibili</span>`;
        if (p === "DOUYIN") return `<span class="dl-platform-tag douyin">Douyin</span>`;
        if (p === "TIKTOK") return `<span class="dl-platform-tag tiktok">TikTok</span>`;
        if (p === "YOUTUBE") return `<span class="dl-platform-tag youtube">YouTube</span>`;
        return `<span class="dl-platform-tag" style="background:rgba(148,163,184,0.12); color:#94a3b8; border:1px solid rgba(148,163,184,0.25);">Khác</span>`;
    }

    function getStatusBadge(status) {
        switch (status) {
            case "QUEUED":
                return `<span class="badge" style="background:rgba(234,179,8,0.12); color:#facc15; border:1px solid rgba(234,179,8,0.25); font-size:10.5px; padding:2px 7px;">⏳ Chờ tải</span>`;
            case "CHECKING":
                return `<span class="badge" style="background:rgba(59,130,246,0.12); color:#60a5fa; border:1px solid rgba(59,130,246,0.25); font-size:10.5px; padding:2px 7px;">🔍 Phân tích</span>`;
            case "DOWNLOADING":
                return `<span class="badge" style="background:rgba(6,182,212,0.12); color:#22d3ee; border:1px solid rgba(6,182,212,0.25); font-size:10.5px; padding:2px 7px;"><span class="pulse-dot" style="display:inline-block; margin-right:4px;"></span>Đang tải</span>`;
            case "COMPLETED":
                return `<span class="badge" style="background:rgba(16,185,129,0.12); color:#34d399; border:1px solid rgba(16,185,129,0.25); font-size:10.5px; padding:2px 7px;">✓ Hoàn thành</span>`;
            case "ERROR":
                return `<span class="badge" style="background:rgba(239,68,68,0.12); color:#f87171; border:1px solid rgba(239,68,68,0.25); font-size:10.5px; padding:2px 7px;">✕ Lỗi</span>`;
            case "CANCELLED":
                return `<span class="badge" style="background:rgba(148,163,184,0.12); color:#94a3b8; border:1px solid rgba(148,163,184,0.25); font-size:10.5px; padding:2px 7px;">Đã hủy</span>`;
            default:
                return `<span class="badge" style="background:rgba(148,163,184,0.12); color:#94a3b8; border:1px solid rgba(148,163,184,0.25); font-size:10.5px; padding:2px 7px;">Sẵn sàng</span>`;
        }
    }

    const expandedJobIds = new Set();
    const autoExpandedJobIds = new Set();

    function getStatusIconSvg(status) {
        switch (status) {
            case "QUEUED":
            case "PENDING":
                return `<div class="downloader-video-status-icon pending" title="Đang chờ trong hàng đợi">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                </div>`;
            case "CHECKING":
                return `<div class="downloader-video-status-icon checking" title="Đang phân tích link video">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                </div>`;
            case "DOWNLOADING":
                return `<div class="downloader-video-status-icon downloading" title="Đang tải dữ liệu">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>
                </div>`;
            case "FINALIZING":
            case "MERGING":
            case "VERIFYING":
                return `<div class="downloader-video-status-icon processing" title="Đang xử lý media & gộp file">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
                </div>`;
            case "COMPLETED":
                return `<div class="downloader-video-status-icon completed" title="Hoàn thành xuất sắc">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                </div>`;
            case "ERROR":
            case "FAILED":
                return `<div class="downloader-video-status-icon failed" title="Tải thất bại">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                </div>`;
            case "CANCELLED":
            case "STOPPED":
            default:
                return `<div class="downloader-video-status-icon stopped" title="Đã dừng tác vụ">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect width="14" height="14" x="5" y="5" rx="2"/></svg>
                </div>`;
        }
    }

    function buildJobLogText(job) {
        const lines = [];
        const timeStr = job.created_at ? new Date(job.created_at * 1000).toLocaleTimeString() : new Date().toLocaleTimeString();
        const jobIdStr = job.job_id || job.id || 'N/A';
        lines.push(`[${timeStr}] ID Tác Vụ: ${jobIdStr}`);
        lines.push(`[${timeStr}] Trang Web: ${(job.platform || 'General').toUpperCase()}`);
        lines.push(`[${timeStr}] Liên Kết Gốc: ${job.url || job.original_url || ''}`);
        lines.push(`[${timeStr}] Tiêu Đề: ${job.title || 'Video #' + jobIdStr.slice(-4)}`);
        lines.push(`[${timeStr}] Thiết Lập: Định dạng ${job.format || 'MP4'} | Độ phân giải ${job.resolution || 'Auto'} | Thumbnail ${job.download_thumbnail ? 'BẬT' : 'TẮT'}`);

        if (job.status === "DOWNLOADING") {
            const pct = Math.min(100, Math.max(0, job.progress_percent || 0)).toFixed(1);
            lines.push(`[${timeStr}] Tiến Trình Tải: ${pct}% | Tốc Độ: ${job.speed_str || formatSpeed(job.speed_bytes)} | ETA: ${job.eta_str || (job.eta_seconds ? job.eta_seconds + 's' : '...')}`);
        } else if (job.status === "VERIFYING" || job.status === "CHECKING" || job.status === "MERGING" || job.status === "FINALIZING") {
            lines.push(`[${timeStr}] Đang thực hiện xử lý media & gộp audio/video qua FFmpeg...`);
        } else if (job.status === "COMPLETED") {
            const compTime = job.completed_at ? new Date(job.completed_at * 1000).toLocaleTimeString() : timeStr;
            lines.push(`[${compTime}] ✓ HOÀN THÀNH XUẤT SẮC!`);
            if (job.output_filename) lines.push(`[${compTime}] File Đầu Ra: ${job.output_filename}`);
            if (job.destination_path || job.output_path) lines.push(`[${compTime}] Vị Trí Lưu: ${job.destination_path || job.output_path}`);
        } else if (job.status === "ERROR" || job.status === "FAILED") {
            lines.push(`[${timeStr}] ⚠️ LỖI THỰC TẾ DƯỚI ENGINE BACKEND:`);
            lines.push(`${job.error_message || job.error || 'Lỗi không xác định.'}`);
        } else if (job.status === "CANCELLED" || job.status === "STOPPED") {
            lines.push(`[${timeStr}] 🛑 Đã dừng tác vụ bởi người dùng.`);
        } else {
            lines.push(`[${timeStr}] Trạng thái hiện tại: ${job.status}`);
        }

        if (job.log_preview) {
            lines.push(`\n--- CHI TIẾT NHẬT KÝ TỪ YT-DLP ---`);
            lines.push(job.log_preview);
        }
        return lines.join('\n');
    }

    function copyJobLogToClipboard(jobId) {
        const job = downloaderJobs.find(j => (j.job_id === jobId || j.id === jobId));
        if (!job) return;
        const logText = buildJobLogText(job);
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(logText).then(() => {
                showToast("Đã sao chép nhật ký tác vụ vào bộ nhớ tạm!");
            }).catch(() => {
                fallbackCopy(logText);
            });
        } else {
            fallbackCopy(logText);
        }
    }

    function fallbackCopy(text) {
        const txt = document.createElement("textarea");
        txt.value = text;
        document.body.appendChild(txt);
        txt.select();
        document.execCommand("copy");
        document.body.removeChild(txt);
        showToast("Đã sao chép nhật ký tác vụ!");
    }

    function showJobReportModal(jobId) {
        const job = downloaderJobs.find(j => (j.job_id === jobId || j.id === jobId));
        if (!job) return;
        const modal = document.getElementById("downloader-report-modal");
        const contentEl = document.getElementById("dl-report-content");
        if (!modal || !contentEl) return;

        contentEl.textContent = buildJobLogText(job);
        modal.style.display = "flex";

        const btnCopy = document.getElementById("btn-copy-dl-report");
        if (btnCopy) {
            btnCopy.onclick = () => {
                copyJobLogToClipboard(jobId);
            };
        }
    }

    async function retryDownloaderJob(jobId) {
        try {
            const res = await fetch(`/api/downloader/retry/${jobId}`, { method: "POST" });
            if (res.ok) {
                showToast("Đã gửi yêu cầu thử lại tác vụ!");
                expandedJobIds.add(jobId);
                fetchDownloaderStatus();
            } else {
                showToast("Khởi chạy lại thất bại.", "error");
            }
        } catch (e) {
            console.error("retryDownloaderJob error:", e);
            showToast("Không thể kết nối máy chủ.", "error");
        }
    }

    function getJobRenderData(job) {
        const isCompleted = job.status === "COMPLETED";
        const isError = job.status === "ERROR" || job.status === "FAILED";
        const isRunning = job.status === "DOWNLOADING" || job.status === "CHECKING" || job.status === "QUEUED" || job.status === "VERIFYING" || job.status === "MERGING";
        const progressPct = Math.min(100, Math.max(0, job.progress_percent || job.progress || 0)).toFixed(1);
        const progressRatio = (Math.min(100, Math.max(0, job.progress_percent || job.progress || 0)) / 100).toFixed(4);

        let statusText = "";
        let metricsText = "";
        let fillClass = "pending";
        let cardStatusClass = "";

        if (job.status === "DOWNLOADING") {
            statusText = `<span style="color:#22d3ee;">Đang tải · ${progressPct}%</span>`;
            metricsText = `<span>${job.speed_str || formatSpeed(job.speed_bytes)} · ETA ${job.eta_str || (job.eta_seconds ? job.eta_seconds + 's' : '...')}</span><span>${job.downloaded_bytes ? formatBytes(job.downloaded_bytes) : '0 B'} / ${job.total_bytes ? formatBytes(job.total_bytes) : '...'}</span>`;
            fillClass = "downloading";
            cardStatusClass = "status-downloading";
        } else if (job.status === "CHECKING" || job.status === "QUEUED") {
            statusText = `<span style="color:#facc15;">${job.status === 'CHECKING' ? 'Đang phân tích link video...' : 'Đang chờ trong hàng đợi...'}</span>`;
            metricsText = `<span>Phân tích định dạng & metadata...</span><span>${progressPct}%</span>`;
            fillClass = "pending";
        } else if (job.status === "VERIFYING" || job.status === "MERGING" || job.status === "FINALIZING") {
            statusText = `<span style="color:#c084fc;">Đang gộp & kiểm tra media (FFprobe)...</span>`;
            metricsText = `<span>Gộp luồng Audio / Video</span><span>100%</span>`;
            fillClass = "downloading";
            cardStatusClass = "status-downloading";
        } else if (isCompleted) {
            statusText = `<span style="color:#34d399;">✓ Hoàn thành</span>`;
            metricsText = `<span>${escapeHtml(job.output_filename || 'video.mp4')} (${job.resolution || 'Auto'})</span><span>${job.total_bytes ? formatBytes(job.total_bytes) : '100%'}</span>`;
            fillClass = "completed";
            cardStatusClass = "status-completed";
        } else if (isError) {
            statusText = `<span style="color:#f87171;">! Tải thất bại</span>`;
            metricsText = `<span>Có lỗi xảy ra khi tải</span>`;
            fillClass = "failed";
            cardStatusClass = "status-failed";
        } else {
            statusText = `<span style="color:#94a3b8;">Đã dừng</span>`;
            metricsText = `<span>Tác vụ đã hủy</span>`;
            fillClass = "pending";
        }

        return {
            isCompleted,
            isError,
            isRunning,
            progressPct,
            progressRatio,
            statusText,
            metricsText,
            fillClass,
            cardStatusClass
        };
    }

    function buildActionsHtml(job, renderData) {
        const jobId = job.job_id || job.id;
        let btns = "";
        if (renderData.isError) {
            btns = `
                <button type="button" class="downloader-btn downloader-btn-copy-log btn-dl-copy-log" data-job-id="${escapeHtml(jobId)}" title="Sao chép nhật ký">
                    <span>📋 Sao chép nhật ký</span>
                </button>
                <button type="button" class="downloader-btn downloader-btn-report btn-dl-report" data-job-id="${escapeHtml(jobId)}" title="Xem báo cáo lỗi chi tiết">
                    <span>⚠️ Báo cáo lỗi</span>
                </button>
                <button type="button" class="downloader-btn downloader-btn-retry btn-dl-retry" data-job-id="${escapeHtml(jobId)}" title="Thử lại tác vụ">
                    <span>↻ Thử lại</span>
                </button>
            `;
        } else if (renderData.isCompleted) {
            btns = `
                <button type="button" class="downloader-btn downloader-btn-save btn-dl-save" onclick="event.preventDefault(); window.triggerSafeFileDownload('/api/downloader/download/${encodeURIComponent(jobId)}', '${escapeHtml(job.filename || 'media')}')" title="Tải file media về máy">
                    <span style="color:#34d399; font-weight:600;">⬇ Tải về máy</span>
                </button>
                <button type="button" class="downloader-btn downloader-btn-copy-log btn-dl-copy-log" data-job-id="${escapeHtml(jobId)}" title="Sao chép nhật ký">
                    <span>📋 Nhật ký</span>
                </button>
                <button type="button" class="downloader-btn downloader-btn-start btn-dl-start" data-job-id="${escapeHtml(jobId)}" title="Tải lại video này">
                    <span>↻ Tải lại</span>
                </button>
            `;
        } else if (renderData.isRunning) {
            btns = `
                <button type="button" class="downloader-btn downloader-btn-copy-log btn-dl-copy-log" data-job-id="${escapeHtml(jobId)}" title="Sao chép nhật ký">
                    <span>📋 Sao chép nhật ký</span>
                </button>
                <button type="button" class="downloader-btn downloader-btn-cancel btn-dl-cancel" data-job-id="${escapeHtml(jobId)}" title="Hủy tác vụ">
                    <span>⏹ Dừng</span>
                </button>
            `;
        } else {
            btns = `
                <button type="button" class="downloader-btn downloader-btn-copy-log btn-dl-copy-log" data-job-id="${escapeHtml(jobId)}" title="Sao chép nhật ký">
                    <span>📋 Sao chép nhật ký</span>
                </button>
                <button type="button" class="downloader-btn downloader-btn-start btn-dl-start" data-job-id="${escapeHtml(jobId)}" title="Bắt đầu tải">
                    <span>▶ Tải</span>
                </button>
            `;
        }
        return btns + `
            <button type="button" class="downloader-btn downloader-btn-delete btn-dl-delete" data-job-id="${escapeHtml(jobId)}" title="Xóa khỏi hàng đợi">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/></svg>
            </button>
        `;
    }

    function createCardDOMNode(job, jobId, isExpanded) {
        const renderData = getJobRenderData(job);
        const titleText = job.title ? job.title : ("Video #" + jobId.slice(-4));

        let thumbnailBlock = "";
        if (job.download_thumbnail || job.thumbnail_url) {
            if (job.thumbnail_url) {
                thumbnailBlock = `
                    <div class="downloader-video-thumb">
                        <img src="${escapeHtml(job.thumbnail_url)}" alt="thumb" onerror="this.parentElement.style.display='none'">
                        ${job.duration ? `<span class="downloader-video-thumb-duration">${formatDuration(job.duration)}</span>` : ""}
                    </div>
                `;
            } else {
                thumbnailBlock = `
                    <div class="downloader-video-thumb">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#475569" stroke-width="1.5"><polygon points="23 7 16 12 23 17 23 7"/><rect width="14" height="14" x="1" y="5" rx="2" ry="2"/></svg>
                        ${job.duration ? `<span class="downloader-video-thumb-duration">${formatDuration(job.duration)}</span>` : ""}
                    </div>
                `;
            }
        }

        let errBoxHtml = "";
        if (renderData.isError && (job.error_message || job.error)) {
            errBoxHtml = `<div class="downloader-video-error-box">⚠️ ${escapeHtml(job.error_message || job.error)}</div>`;
        }

        let destBoxHtml = "";
        if (renderData.isCompleted && (job.destination_path || job.output_path)) {
            destBoxHtml = `<div class="downloader-video-dest-box"><span>📁 Vị trí lưu: <code>${escapeHtml(job.destination_path || job.output_path)}</code></span></div>`;
        }

        const cardEl = document.createElement("div");
        cardEl.className = `downloader-video-card ${renderData.cardStatusClass} ${isExpanded ? 'expanded' : ''}`;
        cardEl.setAttribute("data-job-id", jobId);
        cardEl.setAttribute("data-status", job.status);

        cardEl.innerHTML = `
            <div class="downloader-video-header">
                <div class="downloader-video-header-left">
                    <div class="downloader-status-icon-wrapper">${getStatusIconSvg(job.status)}</div>
                    <div class="downloader-video-title-area">
                        <div class="downloader-video-title" title="${escapeHtml(titleText)}">
                            ${escapeHtml(titleText)}
                        </div>
                        <div class="downloader-video-meta-row">
                            ${getPlatformBadge(job.platform)}
                            <div class="downloader-video-url" title="${escapeHtml(job.original_url || job.url)}">
                                ${escapeHtml(job.original_url || job.url)}
                            </div>
                        </div>
                    </div>
                </div>
                <button type="button" class="downloader-video-toggle-btn btn-dl-toggle" data-job-id="${escapeHtml(jobId)}" title="${isExpanded ? 'Thu gọn' : 'Mở rộng chi tiết'}">
                    ${isExpanded ? '⌃' : '⌄'}
                </button>
            </div>

            <div class="downloader-video-body">
                ${thumbnailBlock}
                <div class="downloader-video-status-block">
                    <div class="downloader-video-status-text">
                        ${renderData.statusText}
                    </div>
                    <div class="downloader-video-progress-track">
                        <div class="downloader-video-progress-fill ${renderData.fillClass}" style="transform: scaleX(${renderData.progressRatio});"></div>
                    </div>
                    <div class="downloader-video-metrics-row">
                        ${renderData.metricsText}
                    </div>
                </div>
            </div>

            ${errBoxHtml}
            ${destBoxHtml}

            <div class="downloader-video-details">
                <div class="downloader-video-opts-row">
                    <div style="display: flex; align-items: center; gap: 4px;">
                        <span style="font-size: 11px; color: #94a3b8;">Định dạng:</span>
                        <select class="dl-opt-select dl-opt-format" data-job-id="${escapeHtml(jobId)}" ${renderData.isRunning ? "disabled" : ""}>
                            <option value="MP4" ${job.format === "MP4" ? "selected" : ""}>MP4</option>
                            <option value="MP3" ${job.format === "MP3" ? "selected" : ""}>MP3 (Audio)</option>
                        </select>
                    </div>
                    <div style="display: flex; align-items: center; gap: 4px;">
                        <span style="font-size: 11px; color: #94a3b8;">Chất lượng:</span>
                        <select class="dl-opt-select dl-opt-resolution" data-job-id="${escapeHtml(jobId)}" ${renderData.isRunning ? "disabled" : ""}>
                            <option value="Auto" ${job.resolution === "Auto" ? "selected" : ""}>Tự động</option>
                            <option value="1080p" ${job.resolution === "1080p" ? "selected" : ""}>1080p</option>
                            <option value="720p" ${job.resolution === "720p" ? "selected" : ""}>720p</option>
                            <option value="480p" ${job.resolution === "480p" ? "selected" : ""}>480p</option>
                        </select>
                    </div>
                    <label style="display: inline-flex; align-items: center; gap: 4px; font-size: 11px; color: #94a3b8; cursor: pointer;">
                        <input type="checkbox" class="dl-opt-thumb" data-job-id="${escapeHtml(jobId)}" ${job.download_thumbnail ? "checked" : ""} ${renderData.isRunning ? "disabled" : ""} style="accent-color: #22d3ee; width: 13px; height: 13px;">
                        <span>Thumbnail</span>
                    </label>
                </div>
                <div class="downloader-video-log-console">${escapeHtml(buildJobLogText(job))}</div>
            </div>

            <div class="downloader-video-actions">
                ${buildActionsHtml(job, renderData)}
            </div>
        `;

        return cardEl;
    }

    function updateCardDOMNode(cardEl, job, jobId, isExpanded) {
        const renderData = getJobRenderData(job);

        const fillEl = cardEl.querySelector(".downloader-video-progress-fill");
        if (fillEl) {
            fillEl.style.transform = `scaleX(${renderData.progressRatio})`;
            if (!fillEl.classList.contains(renderData.fillClass)) {
                fillEl.className = `downloader-video-progress-fill ${renderData.fillClass}`;
            }
        }

        const statusTextEl = cardEl.querySelector(".downloader-video-status-text");
        if (statusTextEl && statusTextEl.innerHTML !== renderData.statusText) {
            statusTextEl.innerHTML = renderData.statusText;
        }

        const metricsTextEl = cardEl.querySelector(".downloader-video-metrics-row");
        if (metricsTextEl && metricsTextEl.innerHTML !== renderData.metricsText) {
            metricsTextEl.innerHTML = renderData.metricsText;
        }

        const prevStatus = cardEl.getAttribute("data-status");
        if (prevStatus !== job.status) {
            cardEl.setAttribute("data-status", job.status);

            const iconWrapper = cardEl.querySelector(".downloader-status-icon-wrapper");
            if (iconWrapper) iconWrapper.innerHTML = getStatusIconSvg(job.status);

            cardEl.className = `downloader-video-card ${renderData.cardStatusClass} ${isExpanded ? 'expanded' : ''}`;

            const actionsEl = cardEl.querySelector(".downloader-video-actions");
            if (actionsEl) actionsEl.innerHTML = buildActionsHtml(job, renderData);

            cardEl.querySelectorAll(".dl-opt-select, .dl-opt-thumb").forEach(opt => {
                opt.disabled = renderData.isRunning;
            });
        }

        const currentlyExpanded = cardEl.classList.contains("expanded");
        if (currentlyExpanded !== isExpanded) {
            cardEl.classList.toggle("expanded", isExpanded);
            const toggleBtn = cardEl.querySelector(".btn-dl-toggle");
            if (toggleBtn) {
                toggleBtn.innerHTML = isExpanded ? "⌃" : "⌄";
                toggleBtn.title = isExpanded ? "Thu gọn" : "Mở rộng chi tiết";
            }
        }

        let errBox = cardEl.querySelector(".downloader-video-error-box");
        if (renderData.isError && (job.error_message || job.error)) {
            const errHtml = `⚠️ ${escapeHtml(job.error_message || job.error)}`;
            if (!errBox) {
                errBox = document.createElement("div");
                errBox.className = "downloader-video-error-box";
                const body = cardEl.querySelector(".downloader-video-body");
                if (body) body.after(errBox);
            }
            if (errBox.innerHTML !== errHtml) errBox.innerHTML = errHtml;
        } else if (errBox) {
            errBox.remove();
        }

        let destBox = cardEl.querySelector(".downloader-video-dest-box");
        if (renderData.isCompleted && (job.destination_path || job.output_path)) {
            const destPath = job.destination_path || job.output_path;
            const destHtml = `<span>📁 Vị trí lưu: <code>${escapeHtml(destPath)}</code></span>`;
            if (!destBox) {
                destBox = document.createElement("div");
                destBox.className = "downloader-video-dest-box";
                const body = cardEl.querySelector(".downloader-video-body");
                if (body) body.after(destBox);
            }
            if (destBox.innerHTML !== destHtml) destBox.innerHTML = destHtml;
        } else if (destBox) {
            destBox.remove();
        }

        const logConsole = cardEl.querySelector(".downloader-video-log-console");
        if (logConsole) {
            const newLog = buildJobLogText(job);
            if (logConsole.textContent !== newLog) {
                logConsole.textContent = newLog;
            }
        }
    }

    function renderDownloaderJobs() {
        const container = document.getElementById("downloader-jobs-container");
        if (!container) return;

        const totalCount = downloaderJobs.length;
        const downloadingCount = downloaderJobs.filter(j => j.status === "DOWNLOADING" || j.status === "CHECKING" || j.status === "QUEUED" || j.status === "VERIFYING" || j.status === "MERGING").length;
        const completedCount = downloaderJobs.filter(j => j.status === "COMPLETED").length;
        const errorCount = downloaderJobs.filter(j => j.status === "ERROR" || j.status === "FAILED").length;

        const totalEl = document.getElementById("downloader-job-count");
        if (totalEl && totalEl.innerText != totalCount) totalEl.innerText = totalCount;
        const cntAll = document.getElementById("dl-cnt-all");
        if (cntAll && cntAll.innerText != totalCount) cntAll.innerText = totalCount;
        const cntDl = document.getElementById("dl-cnt-downloading");
        if (cntDl && cntDl.innerText != downloadingCount) cntDl.innerText = downloadingCount;
        const cntComp = document.getElementById("dl-cnt-completed");
        if (cntComp && cntComp.innerText != completedCount) cntComp.innerText = completedCount;
        const cntErr = document.getElementById("dl-cnt-error");
        if (cntErr && cntErr.innerText != errorCount) cntErr.innerText = errorCount;

        let filtered = downloaderJobs;
        if (downloaderFilter === "downloading") {
            filtered = downloaderJobs.filter(j => j.status === "DOWNLOADING" || j.status === "CHECKING" || j.status === "QUEUED" || j.status === "VERIFYING" || j.status === "MERGING");
        } else if (downloaderFilter === "completed") {
            filtered = downloaderJobs.filter(j => j.status === "COMPLETED");
        } else if (downloaderFilter === "error") {
            filtered = downloaderJobs.filter(j => j.status === "ERROR" || j.status === "FAILED");
        }

        if (filtered.length === 0) {
            if (!container.querySelector("#downloader-empty-state")) {
                container.innerHTML = `
                    <div id="downloader-empty-state" class="dl-empty-state">
                        <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="#334155" stroke-width="1.5" style="margin-bottom: 10px; display: inline-block;"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>
                        <div class="dl-empty-title">${downloaderJobs.length === 0 ? "Chưa có liên kết nào trong hàng đợi." : "Không có tác vụ nào trong bộ lọc này"}</div>
                        <div class="dl-empty-sub">Dán liên kết từ Bilibili, Douyin, TikTok hoặc YouTube vào ô phía trên để bắt đầu.</div>
                    </div>
                `;
            }
            return;
        }

        const emptyState = container.querySelector("#downloader-empty-state");
        if (emptyState) emptyState.remove();

        const validJobIds = new Set(filtered.map(j => j.job_id || j.id));

        const existingCards = container.querySelectorAll(".downloader-video-card");
        existingCards.forEach(card => {
            const id = card.getAttribute("data-job-id");
            if (!validJobIds.has(id)) {
                card.remove();
            }
        });

        filtered.forEach((job, index) => {
            const jobId = job.job_id || job.id;

            if (!autoExpandedJobIds.has(jobId)) {
                if (job.status === "ERROR" || job.status === "FAILED") {
                    expandedJobIds.add(jobId);
                } else if (job.status === "DOWNLOADING" || job.status === "CHECKING") {
                    expandedJobIds.add(jobId);
                } else if (job.status === "COMPLETED") {
                    expandedJobIds.delete(jobId);
                }
                autoExpandedJobIds.add(jobId);
            }

            const isExpanded = expandedJobIds.has(jobId);

            let cardEl = null;
            const selectorId = (typeof CSS !== "undefined" && CSS.escape) ? CSS.escape(jobId) : jobId;
            try {
                cardEl = container.querySelector(`.downloader-video-card[data-job-id="${selectorId}"]`);
            } catch (e) {
                existingCards.forEach(c => {
                    if (c.getAttribute("data-job-id") === jobId) cardEl = c;
                });
            }

            if (!cardEl) {
                cardEl = createCardDOMNode(job, jobId, isExpanded);
            } else {
                updateCardDOMNode(cardEl, job, jobId, isExpanded);
            }

            const currentAtChild = container.children[index];
            if (currentAtChild !== cardEl) {
                container.insertBefore(cardEl, currentAtChild || null);
            }
        });
    }

    function initDownloaderController() {
        const filterBtns = {
            all: document.getElementById("btn-dl-filter-all"),
            downloading: document.getElementById("btn-dl-filter-downloading"),
            completed: document.getElementById("btn-dl-filter-completed"),
            error: document.getElementById("btn-dl-filter-error")
        };

        Object.keys(filterBtns).forEach(key => {
            const btn = filterBtns[key];
            if (btn) {
                btn.addEventListener("click", () => {
                    downloaderFilter = key;
                    Object.values(filterBtns).forEach(b => b?.classList.remove("active"));
                    btn.classList.add("active");
                    renderDownloaderJobs();
                });
            }
        });

        const urlsInput = document.getElementById("downloader-urls-input");
        const detectedCountEl = document.getElementById("dl-detected-count");
        function updateDetectedCount() {
            if (!urlsInput || !detectedCountEl) return;
            const text = urlsInput.value.trim();
            if (!text) {
                detectedCountEl.innerText = "0 link";
                return;
            }
            const lines = text.split("\n").map(l => l.trim()).filter(l => l.length > 0);
            detectedCountEl.innerText = `${lines.length} link`;
        }

        urlsInput?.addEventListener("input", updateDetectedCount);

        document.getElementById("btn-downloader-paste")?.addEventListener("click", async () => {
            try {
                const text = await navigator.clipboard.readText();
                if (text) {
                    const input = document.getElementById("downloader-urls-input");
                    if (input) {
                        input.value = (input.value ? input.value.trim() + "\n" : "") + text.trim();
                        updateDetectedCount();
                    }
                }
            } catch (e) {
                alert("Không thể đọc bộ nhớ tạm tự động. Vui lòng dán thủ công vào ô văn bản.");
            }
        });

        document.getElementById("btn-downloader-clear-input")?.addEventListener("click", () => {
            const input = document.getElementById("downloader-urls-input");
            if (input) {
                input.value = "";
                updateDetectedCount();
            }
        });

        document.getElementById("btn-downloader-check-links")?.addEventListener("click", async () => {
            const input = document.getElementById("downloader-urls-input");
            if (!input) return;
            const text = input.value.trim();
            if (!text) {
                alert("Vui lòng nhập ít nhất 1 liên kết video hoặc audio!");
                return;
            }

            const urls = text.split("\n").map(u => u.trim()).filter(u => u.length > 0);
            const defaultFormat = document.getElementById("downloader-default-format")?.value || "MP4";
            const defaultResolution = document.getElementById("downloader-default-resolution")?.value || "Auto";
            const defaultThumb = document.getElementById("downloader-default-thumb")?.checked || false;

            const checkBtn = document.getElementById("btn-downloader-check-links");
            if (checkBtn) {
                checkBtn.disabled = true;
                checkBtn.innerHTML = `<span>Đang phân tích...</span>`;
            }

            try {
                const res = await fetch("/api/downloader/check-links", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        urls: urls,
                        default_format: defaultFormat,
                        default_resolution: defaultResolution,
                        download_thumbnail: defaultThumb
                    })
                });

                if (!res.ok) {
                    const err = await res.json();
                    alert(err.detail || "Không thể phân tích liên kết.");
                } else {
                    input.value = "";
                    updateDetectedCount();
                    await fetchDownloaderStatus();
                }
            } catch (e) {
                alert("Lỗi khi kết nối đến máy chủ: " + e.message);
            } finally {
                if (checkBtn) {
                    checkBtn.disabled = false;
                    checkBtn.innerHTML = `
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
                        <span>Thêm vào hàng đợi</span>
                    `;
                }
            }
        });

        document.getElementById("btn-downloader-start-all")?.addEventListener("click", async () => {
            try {
                await fetch("/api/downloader/start", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({})
                });
                await fetchDownloaderStatus();
            } catch (e) {
                console.warn(e);
            }
        });

        document.getElementById("btn-downloader-stop-all")?.addEventListener("click", async () => {
            try {
                await fetch("/api/downloader/cancel-all", { method: "POST" });
                await fetchDownloaderStatus();
            } catch (e) {
                console.warn(e);
            }
        });

        document.getElementById("btn-downloader-refresh-list")?.addEventListener("click", () => {
            fetchDownloaderStatus();
            checkDownloaderReadiness();
        });

        document.getElementById("btn-downloader-clear-completed")?.addEventListener("click", async () => {
            const completed = downloaderJobs.filter(j => j.status === "COMPLETED" || j.status === "CANCELLED");
            for (const job of completed) {
                try {
                    await fetch(`/api/downloader/remove/${job.job_id}`, { method: "POST" });
                } catch (e) {}
            }
            await fetchDownloaderStatus();
        });

        const container = document.getElementById("downloader-jobs-container");
        if (container) {
            container.addEventListener("click", async (e) => {
                const toggleBtn = e.target.closest(".btn-dl-toggle");
                if (toggleBtn) {
                    const jobId = toggleBtn.getAttribute("data-job-id");
                    if (jobId) {
                        if (expandedJobIds.has(jobId)) {
                            expandedJobIds.delete(jobId);
                        } else {
                            expandedJobIds.add(jobId);
                        }
                        renderDownloaderJobs();
                    }
                    return;
                }

                const copyLogBtn = e.target.closest(".btn-dl-copy-log");
                if (copyLogBtn) {
                    const jobId = copyLogBtn.getAttribute("data-job-id");
                    if (jobId) copyJobLogToClipboard(jobId);
                    return;
                }

                const reportBtn = e.target.closest(".btn-dl-report");
                if (reportBtn) {
                    const jobId = reportBtn.getAttribute("data-job-id");
                    if (jobId) showJobReportModal(jobId);
                    return;
                }

                const retryBtn = e.target.closest(".btn-dl-retry");
                if (retryBtn) {
                    const jobId = retryBtn.getAttribute("data-job-id");
                    if (jobId) retryDownloaderJob(jobId);
                    return;
                }

                const startBtn = e.target.closest(".btn-dl-start");
                if (startBtn) {
                    const jobId = startBtn.getAttribute("data-job-id");
                    if (jobId) {
                        const job = downloaderJobs.find(j => (j.job_id === jobId || j.id === jobId));
                        try {
                            await fetch("/api/downloader/start", {
                                method: "POST",
                                headers: { "Content-Type": "application/json" },
                                body: JSON.stringify({
                                    job_id: jobId,
                                    format: job ? (job.format || job.selected_format) : undefined,
                                    resolution: job ? (job.resolution || job.selected_resolution) : undefined,
                                    download_thumbnail: job ? job.download_thumbnail : undefined
                                })
                            });
                            await fetchDownloaderStatus();
                        } catch (err) {}
                    }
                    return;
                }

                const cancelBtn = e.target.closest(".btn-dl-cancel");
                if (cancelBtn) {
                    const jobId = cancelBtn.getAttribute("data-job-id");
                    if (jobId) {
                        try {
                            await fetch(`/api/downloader/cancel/${jobId}`, { method: "POST" });
                            await fetchDownloaderStatus();
                        } catch (err) {}
                    }
                    return;
                }

                const delBtn = e.target.closest(".btn-dl-delete");
                if (delBtn) {
                    const jobId = delBtn.getAttribute("data-job-id");
                    if (jobId) {
                        try {
                            await fetch(`/api/downloader/remove/${jobId}`, { method: "POST" });
                            await fetchDownloaderStatus();
                        } catch (err) {}
                    }
                    return;
                }
            });

            container.addEventListener("change", async (e) => {
                const formatSelect = e.target.closest(".dl-opt-format");
                if (formatSelect) {
                    const jobId = formatSelect.getAttribute("data-job-id");
                    const job = downloaderJobs.find(j => (j.job_id === jobId || j.id === jobId));
                    if (job) {
                        job.format = formatSelect.value;
                        job.selected_format = formatSelect.value;
                        try {
                            await fetch("/api/downloader/update", {
                                method: "POST",
                                headers: { "Content-Type": "application/json" },
                                body: JSON.stringify({ job_id: jobId, format: formatSelect.value })
                            });
                        } catch (err) {}
                    }
                    return;
                }

                const resSelect = e.target.closest(".dl-opt-resolution");
                if (resSelect) {
                    const jobId = resSelect.getAttribute("data-job-id");
                    const job = downloaderJobs.find(j => (j.job_id === jobId || j.id === jobId));
                    if (job) {
                        job.resolution = resSelect.value;
                        job.selected_resolution = resSelect.value;
                        try {
                            await fetch("/api/downloader/update", {
                                method: "POST",
                                headers: { "Content-Type": "application/json" },
                                body: JSON.stringify({ job_id: jobId, resolution: resSelect.value })
                            });
                        } catch (err) {}
                    }
                    return;
                }

                const thumbCheck = e.target.closest(".dl-opt-thumb");
                if (thumbCheck) {
                    const jobId = thumbCheck.getAttribute("data-job-id");
                    const job = downloaderJobs.find(j => (j.job_id === jobId || j.id === jobId));
                    if (job) {
                        job.download_thumbnail = thumbCheck.checked;
                        try {
                            await fetch("/api/downloader/update", {
                                method: "POST",
                                headers: { "Content-Type": "application/json" },
                                body: JSON.stringify({ job_id: jobId, download_thumbnail: thumbCheck.checked })
                            });
                        } catch (err) {}
                    }
                    return;
                }
            });
        }

        const closeReportBtn = document.getElementById("btn-close-dl-report-modal");
        const closeReportBtn2 = document.getElementById("btn-close-dl-report-modal-2");
        const reportModal = document.getElementById("downloader-report-modal");
        if (closeReportBtn && reportModal) {
            closeReportBtn.onclick = () => { reportModal.style.display = "none"; };
        }
        if (closeReportBtn2 && reportModal) {
            closeReportBtn2.onclick = () => { reportModal.style.display = "none"; };
        }
    }

    function escapeHtml(text) {
        if (!text) return "";
        return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
    }

    function checkUrlParamsOnLoad() {
        try {
            const params = new URLSearchParams(window.location.search);
            const jobId = params.get("job_id");
            const jobType = params.get("type");
            if (jobId) {
                setTimeout(() => {
                    handleGlobalJobCardClick(jobId, jobType);
                }, 300);
            }
        } catch(e) {}
    }

    // =========================================================================
    // 5. AI DỊCH SRT CONTROLLER (Multi-Model & DS2API Engine)
    // =========================================================================
    let srtTranslateInitialized = false;
    let activeTranslateJobId = null;
    let translatePollTimer = null;
    let lastTranslateJobData = null;
    let customApiPool = [];
    let ds2Accounts = [];
    let transActiveFilter = "all";
    let transSearchKeyword = "";

    const TRANSLATE_PROVIDERS = {
        ds2api: {
            name: "⚡ DS2API (DeepSeek Web Login)",
            models: ["deepseek-v4-flash", "deepseek-v4-flash-nothinking", "deepseek-v4-pro", "deepseek-chat", "deepseek-reasoner", "deepseek-coder"],
            defaultModel: "deepseek-v4-flash"
        },
        deepseek: {
            name: "DeepSeek API (Chính thức)",
            models: ["deepseek-chat", "deepseek-coder", "deepseek-reasoner"],
            defaultModel: "deepseek-chat"
        },
        gemini: {
            name: "Google Gemini API",
            models: ["gemini-2.5-flash", "gemini-2.0-flash", "gemini-1.5-flash", "gemini-1.5-pro"],
            defaultModel: "gemini-2.5-flash"
        },
        openai: {
            name: "OpenAI GPT",
            models: ["gpt-4o", "gpt-4o-mini", "gpt-4-turbo", "gpt-3.5-turbo"],
            defaultModel: "gpt-4o-mini"
        },
        claude: {
            name: "Anthropic Claude",
            models: ["claude-3-5-sonnet-20241022", "claude-3-5-haiku-20241022", "claude-3-opus-20240229"],
            defaultModel: "claude-3-5-haiku-20241022"
        },
        grok: {
            name: "xAI Grok",
            models: ["grok-2-latest", "grok-2-vision-1212", "grok-beta"],
            defaultModel: "grok-2-latest"
        }
    };

    function getDefaultPromptForLang(targetLang) {
        const langNames = {
            vi: "Tiếng Việt",
            en: "English",
            zh: "Chinese",
            ja: "Japanese",
            ko: "Korean"
        };
        const targetName = langNames[targetLang] || targetLang;
        return `Bạn là một chuyên gia biên dịch phụ đề phim ảnh xuất sắc.
Nhiệm vụ: Dịch chính xác từng dòng phụ đề sang ${targetName}.
Yêu cầu bắt buộc:
1. Giữ nguyên số lượng dòng và mã định danh [ID].
2. Ngôn ngữ dịch BẮT BUỘC phải là ${targetName} hoàn toàn tự nhiên, đúng ngữ cảnh điện ảnh.
3. Không thêm lời bình, không giải thích, chỉ trả về đúng định dạng yêu cầu.`;
    }

    function initSrtTranslateController() {
        if (srtTranslateInitialized) return;
        srtTranslateInitialized = true;

        // Load saved API pool from localStorage
        try {
            const savedPool = localStorage.getItem("kage_srt_api_pool");
            if (savedPool) {
                customApiPool = JSON.parse(savedPool);
            }
        } catch (e) {}

        const providerSelect = document.getElementById("trans-provider");
        const modelSelect = document.getElementById("trans-model");
        const ds2Panel = document.getElementById("trans-ds2api-panel");
        const standardPanel = document.getElementById("trans-standard-api-panel");
        const srtContent = document.getElementById("trans-srt-content");
        const statsEl = document.getElementById("trans-content-stats");
        const promptTextarea = document.getElementById("trans-user-prompt");
        const targetLangSelect = document.getElementById("trans-target-lang");
        const sourceLangSelect = document.getElementById("trans-source-lang");

        // 1. Populate Model dropdown based on Provider
        function updateModelDropdown() {
            const provider = providerSelect.value;
            const config = TRANSLATE_PROVIDERS[provider] || TRANSLATE_PROVIDERS.ds2api;
            modelSelect.innerHTML = "";
            config.models.forEach(m => {
                const opt = document.createElement("option");
                opt.value = m;
                opt.textContent = m;
                if (m === config.defaultModel) opt.selected = true;
                modelSelect.appendChild(opt);
            });

            if (provider === "ds2api") {
                if (ds2Panel) ds2Panel.style.display = "flex";
                if (standardPanel) standardPanel.style.display = "none";
                fetchDs2apiAccounts();
                fetchDs2apiStatus();
            } else {
                if (ds2Panel) ds2Panel.style.display = "none";
                if (standardPanel) standardPanel.style.display = "flex";
            }
        }

        if (providerSelect) {
            providerSelect.addEventListener("change", updateModelDropdown);
            updateModelDropdown();
        }

        // 2. Default Prompt setup
        if (promptTextarea && targetLangSelect) {
            promptTextarea.value = getDefaultPromptForLang(targetLangSelect.value);
            targetLangSelect.addEventListener("change", () => {
                promptTextarea.value = getDefaultPromptForLang(targetLangSelect.value);
            });
        }

        document.getElementById("btn-reset-trans-prompt")?.addEventListener("click", () => {
            if (promptTextarea && targetLangSelect) {
                promptTextarea.value = getDefaultPromptForLang(targetLangSelect.value);
                showToast("Đã khôi phục prompt mặc định", "success");
            }
        });

        // Prompt accordion toggle
        const togglePromptBtn = document.getElementById("btn-toggle-trans-prompt");
        const promptContainer = document.getElementById("trans-prompt-container");
        const promptChevron = document.getElementById("trans-prompt-chevron");
        if (togglePromptBtn && promptContainer) {
            togglePromptBtn.addEventListener("click", () => {
                const isHidden = promptContainer.style.display === "none";
                promptContainer.style.display = isHidden ? "block" : "none";
                if (promptChevron) {
                    promptChevron.textContent = isHidden ? "▲ Đóng" : "▼ Mở";
                }
            });
        }

        // 3. Stats updater for SRT Content
        function updateSrtStats() {
            if (!srtContent || !statsEl) return;
            const text = srtContent.value || "";
            const lines = text.split("\n").filter(l => l.trim().length > 0).length;
            const blocks = (text.match(/\d+\s*\n\s*\d{2}:\d{2}:\d{2}/g) || []).length;
            const chars = text.length;
            statsEl.textContent = `${lines} dòng • ${blocks || "0"} câu phụ đề • ${chars.toLocaleString()} ký tự`;
        }

        if (srtContent) {
            srtContent.addEventListener("input", updateSrtStats);
            updateSrtStats();
        }

        // 4. File Open & Sample buttons
        const fileInput = document.getElementById("trans-file-input");
        const openFileBtn = document.getElementById("btn-trans-open-file");
        if (openFileBtn && fileInput) {
            openFileBtn.addEventListener("click", () => fileInput.click());
            fileInput.addEventListener("change", (e) => {
                const file = e.target.files[0];
                if (!file) return;
                const reader = new FileReader();
                reader.onload = (evt) => {
                    srtContent.value = evt.target.result;
                    const filenameInput = document.getElementById("trans-filename");
                    if (filenameInput) {
                        const baseName = file.name.replace(/\.[^/.]+$/, "");
                        filenameInput.value = `${baseName}_VI.srt`;
                    }
                    updateSrtStats();
                    showToast(`Đã mở file: ${file.name}`, "success");
                };
                reader.readAsText(file, "UTF-8");
            });
        }

        document.getElementById("btn-trans-sample")?.addEventListener("click", () => {
            const sampleSrt = `1\n00:00:01,000 --> 00:00:03,500\n你好，欢迎来到这里。\n\n2\n00:00:04,000 --> 00:00:06,200\n今天我们要讨论一个重要的问题。\n\n3\n00:00:07,000 --> 00:00:10,000\n这是一段测试字幕，用于验证AI翻译效果。\n\n4\n00:00:11,500 --> 00:00:14,200\n希望大家都能获得良好的体验！`;
            if (srtContent) {
                srtContent.value = sampleSrt;
                updateSrtStats();
                showToast("Đã nạp phụ đề mẫu", "info");
            }
        });

        document.getElementById("btn-trans-clear")?.addEventListener("click", () => {
            if (srtContent) {
                srtContent.value = "";
                updateSrtStats();
                showToast("Đã xóa nội dung phụ đề", "info");
            }
        });

        // 5. API Key show/hide toggle
        const toggleKeyBtn = document.getElementById("btn-toggle-trans-key");
        const apiKeyInput = document.getElementById("trans-api-key");
        if (toggleKeyBtn && apiKeyInput) {
            toggleKeyBtn.addEventListener("click", () => {
                apiKeyInput.type = apiKeyInput.type === "password" ? "text" : "password";
            });
        }

        // 6. Check API Key
        document.getElementById("btn-check-trans-api")?.addEventListener("click", async () => {
            const key = apiKeyInput ? apiKeyInput.value.trim() : "";
            const provider = providerSelect.value;
            const model = modelSelect.value;
            const resultBox = document.getElementById("trans-api-check-result");

            if (!key) {
                showToast("Vui lòng nhập API Key để kiểm tra", "error");
                return;
            }

            if (resultBox) {
                resultBox.style.display = "block";
                resultBox.style.background = "rgba(99, 102, 241, 0.1)";
                resultBox.style.color = "#818cf8";
                resultBox.textContent = "⏳ Đang kết nối kiểm tra API key...";
            }

            try {
                const res = await fetch("/api/srt/translate/check-api", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ provider, api_key: key, model })
                });
                const data = await res.json();
                if (data.status === "ok" || data.success) {
                    if (resultBox) {
                        resultBox.style.background = "rgba(16, 185, 129, 0.15)";
                        resultBox.style.color = "#34d399";
                        resultBox.textContent = "✓ API Key hợp lệ và sẵn sàng hoạt động!";
                    }
                    showToast("API Key hợp lệ!", "success");
                } else {
                    if (resultBox) {
                        resultBox.style.background = "rgba(239, 68, 68, 0.15)";
                        resultBox.style.color = "#f87171";
                        resultBox.textContent = `⚠️ Lỗi: ${data.message || data.error || "Không thể kết nối"}`;
                    }
                    showToast("Kiểm tra API Key thất bại", "error");
                }
            } catch (err) {
                if (resultBox) {
                    resultBox.style.background = "rgba(239, 68, 68, 0.15)";
                    resultBox.style.color = "#f87171";
                    resultBox.textContent = `⚠️ Lỗi kết nối: ${err.message}`;
                }
            }
        });

        // 7. Add to Pool
        document.getElementById("btn-add-trans-pool")?.addEventListener("click", () => {
            const key = apiKeyInput ? apiKeyInput.value.trim() : "";
            const provider = providerSelect.value;
            const model = modelSelect.value;
            if (!key) {
                showToast("Vui lòng nhập API Key trước khi thêm vào Pool", "error");
                return;
            }
            const exists = customApiPool.some(p => p.api_key === key);
            if (exists) {
                showToast("API Key này đã có trong pool xoay tua", "info");
                return;
            }
            customApiPool.push({
                id: `pool_${Date.now()}`,
                provider,
                api_key: key,
                model
            });
            try {
                localStorage.setItem("kage_srt_api_pool", JSON.stringify(customApiPool));
            } catch (e) {}
            renderApiPool();
            showToast("Đã thêm API Key vào Pool xoay tua", "success");
            if (apiKeyInput) apiKeyInput.value = "";
        });

        function renderApiPool() {
            const listEl = document.getElementById("trans-pool-list");
            const countEl = document.getElementById("trans-pool-count");
            const modalTbody = document.getElementById("modal-pool-tbody");

            if (countEl) countEl.textContent = customApiPool.length;

            if (listEl) {
                if (customApiPool.length === 0) {
                    listEl.innerHTML = `<div style="font-size: 11px; color: #64748b; font-style: italic;">Chưa có API key phụ nào trong pool. Sẽ dùng cấu hình trực tiếp phía trên.</div>`;
                } else {
                    listEl.innerHTML = customApiPool.map((p, idx) => `
                        <div style="display: flex; justify-content: space-between; align-items: center; background: #0b0e17; border: 1px solid #1e2638; border-radius: 4px; padding: 4px 8px; font-size: 11px;">
                            <span style="color: #cbd5e1;"><strong style="color: #818cf8;">${p.provider.toUpperCase()}</strong>: ...${p.api_key.slice(-6)} (${p.model})</span>
                            <button type="button" class="btn-del-pool-item" data-idx="${idx}" style="background: none; border: none; color: #f87171; cursor: pointer; font-size: 12px;">✕</button>
                        </div>
                    `).join("");
                }
            }

            if (modalTbody) {
                if (customApiPool.length === 0) {
                    modalTbody.innerHTML = `<tr><td colspan="4" style="padding: 16px; text-align: center; color: #64748b;">Chưa có API key nào trong rotation pool.</td></tr>`;
                } else {
                    modalTbody.innerHTML = customApiPool.map((p, idx) => `
                        <tr style="border-bottom: 1px solid #1e2638;">
                            <td style="padding: 8px 10px; color: #818cf8; font-weight: 600;">${p.provider.toUpperCase()}</td>
                            <td style="padding: 8px 10px; font-family: var(--font-mono); color: #cbd5e1;">${p.api_key.slice(0, 4)}...${p.api_key.slice(-6)}</td>
                            <td style="padding: 8px 10px; color: #94a3b8;">${p.model}</td>
                            <td style="padding: 8px 10px; text-align: right;">
                                <button type="button" class="btn-del-pool-item" data-idx="${idx}" style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.2); color: #f87171; border-radius: 4px; padding: 2px 8px; font-size: 11px; cursor: pointer;">Xóa</button>
                            </td>
                        </tr>
                    `).join("");
                }
            }

            // Hook up delete buttons
            document.querySelectorAll(".btn-del-pool-item").forEach(btn => {
                btn.onclick = () => {
                    const idx = parseInt(btn.getAttribute("data-idx"), 10);
                    if (!isNaN(idx) && idx >= 0 && idx < customApiPool.length) {
                        customApiPool.splice(idx, 1);
                        try {
                            localStorage.setItem("kage_srt_api_pool", JSON.stringify(customApiPool));
                        } catch (e) {}
                        renderApiPool();
                        showToast("Đã xóa API Key khỏi pool", "info");
                    }
                };
            });
        }

        renderApiPool();

        // 8. Modals (Pool Modal & DS2API Modal)
        const poolModal = document.getElementById("trans-pool-modal");
        document.getElementById("btn-open-pool-modal")?.addEventListener("click", () => {
            if (poolModal) poolModal.style.display = "flex";
        });
        document.getElementById("btn-close-pool-modal")?.addEventListener("click", () => {
            if (poolModal) poolModal.style.display = "none";
        });
        document.getElementById("btn-close-pool-modal-2")?.addEventListener("click", () => {
            if (poolModal) poolModal.style.display = "none";
        });

        const ds2Modal = document.getElementById("ds2api-manager-modal");
        const openDs2Modal = () => {
            if (ds2Modal) ds2Modal.style.display = "flex";
            fetchDs2apiAccounts();
        };
        document.getElementById("btn-open-ds2api-modal")?.addEventListener("click", openDs2Modal);
        document.getElementById("btn-open-ds2api-modal-top")?.addEventListener("click", openDs2Modal);
        document.getElementById("btn-close-ds2-modal")?.addEventListener("click", () => {
            if (ds2Modal) ds2Modal.style.display = "none";
        });
        document.getElementById("btn-close-ds2-modal-2")?.addEventListener("click", () => {
            if (ds2Modal) ds2Modal.style.display = "none";
        });
        document.getElementById("btn-refresh-ds2-accounts")?.addEventListener("click", () => {
            fetchDs2apiAccounts();
        });

        // 9. DS2API Actions (Fetch, Add, Delete, Test)
        async function fetchDs2apiAccounts() {
            try {
                const res = await fetch("/api/ds2api/accounts");
                const data = await res.json();
                ds2Accounts = data.accounts || [];
                renderDs2Accounts();
            } catch (e) {}
        }

        async function fetchDs2apiStatus() {
            try {
                const res = await fetch("/api/ds2api/status");
                const data = await res.json();
                const quickBadge = document.getElementById("trans-ds2api-quick-status");
                const pill = document.getElementById("trans-ds2api-status-pill");
                const isRunning = data.running || data.is_running;
                if (quickBadge) {
                    quickBadge.innerHTML = isRunning
                        ? `<span class="pulse-dot" style="background: #10b981;"></span><span>DS2API: Hoạt động</span>`
                        : `<span style="width: 8px; height: 8px; border-radius: 50%; background: #f59e0b; display: inline-block;"></span><span>DS2API: Sẵn sàng</span>`;
                }
                if (pill) {
                    pill.textContent = isRunning ? "Server: Running (Port 8000)" : "Server: 127.0.0.1:8000";
                }
            } catch (e) {}
        }

        function renderDs2Accounts() {
            const selectEl = document.getElementById("trans-ds2api-account-select");
            const tbody = document.getElementById("ds2-accounts-tbody");
            const countEl = document.getElementById("ds2-modal-count");

            if (countEl) countEl.textContent = ds2Accounts.length;

            if (selectEl) {
                const prevVal = selectEl.value;
                selectEl.innerHTML = `<option value="auto">🔄 Tự động xoay tua tất cả tài khoản active (Khuyên dùng)</option>`;
                ds2Accounts.forEach(acc => {
                    const opt = document.createElement("option");
                    opt.value = acc.id;
                    opt.textContent = `👤 ${acc.name || acc.id} (${acc.login_id || "No email"})${acc.status === "active" ? " ✓" : ""}`;
                    selectEl.appendChild(opt);
                });
                if (prevVal) selectEl.value = prevVal;
            }

            if (tbody) {
                if (ds2Accounts.length === 0) {
                    tbody.innerHTML = `<tr><td colspan="4" style="padding: 16px; text-align: center; color: #64748b;">Chưa có tài khoản nào được thêm.</td></tr>`;
                } else {
                    tbody.innerHTML = ds2Accounts.map(acc => `
                        <tr style="border-bottom: 1px solid #1e2638;">
                            <td style="padding: 8px 10px;">
                                <div style="font-weight: 600; color: #f1f5f9;">${escapeHtml(acc.name || acc.id)}</div>
                                <div style="font-size: 10px; color: #94a3b8;">${escapeHtml(acc.login_id || "")}</div>
                            </td>
                            <td style="padding: 8px 10px; color: #cbd5e1;">
                                ${acc.is_mobile ? "📱 Mobile" : "✉ Email"}
                            </td>
                            <td style="padding: 8px 10px;">
                                <span style="display: inline-flex; align-items: center; gap: 4px; padding: 2px 6px; border-radius: 9999px; font-size: 10px; ${acc.token_valid ? "background: rgba(16,185,129,0.15); color: #34d399;" : "background: rgba(245,158,11,0.15); color: #fbbf24;"}">
                                    ${acc.token_valid ? "✓ Token Live" : "⏳ Ready"}
                                </span>
                            </td>
                            <td style="padding: 8px 10px; text-align: right;">
                                <div style="display: flex; gap: 4px; justify-content: flex-end;">
                                    <button type="button" class="btn-test-ds2" data-id="${acc.id}" style="background: rgba(16,185,129,0.1); border: 1px solid rgba(16,185,129,0.2); color: #34d399; border-radius: 4px; padding: 2px 6px; font-size: 10.5px; cursor: pointer;">Test</button>
                                    <button type="button" class="btn-del-ds2" data-id="${acc.id}" style="background: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.2); color: #f87171; border-radius: 4px; padding: 2px 6px; font-size: 10.5px; cursor: pointer;">Xóa</button>
                                </div>
                            </td>
                        </tr>
                    `).join("");
                }
            }

            // Bind Actions
            document.querySelectorAll(".btn-test-ds2").forEach(btn => {
                btn.onclick = async () => {
                    const id = btn.getAttribute("data-id");
                    btn.disabled = true;
                    btn.textContent = "⏳...";
                    try {
                        const res = await fetch("/api/ds2api/accounts/test", {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({ account_id: id })
                        });
                        const data = await res.json();
                        if (data.status === "ok" || data.success) {
                            showToast(`Tài khoản ${id} hoạt động tốt!`, "success");
                        } else {
                            showToast(`Lỗi test: ${data.message || data.error || "Không thành công"}`, "error");
                        }
                    } catch (e) {
                        showToast(`Lỗi mạng: ${e.message}`, "error");
                    } finally {
                        btn.disabled = false;
                        btn.textContent = "Test";
                        fetchDs2apiAccounts();
                    }
                };
            });

            document.querySelectorAll(".btn-del-ds2").forEach(btn => {
                btn.onclick = async () => {
                    const id = btn.getAttribute("data-id");
                    if (!confirm(`Bạn có chắc muốn xóa tài khoản ${id}?`)) return;
                    try {
                        await fetch(`/api/ds2api/accounts/delete/${id}`, { method: "POST" });
                        showToast("Đã xóa tài khoản", "info");
                        fetchDs2apiAccounts();
                    } catch (e) {
                        showToast("Không thể xóa tài khoản", "error");
                    }
                };
            });
        }

        // Add Account Submit
        document.getElementById("btn-add-ds2-account")?.addEventListener("click", async () => {
            const name = document.getElementById("new-ds2-name")?.value.trim() || "";
            const login = document.getElementById("new-ds2-login")?.value.trim() || "";
            const password = document.getElementById("new-ds2-password")?.value || "";
            const isMobile = document.getElementById("new-ds2-is-mobile")?.checked || false;
            const msgEl = document.getElementById("ds2-add-msg");
            const btn = document.getElementById("btn-add-ds2-account");

            if (!login || !password) {
                showToast("Vui lòng nhập email/SĐT và mật khẩu", "error");
                return;
            }

            if (msgEl) {
                msgEl.style.color = "#818cf8";
                msgEl.textContent = "⏳ Đang kết nối DeepSeek & lưu tài khoản...";
            }
            if (btn) btn.disabled = true;

            try {
                const res = await fetch("/api/ds2api/accounts", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        name: name || login,
                        login_id: login,
                        password: password,
                        is_mobile: isMobile
                    })
                });
                const data = await res.json();
                if (data.status === "ok" || data.success) {
                    if (msgEl) {
                        msgEl.style.color = "#34d399";
                        msgEl.textContent = "✓ Đã thêm tài khoản thành công!";
                    }
                    showToast("Đã thêm tài khoản DeepSeek thành công", "success");
                    document.getElementById("new-ds2-login").value = "";
                    document.getElementById("new-ds2-password").value = "";
                    fetchDs2apiAccounts();
                } else {
                    if (msgEl) {
                        msgEl.style.color = "#f87171";
                        msgEl.textContent = `⚠️ ${data.message || data.error || "Thêm thất bại"}`;
                    }
                    showToast(`Thất bại: ${data.message || "Lỗi"}`, "error");
                }
            } catch (e) {
                if (msgEl) {
                    msgEl.style.color = "#f87171";
                    msgEl.textContent = `⚠️ Lỗi kết nối: ${e.message}`;
                }
            } finally {
                if (btn) btn.disabled = false;
            }
        });

        // 10. Translation Job Flow Execution
        const btnStart = document.getElementById("btn-start-translation");
        const btnPause = document.getElementById("btn-pause-translation");
        const btnResume = document.getElementById("btn-resume-translation");
        const btnStop = document.getElementById("btn-stop-translation");
        const btnRetry = document.getElementById("btn-retry-translation");
        const btnDownload = document.getElementById("btn-download-translated-srt");
        const btnTransfer = document.getElementById("btn-transfer-to-editor");
        const progressPanel = document.getElementById("trans-progress-panel");
        const previewPanel = document.getElementById("trans-preview-panel");

        btnStart?.addEventListener("click", async () => {
            const rawContent = srtContent ? srtContent.value.trim() : "";
            if (!rawContent) {
                showToast("Vui lòng nhập hoặc mở file phụ đề .SRT trước", "error");
                return;
            }

            const provider = providerSelect.value;
            const model = modelSelect.value;
            const sourceLang = sourceLangSelect.value;
            const targetLang = targetLangSelect.value;
            const batchSize = parseInt(document.getElementById("trans-batch-size")?.value || "20", 10);
            const userPrompt = promptTextarea ? promptTextarea.value.trim() : "";
            const filename = document.getElementById("trans-filename")?.value.trim() || "subtitle_VI.srt";

            // Prepare API Pool
            let apiPoolPayload = [];
            if (provider === "ds2api") {
                const accSelect = document.getElementById("trans-ds2api-account-select");
                const selectedAcc = accSelect ? accSelect.value : "auto";
                apiPoolPayload.push({
                    provider: "ds2api",
                    api_key: "ds2api_session",
                    model: model,
                    account_id: selectedAcc
                });
            } else {
                const enteredKey = apiKeyInput ? apiKeyInput.value.trim() : "";
                if (enteredKey) {
                    apiPoolPayload.push({
                        provider: provider,
                        api_key: enteredKey,
                        model: model
                    });
                }
                customApiPool.forEach(p => {
                    apiPoolPayload.push({
                        provider: p.provider,
                        api_key: p.api_key,
                        model: p.model
                    });
                });

                if (apiPoolPayload.length === 0) {
                    showToast("Vui lòng nhập API Key cho nhà cung cấp này", "error");
                    return;
                }
            }

            btnStart.disabled = true;
            btnStart.innerHTML = `<svg class="animate-spin" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="display:inline-block; margin-right: 6px;"><circle cx="12" cy="12" r="10" stroke-opacity="0.25"/><path d="M12 2a10 10 0 0 1 10 10"/></svg> <span>Đang khởi tạo...</span>`;

            try {
                const res = await fetch("/api/srt/translate/start", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        content: rawContent,
                        filename: filename,
                        source_lang: sourceLang,
                        target_lang: targetLang,
                        batch_size: batchSize,
                        user_prompt: userPrompt,
                        api_pool: apiPoolPayload,
                        provider: provider,
                        model: model
                    })
                });

                const data = await res.json();
                if (data.status === "ok" || data.job_id) {
                    activeTranslateJobId = data.job_id;
                    showToast("Bắt đầu dịch phụ đề thành công!", "success");

                    if (progressPanel) progressPanel.style.display = "block";
                    if (previewPanel) previewPanel.style.display = "block";

                    // Update button states
                    btnStart.style.display = "none";
                    if (btnPause) btnPause.style.display = "inline-flex";
                    if (btnResume) btnResume.style.display = "none";
                    if (btnStop) btnStop.style.display = "inline-flex";
                    if (btnRetry) btnRetry.style.display = "none";
                    if (btnDownload) btnDownload.style.display = "none";
                    if (btnTransfer) btnTransfer.style.display = "none";

                    startTranslatePolling(data.job_id);
                } else {
                    showToast(`Không thể bắt đầu dịch: ${data.message || data.error || "Lỗi"}`, "error");
                    btnStart.disabled = false;
                    btnStart.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 3 19 12 5 21 5 3"/></svg> <span>BẮT ĐẦU DỊCH PHỤ ĐỀ</span>`;
                }
            } catch (err) {
                showToast(`Lỗi kết nối: ${err.message}`, "error");
                btnStart.disabled = false;
                btnStart.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 3 19 12 5 21 5 3"/></svg> <span>BẮT ĐẦU DỊCH PHỤ ĐỀ</span>`;
            }
        });

        function startTranslatePolling(jobId) {
            if (translatePollTimer) clearInterval(translatePollTimer);

            const poll = async () => {
                try {
                    const res = await fetch(`/api/srt/translate/status/${jobId}`);
                    if (!res.ok) return;
                    const job = await res.json();
                    lastTranslateJobData = job;
                    updateTranslateUI(job);

                    if (job.status === "completed" || job.status === "failed" || job.status === "stopped") {
                        if (job.status === "completed") {
                            clearInterval(translatePollTimer);
                            showToast("Dịch phụ đề và kiểm tra ngôn ngữ hoàn tất!", "success");
                        }
                    }
                } catch (e) {}
            };

            poll();
            translatePollTimer = setInterval(poll, 1500);
        }

        function updateTranslateUI(job) {
            if (!job) return;

            const total = job.total_subtitles || (job.subtitles ? job.subtitles.length : 0);
            const completed = job.completed_subtitles || (job.subtitles ? job.subtitles.filter(s => s.status === "completed").length : 0);
            const failed = job.failed_subtitles || (job.subtitles ? job.subtitles.filter(s => s.status === "failed").length : 0);
            const pending = Math.max(0, total - completed - failed);
            const percent = total > 0 ? Math.round((completed / total) * 100) : 0;

            const bar = document.getElementById("trans-progress-bar");
            const pctText = document.getElementById("trans-progress-percent");
            const statTotal = document.getElementById("trans-stat-total");
            const statComp = document.getElementById("trans-stat-completed");
            const statPend = document.getElementById("trans-stat-pending");
            const statFail = document.getElementById("trans-stat-failed");
            const liveMsg = document.getElementById("trans-live-status-message");

            if (bar) bar.style.width = `${percent}%`;
            if (pctText) pctText.textContent = `${percent}%`;
            if (statTotal) statTotal.textContent = total;
            if (statComp) statComp.textContent = completed;
            if (statPend) statPend.textContent = pending;
            if (statFail) statFail.textContent = failed;

            if (liveMsg) {
                if (job.status === "translating") {
                    liveMsg.innerHTML = `<span style="display:flex; align-items:center; gap:6px;"><svg class="animate-spin" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#818cf8" stroke-width="2.5"><path d="M12 2a10 10 0 0 1 10 10"/></svg> <span>Đang xử lý: ${job.message || `Đang dịch batch... (${completed}/${total})`}</span></span>`;
                } else if (job.status === "paused") {
                    liveMsg.innerHTML = `<span style="color: #fbbf24; display:flex; align-items:center; gap:6px;"><svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg> <span>Đang tạm dừng. Bấm "Tiếp tục" để dịch tiếp.</span></span>`;
                } else if (job.status === "completed") {
                    liveMsg.innerHTML = `<span style="color: #34d399; display:flex; align-items:center; gap:6px;"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg> <span>Hoàn tất 100% dịch & kiểm tra ngôn ngữ đích! Sẵn sàng tải file.</span></span>`;
                } else if (job.status === "stopped") {
                    liveMsg.innerHTML = `<span style="color: #f87171; display:flex; align-items:center; gap:6px;"><svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><rect x="4" y="4" width="16" height="16" rx="2"/></svg> <span>Đã dừng tác vụ. Các câu đã dịch vẫn được lưu đầy đủ.</span></span>`;
                }
            }

            // Controls adjustment
            if (job.status === "completed") {
                if (btnStart) {
                    btnStart.style.display = "inline-flex";
                    btnStart.disabled = false;
                    btnStart.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 3 19 12 5 21 5 3"/></svg> <span>BẮT ĐẦU DỊCH PHỤ ĐỀ</span>`;
                }
                if (btnPause) btnPause.style.display = "none";
                if (btnResume) btnResume.style.display = "none";
                if (btnStop) btnStop.style.display = "none";
                if (btnDownload) btnDownload.style.display = "inline-flex";
                if (btnTransfer) btnTransfer.style.display = "inline-flex";
                if (failed > 0 && btnRetry) btnRetry.style.display = "inline-flex";
            } else if (job.status === "paused") {
                if (btnPause) btnPause.style.display = "none";
                if (btnResume) btnResume.style.display = "inline-flex";
            } else if (job.status === "translating") {
                if (btnPause) btnPause.style.display = "inline-flex";
                if (btnResume) btnResume.style.display = "none";
            } else if (job.status === "stopped") {
                if (btnStart) {
                    btnStart.style.display = "inline-flex";
                    btnStart.disabled = false;
                    btnStart.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 3 19 12 5 21 5 3"/></svg> <span>BẮT ĐẦU DỊCH PHỤ ĐỀ</span>`;
                }
                if (btnPause) btnPause.style.display = "none";
                if (btnResume) btnResume.style.display = "none";
                if (btnStop) btnStop.style.display = "none";
                if (btnDownload) btnDownload.style.display = "inline-flex";
                if (btnTransfer) btnTransfer.style.display = "inline-flex";
            }

            renderSubtitlesPreview(job.subtitles || []);
        }

        function renderSubtitlesPreview(subtitles) {
            const listEl = document.getElementById("trans-subtitles-list");
            if (!listEl) return;

            let filtered = subtitles;
            if (transActiveFilter === "done") {
                filtered = filtered.filter(s => s.status === "completed");
            } else if (transActiveFilter === "busy") {
                filtered = filtered.filter(s => s.status === "translating" || s.status === "pending");
            } else if (transActiveFilter === "failed") {
                filtered = filtered.filter(s => s.status === "failed");
            }

            if (transSearchKeyword) {
                const kw = transSearchKeyword.toLowerCase();
                filtered = filtered.filter(s =>
                    (s.source_text && s.source_text.toLowerCase().includes(kw)) ||
                    (s.translated_text && s.translated_text.toLowerCase().includes(kw))
                );
            }

            if (filtered.length === 0) {
                listEl.innerHTML = `<div style="text-align: center; padding: 24px; color: #64748b; font-size: 12px;">Không có dòng phụ đề nào phù hợp bộ lọc.</div>`;
                return;
            }

            listEl.innerHTML = filtered.map(sub => {
                let badgeHtml = "";
                let cardBorder = "#1e2638";
                if (sub.status === "completed") {
                    badgeHtml = `<span style="font-size: 10.5px; background: rgba(16, 185, 129, 0.12); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.25); border-radius: 9999px; padding: 2px 8px; display: inline-flex; align-items: center; gap: 4px;"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg> <span>Đã dịch</span></span>`;
                    cardBorder = "rgba(16, 185, 129, 0.2)";
                } else if (sub.status === "translating") {
                    badgeHtml = `<span style="font-size: 10.5px; background: rgba(99, 102, 241, 0.12); color: #818cf8; border: 1px solid rgba(99, 102, 241, 0.25); border-radius: 9999px; padding: 2px 8px; display: inline-flex; align-items: center; gap: 4px;"><svg class="animate-spin" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 2a10 10 0 0 1 10 10"/></svg> <span>Đang dịch...</span></span>`;
                    cardBorder = "rgba(99, 102, 241, 0.25)";
                } else if (sub.status === "failed") {
                    badgeHtml = `<span style="font-size: 10.5px; background: rgba(239, 68, 68, 0.12); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.25); border-radius: 9999px; padding: 2px 8px; display: inline-flex; align-items: center; gap: 4px;"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg> <span>Lỗi dịch</span></span>`;
                    cardBorder = "rgba(239, 68, 68, 0.25)";
                } else {
                    badgeHtml = `<span style="font-size: 10.5px; background: #161d2d; color: #94a3b8; border-radius: 9999px; padding: 2px 8px; display: inline-flex; align-items: center; gap: 4px;"><span>Chờ xử lý</span></span>`;
                }

                return `
                    <div style="background: #080b13; border: 1px solid ${cardBorder}; border-radius: 7px; padding: 9px 12px; display: flex; flex-direction: column; gap: 5px;">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <span style="font-weight: 700; font-size: 11px; color: #818cf8;">#${sub.index} <span style="color: #64748b; font-weight: normal; margin-left: 6px; font-family: var(--font-mono);">${sub.start_time || ""} --> ${sub.end_time || ""}</span></span>
                            ${badgeHtml}
                        </div>
                        <div style="font-size: 12px; color: #94a3b8; line-height: 1.35;">${escapeHtml(sub.source_text || "")}</div>
                        <div style="font-size: 12.5px; font-weight: 600; color: ${sub.translated_text ? "#f1f5f9" : "#475569"}; line-height: 1.35;">
                            ${sub.translated_text ? escapeHtml(sub.translated_text) : "..."}
                        </div>
                    </div>
                `;
            }).join("");
        }

        // Filter clicks
        const btnFilterAll = document.getElementById("btn-trans-filter-all");
        const btnFilterDone = document.getElementById("btn-trans-filter-done");
        const btnFilterBusy = document.getElementById("btn-trans-filter-busy");
        const btnFilterFailed = document.getElementById("btn-trans-filter-failed");
        const searchInput = document.getElementById("trans-search-input");

        function setTransFilter(filter) {
            transActiveFilter = filter;
            [btnFilterAll, btnFilterDone, btnFilterBusy, btnFilterFailed].forEach(b => b?.classList.remove("active"));
            if (filter === "all") btnFilterAll?.classList.add("active");
            if (filter === "done") btnFilterDone?.classList.add("active");
            if (filter === "busy") btnFilterBusy?.classList.add("active");
            if (filter === "failed") btnFilterFailed?.classList.add("active");
            if (lastTranslateJobData) renderSubtitlesPreview(lastTranslateJobData.subtitles || []);
        }

        btnFilterAll?.addEventListener("click", () => setTransFilter("all"));
        btnFilterDone?.addEventListener("click", () => setTransFilter("done"));
        btnFilterBusy?.addEventListener("click", () => setTransFilter("busy"));
        btnFilterFailed?.addEventListener("click", () => setTransFilter("failed"));

        searchInput?.addEventListener("input", (e) => {
            transSearchKeyword = e.target.value.trim();
            if (lastTranslateJobData) renderSubtitlesPreview(lastTranslateJobData.subtitles || []);
        });

        // Pause / Resume / Stop / Retry handlers
        btnPause?.addEventListener("click", async () => {
            if (!activeTranslateJobId) return;
            try {
                await fetch(`/api/srt/translate/pause/${activeTranslateJobId}`, { method: "POST" });
                showToast("Đã gửi lệnh tạm dừng", "info");
            } catch (e) {}
        });

        btnResume?.addEventListener("click", async () => {
            if (!activeTranslateJobId) return;
            try {
                await fetch(`/api/srt/translate/resume/${activeTranslateJobId}`, { method: "POST" });
                showToast("Đang tiếp tục dịch phụ đề", "success");
            } catch (e) {}
        });

        btnStop?.addEventListener("click", async () => {
            if (!activeTranslateJobId) return;
            if (!confirm("Bạn có chắc muốn dừng tác vụ dịch hiện tại? Dữ liệu đã dịch vẫn được lưu.")) return;
            try {
                await fetch(`/api/srt/translate/stop/${activeTranslateJobId}`, { method: "POST" });
                showToast("Đã dừng tác vụ dịch", "info");
            } catch (e) {}
        });

        btnRetry?.addEventListener("click", async () => {
            if (!activeTranslateJobId) return;
            try {
                await fetch(`/api/srt/translate/retry/${activeTranslateJobId}`, { method: "POST" });
                showToast("Đang thử lại các câu dịch bị lỗi...", "info");
            } catch (e) {}
        });

        // Download Translated SRT
        btnDownload?.addEventListener("click", () => {
            if (!lastTranslateJobData || !lastTranslateJobData.translated_srt_content) {
                showToast("Chưa có nội dung SRT đã dịch", "error");
                return;
            }
            const blob = new Blob([lastTranslateJobData.translated_srt_content], { type: "text/plain;charset=utf-8" });
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = document.getElementById("trans-filename")?.value.trim() || "translated_subtitle.srt";
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            showToast("Đã tải xuống file .SRT đã dịch!", "success");
        });

        // Transfer to SRT Editor
        btnTransfer?.addEventListener("click", () => {
            if (!lastTranslateJobData || !lastTranslateJobData.translated_srt_content) {
                showToast("Chưa có nội dung SRT đã dịch", "error");
                return;
            }
            const editorTextarea = document.getElementById("srt-editor-content") || document.getElementById("editor-content");
            if (editorTextarea) {
                editorTextarea.value = lastTranslateJobData.translated_srt_content;
                showToast("Đã chuyển nội dung sang Trình chỉnh sửa SRT", "success");
                switchMainTab("srt", "srt-editor");
            }
        });
    }

    /**
     * ==============================================================================
     * GLOBAL ERROR POPUP MODAL & TOAST ADAPTER
     * ==============================================================================
     */
    const globalErrorModal = document.getElementById("global-error-modal");
    const globalErrorTitle = document.getElementById("global-error-modal-title");
    const globalErrorMessage = document.getElementById("global-error-modal-message");
    const globalErrorDetail = document.getElementById("global-error-modal-detail");
    const btnCloseGlobalError = document.getElementById("btn-close-global-error-modal");
    const btnOkGlobalError = document.getElementById("btn-ok-global-error-modal");

    function showToast(message, type = "info", duration = 3500) {
        if (!message) return;
        console.log(`[Toast ${type.toUpperCase()}] ${message}`);

        let container = document.getElementById("kage-toast-container");
        if (!container) {
            container = document.createElement("div");
            container.id = "kage-toast-container";
            container.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                z-index: 999999;
                display: flex;
                flex-direction: column;
                gap: 8px;
                max-width: 380px;
                pointer-events: none;
            `;
            document.body.appendChild(container);
        }

        const toast = document.createElement("div");
        toast.className = `status-toast ${type}`;
        toast.style.cssText = `
            pointer-events: auto;
            padding: 10px 14px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 500;
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.25s ease;
            opacity: 0;
            transform: translateY(-10px);
            word-break: break-word;
        `;

        let icon = "ℹ️";
        if (type === "success") icon = "✅";
        else if (type === "error") icon = "❌";
        else if (type === "warn" || type === "warning") icon = "⚠️";

        const cleanMsg = String(message).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
        toast.innerHTML = `<span style="font-size:14px;">${icon}</span><span>${cleanMsg}</span>`;
        container.appendChild(toast);

        requestAnimationFrame(() => {
            toast.style.opacity = "1";
            toast.style.transform = "translateY(0)";
        });

        setTimeout(() => {
            toast.style.opacity = "0";
            toast.style.transform = "translateY(-10px)";
            setTimeout(() => toast.remove(), 300);
        }, duration);
    }

    window.showToast = showToast;

    function showGlobalErrorModal(title, message, detail) {
        if (!globalErrorModal) {
            alert(`${title || "LỖI"}\n\n${message || ""}\n${detail ? "\nChi tiết: " + detail : ""}`);
            return;
        }
        if (globalErrorTitle) globalErrorTitle.textContent = title || "Thông Báo Lỗi";
        if (globalErrorMessage) globalErrorMessage.textContent = message || "Đã xảy ra lỗi không xác định.";
        if (globalErrorDetail) {
            if (detail) {
                globalErrorDetail.textContent = typeof detail === "object" ? JSON.stringify(detail, null, 2) : String(detail);
                globalErrorDetail.style.display = "block";
            } else {
                globalErrorDetail.style.display = "none";
            }
        }
        globalErrorModal.style.display = "flex";
    }

    function closeGlobalErrorModal() {
        if (globalErrorModal) globalErrorModal.style.display = "none";
    }

    btnCloseGlobalError?.addEventListener("click", closeGlobalErrorModal);
    btnOkGlobalError?.addEventListener("click", closeGlobalErrorModal);
    globalErrorModal?.addEventListener("click", (e) => {
        if (e.target === globalErrorModal) closeGlobalErrorModal();
    });

    window.showGlobalError = showGlobalErrorModal;

    /**
     * ==============================================================================
     * SAFE FILE DOWNLOAD HELPER (Chống lỗi tải file & hiển thị popup)
     * ==============================================================================
     */
    let isDownloadingFile = false;

    async function triggerSafeFileDownload(identifier, defaultFilename) {
        if (!identifier) {
            showGlobalErrorModal("Lỗi tải file", "Chưa chỉ định đường dẫn hoặc tên file cần tải.");
            return;
        }

        if (isDownloadingFile) {
            showToast("Đang tải xuống file, vui lòng đợi giây lát...", "info");
            return;
        }

        isDownloadingFile = true;
        try {
            showToast("Đang chuẩn bị tải file...", "info");
            let downloadUrl = identifier.startsWith("/") ? identifier : `/api/download/${encodeURIComponent(identifier)}`;
            const res = await fetch(downloadUrl);

            if (!res.ok) {
                let errText = "Không thể tải file.";
                try {
                    const errJson = await res.json();
                    errText = errJson.error || errJson.detail || errText;
                } catch (_) {
                    errText = `Mã phản hồi từ máy chủ: ${res.status} ${res.statusText}`;
                }
                showGlobalErrorModal("Không thể tải file", errText, `File: ${identifier}`);
                return;
            }

            const contentType = res.headers.get("Content-Type") || "";
            if (contentType.includes("application/json")) {
                let errText = "Máy chủ trả về phản hồi lỗi JSON.";
                try {
                    const text = await res.text();
                    const errJson = JSON.parse(text);
                    errText = errJson.error || errJson.detail || errText;
                } catch (_) {}
                showGlobalErrorModal("Lỗi dữ liệu tải về", errText, `File: ${identifier}`);
                return;
            }

            const blob = await res.blob();
            if (blob.size === 0) {
                showGlobalErrorModal("Không thể tải file", "File tải về rỗng (0 bytes) hoặc chưa sẵn sàng trên máy chủ.", `File: ${identifier}`);
                return;
            }

            let filename = defaultFilename;
            const disposition = res.headers.get("Content-Disposition");
            if (disposition && disposition.includes("filename=")) {
                const matches = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/.exec(disposition);
                if (matches && matches[1]) {
                    filename = matches[1].replace(/['"]/g, "");
                }
            }
            if (!filename) {
                filename = identifier.split("/").pop() || "downloaded_file";
            }

            const blobUrl = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = blobUrl;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            setTimeout(() => URL.revokeObjectURL(blobUrl), 10000);
            showToast(`Đã tải file ${filename} thành công!`, "success");
        } catch (err) {
            showGlobalErrorModal("Lỗi kết nối tải file", "Không thể kết nối đến máy chủ để tải file.", err.message);
        } finally {
            isDownloadingFile = false;
        }
    }
    window.triggerSafeFileDownload = triggerSafeFileDownload;

    /**
     * ==============================================================================
     * REALTIME LOGS & EXPORT CONTROLLER (Tab LOG)
     * ==============================================================================
     */
    let logsAutoRefreshInterval = null;
    let rawLogLinesCache = [];

    async function fetchRealtimeLogs(forceScroll = false) {
        const terminal = document.getElementById("logs-terminal-container");
        const statusLbl = document.getElementById("lbl-logs-status");
        if (!terminal) return;

        try {
            const res = await fetch("/api/logs/realtime?lines=200");
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            const data = await res.json();

            if (statusLbl) {
                statusLbl.textContent = `Cập nhật: ${data.updated_at || "Vừa xong"} (${data.lines_count || 0} dòng)`;
            }

            if (!data.raw_text || data.raw_text.trim() === "") {
                terminal.innerHTML = '<div style="color:#64748b; font-style:italic;">Chưa có dữ liệu nhật ký cho ngày hôm nay.</div>';
                return;
            }

            rawLogLinesCache = data.raw_text.split("\n");
            renderFilteredLogs(forceScroll);
        } catch (err) {
            if (statusLbl) statusLbl.textContent = "Mất kết nối log";
            terminal.innerHTML = `<div style="color:#ef4444;">⚠️ Không thể tải nhật ký thời gian thực: ${err.message}</div>`;
        }
    }
    window.fetchRealtimeLogs = fetchRealtimeLogs;

    function renderFilteredLogs(forceScroll = false) {
        const terminal = document.getElementById("logs-terminal-container");
        const filterSel = document.getElementById("sel-logs-filter-level");
        const autoScrollChk = document.getElementById("chk-logs-autoscroll");
        if (!terminal) return;

        const levelFilter = filterSel ? filterSel.value : "ALL";

        const formattedHtml = rawLogLinesCache.map(line => {
            if (!line) return "";
            let color = "#94a3b8";
            const upper = line.toUpperCase();

            if (levelFilter === "INFO" && !upper.includes("[INFO]")) return null;
            if (levelFilter === "WARNING" && !upper.includes("[WARNING]")) return null;
            if (levelFilter === "ERROR" && !upper.includes("[ERROR]") && !upper.includes("[CRITICAL]")) return null;

            if (upper.includes("[ERROR]") || upper.includes("[CRITICAL]") || upper.includes("EXCEPTION") || upper.includes("TRACEBACK")) {
                color = "#f87171";
            } else if (upper.includes("[WARNING]")) {
                color = "#fbbf24";
            } else if (upper.includes("[INFO]")) {
                color = "#60a5fa";
            } else if (upper.includes("[DEBUG]")) {
                color = "#64748b";
            }

            const escaped = line
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;");

            return `<div style="color: ${color}; line-height: 1.5; padding: 1px 0;">${escaped}</div>`;
        }).filter(item => item !== null).join("");

        terminal.innerHTML = formattedHtml || '<div style="color:#64748b;">Không có dòng log nào khớp với bộ lọc.</div>';

        if (forceScroll || (autoScrollChk && autoScrollChk.checked)) {
            terminal.scrollTop = terminal.scrollHeight;
        }
    }

    function initLogsController() {
        const btnDownload = document.getElementById("btn-download-logs-file");
        const btnRefresh = document.getElementById("btn-refresh-logs-realtime");
        const btnClear = document.getElementById("btn-clear-logs-view");
        const filterSel = document.getElementById("sel-logs-filter-level");
        const autoRefreshChk = document.getElementById("chk-logs-auto-refresh");

        btnDownload?.addEventListener("click", () => {
            triggerSafeFileDownload("/api/logs/download", "kagevietsub_logs.log");
        });

        btnRefresh?.addEventListener("click", () => {
            fetchRealtimeLogs(true);
            showToast("Đã cập nhật nhật ký", "success");
        });

        btnClear?.addEventListener("click", () => {
            const terminal = document.getElementById("logs-terminal-container");
            if (terminal) terminal.innerHTML = '<div style="color:#64748b; font-style:italic;">Màn hình log đã được làm sạch.</div>';
        });

        filterSel?.addEventListener("change", () => {
            renderFilteredLogs(true);
        });

        function setupAutoRefreshTimer() {
            if (logsAutoRefreshInterval) clearInterval(logsAutoRefreshInterval);
            logsAutoRefreshInterval = setInterval(() => {
                const logsTab = document.getElementById("main-tab-logs");
                if (logsTab && logsTab.classList.contains("active") && autoRefreshChk && autoRefreshChk.checked) {
                    fetchRealtimeLogs(false);
                }
            }, 3000);
        }

        autoRefreshChk?.addEventListener("change", () => {
            if (autoRefreshChk.checked) {
                setupAutoRefreshTimer();
                fetchRealtimeLogs(true);
            } else if (logsAutoRefreshInterval) {
                clearInterval(logsAutoRefreshInterval);
            }
        });

        setupAutoRefreshTimer();
    }

    fetchAppVersion();
    checkHealth();
    initTTSController();
    initTTSRecoveryController();
    initDownloaderController();
    initSrtTranslateController();
    initLogsController();
    checkUrlParamsOnLoad();
});

