# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB - DEDICATED WEB SERVER ENTRYPOINT FOR GOOGLE COLAB
==============================================================================
Module máy chủ web và API phục vụ giao diện trình duyệt & Colab:
- Chạy thông qua: python start_server.py hoặc python TOOL/web_server.py
- Tận dụng 100% backend API, Task Manager, Engines và Services của KAGEVIETSUB.
- Tích hợp Cloudflare Tunnel tự động cấp link Public HTTPS cho Google Colab.
==============================================================================
"""

import sys
import argparse
from pathlib import Path

# Đảm bảo đường dẫn gốc
CURRENT_DIR = Path(__file__).resolve().parent
ROOT_DIR = CURRENT_DIR.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))
if str(CURRENT_DIR) not in sys.path:
    sys.path.insert(0, str(CURRENT_DIR))

from TOOL.config import ensure_directories
from TOOL.web_server.server import start_web_server

def main():
    parser = argparse.ArgumentParser(description="KAGEVIETSUB Web Server for Colab & Web UI")
    parser.add_argument("--host", default="0.0.0.0", help="Địa chỉ host lắng nghe (mặc định: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=8000, help="Cổng máy chủ (mặc định: 8000)")
    parser.add_argument("--no-tunnel", action="store_true", help="Không tự động mở Cloudflare Tunnel")
    args = parser.parse_args()

    ensure_directories()
    start_web_server(host=args.host, port=args.port, enable_tunnel=not args.no_tunnel)

if __name__ == "__main__":
    main()
