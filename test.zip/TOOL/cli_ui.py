#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB - CLI & TERMINAL UI MODULE
==============================================================================
Hệ thống hiển thị Terminal cao cấp cho KAGEVIETSUB:
- Hỗ trợ màu đa nền tảng (Windows CMD, PowerShell, Termux Android, Linux, macOS)
- Banner nghệ thuật Box-drawing
- Check-list từng bước khởi động [1/7]...
- Thanh tiến trình (Progress Bar) & Spinner
- Quản lý nhật ký màu (INFO, OK, WARN, ERROR, DEBUG)
- Thiết lập tiêu đề cửa sổ Terminal
- Hoàn toàn an toàn, tự động fallback nếu không hỗ trợ màu ANSI/Unicode
==============================================================================
"""

import os
import sys
import time
import shutil
import platform
import threading
from typing import Optional, List, Dict, Any

HAS_COLORAMA = False
try:
    import colorama
    colorama.init(autoreset=True)
    HAS_COLORAMA = True
except ImportError:
    pass

if os.name == "nt" and not HAS_COLORAMA:
    try:
        import ctypes
        kernel32 = ctypes.windll.kernel32
                                                     
        handle = kernel32.GetStdHandle(-11)
        mode = ctypes.c_ulong()
        if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
            kernel32.SetConsoleMode(handle, mode.value | 0x0004)
                                                                             
        os.system("")
    except Exception:
        pass

def supports_color() -> bool:
    """Kiểm tra xem Terminal hiện tại có hỗ trợ mã màu ANSI hay không."""
    if os.getenv("NO_COLOR") or os.getenv("TERM") == "dumb":
        return False
    if HAS_COLORAMA:
        return True
    if hasattr(sys.stdout, "isatty") and sys.stdout.isatty():
        if os.name != "nt":
            return True
                                                    
        if "ANSICON" in os.environ or "WT_SESSION" in os.environ or os.environ.get("TERM_PROGRAM") in ("vscode", "hyper", "mintty"):
            return True
        return True
    return False

def supports_unicode() -> bool:
    """Kiểm tra khả năng hiển thị ký tự Unicode / Box-drawing."""
    encoding = getattr(sys.stdout, "encoding", None) or "utf-8"
    try:
        encoding_lower = encoding.lower()
        if "utf" in encoding_lower or "cp65001" in encoding_lower:
            return True
    except Exception:
        pass
    if os.environ.get("TERMUX_VERSION") or os.environ.get("PREFIX", "").startswith("/data/data/com.termux"):
        return True
    if os.name != "nt":
        return True
    return False

USE_COLOR = supports_color()
USE_UNICODE = supports_unicode()

class Colors:
    if USE_COLOR:
        RESET = "\033[0m"
        BOLD = "\033[1m"
        DIM = "\033[2m"
        ITALIC = "\033[3m"
        UNDERLINE = "\033[4m"

        BLACK = "\033[30m"
        RED = "\033[91m"
        GREEN = "\033[92m"
        YELLOW = "\033[93m"
        BLUE = "\033[94m"
        MAGENTA = "\033[95m"
        CYAN = "\033[96m"
        WHITE = "\033[97m"
        GRAY = "\033[90m"

        BRIGHT_CYAN = "\033[1;96m"
        BRIGHT_BLUE = "\033[1;94m"
        BRIGHT_GREEN = "\033[1;92m"
        BRIGHT_YELLOW = "\033[1;93m"
        BRIGHT_RED = "\033[1;91m"
        BRIGHT_WHITE = "\033[1;97m"
        BG_CYAN = "\033[46m\033[30m"
        BG_BLUE = "\033[44m\033[97m"
        BG_DARK = "\033[48;5;236m"
    else:
        RESET = ""
        BOLD = ""
        DIM = ""
        ITALIC = ""
        UNDERLINE = ""
        BLACK = ""
        RED = ""
        GREEN = ""
        YELLOW = ""
        BLUE = ""
        MAGENTA = ""
        CYAN = ""
        WHITE = ""
        GRAY = ""
        BRIGHT_CYAN = ""
        BRIGHT_BLUE = ""
        BRIGHT_GREEN = ""
        BRIGHT_YELLOW = ""
        BRIGHT_RED = ""
        BRIGHT_WHITE = ""
        BG_CYAN = ""
        BG_BLUE = ""
        BG_DARK = ""

class Icons:
    if USE_UNICODE:
        CHECK = "✓"
        CROSS = "✕"
        WARN = "!"
        INFO = "●"
        ARROW = "→"
        BULLET = "•"
        SPARKLE = "✦"
        CIRCLE_OPT = "○"
        BAR_FULL = "█"
        BAR_EMPTY = "░"
        TOP_LEFT = "╔"
        TOP_RIGHT = "╗"
        BOT_LEFT = "╚"
        BOT_RIGHT = "╝"
        HORIZ = "═"
        VERT = "║"
        DIVIDER_LEFT = "╠"
        DIVIDER_RIGHT = "╣"
        ROUND_TL = "╭"
        ROUND_TR = "╮"
        ROUND_BL = "╰"
        ROUND_BR = "╯"
        ROUND_HORIZ = "─"
        ROUND_VERT = "│"
    else:
        CHECK = "[OK]"
        CROSS = "[X]"
        WARN = "[!]"
        INFO = "[*]"
        ARROW = "->"
        BULLET = "*"
        SPARKLE = "*"
        CIRCLE_OPT = "(o)"
        BAR_FULL = "#"
        BAR_EMPTY = "-"
        TOP_LEFT = "+"
        TOP_RIGHT = "+"
        BOT_LEFT = "+"
        BOT_RIGHT = "+"
        HORIZ = "="
        VERT = "|"
        DIVIDER_LEFT = "+"
        DIVIDER_RIGHT = "+"
        ROUND_TL = "+"
        ROUND_TR = "+"
        ROUND_BL = "+"
        ROUND_BR = "+"
        ROUND_HORIZ = "-"
        ROUND_VERT = "|"

def set_terminal_title(title: str = "KAGEVIETSUB"):
    """Đặt tiêu đề cửa sổ console/terminal."""
    try:
        if os.name == "nt":
            try:
                import ctypes
                ctypes.windll.kernel32.SetConsoleTitleW(title)
            except Exception:
                sys.stdout.write(f"\033]0;{title}\007")
                sys.stdout.flush()
        else:
            sys.stdout.write(f"\033]0;{title}\007")
            sys.stdout.flush()
    except Exception:
        pass

def clear_screen():
    """Xóa màn hình an toàn theo hệ điều hành mà không phụ thuộc shell cứng."""
    try:
        if os.name == "nt":
            os.system("cls")
        else:
                                    
            sys.stdout.write("\033[H\033[2J")
            sys.stdout.flush()
    except Exception:
        pass

def get_terminal_width(default: int = 68) -> int:
    """Lấy độ rộng màn hình terminal hiện tại."""
    try:
        size = shutil.get_terminal_size((default, 24))
        return max(40, min(size.columns, 80))
    except Exception:
        return default

def print_banner():
    """Hiển thị Banner chào mừng nghệ thuật chuẩn KAGEVIETSUB."""
    set_terminal_title("KAGEVIETSUB")
    width = 48
    inner_width = width - 2
    
    C = Colors
    I = Icons

    line_top = f"{C.CYAN}{I.TOP_LEFT}{I.HORIZ * inner_width}{I.TOP_RIGHT}{C.RESET}"
    line_bot = f"{C.CYAN}{I.BOT_LEFT}{I.HORIZ * inner_width}{I.BOT_RIGHT}{C.RESET}"
    line_empty = f"{C.CYAN}{I.VERT}{' ' * inner_width}{I.VERT}{C.RESET}"
    
    title_text = "K A G E V I E T S U B"
    subtitle_text = "VIDEO • SRT • TTS • TOOLS"
    
    title_pad_l = (inner_width - len(title_text)) // 2
    title_pad_r = inner_width - len(title_text) - title_pad_l
    
    sub_pad_l = (inner_width - len(subtitle_text)) // 2
    sub_pad_r = inner_width - len(subtitle_text) - sub_pad_l

    title_line = (
        f"{C.CYAN}{I.VERT}{' ' * title_pad_l}"
        f"{C.BRIGHT_CYAN}{C.BOLD}{title_text}{C.RESET}"
        f"{' ' * title_pad_r}{C.CYAN}{I.VERT}{C.RESET}"
    )
    
    subtitle_line = (
        f"{C.CYAN}{I.VERT}{' ' * sub_pad_l}"
        f"{C.GRAY}{subtitle_text}{C.RESET}"
        f"{' ' * sub_pad_r}{C.CYAN}{I.VERT}{C.RESET}"
    )

    print()
    print(line_top)
    print(line_empty)
    print(title_line)
    print(line_empty)
    print(subtitle_line)
    print(line_empty)
    print(line_bot)
    print()

def print_info(msg: str):
    """In thông báo Info."""
    C = Colors
    I = Icons
    print(f" {C.CYAN}{I.INFO}{C.RESET} {C.WHITE}{msg}{C.RESET}")

def print_success(msg: str):
    """In thông báo Thành công."""
    C = Colors
    I = Icons
    print(f" {C.GREEN}{I.CHECK}{C.RESET} {C.WHITE}{msg}{C.RESET}")

def print_warning(msg: str):
    """In thông báo Cảnh báo."""
    C = Colors
    I = Icons
    print(f" {C.YELLOW}{I.WARN}{C.RESET} {C.YELLOW}{msg}{C.RESET}")

def print_error(msg: str, reason: Optional[str] = None):
    """In thông báo Lỗi chuyên nghiệp không dump traceback nếu không cần thiết."""
    C = Colors
    I = Icons
    print(f" {C.RED}{I.CROSS}{C.RESET} {C.BRIGHT_RED}{msg}{C.RESET}")
    if reason:
        print(f"   {C.GRAY}Reason: {C.RED}{reason}{C.RESET}")

def print_check(step_idx: int, total_steps: int, title: str, status: Any = "ok", reason: Optional[str] = None):
    """
    In một bước trong tiến trình kiểm tra với độ rộng cố định giúp tất cả dấu check (✓ / [OK])
    thẳng hàng 100% trên cả Windows CMD, PowerShell và Termux:
    [1/7] Checking Python          ✓
    """
    C = Colors
    I = Icons
    step_str = f"[{step_idx}/{total_steps}]"
    
    if status == "ok" or status is True or status == "OK":
        stat_icon = f"{C.GREEN}{I.CHECK}{C.RESET}"
    elif status == "fail" or status is False or status == "FAIL":
        stat_icon = f"{C.RED}{I.CROSS} FAILED{C.RESET}"
    elif status == "warn" or status == "WARN":
        stat_icon = f"{C.YELLOW}{I.WARN}{C.RESET}"
    elif status == "opt" or status == "OPTIONAL":
        stat_icon = f"{C.GRAY}{I.CIRCLE_OPT} OPTIONAL{C.RESET}"
    else:
        stat_icon = f"{C.CYAN}{status}{C.RESET}"

    title_padded = f"{title:<28}"
    
    print(f" {C.CYAN}{step_str}{C.RESET} {C.WHITE}{title_padded}{C.RESET} {stat_icon}")
    if (status == "fail" or status is False or status == "FAIL") and reason:
        print(f"        {C.GRAY}Reason: {C.RED}{reason}{C.RESET}")

def print_step(step_idx: int, total_steps: int, title: str, status: Any = "ok", reason: Optional[str] = None):
    """Alias tương thích cho print_check."""
    print_check(step_idx, total_steps, title, status, reason)

def print_server_card(local_url: str, lan_url: Optional[str] = None, port: int = 8000):
    """Hiển thị Card máy chủ đang hoạt động đẹp mắt (Localhost Only)."""
    C = Colors
    I = Icons
    width = 50
    inner = width - 2

    top = f"{C.CYAN}{I.ROUND_TL}{I.ROUND_HORIZ * inner}{I.ROUND_TR}{C.RESET}"
    mid = f"{C.CYAN}{I.ROUND_TL if not USE_UNICODE else '├'}{I.ROUND_HORIZ * inner}{I.ROUND_TR if not USE_UNICODE else '┤'}{C.RESET}"
    bot = f"{C.CYAN}{I.ROUND_BL}{I.ROUND_HORIZ * inner}{I.ROUND_BR}{C.RESET}"
    empty = f"{C.CYAN}{I.ROUND_VERT}{' ' * inner}{I.ROUND_VERT}{C.RESET}"

    def pad_line(content_raw: str, visible_len: int) -> str:
        pad_right = max(0, inner - visible_len - 2)
        return f"{C.CYAN}{I.ROUND_VERT}{C.RESET}  {content_raw}{' ' * pad_right}{C.CYAN}{I.ROUND_VERT}{C.RESET}"

    title = f"{C.BRIGHT_CYAN}{C.BOLD}KAGEVIETSUB{C.RESET}"
    status = f"{C.BRIGHT_GREEN}{I.CHECK} MÁY CHỦ SẴN SÀNG{C.RESET}"
    mode_line = f"{C.WHITE}Chế độ:  {C.BRIGHT_GREEN}Localhost Only (Riêng tư & An toàn){C.RESET}"
    local_line = f"{C.WHITE}Địa chỉ: {C.BRIGHT_CYAN}{C.UNDERLINE}{local_url}{C.RESET}"
    save_line = f"{C.WHITE}Lưu vào: {C.BRIGHT_YELLOW}Download/KAGEVIETSUB/{C.RESET}"
    hint = f"{C.GRAY}Bấm CTRL+C để dừng máy chủ{C.RESET}"

    title_pad_l = (inner - len("KAGEVIETSUB")) // 2
    title_pad_r = inner - len("KAGEVIETSUB") - title_pad_l
    title_centered = f"{C.CYAN}{I.ROUND_VERT}{' ' * title_pad_l}{title}{' ' * title_pad_r}{C.CYAN}{I.ROUND_VERT}{C.RESET}"

    print()
    print(top)
    print(title_centered)
    print(mid)
    print(empty)
    print(pad_line(status, len("  MÁY CHỦ SẴN SÀNG")))
    print(pad_line(mode_line, len("Chế độ:  Localhost Only (Riêng tư & An toàn)")))
    print(pad_line(local_line, len(f"Địa chỉ: {local_url}")))
    print(pad_line(save_line, len("Lưu vào: Download/KAGEVIETSUB/")))
    print(empty)
    print(pad_line(hint, len("Bấm CTRL+C để dừng máy chủ")))
    print(bot)
    print()

def print_progress(current: int, total: int, prefix: str = "", length: int = 24):
    """Alias cho print_progress_bar."""
    print_progress_bar(current, total, prefix, length)

def print_progress_bar(current: int, total: int, prefix: str = "", length: int = 24):
    """Vẽ thanh tiến trình trên cùng 1 dòng mà không spam hàng trăm dòng log."""
    if total <= 0:
        total = 1
    percent = float(current) / float(total)
    percent = min(1.0, max(0.0, percent))
    filled_len = int(length * percent)
    
    C = Colors
    I = Icons
    
    bar = f"{C.CYAN}{I.BAR_FULL * filled_len}{C.GRAY}{I.BAR_EMPTY * (length - filled_len)}{C.RESET}"
    pct_str = f"{int(percent * 100):3d}%"
    count_str = f"({current}/{total})"
    
    msg = f"\r {C.BRIGHT_CYAN}{prefix}{C.RESET} {bar} {C.BRIGHT_WHITE}{pct_str}{C.RESET} {C.GRAY}{count_str}{C.RESET}"
    sys.stdout.write(msg)
    sys.stdout.flush()
    if current >= total:
        sys.stdout.write("\n")
        sys.stdout.flush()

class Spinner:
    """Spinner xoay động mượt mà cho các tác vụ nền với ASCII/Unicode fallback."""
    def __init__(self, message: str = "Đang xử lý..."):
        self.message = message
        self.running = False
        self.thread = None
        if USE_UNICODE:
            self.frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
        else:
            self.frames = ["|", "/", "-", "\\"]

    def _spin(self):
        idx = 0
        C = Colors
        while self.running:
            frame = self.frames[idx % len(self.frames)]
            sys.stdout.write(f"\r {C.CYAN}{frame}{C.RESET} {C.WHITE}{self.message}{C.RESET}   ")
            sys.stdout.flush()
            idx += 1
            time.sleep(0.08)

    def start(self):
        self.running = True
        self.thread = threading.Thread(target=self._spin, daemon=True)
        self.thread.start()

    def stop(self, final_message: Optional[str] = None, success: bool = True):
        self.running = False
        if self.thread:
            self.thread.join(timeout=0.2)
        C = Colors
        I = Icons
        sys.stdout.write("\r" + " " * (len(self.message) + 15) + "\r")
        if final_message:
            icon = f"{C.GREEN}{I.CHECK}{C.RESET}" if success else f"{C.RED}{I.CROSS}{C.RESET}"
            sys.stdout.write(f" {icon} {C.WHITE}{final_message}{C.RESET}\n")
        sys.stdout.flush()

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.stop()
