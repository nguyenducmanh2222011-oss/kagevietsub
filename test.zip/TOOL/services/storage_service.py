import os
import sys
import json
import shutil
import platform
from pathlib import Path
from typing import Dict, Any, List, Optional

TOOL_DIR = Path(__file__).resolve().parent.parent
PROJECT_ROOT = TOOL_DIR.parent
DATA_DIR = PROJECT_ROOT / "DATA"

class StorageService:
    """
    Service quản lý lưu trữ trừu tượng hóa (Storage Abstraction).
    Tự động tương thích với Android/Termux, Windows, Linux Desktop và Google Colab.
    KHÔNG hardcode đường dẫn thiết bị trực tiếp trong các module khác.
    """

    @staticmethod
    def is_android() -> bool:
        if os.environ.get("TERMUX_VERSION") or os.environ.get("PREFIX", "").startswith("/data/data/com.termux"):
            return True
        if Path("/data/data/com.termux").exists():
            return True
        system_str = platform.system().lower()
        if "android" in system_str or "android" in platform.platform().lower():
            return True
        try:
            if hasattr(os, "uname") and "android" in os.uname().release.lower():
                return True
        except Exception:
            pass
        return False

    @staticmethod
    def is_colab() -> bool:
        """Nhận diện môi trường Google Colab."""
        if os.environ.get("COLAB_GPU") is not None or os.environ.get("COLAB_RELEASE_TAG") is not None or os.environ.get("KAGEVIETSUB_ENV") == "colab":
            return True
        if Path("/content").exists() and Path("/content").is_dir() and not StorageService.is_android():
            return True
        return False

    @staticmethod
    def is_drive_mounted() -> bool:
        """Kiểm tra xem Google Drive đã được mount tại /content/drive/MyDrive hay chưa."""
        drive_path = Path("/content/drive/MyDrive")
        if drive_path.exists() and drive_path.is_dir():
            try:
                test_file = drive_path / ".kage_test.tmp"
                test_file.touch()
                if test_file.exists():
                    test_file.unlink()
                return True
            except Exception:
                return False
        return False

    @classmethod
    def get_drive_dir(cls) -> Optional[Path]:
        """Trả về thư mục KAGEVIETSUB trên Google Drive nếu được mount."""
        if cls.is_drive_mounted():
            d = Path("/content/drive/MyDrive/KAGEVIETSUB")
            try:
                d.mkdir(parents=True, exist_ok=True)
                (d / "checkpoints").mkdir(parents=True, exist_ok=True)
                (d / "outputs").mkdir(parents=True, exist_ok=True)
                return d
            except Exception:
                return None
        return None

    @classmethod
    def sync_checkpoint_to_drive(cls, job_id: str, checkpoint_data: Dict[str, Any]):
        """Sao lưu file checkpoint nguyên tử sang Google Drive nếu khả dụng."""
        drive_dir = cls.get_drive_dir()
        if not drive_dir:
            return
        try:
            chk_dir = drive_dir / "checkpoints"
            chk_dir.mkdir(parents=True, exist_ok=True)
            target_f = chk_dir / f"{job_id}.json"
            tmp_f = chk_dir / f"{job_id}.tmp"
            with open(tmp_f, "w", encoding="utf-8") as f:
                json.dump(checkpoint_data, f, ensure_ascii=False, indent=2)
            tmp_f.replace(target_f)
        except Exception:
            pass

    @classmethod
    def sync_output_to_drive(cls, file_path: Path):
        """Sao lưu file kết quả đã hoàn thành sang Google Drive nếu khả dụng."""
        drive_dir = cls.get_drive_dir()
        if not drive_dir or not file_path or not file_path.exists():
            return
        try:
            out_dir = drive_dir / "outputs"
            out_dir.mkdir(parents=True, exist_ok=True)
            dest_f = out_dir / file_path.name
            if not dest_f.exists() or dest_f.stat().st_size != file_path.stat().st_size:
                tmp_f = out_dir / f"{file_path.name}.tmp"
                shutil.copy2(file_path, tmp_f)
                tmp_f.replace(dest_f)
        except Exception:
            pass

    @staticmethod
    def is_windows() -> bool:
        return os.name == "nt" or sys.platform == "win32"

    @classmethod
    def get_platform(cls) -> str:
        if cls.is_colab():
            return "colab"
        if cls.is_android():
            return "android"
        if cls.is_windows():
            return "windows"
        return "linux"

    @classmethod
    def get_root(cls) -> Path:
        return PROJECT_ROOT

    @classmethod
    def get_data_dir(cls) -> Path:
        if cls.is_colab():
            d = Path("/content/KAGEVIETSUB")
            d.mkdir(parents=True, exist_ok=True)
            return d
        d = DATA_DIR
        d.mkdir(parents=True, exist_ok=True)
        return d

    @classmethod
    def get_upload_dir(cls) -> Path:
        if cls.is_colab():
            d = Path("/content/KAGEVIETSUB/uploads")
            d.mkdir(parents=True, exist_ok=True)
            return d
        d = DATA_DIR / "uploads"
        d.mkdir(parents=True, exist_ok=True)
        return d

    @classmethod
    def get_temp_dir(cls) -> Path:
        if cls.is_colab():
            d = Path("/content/KAGEVIETSUB/temp")
            d.mkdir(parents=True, exist_ok=True)
            return d
        d = DATA_DIR / "temp"
        d.mkdir(parents=True, exist_ok=True)
        return d

    @classmethod
    def get_output_dir(cls) -> Path:
        """
        Xác định chính xác thư mục xuất file kết quả theo hệ điều hành:
        - COLAB: /content/KAGEVIETSUB/outputs
        - ANDROID: /storage/emulated/0/Download/KAGEVIETSUB hoặc ~/storage/downloads/KAGEVIETSUB
        - WINDOWS: %USERPROFILE%\\Downloads\\KAGEVIETSUB (~/Downloads/KAGEVIETSUB)
        - LINUX: ~/Downloads/KAGEVIETSUB
        """
        plat = cls.get_platform()

        if plat == "colab":
            out = Path("/content/KAGEVIETSUB/outputs")
            out.mkdir(parents=True, exist_ok=True)
            return out.resolve()

        if plat == "android":
            candidates = [
                Path("/storage/emulated/0/Download"),
                Path.home() / "storage" / "downloads",
                Path("/sdcard/Download")
            ]
            for base_dir in candidates:
                try:
                    if not base_dir.exists():
                        try:
                            base_dir.mkdir(parents=True, exist_ok=True)
                        except Exception:
                            continue
                    target = base_dir / "KAGEVIETSUB"
                    target.mkdir(parents=True, exist_ok=True)
                                                              
                    test_file = target / ".write_test.tmp"
                    try:
                        test_file.touch()
                        if test_file.exists():
                            test_file.unlink()
                        return target.resolve()
                    except Exception:
                        continue
                except Exception:
                    continue

            fallback = PROJECT_ROOT / "Download" / "KAGEVIETSUB"
            fallback.mkdir(parents=True, exist_ok=True)
            return fallback.resolve()

        elif plat == "windows":
            try:
                win_downloads = Path.home() / "Downloads" / "KAGEVIETSUB"
                win_downloads.mkdir(parents=True, exist_ok=True)
                return win_downloads.resolve()
            except Exception:
                pass

        elif plat == "linux":
            try:
                linux_downloads = Path.home() / "Downloads" / "KAGEVIETSUB"
                linux_downloads.mkdir(parents=True, exist_ok=True)
                return linux_downloads.resolve()
            except Exception:
                pass

        out = DATA_DIR / "output"
        out.mkdir(parents=True, exist_ok=True)
        return out.resolve()

    @classmethod
    def get_models_dir(cls) -> Path:
        if cls.is_colab():
            d = Path("/content/KAGEVIETSUB/models")
            d.mkdir(parents=True, exist_ok=True)
            return d
        d = DATA_DIR / "models"
        d.mkdir(parents=True, exist_ok=True)
        return d

    @classmethod
    def get_job_temp_dir(cls, job_id: str) -> Path:
        d = cls.get_temp_dir() / f"job_{job_id}"
        d.mkdir(parents=True, exist_ok=True)
        return d

    @classmethod
    def ensure_all_directories(cls):
        """Tự tạo tất cả các thư mục dữ liệu nếu chưa tồn tại."""
        dirs = [
            cls.get_data_dir(),
            cls.get_upload_dir(),
            cls.get_temp_dir(),
            cls.get_temp_dir() / "task_jobs",
            cls.get_output_dir(),
            cls.get_models_dir(),
            DATA_DIR / "logs",
        ]
        for d in dirs:
            d.mkdir(parents=True, exist_ok=True)
