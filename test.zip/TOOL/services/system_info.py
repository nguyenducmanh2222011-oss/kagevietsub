import os
import sys
import shutil
import platform
import subprocess
import logging
import traceback
from pathlib import Path
from typing import Dict, Any, Optional
from logging.handlers import RotatingFileHandler
from datetime import datetime, timezone

logger = logging.getLogger("kagevietsub.system_info")

class SystemInfoDetector:

    @staticmethod
    def is_android() -> bool:
        if os.environ.get("TERMUX_VERSION") or os.environ.get("PREFIX", "").startswith("/data/data/com.termux"):
            return True
        if Path("/data/data/com.termux").exists():
            return True
        system_str = platform.system().lower()
        if "android" in system_str or "android" in platform.platform().lower():
            return True
        try:
            if hasattr(os, "uname") and "android" in os.uname().release.lower():
                return True
        except Exception:
            pass
        return False

    @staticmethod
    def is_termux() -> bool:
        if os.environ.get("TERMUX_VERSION") or os.environ.get("PREFIX", "").startswith("/data/data/com.termux"):
            return True
        if Path("/data/data/com.termux").exists():
            return True
        return False

    @classmethod
    def get_device_type(cls) -> str:
        if cls.is_android():
            return "phone"
        return "pc"

    @staticmethod
    def get_cpu_model() -> str:
        try:
            cpuinfo_p = Path("/proc/cpuinfo")
            if cpuinfo_p.exists() and os.access(str(cpuinfo_p), os.R_OK):
                with open(cpuinfo_p, "r", encoding="utf-8", errors="ignore") as f:
                    for line in f:
                        line_s = line.strip()
                        if line_s.startswith("model name") or line_s.startswith("Hardware") or line_s.startswith("Processor"):
                            parts = line_s.split(":", 1)
                            if len(parts) > 1 and parts[1].strip():
                                return parts[1].strip()
        except Exception:
            pass

        try:
            proc = platform.processor()
            if proc and proc.lower() not in ["", "unknown", "none"]:
                return proc
        except Exception:
            pass

        if platform.system().lower() == "darwin":
            try:
                res = subprocess.run(["sysctl", "-n", "machdep.cpu.brand_string"], capture_output=True, text=True, timeout=2)
                if res.returncode == 0 and res.stdout.strip():
                    return res.stdout.strip()
            except Exception:
                pass

        if platform.system().lower() == "windows":
            ident = os.environ.get("PROCESSOR_IDENTIFIER")
            if ident:
                return ident

        arch = platform.machine() or "unknown"
        return f"Generic {arch} Processor"

    @classmethod
    def get_cpu_info(cls) -> Dict[str, Any]:
        logical_cores = os.cpu_count() or 4
        physical_cores = logical_cores

        try:
            import psutil
            p_cores = psutil.cpu_count(logical=False)
            if p_cores and p_cores > 0:
                physical_cores = p_cores
        except Exception:
            try:
                cpuinfo_p = Path("/proc/cpuinfo")
                if cpuinfo_p.exists() and os.access(str(cpuinfo_p), os.R_OK):
                    cores = set()
                    with open(cpuinfo_p, "r", encoding="utf-8", errors="ignore") as f:
                        for line in f:
                            if line.startswith("core id"):
                                cores.add(line.strip())
                    if cores:
                        physical_cores = len(cores)
            except Exception:
                pass

        model = cls.get_cpu_model()

        return {
            "model": model,
            "logical_cores": logical_cores,
            "physical_cores": physical_cores
        }

    @staticmethod
    def get_memory_info() -> Dict[str, int]:
        total_mb = 0
        available_mb = 0

        try:
            import psutil
            vm = psutil.virtual_memory()
            total_mb = int(vm.total / (1024 * 1024))
            available_mb = int(vm.available / (1024 * 1024))
            return {
                "total_mb": max(512, total_mb),
                "available_mb": max(256, available_mb)
            }
        except Exception:
            pass

        try:
            meminfo_p = Path("/proc/meminfo")
            if meminfo_p.exists() and os.access(str(meminfo_p), os.R_OK):
                mem_dict = {}
                with open(meminfo_p, "r", encoding="utf-8", errors="ignore") as f:
                    for line in f:
                        parts = line.split(":")
                        if len(parts) == 2:
                            k = parts[0].strip()
                            v_str = parts[1].strip().split()[0]
                            try:
                                mem_dict[k] = int(v_str)
                            except ValueError:
                                pass

                if "MemTotal" in mem_dict:
                    total_mb = int(mem_dict["MemTotal"] / 1024)

                if "MemAvailable" in mem_dict:
                    available_mb = int(mem_dict["MemAvailable"] / 1024)
                elif "MemFree" in mem_dict:
                    free_kb = mem_dict.get("MemFree", 0) + mem_dict.get("Buffers", 0) + mem_dict.get("Cached", 0)
                    available_mb = int(free_kb / 1024)

                if total_mb > 0:
                    if available_mb <= 0:
                        available_mb = max(256, int(total_mb * 0.5))
                    return {
                        "total_mb": total_mb,
                        "available_mb": available_mb
                    }
        except Exception:
            pass

        if platform.system().lower() == "windows":
            try:
                import ctypes

                class MEMORYSTATUSEX(ctypes.Structure):
                    _fields_ = [
                        ("dwLength", ctypes.c_ulong),
                        ("dwMemoryLoad", ctypes.c_ulong),
                        ("ullTotalPhys", ctypes.c_ulonglong),
                        ("ullAvailPhys", ctypes.c_ulonglong),
                        ("ullTotalPageFile", ctypes.c_ulonglong),
                        ("ullAvailPageFile", ctypes.c_ulonglong),
                        ("ullTotalVirtual", ctypes.c_ulonglong),
                        ("ullAvailVirtual", ctypes.c_ulonglong),
                        ("sullAvailExtendedVirtual", ctypes.c_ulonglong),
                    ]

                stat = MEMORYSTATUSEX()
                stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
                if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat)):
                    total_mb = int(stat.ullTotalPhys / (1024 * 1024))
                    available_mb = int(stat.ullAvailPhys / (1024 * 1024))
                    return {
                        "total_mb": max(512, total_mb),
                        "available_mb": max(256, available_mb)
                    }
            except Exception:
                pass

        if platform.system().lower() == "darwin":
            try:
                res = subprocess.run(["sysctl", "-n", "hw.memsize"], capture_output=True, text=True, timeout=2)
                if res.returncode == 0 and res.stdout.strip():
                    total_bytes = int(res.stdout.strip())
                    total_mb = int(total_bytes / (1024 * 1024))
                    available_mb = int(total_mb * 0.5)
                    return {
                        "total_mb": max(512, total_mb),
                        "available_mb": max(256, available_mb)
                    }
            except Exception:
                pass

        logical_cores = os.cpu_count() or 4
        est_total = logical_cores * 1024
        return {
            "total_mb": max(1024, est_total),
            "available_mb": max(512, int(est_total * 0.5))
        }

    @classmethod
    def get_android_info(cls) -> Dict[str, Any]:
        is_and = cls.is_android()
        is_ter = cls.is_termux()
        android_ver = "NOT_AVAILABLE"
        api_level = "NOT_AVAILABLE"
        manufacturer = "Unknown"
        model = "Unknown"
        brand = "Unknown"
        device = "Unknown"

        if is_and:
            def _getprop(prop: str) -> str:
                try:
                    res = subprocess.run(["getprop", prop], capture_output=True, text=True, timeout=2)
                    if res.returncode == 0 and res.stdout.strip():
                        return res.stdout.strip()
                except Exception:
                    pass
                return ""

            android_ver = _getprop("ro.build.version.release") or os.environ.get("ANDROID_VERSION", "NOT_AVAILABLE")
            api_level = _getprop("ro.build.version.sdk") or "NOT_AVAILABLE"
            manufacturer = _getprop("ro.product.manufacturer") or "Unknown"
            model = _getprop("ro.product.model") or "Unknown"
            brand = _getprop("ro.product.brand") or "Unknown"
            device = _getprop("ro.product.device") or "Unknown"

        termux_ver = os.environ.get("TERMUX_VERSION", "NOT_AVAILABLE")
        termux_prefix = os.environ.get("PREFIX", "NOT_AVAILABLE")
        termux_home = os.environ.get("HOME", "NOT_AVAILABLE")
        termux_storage = "NOT_AVAILABLE"
        try:
            st_p = Path.home() / "storage"
            if st_p.exists():
                termux_storage = str(st_p.resolve())
        except Exception:
            pass

        device_display = f"{manufacturer} {model}".strip() if (manufacturer != "Unknown" or model != "Unknown") else "Android Device"

        return {
            "is_android": is_and,
            "is_termux": is_ter,
            "android_version": android_ver,
            "api_level": api_level,
            "manufacturer": manufacturer,
            "model": model,
            "brand": brand,
            "device": device,
            "device_display": device_display,
            "termux_version": termux_ver,
            "termux_prefix": termux_prefix,
            "termux_home": termux_home,
            "termux_storage_path": termux_storage,
            "cpu_architecture": platform.machine() or "unknown"
        }

    @staticmethod
    def get_storage_info() -> Dict[str, Any]:
        from TOOL.services.storage_service import StorageService
        data_dir = StorageService.get_data_dir()
        out_dir = StorageService.get_output_dir()

        def _disk_stats(p: Path) -> Dict[str, Any]:
            try:
                target_p = p.resolve() if p.exists() else p.parent.resolve()
                if not target_p.exists():
                    target_p.mkdir(parents=True, exist_ok=True)

                total, used, free = 0, 0, 0
                try:
                    u = shutil.disk_usage(target_p)
                    total, used, free = u.total, u.used, u.free
                except Exception:
                    if hasattr(os, "statvfs"):
                        st = os.statvfs(str(target_p))
                        free = st.f_bavail * st.f_frsize
                        total = st.f_blocks * st.f_frsize
                        used = total - (st.f_bfree * st.f_frsize)
                    else:
                        raise

                free_mb = round(free / (1024 * 1024), 2)
                return {
                    "status": "ok",
                    "total_bytes": total,
                    "used_bytes": used,
                    "free_bytes": free,
                    "free_mb": free_mb,
                    "total_gb": round(total / (1024 ** 3), 2),
                    "used_gb": round(used / (1024 ** 3), 2),
                    "free_gb": round(free / (1024 ** 3), 2)
                }
            except Exception as e:
                return {
                    "status": "error",
                    "error_type": "STORAGE_CHECK_ERROR",
                    "error_message": str(e),
                    "total_gb": 0.0,
                    "used_gb": 0.0,
                    "free_gb": 0.0,
                    "free_mb": "STORAGE_CHECK_ERROR"
                }

        data_stats = _disk_stats(data_dir)
        out_stats = _disk_stats(out_dir)

        primary_free_mb = "STORAGE_CHECK_ERROR"
        if out_stats.get("status") == "ok":
            primary_free_mb = out_stats.get("free_mb", 0.0)
        elif data_stats.get("status") == "ok":
            primary_free_mb = data_stats.get("free_mb", 0.0)

        return {
            "free_mb": primary_free_mb,
            "data_storage": data_stats,
            "output_storage": out_stats
        }

    @staticmethod
    def get_dependencies_info() -> Dict[str, Any]:
        ffmpeg_p = shutil.which("ffmpeg")
        ffprobe_p = shutil.which("ffprobe")
        ytdlp_p = shutil.which("yt-dlp") or (Path(__file__).resolve().parent.parent / "bin" / "yt-dlp")
        ytdlp_exists = ytdlp_p is not None and (isinstance(ytdlp_p, str) or ytdlp_p.exists())

        ffmpeg_ver = "NOT_AVAILABLE"
        if ffmpeg_p:
            try:
                res = subprocess.run([ffmpeg_p, "-version"], capture_output=True, text=True, timeout=3)
                if res.returncode == 0 and res.stdout:
                    ffmpeg_ver = res.stdout.splitlines()[0]
            except Exception:
                pass

        ffprobe_ver = "NOT_AVAILABLE"
        if ffprobe_p:
            try:
                res = subprocess.run([ffprobe_p, "-version"], capture_output=True, text=True, timeout=3)
                if res.returncode == 0 and res.stdout:
                    ffprobe_ver = res.stdout.splitlines()[0]
            except Exception:
                pass

        ytdlp_ver = "NOT_AVAILABLE"
        if ytdlp_exists:
            try:
                cmd_y = str(ytdlp_p)
                res = subprocess.run([cmd_y, "--version"], capture_output=True, text=True, timeout=3)
                if res.returncode == 0 and res.stdout:
                    ytdlp_ver = res.stdout.strip()
            except Exception:
                pass

        return {
            "python": {
                "version": platform.python_version(),
                "implementation": platform.python_implementation(),
                "executable": sys.executable
            },
            "ffmpeg": {
                "installed": ffmpeg_p is not None,
                "path": str(ffmpeg_p) if ffmpeg_p else "NOT_AVAILABLE",
                "version": ffmpeg_ver
            },
            "ffprobe": {
                "installed": ffprobe_p is not None,
                "path": str(ffprobe_p) if ffprobe_p else "NOT_AVAILABLE",
                "version": ffprobe_ver
            },
            "ytdlp": {
                "installed": ytdlp_exists,
                "path": str(ytdlp_p) if ytdlp_p else "NOT_AVAILABLE",
                "version": ytdlp_ver
            }
        }

    @staticmethod
    def get_sanitized_env() -> Dict[str, str]:
        SECRET_KEYWORDS = ["KEY", "TOKEN", "SECRET", "PASSWORD", "PASS", "COOKIE", "AUTH", "CREDENTIALS", "CAPCUT", "PROXY"]
        result = {}
        for k, v in os.environ.items():
            k_upper = k.upper()
            if any(sec in k_upper for sec in SECRET_KEYWORDS):
                result[k] = "SECRET_PRESENT=true" if bool(v) else "SECRET_PRESENT=false"
            else:
                result[k] = v
        return result

    @classmethod
    def get_full_system_info(cls) -> Dict[str, Any]:
        from TOOL.services.storage_service import StorageService
        from TOOL.config import get_local_version

        android_env = cls.is_android()
        dev_type = cls.get_device_type()
        cpu_inf = cls.get_cpu_info()
        mem_inf = cls.get_memory_info()
        st_inf = cls.get_storage_info()
        and_inf = cls.get_android_info()
        deps_inf = cls.get_dependencies_info()

        arch = platform.machine() or "unknown"
        os_name = "Android" if android_env else platform.system()
        py_ver = platform.python_version()

        ffmpeg_installed = deps_inf["ffmpeg"]["installed"]
        ffprobe_installed = deps_inf["ffprobe"]["installed"]

        data_d = StorageService.get_data_dir()
        out_d = StorageService.get_output_dir()
        root_d = StorageService.get_root()

        paths = {
            "project_root": str(root_d.resolve()),
            "data": str(data_d.resolve()),
            "temp": str(StorageService.get_temp_dir().resolve()),
            "models": str(StorageService.get_models_dir().resolve()),
            "output": str((data_d / "output").resolve()),
            "uploads": str(StorageService.get_upload_dir().resolve()),
            "logs": str((data_d / "logs").resolve()),
            "download_output": str(out_d.resolve())
        }

        plat_str = "android_termux" if (and_inf["is_termux"] or android_env) else platform.system().lower()

        return {
            "status": "ok",
            "platform": plat_str,
            "device_type": dev_type,
            "os": os_name,
            "platform_display": "Android / Termux" if android_env else f"{platform.system()} ({platform.release()})",
            "version": get_local_version(),
            "python_version": py_ver,
            "architecture": arch,
            "cpu": cpu_inf,
            "memory": mem_inf,
            "storage": st_inf,
            "android": and_inf,
            "dependencies": deps_inf,
            "paths": paths,
            "ffmpeg": ffmpeg_installed,
            "ffprobe": ffprobe_installed
        }

    @classmethod
    def log_startup_session(cls, host: str = "127.0.0.1", port: int = 8000):
        from TOOL.services.logger import logger
        full_info = cls.get_full_system_info()
        logger.write_machine_info(full_info, host=host, port=port)
        logger.info("SYSTEM", "STARTUP", f"Server binding http://{host}:{port}")

    @classmethod
    def log_system_error(cls, module: str, error: Exception, job_id: Optional[str] = None, extra_context: Optional[Dict[str, Any]] = None):
        from TOOL.services.logger import logger
        logger.error(module, "SYSTEM_ERROR", str(error), job_id=job_id, exc=error, **(extra_context or {}))

def calculate_merge_workers(
    system_info: Optional[Dict[str, Any]] = None,
    job_info: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    if not system_info:
        system_info = SystemInfoDetector.get_full_system_info()

    if not job_info:
        job_info = {}

    is_android = system_info.get("platform") == "android" or system_info.get("device_type") == "phone"
    cpu_data = system_info.get("cpu", {})
    mem_data = system_info.get("memory", {})

    logical_cores = int(cpu_data.get("logical_cores") or os.cpu_count() or 4)
    available_ram_mb = int(mem_data.get("available_mb") or 2048)
    total_ram_mb = int(mem_data.get("total_mb") or 4096)
    audio_count = int(job_info.get("audio_count") or job_info.get("total_subtitles") or 100)
    active_tts_workers = int(job_info.get("active_tts_workers") or 0)

    if is_android:
        reserve_cpu = 1
        cpu_allowed = max(1, logical_cores - reserve_cpu)
        max_safe_limit = min(4, cpu_allowed)
    else:
        reserve_cpu = 1 if logical_cores <= 4 else 2
        cpu_allowed = max(1, logical_cores - reserve_cpu)
        max_safe_limit = min(12, cpu_allowed)

    if is_android:
        if available_ram_mb < 600:
            ram_allowed = 1
        elif available_ram_mb < 1500:
            ram_allowed = 2
        elif available_ram_mb < 3000:
            ram_allowed = 3
        else:
            ram_allowed = 4
    else:
        if available_ram_mb < 1000:
            ram_allowed = 1
        elif available_ram_mb < 2048:
            ram_allowed = 2
        elif available_ram_mb < 4096:
            ram_allowed = min(4, max_safe_limit)
        elif available_ram_mb < 8192:
            ram_allowed = min(6, max_safe_limit)
        else:
            ram_allowed = min(8, max_safe_limit)

    if audio_count <= 15:
        workload_cap = 1
    elif audio_count <= 50:
        workload_cap = 2
    elif audio_count <= 120:
        workload_cap = 4
    else:
        workload_cap = max_safe_limit

    tts_concurrency_penalty = 0
    if active_tts_workers > 0:
        tts_concurrency_penalty = max(1, int(active_tts_workers / 6))

    calculated_workers = min(cpu_allowed, ram_allowed, workload_cap)
    if tts_concurrency_penalty > 0:
        calculated_workers = max(1, calculated_workers - tts_concurrency_penalty)

    recommended_workers = max(1, min(calculated_workers, max_safe_limit))
    max_safe_workers = max(1, min(max_safe_limit, ram_allowed))

    ffmpeg_threads_per_worker = 1 if (is_android or recommended_workers >= 4) else 2

    debug_msg = (
        f"Device: {'Android' if is_android else 'PC'}, "
        f"CPU: {logical_cores} cores, RAM Avail: {available_ram_mb}MB, "
        f"Audio: {audio_count} items, Active TTS: {active_tts_workers} -> "
        f"Recommended: {recommended_workers} merge workers (Max Safe: {max_safe_workers})"
    )
    logger.info(f"[MERGE WORKER OPTIMIZER] {debug_msg}")

    return {
        "recommended_workers": recommended_workers,
        "max_safe_workers": max_safe_workers,
        "active_workers": recommended_workers,
        "device_type": "phone" if is_android else "pc",
        "is_android": is_android,
        "logical_cores": logical_cores,
        "available_ram_mb": available_ram_mb,
        "total_ram_mb": total_ram_mb,
        "audio_count": audio_count,
        "active_tts_workers": active_tts_workers,
        "ffmpeg_threads_per_worker": ffmpeg_threads_per_worker,
        "explanation": debug_msg
    }
