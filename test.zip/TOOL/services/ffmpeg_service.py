import os
import re
import shutil
import subprocess
import json
import time
import threading
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple, Callable
from TOOL.config import TEMP_DIR, OUTPUT_DIR
from TOOL.services.logger import logger

def parse_time_to_seconds(time_str: str) -> float:
    """Chuyển đổi chuỗi thời gian HH:MM:SS.micro sang giây."""
    try:
        parts = time_str.strip().split(":")
        if len(parts) == 3:
            return float(parts[0]) * 3600 + float(parts[1]) * 60 + float(parts[2])
    except Exception:
        pass
    return 0.0

def parse_speed_val(raw_val: str) -> float:
    """Chuyển đổi chuỗi tốc độ của FFmpeg (vd: 2.45x) sang số float."""
    try:
        cleaned = raw_val.strip().lower().replace("x", "")
        return float(cleaned)
    except Exception:
        return 0.0

class ETACalculator:
    """Tính toán thời gian dự kiến (ETA) và tốc độ thực tế với thuật toán làm mượt EWMA."""
    def __init__(self, smoothing: float = 0.25, min_samples_for_eta: int = 2):
        self.smoothing = smoothing
        self.min_samples_for_eta = min_samples_for_eta
        self.t_start = time.perf_counter()
        self.smoothed_eta: Optional[float] = None
        self.sample_count = 0

    def update(self, current_pct: float, current_speed_mult: float = 0.0) -> Tuple[Optional[int], str, float]:
        """
        Returns:
            (eta_seconds: Optional[int], speed_str: str, elapsed_seconds: float)
        """
        now = time.perf_counter()
        elapsed = now - self.t_start
        pct = max(0.0, min(100.0, float(current_pct)))
        if pct >= 100.0:
            return 0, "Hoàn tất", round(elapsed, 1)

        self.sample_count += 1
        # Tránh chia cho 0 hoặc dữ liệu chưa đủ trong 1 giây đầu
        if elapsed < 1.0 or pct < 2.0 or self.sample_count < self.min_samples_for_eta:
            speed_display = f"{current_speed_mult:.1f}x" if current_speed_mult > 0 else "Đang tính"
            return None, speed_display, round(elapsed, 1)

        pct_per_sec = pct / max(0.1, elapsed)
        if pct_per_sec <= 0.001:
            speed_display = f"{current_speed_mult:.1f}x" if current_speed_mult > 0 else "Đang tính"
            return None, speed_display, round(elapsed, 1)

        raw_eta = (100.0 - pct) / pct_per_sec
        if self.smoothed_eta is None:
            self.smoothed_eta = raw_eta
        else:
            self.smoothed_eta = self.smoothing * raw_eta + (1.0 - self.smoothing) * self.smoothed_eta

        eta_sec = max(1, int(round(self.smoothed_eta)))
        speed_display = f"{current_speed_mult:.1f}x" if current_speed_mult > 0 else f"{pct_per_sec:.1f}%/s"
        return eta_sec, speed_display, round(elapsed, 1)

class FFmpegService:
    @staticmethod
    def is_ffmpeg_installed() -> bool:
        """Check if FFmpeg executable is available."""
        return shutil.which("ffmpeg") is not None

    @staticmethod
    def is_ffprobe_installed() -> bool:
        """Check if FFprobe executable is available."""
        return shutil.which("ffprobe") is not None

    @staticmethod
    def check_nvenc_support() -> bool:
        """Check if NVIDIA GPU hardware encoding (h264_nvenc) is available."""
        try:
            res = subprocess.run(["ffmpeg", "-encoders"], capture_output=True, text=True)
            return "h264_nvenc" in res.stdout
        except Exception:
            return False

    @staticmethod
    def get_media_info(filepath: Path) -> Dict[str, Any]:
        """Extract media stream information using ffprobe."""
        path_str = str(filepath)
        cmd = [
            "ffprobe", "-v", "quiet", "-print_format", "json",
            "-show_streams", "-show_format", path_str
        ]
        start_t = time.time()
        try:
            res = subprocess.run(cmd, capture_output=True, text=True)
            dur_ms = int((time.time() - start_t) * 1000)
            if res.returncode != 0:
                logger.warning("FFPROBE", "INFO_FAILED", f"ffprobe exit code {res.returncode}", file=str(filepath), duration_ms=dur_ms)
                return {"duration": 0.0, "has_video": False, "has_audio": False}
            data = json.loads(res.stdout)
            streams = data.get("streams", [])
            fmt = data.get("format", {})
            duration = float(fmt.get("duration", 0.0))

            video_stream = next((s for s in streams if s.get("codec_type") == "video"), None)
            audio_stream = next((s for s in streams if s.get("codec_type") == "audio"), None)

            fps = 0.0
            if video_stream and "avg_frame_rate" in video_stream:
                rate = video_stream["avg_frame_rate"]
                if "/" in rate:
                    num, den = rate.split("/")
                    fps = float(num) / float(den) if float(den) != 0 else 0.0
                else:
                    fps = float(rate or 0.0)

            media_info = {
                "duration": duration,
                "size_mb": round(os.path.getsize(filepath) / (1024 * 1024), 2) if filepath.exists() else 0,
                "has_video": video_stream is not None,
                "has_audio": audio_stream is not None,
                "width": video_stream.get("width", 0) if video_stream else 0,
                "height": video_stream.get("height", 0) if video_stream else 0,
                "video_codec": video_stream.get("codec_name", "None") if video_stream else "None",
                "audio_codec": audio_stream.get("codec_name", "None") if audio_stream else "None",
                "fps": round(fps, 2)
            }
            logger.debug("FFPROBE", "MEDIA_INFO", f"Parsed info for {filepath.name}", duration=duration, has_v=media_info['has_video'], has_a=media_info['has_audio'])
            return media_info
        except Exception as e:
            logger.error("FFPROBE", "INFO_ERROR", f"Lỗi lấy thông tin file {filepath.name}", exc=e)
            return {"duration": 0.0, "error": str(e)}

    @staticmethod
    def prepare_audio_for_whisper(input_file: Path, output_wav: Path) -> Tuple[bool, str]:
        """
        Boost audio 25dB + acompressor:
        -vn -acodec pcm_s16le -ar 16000 -ac 1 -af "volume=25dB, acompressor=threshold=-30dB:ratio=3:attack=5:release=50"
        """
        cmd = [
            "ffmpeg", "-y", "-i", str(input_file),
            "-vn", "-acodec", "pcm_s16le", "-ar", "16000", "-ac", "1",
            "-af", "volume=25dB, acompressor=threshold=-30dB:ratio=3:attack=5:release=50",
            str(output_wav), "-loglevel", "error"
        ]
        start_t = time.time()
        logger.info("FFMPEG", "CMD_START", f"Prepare audio for whisper: {input_file.name} -> {output_wav.name}")
        res = subprocess.run(cmd, capture_output=True, text=True)
        dur_s = round(time.time() - start_t, 2)
        if res.returncode == 0:
            logger.info("FFMPEG", "CMD_SUCCESS", f"Audio boost prepared ({dur_s}s)", file=str(output_wav.name))
        else:
            logger.error(
                "FFMPEG", "CMD_ERROR",
                f"Audio boost failed ({dur_s}s) exit_code={res.returncode}",
                return_code=res.returncode,
                command=" ".join(cmd),
                stderr=res.stderr
            )
        return (res.returncode == 0, res.stderr)

    @staticmethod
    def run_ffmpeg_with_progress(
        cmd: List[str],
        total_duration: Optional[float] = None,
        progress_callback = None,
        cancel_check: Optional[Callable[[], bool]] = None,
        timeout: float = 300.0
    ) -> Tuple[bool, str]:
        """
        Execute FFmpeg command with non-blocking stderr drainage, -progress pipe:1 parsing,
        timeout control, and real-time percentage/speed/eta reporting.
        """
        full_cmd = list(cmd)
        if "-progress" not in full_cmd:
            insert_idx = 2 if len(full_cmd) > 1 and full_cmd[1] == "-y" else 1
            full_cmd[insert_idx:insert_idx] = ["-nostats", "-progress", "pipe:1"]

        stderr_lines: List[str] = []
        cmd_str = " ".join(full_cmd[:10]) + ("..." if len(full_cmd) > 10 else "")
        logger.info("FFMPEG", "CMD_START", f"Running progress command: {cmd_str}")
        start_t = time.perf_counter()

        try:
            process = subprocess.Popen(
                full_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1,
                universal_newlines=True
            )
        except Exception as ex:
            logger.error("FFMPEG", "CMD_EXCEPTION", f"Lỗi khởi chạy FFmpeg: {ex}", exc=ex)
            return False, str(ex)

        def _drain_stderr():
            try:
                if process.stderr:
                    for line in process.stderr:
                        stderr_lines.append(line)
            except Exception:
                pass

        drain_thread = threading.Thread(target=_drain_stderr, daemon=True)
        drain_thread.start()

        cur_sec = 0.0
        cur_speed_str = ""
        last_report_t = 0.0

        try:
            if process.stdout:
                for line in process.stdout:
                    line = line.strip()
                    if not line or "=" not in line:
                        continue
                    k, v = line.split("=", 1)
                    k, v = k.strip(), v.strip()

                    if k in ["out_time_us", "out_time_ms"]:
                        try:
                            cur_sec = float(v) / 1_000_000.0
                        except Exception:
                            pass
                    elif k == "out_time" and cur_sec <= 0.0:
                        cur_sec = parse_time_to_seconds(v)
                    elif k == "speed":
                        s_val = parse_speed_val(v)
                        if s_val > 0:
                            cur_speed_str = f"{s_val:.1f}x"
                    elif k == "progress" and v == "end":
                        if total_duration and total_duration > 0:
                            cur_sec = total_duration

                    # Kiểm tra hủy tác vụ
                    if cancel_check and cancel_check():
                        try:
                            process.kill()
                        except Exception:
                            pass
                        drain_thread.join(timeout=2)
                        return False, "Tiến trình bị dừng bởi người dùng."

                    # Kiểm tra timeout
                    now = time.perf_counter()
                    if now - start_t > timeout:
                        try:
                            process.kill()
                        except Exception:
                            pass
                        drain_thread.join(timeout=2)
                        return False, f"FFmpeg timed out sau {timeout}s."

                    # Báo cáo tiến độ với tần suất tối đa 10Hz (mỗi 0.1s)
                    if progress_callback and (now - last_report_t >= 0.08 or (k == "progress" and v == "end")):
                        last_report_t = now
                        if total_duration and total_duration > 0:
                            percent = min(99.0, (cur_sec / total_duration) * 100.0)
                        else:
                            percent = 0.0
                        try:
                            # Hỗ trợ callback nhận (percent, cur_sec, total_duration, speed_str)
                            progress_callback(percent, cur_sec, total_duration, cur_speed_str)
                        except TypeError:
                            try:
                                # Fallback callback cũ: (percent, cur_sec, total_duration)
                                progress_callback(percent, cur_sec, total_duration)
                            except Exception:
                                pass

            process.wait(timeout=10)
            drain_thread.join(timeout=3)

            full_stderr = "".join(stderr_lines).strip()
            dur_s = round(time.perf_counter() - start_t, 2)
            success = (process.returncode == 0)

            if success:
                logger.info("FFMPEG", "CMD_SUCCESS", f"FFmpeg command finished successfully in {dur_s}s")
                if progress_callback and total_duration and total_duration > 0:
                    try:
                        progress_callback(100.0, total_duration, total_duration, cur_speed_str)
                    except TypeError:
                        try:
                            progress_callback(100.0, total_duration, total_duration)
                        except Exception:
                            pass
            else:
                logger.error(
                    "FFMPEG", "CMD_FAILED",
                    f"FFmpeg command failed with exit code {process.returncode} ({dur_s}s)",
                    return_code=process.returncode,
                    command=" ".join(full_cmd),
                    stderr=full_stderr
                )

            return success, full_stderr

        except Exception as e:
            try:
                process.kill()
            except Exception:
                pass
            logger.error("FFMPEG", "CMD_EXCEPTION", f"Lỗi chạy tiến trình FFmpeg: {e}", exc=e)
            return False, str(e)

    @staticmethod
    def concat_audio_files(audio_files: List[Path], output_path: Path, progress_callback = None) -> Tuple[bool, str]:
        """Merge multiple audio files into one single audio file using concat demuxer."""
        concat_list_file = TEMP_DIR / f"audio_concat_{os.getpid()}.txt"
        with open(concat_list_file, "w", encoding="utf-8") as f:
            for p in audio_files:
                escaped = str(p.resolve()).replace("'", "'\\''")
                f.write(f"file '{escaped}'\n")

        total_duration = 0.0
        for f in audio_files:
            info = FFmpegService.get_media_info(f)
            total_duration += info.get("duration", 0.0)

        cmd = [
            "ffmpeg", "-y", "-f", "concat", "-safe", "0",
            "-i", str(concat_list_file),
            "-c:a", "libmp3lame", "-b:a", "192k",
            str(output_path)
        ]

        if total_duration > 0 and progress_callback:
            success, stderr = FFmpegService.run_ffmpeg_with_progress(cmd, total_duration, progress_callback)
        else:
            res = subprocess.run(cmd, capture_output=True, text=True)
            success = (res.returncode == 0)
            stderr = res.stderr

        if concat_list_file.exists():
            concat_list_file.unlink()
        return (success, stderr)

    @staticmethod
    def cut_video_segment(
        input_file: Path,
        start_seconds: float,
        duration_seconds: float,
        output_path: Path,
        mode: str = "copy"
    ) -> Tuple[bool, str]:
        """Cut a specific segment of a video file."""
        if mode == "copy":
            cmd = [
                "ffmpeg", "-y", "-ss", str(start_seconds),
                "-i", str(input_file),
                "-t", str(duration_seconds),
                "-c", "copy", "-avoid_negative_ts", "make_zero",
                str(output_path)
            ]
        else:
            cmd = [
                "ffmpeg", "-y", "-ss", str(start_seconds),
                "-i", str(input_file),
                "-t", str(duration_seconds),
                "-c:v", "libx264", "-c:a", "aac",
                str(output_path)
            ]
        res = subprocess.run(cmd, capture_output=True, text=True)
        return (res.returncode == 0, res.stderr)

    @staticmethod
    def concat_videos_lossless(video_files: List[Path], output_path: Path) -> Tuple[bool, str]:
        """Concatenate videos without re-encoding."""
        concat_file = TEMP_DIR / f"video_concat_{os.getpid()}.txt"
        with open(concat_file, "w", encoding="utf-8") as f:
            for vf in video_files:
                escaped = str(vf.resolve()).replace("'", "'\\''")
                f.write(f"file '{escaped}'\n")

        cmd = [
            "ffmpeg", "-y",
            "-f", "concat", "-safe", "0",
            "-i", str(concat_file),
            "-c", "copy",
            str(output_path)
        ]
        res = subprocess.run(cmd, capture_output=True, text=True)
        if concat_file.exists():
            concat_file.unlink()
        return (res.returncode == 0, res.stderr)

    @staticmethod
    def build_video_filter_complex(num_videos: int, has_audio_flags: List[bool]) -> str:
        """
        Build safe filter_complex handling videos with or without audio (from tool_gop_videov03.5).
        Synthesizes silent stereo audio if video has no audio.
        Normalizes video dimensions: scale=trunc(iw/2)*2:trunc(ih/2)*2, format=yuv420p.
        Normalizes audio: aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=stereo.
        """
        filter_parts = []
        for i in range(num_videos):
            if not has_audio_flags[i]:
                                                                        
                filter_parts.append(
                    f"[{i}:v:0]scale=trunc(iw/2)*2:trunc(ih/2)*2,format=yuv420p[v{i}];"
                    f"anullsrc=channel_layout=stereo:sample_rate=44100[a{i}]"
                )
            else:
                filter_parts.append(
                    f"[{i}:v:0]scale=trunc(iw/2)*2:trunc(ih/2)*2,format=yuv420p[v{i}];"
                    f"[{i}:a:0]aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=stereo[a{i}]"
                )

        video_inputs = "".join([f"[v{i}]" for i in range(num_videos)])
        audio_inputs = "".join([f"[a{i}]" for i in range(num_videos)])

        filter_complex = ";".join(filter_parts)
        filter_complex += f";{video_inputs}concat=n={num_videos}:v=1:a=0[vout];"
        filter_complex += f"{audio_inputs}concat=n={num_videos}:v=0:a=1[aout]"
        return filter_complex

    @staticmethod
    def concat_videos_reencode(
        video_files: List[Path],
        output_path: Path,
        use_gpu: bool = False,
        crf: int = 23,
        preset: str = "fast",
        progress_callback = None
    ) -> Tuple[bool, str]:
        """Concatenate videos with re-encoding, handling missing audio streams safely."""
        num_videos = len(video_files)
        has_audio_flags = []
        total_duration = 0.0

        for vf in video_files:
            info = FFmpegService.get_media_info(vf)
            has_audio_flags.append(info.get("has_audio", True))
            total_duration += info.get("duration", 0.0)

        inputs = []
        for vf in video_files:
            inputs.extend(["-i", str(vf.resolve())])

        filter_complex = FFmpegService.build_video_filter_complex(num_videos, has_audio_flags)

        can_use_gpu = use_gpu and FFmpegService.check_nvenc_support()
        if can_use_gpu:
            cmd = [
                "ffmpeg", "-y",
                "-fflags", "+genpts",
                *inputs,
                "-filter_complex", filter_complex,
                "-map", "[vout]", "-map", "[aout]",
                "-c:v", "h264_nvenc",
                "-preset", "p1",
                "-cq", str(crf or 23),
                "-c:a", "aac",
                "-b:a", "192k",
                str(output_path)
            ]
        else:
            cmd = [
                "ffmpeg", "-y",
                "-fflags", "+genpts",
                *inputs,
                "-filter_complex", filter_complex,
                "-map", "[vout]", "-map", "[aout]",
                "-c:v", "libx264",
                "-preset", preset or "fast",
                "-crf", str(crf or 23),
                "-c:a", "aac",
                "-b:a", "192k",
                str(output_path)
            ]

        if total_duration > 0 and progress_callback:
            return FFmpegService.run_ffmpeg_with_progress(cmd, total_duration, progress_callback)
        else:
            res = subprocess.run(cmd, capture_output=True, text=True)
            return (res.returncode == 0, res.stderr)

    @staticmethod
    def add_caption_to_video(
        input_video: Path,
        caption_text: str,
        output_path: Path,
        font_size: int = 24,
        font_color: str = "white",
        position: str = "bottom",
        use_gpu: bool = False,
        progress_callback = None
    ) -> Tuple[bool, str]:
        """Add text caption overlay onto a video with standard bounding box."""
        escaped_text = caption_text.replace("\\", "\\\\").replace(":", "\\:").replace("'", "\\'")
        if position == "bottom":
            y_pos = "h-th-50"
        elif position == "top":
            y_pos = "50"
        elif position == "center":
            y_pos = "(h-th)/2"
        else:
            y_pos = "h-th-50"

        drawtext_filter = (
            f"drawtext=text='{escaped_text}':"
            f"fontsize={font_size}:"
            f"fontcolor={font_color}:"
            f"x=(w-tw)/2:"
            f"y={y_pos}:"
            f"box=1:boxcolor=black@0.5:boxborderw=10"
        )

        can_use_gpu = use_gpu and FFmpegService.check_nvenc_support()
        codec = "h264_nvenc" if can_use_gpu else "libx264"
        cmd = [
            "ffmpeg", "-y", "-i", str(input_video),
            "-vf", drawtext_filter,
            "-c:v", codec, "-crf" if codec == "libx264" else "-cq", "23",
            "-preset", "p1" if codec == "h264_nvenc" else "fast",
            "-c:a", "copy",
            str(output_path)
        ]

        info = FFmpegService.get_media_info(input_video)
        total_duration = info.get("duration", 0.0)
        if total_duration > 0 and progress_callback:
            return FFmpegService.run_ffmpeg_with_progress(cmd, total_duration, progress_callback)
        else:
            res = subprocess.run(cmd, capture_output=True, text=True)
            return (res.returncode == 0, res.stderr)

    @staticmethod
    def compress_video(
        input_video: Path,
        output_path: Path,
        crf: int = 18,
        preset: str = "slow",
        codec: str = "libx264"
    ) -> Tuple[bool, str]:
        """Compress video using given CRF and preset."""
        cmd = [
            "ffmpeg", "-y", "-i", str(input_video),
            "-c:v", codec,
            "-preset", preset,
            "-crf", str(crf),
            "-c:a", "copy",
            "-movflags", "+faststart",
            str(output_path)
        ]
        res = subprocess.run(cmd, capture_output=True, text=True)
        return (res.returncode == 0, res.stderr)
