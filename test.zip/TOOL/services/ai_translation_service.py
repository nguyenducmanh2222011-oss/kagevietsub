import os
import re
import json
import time
import logging
import urllib.request
import urllib.error
import threading
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple
from enum import Enum
from TOOL.engines.srt_engine import SrtEngine
from TOOL.services.storage_service import StorageService
from TOOL.services.language_validator import LanguageValidator

logger = logging.getLogger("kagevietsub.ai_translation")


class ErrorCategory(str, Enum):
    INVALID_API_KEY = "INVALID_API_KEY"
    MODEL_NOT_FOUND = "MODEL_NOT_FOUND"
    RATE_LIMIT = "RATE_LIMIT"
    QUOTA_EXCEEDED = "QUOTA_EXCEEDED"
    TIMEOUT = "TIMEOUT"
    SERVER_ERROR = "SERVER_ERROR"
    NETWORK_ERROR = "NETWORK_ERROR"
    INVALID_RESPONSE = "INVALID_RESPONSE"
    CONTENT_ERROR = "CONTENT_ERROR"
    UNKNOWN_ERROR = "UNKNOWN_ERROR"


DEFAULT_PROMPTS = {
    "zh-vi": "Bạn là biên dịch viên chuyên dịch phụ đề phim Trung Quốc sang tiếng Việt.\nYêu cầu:\n- Dịch tự nhiên, thoát ý, đúng ngữ cảnh điện ảnh.\n- Giữ tên riêng (hán việt hoặc phiên âm phổ biến phù hợp).\n- Không dịch máy móc, giữ văn phong thoại tự nhiên.\n- Giữ nguyên các ký tự đặc biệt hoặc dấu câu thể hiện cảm xúc.",
    "en-vi": "Bạn là biên dịch viên chuyên nghiệp dịch phụ đề tiếng Anh sang tiếng Việt.\nYêu cầu:\n- Dịch tự nhiên, chính xác ngữ cảnh.\n- Giữ tên riêng và xưng hô phù hợp.\n- Văn phong thoại trôi chảy, không dịch thô.",
    "ja-vi": "Bạn là biên dịch viên chuyên nghiệp dịch phụ đề tiếng Nhật sang tiếng Việt.\nYêu cầu:\n- Dịch tự nhiên, đúng sắc thái xưng hô.\n- Giữ tên riêng và văn phong thoại phim.",
    "ko-vi": "Bạn là biên dịch viên chuyên nghiệp dịch phụ đề tiếng Hàn sang tiếng Việt.\nYêu cầu:\n- Dịch tự nhiên, đúng xưng hô thân mật hoặc trang trọng.\n- Giữ văn phong thoại tự nhiên."
}

PROVIDER_MODELS = {
    "ds2api": [
        "deepseek-v4-flash",
        "deepseek-v4-flash-nothinking",
        "deepseek-v4-pro",
        "deepseek-chat",
        "deepseek-reasoner",
        "deepseek-coder"
    ],
    "deepseek": [
        "deepseek-chat",
        "deepseek-coder",
        "deepseek-reasoner"
    ],
    "openai": [
        "gpt-4o",
        "gpt-4o-mini",
        "gpt-4-turbo",
        "gpt-3.5-turbo"
    ],
    "gemini": [
        "gemini-2.5-flash",
        "gemini-2.0-flash",
        "gemini-1.5-flash",
        "gemini-1.5-pro"
    ],
    "claude": [
        "claude-3-5-sonnet-20241022",
        "claude-3-5-haiku-20241022",
        "claude-3-opus-20240229"
    ],
    "grok": [
        "grok-2-latest",
        "grok-2-vision-1212",
        "grok-beta"
    ]
}


class AIProvider:
    def __init__(self, api_key: str, model: str):
        self.api_key = api_key.strip()
        self.model = model.strip()

    def validate_api(self) -> Dict[str, Any]:
        raise NotImplementedError

    def translate_batch(
        self,
        batch: List[Dict[str, Any]],
        source_lang: str,
        target_lang: str,
        user_prompt: str
    ) -> List[Dict[str, Any]]:
        raise NotImplementedError

    def classify_error(self, error: Exception) -> Tuple[ErrorCategory, str]:
        err_str = str(error).lower()
        if isinstance(error, urllib.error.HTTPError):
            code = error.code
            if code in (401, 403):
                return ErrorCategory.INVALID_API_KEY, f"API Key không hợp lệ hoặc bị từ chối (HTTP {code})"
            elif code == 404:
                return ErrorCategory.MODEL_NOT_FOUND, f"Model '{self.model}' không tồn tại hoặc không có quyền truy cập (HTTP 404)"
            elif code == 429:
                if "quota" in err_str or "exceeded" in err_str:
                    return ErrorCategory.QUOTA_EXCEEDED, "API hết quota / vượt hạn ngạch tài khoản (HTTP 429)"
                return ErrorCategory.RATE_LIMIT, "API vượt giới hạn tần suất request / Rate Limit (HTTP 429)"
            elif code in (500, 502, 503, 504):
                return ErrorCategory.SERVER_ERROR, f"Lỗi máy chủ Provider AI (HTTP {code})"
        elif isinstance(error, urllib.error.URLError):
            if "timeout" in err_str or "timed out" in err_str:
                return ErrorCategory.TIMEOUT, "Hết thời gian chờ phản hồi (Timeout)"
            return ErrorCategory.NETWORK_ERROR, f"Lỗi kết nối mạng: {error.reason}"
        elif isinstance(error, json.JSONDecodeError):
            return ErrorCategory.INVALID_RESPONSE, "Phản hồi từ AI không đúng định dạng JSON yêu cầu"
        
        if "rate limit" in err_str or "429" in err_str:
            return ErrorCategory.RATE_LIMIT, "Vượt quá tần suất gọi API (Rate Limit)"
        if "quota" in err_str:
            return ErrorCategory.QUOTA_EXCEEDED, "Hết dung lượng API / Quota Exceeded"
        if "unauthorized" in err_str or "invalid key" in err_str:
            return ErrorCategory.INVALID_API_KEY, "API Key không chính xác"

        return ErrorCategory.UNKNOWN_ERROR, f"Lỗi không xác định: {str(error)}"

    def _http_post_json(self, url: str, headers: Dict[str, str], payload: Dict[str, Any], timeout: int = 35) -> Dict[str, Any]:
        data_bytes = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(url, data=data_bytes, headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=timeout) as response:
            res_body = response.read().decode("utf-8")
            return json.loads(res_body)


class OpenAIStyleProvider(AIProvider):
    def __init__(self, api_key: str, model: str, base_url: str):
        super().__init__(api_key, model)
        self.base_url = base_url.rstrip("/")

    def validate_api(self) -> Dict[str, Any]:
        url = f"{self.base_url}/chat/completions"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": "You are a validator. Respond with JSON: {\"status\": \"ok\"}"},
                {"role": "user", "content": "Hi"}
            ],
            "max_tokens": 20
        }
        try:
            res = self._http_post_json(url, headers, payload, timeout=15)
            if "choices" in res and len(res["choices"]) > 0:
                return {
                    "valid": True,
                    "status": "VALID",
                    "message": f"✓ API hợp lệ. Kết nối thành công tới model {self.model}"
                }
            return {
                "valid": False,
                "status": "INVALID_RESPONSE",
                "message": "✕ Phản hồi từ provider không đúng cấu trúc OpenAI"
            }
        except Exception as e:
            cat, msg = self.classify_error(e)
            return {"valid": False, "status": cat.value, "message": f"✕ {msg}"}

    def translate_batch(
        self,
        batch: List[Dict[str, Any]],
        source_lang: str,
        target_lang: str,
        user_prompt: str
    ) -> List[Dict[str, Any]]:
        url = f"{self.base_url}/chat/completions"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }

        system_msg = (
            f"{user_prompt.strip()}\n\n"
            "QUY TẮC BẮT BUỘC:\n"
            "1. BẮT BUỘC trả về duy nhất 1 JSON object chuẩn có dạng:\n"
            '   {"translations": [{"id": <number>, "translation": "<nội dung dịch>"}]}\n'
            "2. ID trong kết quả phải KHỚP CHÍNH XÁC với ID nhập vào.\n"
            "3. CHỈ dịch phần text. KHÔNG tạo timestamp, KHÔNG tạo subtitle index, KHÔNG thêm giải thích.\n"
            "4. KHÔNG bọc JSON trong markdown fence hoặc văn bản dư thừa."
        )

        sub_input = [{"id": b["index"], "text": b["source"]} for b in batch]
        user_msg = f"Dịch các câu phụ đề sau sang {target_lang}:\n" + json.dumps(sub_input, ensure_ascii=False, indent=2)

        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_msg},
                {"role": "user", "content": user_msg}
            ],
            "temperature": 0.3
        }

        if "reasoner" not in self.model:
            payload["response_format"] = {"type": "json_object"}

        res = self._http_post_json(url, headers, payload, timeout=60)
        content_str = res["choices"][0]["message"]["content"]
        return parse_ai_json_response(content_str)


class GeminiProvider(AIProvider):
    def validate_api(self) -> Dict[str, Any]:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent?key={self.api_key}"
        headers = {"Content-Type": "application/json"}
        payload = {
            "contents": [{
                "parts": [{"text": "Hi"}]
            }],
            "generationConfig": {"maxOutputTokens": 10}
        }
        try:
            res = self._http_post_json(url, headers, payload, timeout=15)
            if "candidates" in res:
                return {
                    "valid": True,
                    "status": "VALID",
                    "message": f"✓ API hợp lệ. Kết nối thành công tới Gemini model {self.model}"
                }
            return {"valid": False, "status": "INVALID_RESPONSE", "message": "✕ Phản hồi từ Gemini API không khớp cấu trúc"}
        except Exception as e:
            cat, msg = self.classify_error(e)
            return {"valid": False, "status": cat.value, "message": f"✕ {msg}"}

    def translate_batch(
        self,
        batch: List[Dict[str, Any]],
        source_lang: str,
        target_lang: str,
        user_prompt: str
    ) -> List[Dict[str, Any]]:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent?key={self.api_key}"
        headers = {"Content-Type": "application/json"}

        system_instruction = (
            f"{user_prompt.strip()}\n\n"
            "QUY TẮC BẮT BUỘC:\n"
            '1. Trả về đúng JSON có dạng: {"translations": [{"id": <number>, "translation": "<string>"}]}\n'
            "2. ID trong kết quả KHỚP VỚI ID ĐẦU VÀO.\n"
            "3. Không thêm timestamp, không thêm nhận xét hay markdown."
        )

        sub_input = [{"id": b["index"], "text": b["source"]} for b in batch]
        prompt_text = f"{system_instruction}\n\nDịch danh sách phụ đề sau sang {target_lang}:\n" + json.dumps(sub_input, ensure_ascii=False)

        payload = {
            "contents": [{
                "parts": [{"text": prompt_text}]
            }],
            "generationConfig": {
                "temperature": 0.3,
                "responseMimeType": "application/json"
            }
        }

        res = self._http_post_json(url, headers, payload, timeout=60)
        cand = res.get("candidates", [])[0]
        text_res = cand.get("content", {}).get("parts", [])[0].get("text", "")
        return parse_ai_json_response(text_res)


class ClaudeProvider(AIProvider):
    def validate_api(self) -> Dict[str, Any]:
        url = "https://api.anthropic.com/v1/messages"
        headers = {
            "Content-Type": "application/json",
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01"
        }
        payload = {
            "model": self.model,
            "max_tokens": 10,
            "messages": [{"role": "user", "content": "Hi"}]
        }
        try:
            res = self._http_post_json(url, headers, payload, timeout=15)
            if "content" in res:
                return {
                    "valid": True,
                    "status": "VALID",
                    "message": f"✓ API hợp lệ. Kết nối thành công tới Claude model {self.model}"
                }
            return {"valid": False, "status": "INVALID_RESPONSE", "message": "✕ Phản hồi từ Anthropic API không hợp lệ"}
        except Exception as e:
            cat, msg = self.classify_error(e)
            return {"valid": False, "status": cat.value, "message": f"✕ {msg}"}

    def translate_batch(
        self,
        batch: List[Dict[str, Any]],
        source_lang: str,
        target_lang: str,
        user_prompt: str
    ) -> List[Dict[str, Any]]:
        url = "https://api.anthropic.com/v1/messages"
        headers = {
            "Content-Type": "application/json",
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01"
        }

        system_msg = (
            f"{user_prompt.strip()}\n\n"
            "QUY TẮC BẮT BUỘC:\n"
            '1. Trả về đúng JSON object dạng: {"translations": [{"id": <number>, "translation": "<string>"}]}\n'
            "2. ID giữ nguyên 100%. CHỈ dịch text.\n"
            "3. Không thêm bớt dòng hay timestamp."
        )

        sub_input = [{"id": b["index"], "text": b["source"]} for b in batch]
        user_msg = f"Dịch các dòng sau sang {target_lang}:\n" + json.dumps(sub_input, ensure_ascii=False)

        payload = {
            "model": self.model,
            "max_tokens": 4096,
            "system": system_msg,
            "messages": [{"role": "user", "content": user_msg}],
            "temperature": 0.3
        }

        res = self._http_post_json(url, headers, payload, timeout=60)
        content_block = res.get("content", [])[0]
        text_res = content_block.get("text", "")
        return parse_ai_json_response(text_res)


class DS2APIProvider(AIProvider):
    """
    Provider kết nối tới DS2API local service / account pool.
    Tuân thủ chuẩn OpenAI / DeepSeek Web và tự động xác thực token session.
    """
    def __init__(self, api_key: str, model: str, account_id: Optional[str] = None):
        super().__init__(api_key, model)
        self.account_id = account_id

    def validate_api(self) -> Dict[str, Any]:
        from TOOL.services.ds2api_service import ds2api_service
        # Kiểm tra trạng thái service và accounts
        status_info = ds2api_service.get_status()
        if not status_info.get("running"):
            ds2api_service.start_service()
            status_info = ds2api_service.get_status()

        if status_info.get("total_accounts", 0) == 0:
            return {
                "valid": False,
                "status": "NO_ACCOUNTS",
                "message": "✕ Chưa có tài khoản DeepSeek nào trong DS2API Account Pool. Vui lòng thêm tài khoản trước."
            }

        if status_info.get("active_accounts", 0) == 0:
            return {
                "valid": False,
                "status": "ALL_ACCOUNTS_ERROR",
                "message": "✕ Tất cả tài khoản DS2API đang gặp lỗi đăng nhập hoặc token hết hạn. Vui lòng kiểm tra lại tài khoản."
            }

        return {
            "valid": True,
            "status": "VALID",
            "message": f"✓ DS2API sẵn sàng ({status_info.get('active_accounts')} tài khoản hoạt động). Model: {self.model}"
        }

    def translate_batch(
        self,
        batch: List[Dict[str, Any]],
        source_lang: str,
        target_lang: str,
        user_prompt: str
    ) -> List[Dict[str, Any]]:
        from TOOL.services.ds2api_service import ds2api_service

        system_msg = (
            f"{user_prompt.strip()}\n\n"
            "QUY TẮC BẮT BUỘC:\n"
            "1. BẮT BUỘC trả về duy nhất 1 JSON object chuẩn có dạng:\n"
            '   {"translations": [{"id": <number>, "translation": "<nội dung dịch>"}]}\n'
            "2. ID trong kết quả phải KHỚP CHÍNH XÁC với ID nhập vào.\n"
            "3. CHỈ dịch phần text. KHÔNG tạo timestamp, KHÔNG tạo subtitle index, KHÔNG thêm giải thích.\n"
            "4. KHÔNG bọc JSON trong markdown fence hoặc văn bản dư thừa."
        )

        sub_input = [{"id": b["index"], "text": b["source"]} for b in batch]
        user_msg = f"Dịch các câu phụ đề sau sang {target_lang}:\n" + json.dumps(sub_input, ensure_ascii=False, indent=2)

        messages = [
            {"role": "system", "content": system_msg},
            {"role": "user", "content": user_msg}
        ]

        ok, err_msg, content_str = ds2api_service.execute_chat_completion(
            messages=messages,
            model=self.model,
            account_id=self.account_id,
            temperature=0.3
        )

        if not ok or not content_str:
            raise RuntimeError(err_msg or "Không nhận được phản hồi từ DS2API")

        return parse_ai_json_response(content_str)


def create_provider(provider_name: str, api_key: str, model: str, account_id: Optional[str] = None) -> AIProvider:
    p_name = provider_name.lower().strip()
    if p_name in ("ds2api", "deepseek_web", "ds2api_web"):
        return DS2APIProvider(api_key, model, account_id=account_id)
    elif p_name == "deepseek":
        return OpenAIStyleProvider(api_key, model, "https://api.deepseek.com/v1")
    elif p_name == "openai":
        return OpenAIStyleProvider(api_key, model, "https://api.openai.com/v1")
    elif p_name == "grok":
        return OpenAIStyleProvider(api_key, model, "https://api.xai.com/v1")
    elif p_name == "gemini":
        return GeminiProvider(api_key, model)
    elif p_name == "claude":
        return ClaudeProvider(api_key, model)
    else:
        return OpenAIStyleProvider(api_key, model, "https://api.openai.com/v1")


def parse_ai_json_response(text: str) -> List[Dict[str, Any]]:
    if not text or not text.strip():
        return []

    clean_text = text.strip()
    clean_text = re.sub(r"^```(?:json)?", "", clean_text, flags=re.IGNORECASE).strip()
    clean_text = re.sub(r"```$", "", clean_text).strip()

    try:
        data = json.loads(clean_text)
        if isinstance(data, dict):
            if "translations" in data and isinstance(data["translations"], list):
                return data["translations"]
            elif "data" in data and isinstance(data["data"], list):
                return data["data"]
            elif "subtitles" in data and isinstance(data["subtitles"], list):
                return data["subtitles"]
            for v in data.values():
                if isinstance(v, list) and len(v) > 0 and isinstance(v[0], dict) and ("id" in v[0] or "index" in v[0]):
                    return v
        elif isinstance(data, list):
            return data
    except Exception:
        pass

    match = re.search(r"\{.*\"translations\"\s*:\s*\[.*\]\s*\}", text, re.DOTALL)
    if match:
        try:
            data = json.loads(match.group(0))
            return data.get("translations", [])
        except Exception:
            pass

    results = []
    items = re.findall(r'\{\s*"id"\s*:\s*(\d+)\s*,\s*"translation"\s*:\s*"([^"]+)"\s*\}', text)
    for item_id, item_trans in items:
        try:
            results.append({"id": int(item_id), "translation": item_trans})
        except ValueError:
            pass

    return results


class ApiPoolScheduler:
    def __init__(self, api_pool: List[Dict[str, Any]]):
        self.lock = threading.Lock()
        self.pool = []
        for idx, item in enumerate(api_pool):
            self.pool.append({
                "id": item.get("id") or f"api_{idx+1}",
                "provider": item.get("provider", "deepseek"),
                "api_key": item.get("api_key", ""),
                "model": item.get("model", "deepseek-chat"),
                "status": "active",
                "error_count": 0,
                "cooldown_until": 0.0,
                "disabled": False
            })
        self.current_idx = 0

    def mask_key(self, key: str) -> str:
        if not key or len(key) < 8:
            return "sk-••••••••"
        return f"{key[:3]}••••••••{key[-4:]}"

    def get_working_api(self) -> Optional[Dict[str, Any]]:
        with self.lock:
            if not self.pool:
                return None
            
            now = time.time()
            pool_len = len(self.pool)

            for i in range(pool_len):
                candidate_idx = (self.current_idx + i) % pool_len
                api = self.pool[candidate_idx]

                if api["disabled"]:
                    continue

                if api["cooldown_until"] > now:
                    continue

                self.current_idx = (candidate_idx + 1) % pool_len
                return api

            for api in self.pool:
                if not api["disabled"]:
                    api["cooldown_until"] = 0.0
                    return api

            return None

    def report_success(self, api_id: str):
        with self.lock:
            for api in self.pool:
                if api["id"] == api_id:
                    api["error_count"] = 0
                    api["status"] = "active"
                    api["cooldown_until"] = 0.0
                    break

    def report_error(self, api_id: str, category: ErrorCategory, detail: str):
        with self.lock:
            for api in self.pool:
                if api["id"] == api_id:
                    api["error_count"] += 1
                    if category == ErrorCategory.INVALID_API_KEY:
                        api["disabled"] = True
                        api["status"] = "disabled"
                        logger.warning(f"[API SCHEDULER] Vô hiệu hóa API {api_id} do Key không hợp lệ.")
                    elif category in (ErrorCategory.RATE_LIMIT, ErrorCategory.QUOTA_EXCEEDED, ErrorCategory.TIMEOUT, ErrorCategory.SERVER_ERROR):
                        cooldown_secs = min(300, 30 * api["error_count"])
                        api["cooldown_until"] = time.time() + cooldown_secs
                        api["status"] = "cooldown"
                        logger.info(f"[API SCHEDULER] Đặt API {api_id} vào Cooldown {cooldown_secs}s do lỗi {category.value}.")
                    break

    def get_status_summary(self) -> List[Dict[str, Any]]:
        with self.lock:
            now = time.time()
            summary = []
            for api in self.pool:
                st = "active"
                if api["disabled"]:
                    st = "disabled"
                elif api["cooldown_until"] > now:
                    st = "cooldown"
                summary.append({
                    "id": api["id"],
                    "provider": api["provider"],
                    "masked_key": self.mask_key(api["api_key"]),
                    "model": api["model"],
                    "status": st,
                    "error_count": api["error_count"],
                    "cooldown_remaining": max(0, int(api["cooldown_until"] - now))
                })
            return summary


class QaScanner:
    TIMESTAMP_REGEX = re.compile(r"\d{2}:\d{2}:\d{2}[,\.]\d{3}\s*-->\s*\d{2}:\d{2}:\d{2}[,\.]\d{3}")
    ERROR_KEYWORDS = ["ERROR", "[ERROR]", "NULL", "N/A", "TODO", "[API_ERROR]", "UNDEFINED"]

    @classmethod
    def verify_block(
        cls,
        source_item: Dict[str, Any],
        translated_item: Optional[Dict[str, Any]],
        target_lang: str = "vi"
    ) -> Tuple[bool, str, Optional[str]]:
        if not translated_item:
            return False, "Không nhận được phản hồi từ AI cho câu này", None

        trans_text = str(translated_item.get("translation", "")).strip()
        if not trans_text:
            return False, "Bản dịch rỗng", None

        if trans_text.isdigit() and int(trans_text) == source_item["index"]:
            return False, "AI trả về index thay vì bản dịch text", None

        if cls.TIMESTAMP_REGEX.search(trans_text):
            return False, "Bản dịch chứa timestamp thừa từ AI", None

        upper_trans = trans_text.upper()
        for kw in cls.ERROR_KEYWORDS:
            if kw in upper_trans:
                return False, f"Bản dịch chứa từ khóa lỗi '{kw}'", None

        clean_trans = re.sub(r"^```(?:json)?", "", trans_text, flags=re.IGNORECASE).strip()
        clean_trans = re.sub(r"```$", "", clean_trans).strip()

        # Language Detection and Validation on output
        lang_res = LanguageValidator.validate_item(
            source_text=source_item.get("source", ""),
            translated_text=clean_trans,
            target_lang_input=target_lang
        )

        if lang_res["result"] == "FAIL":
            return False, f"Không đúng ngôn ngữ đích ({lang_res['reason']})", None

        return True, "OK", clean_trans


class SrtTranslationJobManager:
    def __init__(self):
        self.jobs: Dict[str, Dict[str, Any]] = {}
        self.lock = threading.Lock()
        self.storage_dir = StorageService.get_temp_dir() / "translate_jobs"
        self.storage_dir.mkdir(parents=True, exist_ok=True)

    def create_job(
        self,
        srt_content: str,
        filename: str,
        api_pool: List[Dict[str, Any]],
        source_lang: str = "zh",
        target_lang: str = "vi",
        batch_size: int = 20,
        user_prompt: Optional[str] = None
    ) -> str:
        job_id = f"trans_{int(time.time()*1000)}"
        blocks = SrtEngine.parse_srt(srt_content)

        parsed_items = []
        for idx, b in enumerate(blocks):
            parsed_items.append({
                "index": int(b["index"]) if str(b["index"]).isdigit() else (idx + 1),
                "raw_index": b["index"],
                "start": b["start"],
                "end": b["end"],
                "source": b["text"],
                "translation": None,
                "status": "pending",
                "error": None,
                "retry_count": 0
            })

        default_prompt = DEFAULT_PROMPTS.get(f"{source_lang}-{target_lang}", DEFAULT_PROMPTS["zh-vi"])
        final_prompt = user_prompt.strip() if user_prompt and user_prompt.strip() else default_prompt

        job = {
            "job_id": job_id,
            "filename": filename or "subtitle.srt",
            "source_lang": source_lang,
            "target_lang": target_lang,
            "batch_size": max(1, min(100, batch_size)),
            "user_prompt": final_prompt,
            "api_pool": api_pool,
            "status": "queued",
            "progress": 0,
            "message": "Đã khởi tạo công việc dịch SRT...",
            "total_items": len(parsed_items),
            "completed_items": 0,
            "verified_items": 0,
            "retry_items": 0,
            "failed_items": 0,
            "items": parsed_items,
            "output_path": None,
            "output_location": None,
            "created_at": time.time(),
            "logs": [f"[{time.strftime('%H:%M:%S')}] Đã tạo job dịch SRT với {len(parsed_items)} câu."]
        }

        with self.lock:
            self.jobs[job_id] = job

        threading.Thread(target=self._run_job, args=(job_id,), daemon=True).start()
        return job_id

    def pause_job(self, job_id: str) -> Dict[str, Any]:
        with self.lock:
            job = self.jobs.get(job_id)
            if not job:
                return {"status": "error", "message": "Không tìm thấy job."}
            if job["status"] == "processing":
                job["status"] = "paused"
                job["message"] = "Đã tạm dừng tiến trình dịch SRT."
                self._add_log(job, "Tiến trình dịch đã được tạm dừng bởi người dùng.")
                return {"status": "ok", "message": "Đã tạm dừng."}
            return {"status": "ok", "message": f"Trạng thái hiện tại: {job['status']}"}

    def resume_job(self, job_id: str) -> Dict[str, Any]:
        with self.lock:
            job = self.jobs.get(job_id)
            if not job:
                return {"status": "error", "message": "Không tìm thấy job."}
            if job["status"] in ("paused", "stopped", "cancelled"):
                job["status"] = "processing"
                job["message"] = "Đang tiếp tục dịch các câu chưa hoàn thành..."
                self._add_log(job, "Tiếp tục tiến trình dịch từ câu chưa hoàn tất.")
                threading.Thread(target=self._run_job, args=(job_id,), daemon=True).start()
                return {"status": "ok", "message": "Đã tiếp tục tiến trình dịch."}
            return {"status": "ok", "message": f"Job đang ở trạng thái: {job['status']}"}

    def stop_job(self, job_id: str) -> Dict[str, Any]:
        with self.lock:
            job = self.jobs.get(job_id)
            if not job:
                return {"status": "error", "message": "Không tìm thấy job."}
            job["status"] = "stopped"
            job["message"] = "Đã dừng tiến trình dịch SRT (Giữ nguyên các câu đã dịch)."
            self._add_log(job, "Đã dừng tiến trình. Xuất kết quả hiện tại...")
            try:
                out_p = self._export_final_srt(job)
                job["output_path"] = str(out_p)
                job["output_location"] = f"Download/KAGEVIETSUB/{out_p.name}"
            except Exception as e:
                logger.error(f"Lỗi xuất file khi stop job: {e}")
            return {"status": "ok", "message": "Đã dừng tiến trình và lưu kết quả hiện tại."}

    def retry_job(self, job_id: str) -> Dict[str, Any]:
        with self.lock:
            job = self.jobs.get(job_id)
            if not job:
                return {"status": "error", "message": "Không tìm thấy job."}
            failed_count = 0
            for it in job["items"]:
                if it["status"] in ("failed", "retry"):
                    it["status"] = "pending"
                    it["error"] = None
                    failed_count += 1
            if failed_count == 0:
                return {"status": "ok", "message": "Không có câu lỗi nào cần thử lại."}
            job["status"] = "processing"
            job["message"] = f"Đang thử lại {failed_count} câu bị lỗi..."
            self._add_log(job, f"Bắt đầu thử lại {failed_count} câu bị lỗi...")
            threading.Thread(target=self._run_job, args=(job_id,), daemon=True).start()
            return {"status": "ok", "message": f"Bắt đầu thử lại {failed_count} câu lỗi."}

    def get_job(self, job_id: str) -> Optional[Dict[str, Any]]:
        with self.lock:
            job = self.jobs.get(job_id)
            if not job:
                return None

            return {
                "job_id": job["job_id"],
                "filename": job["filename"],
                "status": job["status"],
                "progress": job["progress"],
                "message": job["message"],
                "total_items": job["total_items"],
                "completed_items": job["completed_items"],
                "verified_items": job["verified_items"],
                "retry_items": job["retry_items"],
                "failed_items": job["failed_items"],
                "output_path": job.get("output_path"),
                "output_location": job.get("output_location"),
                "created_at": job["created_at"],
                "logs": job["logs"][-20:],
                "items_summary": [
                    {
                        "index": it["index"],
                        "start": it["start"],
                        "end": it["end"],
                        "source": it["source"],
                        "translation": it["translation"],
                        "status": it["status"]
                    }
                    for it in job["items"]
                ]
            }

    def _add_log(self, job: Dict[str, Any], text: str):
        t_str = time.strftime("%H:%M:%S")
        log_entry = f"[{t_str}] {text}"
        job["logs"].append(log_entry)
        logger.info(f"[{job['job_id']}] {text}")

    def _run_job(self, job_id: str):
        with self.lock:
            job = self.jobs.get(job_id)
            if not job:
                return
            job["status"] = "processing"
            job["message"] = "Đang bắt đầu dịch các batch phụ đề..."

        scheduler = ApiPoolScheduler(job["api_pool"])
        items = job["items"]
        batch_size = job["batch_size"]
        total = len(items)

        batches = [items[i:i + batch_size] for i in range(0, total, batch_size)]
        self._add_log(job, f"Chia làm {len(batches)} batch (kích thước {batch_size} câu/batch).")

        for b_idx, batch in enumerate(batches):
            if job["status"] in ("cancelled", "failed", "stopped"):
                self._add_log(job, f"Job đã chuyển sang trạng thái {job['status']}.")
                return

            while job["status"] == "paused":
                time.sleep(0.5)
                if job["status"] in ("cancelled", "failed", "stopped"):
                    return

            # Check if all items in this batch are already translated
            untranslated = [it for it in batch if it["status"] != "translated"]
            if not untranslated:
                continue

            self._process_batch_with_retry(job, untranslated, scheduler, b_idx + 1, len(batches))
            
            with self.lock:
                done = sum(1 for it in items if it["status"] == "translated")
                job["completed_items"] = done
                job["verified_items"] = done
                job["progress"] = int((done / total) * 100) if total > 0 else 100
                job["message"] = f"Đã dịch thành công {done}/{total} câu ({job['progress']}%)..."

        if job["status"] in ("cancelled", "failed", "stopped", "paused"):
            return

        retry_queue = [it for it in items if it["status"] in ("pending", "retry", "failed")]
        if retry_queue:
            self._add_log(job, f"Bắt đầu QA Scan & Retry Queue cho {len(retry_queue)} câu chưa hoàn tất...")
            for attempt in range(1, 4):
                if job["status"] in ("cancelled", "failed", "stopped", "paused"):
                    return
                still_failing = [it for it in items if it["status"] in ("pending", "retry", "failed")]
                if not still_failing:
                    break
                self._add_log(job, f"Lần Retry #{attempt} cho {len(still_failing)} câu...")
                retry_batches = [still_failing[i:i + batch_size] for i in range(0, len(still_failing), batch_size)]
                for rb_idx, r_batch in enumerate(retry_batches):
                    if job["status"] in ("cancelled", "failed", "stopped", "paused"):
                        return
                    self._process_batch_with_retry(job, r_batch, scheduler, rb_idx + 1, len(retry_batches), is_retry=True)

        final_done = sum(1 for it in items if it["status"] == "translated")
        final_failed = sum(1 for it in items if it["status"] == "failed")
        job["completed_items"] = final_done
        job["verified_items"] = final_done
        job["failed_items"] = final_failed
        job["progress"] = 100

        output_file_path = self._export_final_srt(job)
        job["output_path"] = str(output_file_path)
        job["output_location"] = f"Download/KAGEVIETSUB/{output_file_path.name}"
        job["status"] = "completed"
        job["message"] = f"✓ Hoàn tất dịch phụ đề ({final_done}/{total} câu). File đã lưu tại {job['output_location']}"
        self._add_log(job, job["message"])

    def _process_batch_with_retry(
        self,
        job: Dict[str, Any],
        batch: List[Dict[str, Any]],
        scheduler: ApiPoolScheduler,
        batch_num: int,
        total_batches: int,
        is_retry: bool = False
    ):
        for it in batch:
            it["status"] = "translating" if not is_retry else "retry"

        max_attempts = 3
        success = False

        for attempt in range(max_attempts):
            api_info = scheduler.get_working_api()
            if not api_info:
                self._add_log(job, "⚠ Không còn API làm việc khả dụng trong pool.")
                break

            provider_obj = create_provider(api_info["provider"], api_info["api_key"], api_info["model"])
            try:
                target_lang_name = LanguageValidator.normalize_lang_name(job["target_lang"])
                effective_prompt = job["user_prompt"]
                if attempt > 0 or is_retry:
                    effective_prompt += (
                        f"\n\nOUTPUT MUST BE IN {target_lang_name.upper()}.\n"
                        f"DO NOT OUTPUT THE SOURCE LANGUAGE.\n"
                        f"DO NOT EXPLAIN.\n"
                        f"RETURN ONLY THE TRANSLATED TEXT."
                    )

                res_list = provider_obj.translate_batch(
                    batch,
                    job["source_lang"],
                    job["target_lang"],
                    effective_prompt
                )

                res_map = {}
                for r in res_list:
                    r_id = r.get("id") or r.get("index")
                    if r_id is not None and str(r_id).isdigit():
                        res_map[int(r_id)] = r

                batch_all_ok = True
                for item in batch:
                    matched_res = res_map.get(item["index"])
                    is_ok, reason, clean_text = QaScanner.verify_block(item, matched_res, job["target_lang"])
                    if is_ok and clean_text:
                        item["translation"] = clean_text
                        item["status"] = "translated"
                        item["error"] = None
                    else:
                        batch_all_ok = False
                        item["status"] = "retry"
                        item["error"] = reason

                scheduler.report_success(api_info["id"])
                if batch_all_ok or any(it["status"] == "translated" for it in batch):
                    success = True
                    break
                else:
                    logger.info(f"[LANG CHECK] Retry: {attempt + 1}/{max_attempts} cho Batch {batch_num}/{total_batches}")

            except Exception as e:
                cat, err_msg = provider_obj.classify_error(e)
                scheduler.report_error(api_info["id"], cat, err_msg)
                self._add_log(job, f"Batch {batch_num}/{total_batches} qua API {api_info['id']} gặp lỗi [{cat.value}]: {err_msg}")
                time.sleep(1)

        for item in batch:
            if item["status"] != "translated":
                if item["translation"]:
                    item["status"] = "translated"
                else:
                    item["status"] = "failed"
                    item["translation"] = f"[DỊCH THẤT BẠI] {item['source']}"

    def _export_final_srt(self, job: Dict[str, Any]) -> Path:
        out_lines = []
        for item in job["items"]:
            out_lines.append(str(item["raw_index"]))
            out_lines.append(f"{item['start']} --> {item['end']}")
            out_lines.append(item["translation"] or item["source"])
            out_lines.append("")

        final_srt_str = "\n".join(out_lines).strip() + "\n"

        from TOOL.config import KAGE_DOWNLOAD_DIR, get_safe_unique_filepath
        orig_name = job.get("filename") or "translated.srt"
        base_stem = Path(orig_name).stem
        target_suffix = str(job.get("target_lang", "VI")).upper()
        target_name = f"{base_stem}_{target_suffix}.srt"

        out_path = get_safe_unique_filepath(KAGE_DOWNLOAD_DIR, target_name)
        out_path.write_text(final_srt_str, encoding="utf-8")

        temp_out = StorageService.get_data_dir() / "output" / out_path.name
        temp_out.write_text(final_srt_str, encoding="utf-8")

        return out_path


translation_job_manager = SrtTranslationJobManager()
