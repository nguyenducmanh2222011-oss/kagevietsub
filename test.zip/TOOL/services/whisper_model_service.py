#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB - WHISPER MODEL DETECTOR & MANAGEMENT SERVICE
==============================================================================
Tự động quét, nhận diện, kiểm tra tính hợp lệ và quản lý Whisper AI Models
trong thư mục DATA/models/:
- Nhận diện các model Whisper được hỗ trợ (tiny, base, small, medium, large-v3, large-v3-turbo)
- Kiểm tra toàn vẹn cấu trúc file (model.bin, config.json, tokenizer/vocabulary)
- Phát hiện model lỗi / tải dở dang / 0-byte (invalid_models)
- Phát hiện thư mục lạ / model không được hỗ trợ (unsupported_models)
- Chỉ cho phép chọn các model Whisper đã tải thực tế và hợp lệ
- Tự động tải model từ Hugging Face qua background task với thanh tiến trình
- Cung cấp thông tin cảnh báo RAM/CPU và khuyến nghị cấu hình máy
==============================================================================
"""

import os
import re
import json
import shutil
import urllib.request
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple

from TOOL.config import MODELS_DIR
from TOOL.services.task_service import job_manager

WHISPER_SPECS: Dict[str, Dict[str, Any]] = {
    "tiny": {
        "id": "tiny",
        "name": "Tiny (Siêu nhẹ)",
        "hf_repo": "Systran/faster-whisper-tiny",
        "size_mb": 75,
        "min_ram": "500 MB",
        "speed": "Siêu nhanh (Rất nhanh)",
        "accuracy": "Cơ bản",
        "desc": "Tốc độ nhanh nhất, tiêu tốn cực ít RAM. Thích hợp máy rất yếu, Android đời cũ hoặc thử nghiệm nhanh.",
        "recommended": False
    },
    "base": {
        "id": "base",
        "name": "Base (Nhẹ)",
        "hf_repo": "Systran/faster-whisper-base",
        "size_mb": 145,
        "min_ram": "1 GB",
        "speed": "Nhanh",
        "accuracy": "Khá",
        "desc": "Nhanh và nhẹ. Phù hợp cho thiết bị Android Termux và máy tính cấu hình văn phòng.",
        "recommended": False
    },
    "small": {
        "id": "small",
        "name": "Small (Cân bằng & Nhanh)",
        "hf_repo": "Systran/faster-whisper-small",
        "size_mb": 461,
        "min_ram": "2 GB",
        "speed": "Tốt",
        "accuracy": "Tốt",
        "desc": "Cân bằng hoàn hảo giữa tốc độ và độ chính xác nhận diện tiếng Trung. Khuyên dùng cho Android & PC phổ thông.",
        "recommended": True
    },
    "medium": {
        "id": "medium",
        "name": "Medium (Chính xác cao)",
        "hf_repo": "Systran/faster-whisper-medium",
        "size_mb": 1500,
        "min_ram": "5 GB",
        "speed": "Trung bình",
        "accuracy": "Rất cao",
        "desc": "Độ chính xác cao, nhận diện tốt các từ phức tạp. Cần thiết bị có tối thiểu 6GB RAM.",
        "recommended": False
    },
    "large-v3-turbo": {
        "id": "large-v3-turbo",
        "name": "Large v3 Turbo (Chuẩn Studio)",
        "hf_repo": "Systran/faster-whisper-large-v3-turbo",
        "size_mb": 1600,
        "min_ram": "6 GB",
        "speed": "Nhanh (Tối ưu Turbo)",
        "accuracy": "Xuất sắc (Tương đương Large-v3)",
        "desc": "Độ chính xác chuẩn phòng thu như Large v3 nhưng được tối ưu tốc độ nhanh hơn 4x-8x. Khuyên dùng cho PC / máy mạnh.",
        "recommended": True
    },
    "large-v3": {
        "id": "large-v3",
        "name": "Large v3 (Chính xác tối đa)",
        "hf_repo": "Systran/faster-whisper-large-v3",
        "size_mb": 3100,
        "min_ram": "8 GB",
        "speed": "Chậm",
        "accuracy": "Tối đa",
        "desc": "Chính xác tuyệt đối cho các đoạn thoại khó, lẫn tạp âm nặng. Yêu cầu PC hoặc card đồ họa mạnh.",
        "recommended": False
    },
}

ADDITIONAL_SUPPORTED_NAMES = {
    "tiny.en": "tiny",
    "base.en": "base",
    "small.en": "small",
    "medium.en": "medium",
    "large-v1": "large-v3",
    "large-v2": "large-v3",
    "large": "large-v3",
}

CT2_REQUIRED_CORE_FILES = ["model.bin", "config.json"]
CT2_TOKENIZER_FILES = ["tokenizer.json", "vocabulary.json", "vocabulary.txt"]

class WhisperModelService:
    """Service kiểm tra, quét và tải Whisper AI Models."""

    @staticmethod
    def get_supported_specs() -> List[Dict[str, Any]]:
        """Trả về thông tin đặc tả của tất cả model Whisper được hỗ trợ."""
        return list(WHISPER_SPECS.values())

    @staticmethod
    def _normalize_model_id(name: str) -> Optional[str]:
        """Chuẩn hóa tên thư mục thành model ID Whisper hợp lệ."""
        clean = name.strip().lower()

        clean = re.sub(r"^models--systran--faster-whisper-", "", clean)
        clean = re.sub(r"^systran[-_/]faster-whisper-", "", clean)
        clean = re.sub(r"^faster[-_]whisper[-_]", "", clean)
        clean = re.sub(r"^whisper[-_]", "", clean)

        if clean.endswith(".pt") or clean.endswith(".bin"):
            clean = clean[:-3]

        if clean in WHISPER_SPECS:
            return clean

        if clean in ADDITIONAL_SUPPORTED_NAMES:
            return ADDITIONAL_SUPPORTED_NAMES[clean]

        for key in WHISPER_SPECS.keys():
            if clean == key or clean.startswith(f"{key}-") or clean.endswith(f"-{key}"):
                return key

        return None

    @staticmethod
    def _check_ctranslate2_directory(model_dir: Path) -> Tuple[bool, Optional[str], int]:
        """
        Kiểm tra thư mục model định dạng CTranslate2 / faster-whisper.
        Trả về: (is_valid, error_reason, total_bytes)
        """
                                                                
        snapshot_dir = model_dir / "snapshots"
        if snapshot_dir.is_dir():
            snaps = [d for d in snapshot_dir.iterdir() if d.is_dir()]
            if snaps:
                                        
                return WhisperModelService._check_ctranslate2_directory(snaps[0])

        model_bin = model_dir / "model.bin"
        config_json = model_dir / "config.json"

        if not model_bin.is_file():
            return False, "Thiếu file model.bin bắt buộc của CTranslate2", 0

        bin_size = model_bin.stat().st_size
        if bin_size < 1_000_000:                                                   
            return False, f"File model.bin bị lỗi hoặc chưa tải xong (Kích thước: {bin_size} bytes)", bin_size

        if not config_json.is_file():
            return False, "Thiếu file config.json", bin_size

        try:
            with open(config_json, "r", encoding="utf-8") as f:
                cfg = json.load(f)
                                                                            
            model_type = cfg.get("model_type", "")
            if model_type and "whisper" not in str(model_type).lower():
                return False, f"config.json không phải kiến trúc Whisper (model_type: {model_type})", bin_size
        except Exception as e:
            return False, f"File config.json không đọc được hoặc lỗi định dạng JSON: {str(e)}", bin_size

        has_tokenizer = any((model_dir / tok_f).is_file() for tok_f in CT2_TOKENIZER_FILES)
        if not has_tokenizer:
            return False, "Thiếu file từ điển (tokenizer.json, vocabulary.json hoặc vocabulary.txt)", bin_size

        total_size = 0
        for root, _, files in os.walk(model_dir):
            for file in files:
                fp = Path(root) / file
                try:
                    total_size += fp.stat().st_size
                except Exception:
                    pass

        return True, None, total_size

    @staticmethod
    def scan_models() -> Dict[str, Any]:
        """
        Quét toàn bộ thư mục DATA/models/ và trả về phân loại chi tiết:
        - models: Các model Whisper hợp lệ và đã tải thực tế
        - unsupported_models: Các thư mục/model lạ không được hỗ trợ
        - invalid_models: Model Whisper nhưng thiếu file hoặc bị hỏng
        - default_model: Model mặc định (CHỈ chọn trong số các model đã tải)
        - available: True nếu có ít nhất 1 model Whisper hợp lệ
        """
        MODELS_DIR.mkdir(parents=True, exist_ok=True)

        valid_models: List[Dict[str, Any]] = []
        unsupported_models: List[Dict[str, Any]] = []
        invalid_models: List[Dict[str, Any]] = []

        try:
            entries = sorted(list(MODELS_DIR.iterdir()), key=lambda x: x.name.lower())
        except Exception:
            entries = []

        seen_model_ids = set()

        for item in entries:
                                                         
            if item.name.startswith(".") or item.name.endswith(".tmp") or item.name.endswith(".part"):
                continue

            if item.is_dir():
                matched_id = WhisperModelService._normalize_model_id(item.name)

                if not matched_id:
                                                                                
                    cfg_file = item / "config.json"
                    is_whisper_cfg = False
                    if cfg_file.is_file():
                        try:
                            with open(cfg_file, "r", encoding="utf-8") as f:
                                c = json.load(f)
                            if "whisper" in str(c.get("model_type", "")).lower():
                                is_whisper_cfg = True
                        except Exception:
                            pass

                    if not is_whisper_cfg:
                        unsupported_models.append({
                            "folder_name": item.name,
                            "path": f"DATA/models/{item.name}",
                            "status": "unsupported",
                            "reason": "Thư mục không thuộc danh mục Whisper AI được KAGEVIETSUB hỗ trợ"
                        })
                        continue
                    else:
                        matched_id = "custom-whisper"

                is_valid, err_reason, total_bytes = WhisperModelService._check_ctranslate2_directory(item)

                if is_valid:
                    spec = WHISPER_SPECS.get(matched_id, {})
                    display_name = spec.get("name", matched_id.capitalize())
                    valid_models.append({
                        "id": matched_id,
                        "name": display_name,
                        "folder_name": item.name,
                        "path": f"DATA/models/{item.name}",
                        "abs_path": str(item.resolve()),
                        "type": "faster-whisper",
                        "format": "CTranslate2",
                        "status": "available",
                        "size_mb": round(total_bytes / (1024 * 1024), 1),
                        "min_ram": spec.get("min_ram", "1 GB"),
                        "speed": spec.get("speed", "Tốt"),
                        "accuracy": spec.get("accuracy", "Tốt"),
                        "desc": spec.get("desc", ""),
                        "recommended": spec.get("recommended", False)
                    })
                    seen_model_ids.add(matched_id)
                else:
                    invalid_models.append({
                        "id": matched_id,
                        "folder_name": item.name,
                        "path": f"DATA/models/{item.name}",
                        "status": "invalid",
                        "reason": err_reason or "Cấu trúc thư mục model không hợp lệ"
                    })

            elif item.is_file():
                if item.name.endswith(".pt"):
                    stem = item.stem.lower()
                    matched_id = WhisperModelService._normalize_model_id(stem)
                    if matched_id:
                        f_size = item.stat().st_size
                        if f_size > 10_000_000:          
                            spec = WHISPER_SPECS.get(matched_id, {})
                            valid_models.append({
                                "id": matched_id,
                                "name": spec.get("name", matched_id.capitalize()),
                                "folder_name": item.name,
                                "path": f"DATA/models/{item.name}",
                                "abs_path": str(item.resolve()),
                                "type": "openai-whisper",
                                "format": "PyTorch (.pt)",
                                "status": "available",
                                "size_mb": round(f_size / (1024 * 1024), 1),
                                "min_ram": spec.get("min_ram", "1 GB"),
                                "speed": spec.get("speed", "Tốt"),
                                "accuracy": spec.get("accuracy", "Tốt"),
                                "desc": spec.get("desc", ""),
                                "recommended": spec.get("recommended", False)
                            })
                            seen_model_ids.add(matched_id)
                        else:
                            invalid_models.append({
                                "id": matched_id,
                                "folder_name": item.name,
                                "path": f"DATA/models/{item.name}",
                                "status": "invalid",
                                "reason": f"File PyTorch model (.pt) quá nhỏ ({f_size} bytes)"
                            })
                    else:
                        unsupported_models.append({
                            "folder_name": item.name,
                            "path": f"DATA/models/{item.name}",
                            "status": "unsupported",
                            "reason": "File .pt không thuộc danh sách model Whisper được hỗ trợ"
                        })

        default_model = None
        if valid_models:
            valid_ids = [m["id"] for m in valid_models]
                                                                 
            preference = ["large-v3-turbo", "small", "base", "tiny", "medium", "large-v3"]
            for pref in preference:
                if pref in valid_ids:
                    default_model = pref
                    break
            if not default_model:
                default_model = valid_models[0]["id"]

        active_downloads: Dict[str, Dict[str, Any]] = {}
        for j in job_manager.get_active_jobs():
            if j.get("type") == "whisper_model_download":
                m_id = j.get("metadata", {}).get("model_id")
                if m_id:
                    active_downloads[m_id] = {
                        "job_id": j.get("job_id"),
                        "status": "downloading",
                        "progress": j.get("progress", 0),
                        "message": j.get("message", "Đang tải..."),
                    }

        valid_map = {m["id"]: m for m in valid_models}
        invalid_map = {m["id"]: m for m in invalid_models if m.get("id")}
        
        catalog = []
        for spec_key, spec_val in WHISPER_SPECS.items():
            item_status = "not_downloaded"
            item_progress = 0
            item_error = None
            item_job_id = None
            item_valid = False
            item_path = None
            
            if spec_key in valid_map:
                item_status = "downloaded"
                item_valid = True
                item_progress = 100
                item_path = valid_map[spec_key].get("path")
            elif spec_key in active_downloads:
                item_status = "downloading"
                item_progress = active_downloads[spec_key].get("progress", 0)
                item_job_id = active_downloads[spec_key].get("job_id")
            elif spec_key in invalid_map:
                item_status = "invalid"
                item_error = invalid_map[spec_key].get("reason")
                item_path = invalid_map[spec_key].get("path")
            
            catalog.append({
                "id": spec_key,
                "name": spec_val["name"],
                "size_mb": spec_val["size_mb"],
                "min_ram": spec_val["min_ram"],
                "speed": spec_val["speed"],
                "accuracy": spec_val["accuracy"],
                "desc": spec_val["desc"],
                "recommended": spec_val.get("recommended", False),
                "status": item_status,
                "valid": item_valid,
                "progress": item_progress,
                "job_id": item_job_id,
                "error": item_error,
                "path": item_path
            })

        recommendation = WhisperModelService._get_system_recommendation()

        return {
            "available": len(valid_models) > 0,
            "models": valid_models,
            "catalog": catalog,
            "active_downloads": active_downloads,
            "default_model": default_model,
            "unsupported_models": unsupported_models,
            "invalid_models": invalid_models,
            "supported_specs": WhisperModelService.get_supported_specs(),
            "models_dir": str(MODELS_DIR),
            "recommendation": recommendation,
            "total_valid_count": len(valid_models),
            "total_unsupported_count": len(unsupported_models),
            "total_invalid_count": len(invalid_models)
        }

    @staticmethod
    def _get_system_recommendation() -> Dict[str, Any]:
        """Tự động phân tích môi trường và đưa ra khuyến nghị model phù hợp."""
        is_android = "ANDROID_ROOT" in os.environ or "TERMUX_VERSION" in os.environ or Path("/data/data/com.termux").exists()

        if is_android:
            return {
                "platform": "Android / Termux",
                "recommended_model": "small",
                "alternative_model": "base",
                "warning": "Trên thiết bị Android / Termux, nên ưu tiên dùng model Small hoặc Base để tránh tràn RAM (OOM) và tối ưu thời gian xử lý."
            }
        else:
            return {
                "platform": "PC / Laptop / Server",
                "recommended_model": "large-v3-turbo",
                "alternative_model": "small",
                "warning": "Hãy chọn Model phù hợp với cấu hình máy của bạn. Model càng lớn thường yêu cầu nhiều RAM/CPU hơn và thời gian xử lý có thể lâu hơn."
            }

    @staticmethod
    def start_download_model(model_id: str) -> Dict[str, Any]:
        """
        Bắt đầu tiến trình tải Whisper model từ Hugging Face về DATA/models/{model_id}/
        thông qua background task của job_manager.
        """
        clean_id = WhisperModelService._normalize_model_id(model_id) or model_id
        if clean_id not in WHISPER_SPECS:
            raise ValueError(f"Model '{model_id}' không nằm trong danh mục Whisper được hỗ trợ ({', '.join(WHISPER_SPECS.keys())}).")

        for j in job_manager.get_active_jobs():
            if j.get("type") == "whisper_model_download" and j.get("metadata", {}).get("model_id") == clean_id:
                return {
                    "job_id": j["job_id"],
                    "status": "downloading",
                    "model_id": clean_id,
                    "name": WHISPER_SPECS[clean_id]["name"],
                    "progress": j.get("progress", 0),
                    "message": f"Model '{WHISPER_SPECS[clean_id]['name']}' đang được tải trong tiến trình (Job: {j['job_id']})."
                }

        spec = WHISPER_SPECS[clean_id]
        target_dir = MODELS_DIR / clean_id

        job_id = job_manager.create_job("whisper_model_download", {
            "model_id": clean_id,
            "name": spec["name"],
            "target_dir": str(target_dir),
            "size_mb": spec["size_mb"]
        })

        def _download_task(jid: str):
            WhisperModelService._execute_download_job(clean_id, spec, target_dir, jid)

        job_manager.run_in_background(job_id, _download_task)

        return {
            "job_id": job_id,
            "status": "queued",
            "model_id": clean_id,
            "name": spec["name"],
            "message": f"Đã bắt đầu tải model '{spec['name']}' vào {target_dir}."
        }

    @staticmethod
    def _execute_download_job(model_id: str, spec: Dict[str, Any], target_dir: Path, job_id: str):
        """Thực hiện tải model theo các file cần thiết với cập nhật % tiến trình."""
        try:
            job_manager.update_job(job_id, progress=5, message=f"Đang chuẩn bị thư mục tải cho model '{spec['name']}'...")
            target_dir.mkdir(parents=True, exist_ok=True)

            repo = spec["hf_repo"]
            base_url = f"https://huggingface.co/{repo}/resolve/main"

            files_to_download = [
                ("config.json", True),
                ("tokenizer.json", True),
                ("vocabulary.json", False),
                ("model.bin", True)
            ]

            total_files = len(files_to_download)
            for idx, (filename, is_required) in enumerate(files_to_download, 1):
                file_url = f"{base_url}/{filename}"
                dest_file = target_dir / filename
                part_file = target_dir / f"{filename}.part"

                if dest_file.is_file() and dest_file.stat().st_size > (1_000_000 if filename == "model.bin" else 10):
                    continue

                msg = f"Đang tải {filename} [{idx}/{total_files}] của model '{spec['name']}'..."
                pct_start = int(10 + (idx - 1) / total_files * 85)
                job_manager.update_job(job_id, progress=pct_start, message=msg)

                req = urllib.request.Request(file_url, headers={"User-Agent": "KageVietSub/1.0"})
                try:
                    with urllib.request.urlopen(req, timeout=60) as resp, open(part_file, "wb") as out_f:
                        content_len = resp.headers.get("Content-Length")
                        total_bytes = int(content_len) if content_len else None
                        downloaded = 0
                        chunk_size = 1024 * 256          

                        while True:
                            chunk = resp.read(chunk_size)
                            if not chunk:
                                break
                            out_f.write(chunk)
                            downloaded += len(chunk)

                            if total_bytes and total_bytes > 0:
                                file_pct = downloaded / total_bytes
                                current_pct = min(95, int(pct_start + file_pct * (85 / total_files)))
                                mb_down = downloaded / (1024 * 1024)
                                mb_tot = total_bytes / (1024 * 1024)
                                job_manager.update_job(
                                    job_id,
                                    progress=current_pct,
                                    message=f"Đang tải {filename} ({mb_down:.1f}/{mb_tot:.1f} MB)..."
                                )

                    if part_file.exists():
                        if dest_file.exists():
                            dest_file.unlink()
                        part_file.rename(dest_file)

                except Exception as dl_err:
                    if part_file.exists():
                        try:
                            part_file.unlink()
                        except Exception:
                            pass
                    if is_required:
                        raise RuntimeError(f"Lỗi khi tải file bắt buộc '{filename}' từ {file_url}: {str(dl_err)}")

            is_valid, err_reason, _ = WhisperModelService._check_ctranslate2_directory(target_dir)
            if not is_valid:
                raise RuntimeError(f"Xác thực model sau tải thất bại: {err_reason or 'Thiếu file hoặc dung lượng không đúng'}")

            scan_res = WhisperModelService.scan_models()

            job_manager.update_job(
                job_id,
                status="completed",
                progress=100,
                message=f"Tải và xác thực thành công model Whisper '{spec['name']}'!",
                result=scan_res
            )

        except Exception as err:
            job_manager.update_job(
                job_id,
                status="failed",
                error=f"Quá trình tải model '{model_id}' thất bại: {str(err)}",
                message="Tải model thất bại."
            )
