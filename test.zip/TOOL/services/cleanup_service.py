import time
import shutil
import logging
from pathlib import Path
from typing import List, Optional
from TOOL.config import TEMP_DIR, UPLOADS_DIR, OUTPUT_DIR, MODELS_DIR, KAGE_DOWNLOAD_DIR
from TOOL.services.logger import logger as central_logger

logger = central_logger.get_module_logger("CLEANUP")

class CleanupService:
    @staticmethod
    def cleanup_orphaned_temp():
        """
        Quét và dọn dẹp CHỈ thư mục DATA/temp/ mồ côi khi khởi động lại sau crash.
        TUYỆT ĐỐI KHÔNG xóa DATA/models/, DATA/output/, DATA/uploads/ và Download/KAGEVIETSUB/.
        """
        cleaned_count = 0
        cleaned_bytes = 0

        if TEMP_DIR.exists():
            for item in list(TEMP_DIR.iterdir()):
                try:
                    if item.name == "task_jobs":
                        continue
                    if not str(item.resolve()).startswith(str(TEMP_DIR.resolve())):
                        continue
                    if item.is_file():
                        cleaned_bytes += item.stat().st_size
                        item.unlink()
                        cleaned_count += 1
                    elif item.is_dir():
                        for sub in item.rglob("*"):
                            if sub.is_file():
                                cleaned_bytes += sub.stat().st_size
                        shutil.rmtree(item, ignore_errors=True)
                        cleaned_count += 1
                except Exception as e:
                    logger.debug(f"Bỏ qua file temp: {e}")

        (TEMP_DIR / "task_jobs").mkdir(parents=True, exist_ok=True)
        logger.info(f"Crash recovery cleanup: {cleaned_count} items ({round(cleaned_bytes / (1024*1024), 2)} MB) đã được dọn an toàn trong TEMP_DIR.")
        return {"cleaned_files": cleaned_count, "freed_mb": round(cleaned_bytes / (1024 * 1024), 2)}

    @staticmethod
    def clear_temp_folder():
        """Alias cho cleanup_orphaned_temp."""
        return CleanupService.cleanup_orphaned_temp()

    @staticmethod
    def cleanup_job_temp(job_id: str, uploaded_files: Optional[List[Path]] = None):
        """
        Dọn dẹp thư mục temp và uploads tạm thời của một job sau khi hoàn tất.
        """
                                        
        job_temp_dir = TEMP_DIR / f"job_{job_id}"
        if job_temp_dir.exists() and str(job_temp_dir.resolve()).startswith(str(TEMP_DIR.resolve())):
            shutil.rmtree(job_temp_dir, ignore_errors=True)

        if TEMP_DIR.exists():
            for item in TEMP_DIR.glob(f"*{job_id}*"):
                try:
                    if item.is_file():
                        item.unlink()
                    elif item.is_dir():
                        shutil.rmtree(item, ignore_errors=True)
                except Exception:
                    pass

        if uploaded_files:
            for up_file in uploaded_files:
                try:
                    p = Path(up_file)
                                                                                                                 
                    if p.exists() and str(p.resolve()).startswith(str(UPLOADS_DIR.resolve())):
                        p.unlink()
                except Exception:
                    pass

    @staticmethod
    def cleanup_old_files(max_age_hours: int = 24):
        """Clean up files in temp/ and uploads/ older than max_age_hours."""
        now = time.time()
        cutoff = now - (max_age_hours * 3600)
        cleaned_count = 0
        cleaned_bytes = 0

        for folder in [TEMP_DIR, UPLOADS_DIR]:
            if not folder.exists():
                continue
            for item in folder.iterdir():
                try:
                                                                   
                    if not str(item.resolve()).startswith(str(folder.resolve())):
                        continue
                    if item.is_file() and item.stat().st_mtime < cutoff:
                        cleaned_bytes += item.stat().st_size
                        item.unlink()
                        cleaned_count += 1
                except Exception:
                    pass
        return {"cleaned_files": cleaned_count, "freed_mb": round(cleaned_bytes / (1024 * 1024), 2)}

    @staticmethod
    def clear_temp_folder(active_job_ids: Optional[List[str]] = None) -> dict:
        """
        Dọn dẹp triệt để tất cả file tạm trong TEMP_DIR và UPLOADS_DIR.
        Bảo vệ tuyệt đối:
        - KHÔNG xóa DATA/models/, DATA/output/, Download/KAGEVIETSUB/
        - KHÔNG xóa temp của các job đang active (processing, paused, merging)
        """
        if active_job_ids is None:
            try:
                from TOOL.services.task_service import job_manager
                active_jobs = job_manager.list_jobs()
                active_job_ids = [
                    str(j.get("job_id")) for j in active_jobs
                    if j.get("status") in ["processing", "paused", "merging", "generating"]
                ]
            except Exception:
                active_job_ids = []

        cleaned_count = 0
        failed_count = 0
        cleaned_bytes = 0
        errors = []

        def _is_active_path(path_obj: Path) -> bool:
            p_str = str(path_obj)
            for active_id in active_job_ids:
                if active_id and active_id in p_str:
                    return True
            return False

        def _delete_item(item: Path):
            nonlocal cleaned_count, failed_count, cleaned_bytes
            if item.name == "task_jobs":
                return
            if _is_active_path(item):
                logger.info(f"Bỏ qua item thuộc job đang hoạt động: {item.name}")
                return

            if item.is_file() or item.is_symlink():
                try:
                    sz = item.stat().st_size
                    item.unlink()
                    cleaned_bytes += sz
                    cleaned_count += 1
                except Exception as e:
                    failed_count += 1
                    errors.append(f"Không thể xóa file {item.name}: {str(e)}")
            elif item.is_dir():
                try:
                    children = list(item.iterdir())
                    for child in children:
                        _delete_item(child)
                                                                      
                    try:
                        if not list(item.iterdir()):
                            item.rmdir()
                    except Exception:
                        pass
                except Exception as e:
                    failed_count += 1
                    errors.append(f"Lỗi khi xóa thư mục {item.name}: {str(e)}")

        for folder in [TEMP_DIR, UPLOADS_DIR]:
            if not folder.exists():
                continue
            for item in list(folder.iterdir()):
                try:
                    resolved_item = item.resolve()
                    if not str(resolved_item).startswith(str(folder.resolve())):
                        continue
                    _delete_item(item)
                except Exception as e:
                    failed_count += 1
                    errors.append(f"Không thể duyệt {item.name}: {str(e)}")

        (TEMP_DIR / "task_jobs").mkdir(parents=True, exist_ok=True)
        freed_mb = round(cleaned_bytes / (1024 * 1024), 2)
        logger.info(f"Manual cleanup: {cleaned_count} file tạm đã dọn ({freed_mb} MB). Lỗi: {failed_count}")
        return {
            "status": "ok",
            "cleaned_files": cleaned_count,
            "deleted_count": cleaned_count,
            "failed_count": failed_count,
            "freed_bytes": cleaned_bytes,
            "freed_mb": freed_mb,
            "errors": errors
        }

    @staticmethod
    def run_shutdown_cleanup():
        """
        Dọn dẹp nhanh gọn các file tạm khi dừng server.
        Bảo vệ tuyệt đối:
        - Download/KAGEVIETSUB/
        - DATA/models/
        - DATA/output/
        - File SRT/Video gốc
        """
        try:
            return CleanupService.clear_temp_folder(active_job_ids=[])
        except Exception as e:
            logger.warning(f"Lỗi khi dọn file tạm lúc tắt server: {e}")
            return {"cleaned_files": 0, "freed_mb": 0}

