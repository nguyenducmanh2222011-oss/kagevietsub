#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB - VOICE SERVICE (Official Voice.json GitHub Source + RAM Cache)
==============================================================================
Service quản lý duy nhất cho Voice catalog từ repository K07VN/capcut-tts-api:
- Lấy Voice.json chính thức từ https://raw.githubusercontent.com/K07VN/capcut-tts-api/refs/heads/main/Voice.json
- Cache kết quả trong RAM với thời gian TTL
- Lọc danh sách giọng đọc chuẩn tiếng Việt (lang = vi-VN / lan = vi)
- Đảm bảo kiểm tra tính hợp lệ của resource_id và voice_type
==============================================================================
"""

import time
import json
import logging
import threading
import urllib.request
from typing import List, Dict, Any, Optional

logger = logging.getLogger("VoiceService")

class VoiceService:
    """Service quản lý danh sách Voice tiếng Việt chính thức từ GitHub với Cache RAM."""

    PRIMARY_URL = "https://raw.githubusercontent.com/K07VN/capcut-tts-api/refs/heads/main/Voice.json"
    FALLBACK_URLS = [
        "https://raw.githubusercontent.com/K07VN/capcut-tts-api/main/Voice.json",
        "https://raw.githubusercontent.com/K07VN/capcut-tts-api/master/Voice.json"
    ]

    CACHE_TTL_SECONDS = 900  # 15 phút cache RAM
    _ram_cache: Optional[List[Dict[str, Any]]] = None
    _cache_timestamp: float = 0.0
    _lock = threading.Lock()

    @classmethod
    def fetch_raw_voice_catalog(cls) -> List[Dict[str, Any]]:
        """Tải dữ liệu Voice.json từ file cục bộ trong tool trước tiên, sau đó tới GitHub URL nếu cần."""
        now = time.time()
        with cls._lock:
            if cls._ram_cache is not None and (now - cls._cache_timestamp) < cls.CACHE_TTL_SECONDS:
                return cls._ram_cache

        # 1. Ưu tiên đọc từ file Voice.json local trong TOOL
        from pathlib import Path
        local_paths = [
            Path(__file__).parent.parent / "Voice.json",
            Path(__file__).parent.parent.parent / "Voice.json",
            Path("Voice.json"),
            Path("TOOL/Voice.json")
        ]

        data = None
        for p in local_paths:
            try:
                if p.is_file():
                    with open(p, "r", encoding="utf-8") as f:
                        parsed = json.load(f)
                        if isinstance(parsed, list) and len(parsed) > 0:
                            data = parsed
                            logger.info(f"Loaded {len(data)} items from local Voice.json at {p}")
                            break
            except Exception as e:
                logger.warning(f"Error reading local Voice.json from {p}: {e}")

        # 2. Nếu không có file local hoặc file rỗng, thử tải từ GitHub
        if data is None:
            urls_to_try = [cls.PRIMARY_URL] + cls.FALLBACK_URLS
            headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}

            for url in urls_to_try:
                try:
                    req = urllib.request.Request(url, headers=headers)
                    with urllib.request.urlopen(req, timeout=10) as resp:
                        if resp.status == 200:
                            raw_bytes = resp.read()
                            parsed = json.loads(raw_bytes.decode('utf-8'))
                            if isinstance(parsed, list):
                                data = parsed
                                break
                except Exception as e:
                    logger.warning(f"Failed to fetch Voice.json from {url}: {e}")

        with cls._lock:
            if data is not None:
                cls._ram_cache = data
                cls._cache_timestamp = time.time()
                return cls._ram_cache
            elif cls._ram_cache is not None:
                logger.warning("Voice.json fetch failed. Using last valid RAM cache.")
                return cls._ram_cache
            else:
                raise RuntimeError("Không thể nạp Voice.json (cả local và online).")

    @classmethod
    def get_vietnamese_voices(cls) -> List[Dict[str, Any]]:
        """Lọc danh sách các giọng đọc tiếng Việt hợp lệ (có resource_id và lang = vi-VN)."""
        raw_catalog = cls.fetch_raw_voice_catalog()
        vietnamese_voices = []

        for item in raw_catalog:
            if not isinstance(item, dict):
                continue

            lang = str(item.get("lang") or item.get("lan") or "").lower()
            resource_id = str(item.get("resource_id") or "").strip()
            voice_type = str(item.get("voice_type") or item.get("id") or "").strip()
            display_name = str(item.get("display_name") or item.get("name") or voice_type).strip()

            is_vi = "vi" in lang or lang == "vi-vn"
            if is_vi and resource_id and voice_type:
                vietnamese_voices.append({
                    "resource_id": resource_id,
                    "voice_type": voice_type,
                    "name": display_name,
                    "lang": "vi-VN"
                })

        if not vietnamese_voices:
            raise RuntimeError("Không tìm thấy giọng đọc tiếng Việt hợp lệ trong Voice.json.")

        return vietnamese_voices
