import os
import sys
import time
import datetime
import threading
import re
import traceback
import logging
from pathlib import Path
from typing import Optional, Any, Dict, List, Tuple, Union

from TOOL.config import LOGS_DIR

DAILY_LOG_RETENTION_DAYS = int(os.getenv("DAILY_LOG_RETENTION_DAYS", "30"))

SECRET_PATTERNS = [
    re.compile(r'(?i)(api[_-]?key\s*[:=]\s*["\']?)([^"\'\s&,;]{6,})', re.IGNORECASE),
    re.compile(r'(?i)(token\s*[:=]\s*["\']?)([^"\'\s&,;]{6,})', re.IGNORECASE),
    re.compile(r'(?i)(authorization\s*[:=]\s*["\']?Bearer\s+)([^"\'\s&,;]{6,})', re.IGNORECASE),
    re.compile(r'(?i)(cookie\s*[:=]\s*["\']?)([^"\'\s\r\n]{6,})', re.IGNORECASE),
    re.compile(r'(?i)(password\s*[:=]\s*["\']?)([^"\'\s&,;]{3,})', re.IGNORECASE),
    re.compile(r'(?i)(secret\s*[:=]\s*["\']?)([^"\'\s&,;]{6,})', re.IGNORECASE),
    re.compile(r'(?i)(access[_-]?token\s*[:=]\s*["\']?)([^"\'\s&,;]{6,})', re.IGNORECASE),
    re.compile(r'(?i)(refresh[_-]?token\s*[:=]\s*["\']?)([^"\'\s&,;]{6,})', re.IGNORECASE),
    re.compile(r'(?i)(ds2_token\s*[:=]\s*["\']?)([^"\'\s&,;]{6,})', re.IGNORECASE),
    re.compile(r'(?i)(bearer\s+)([a-zA-Z0-9_\-\.]{10,})', re.IGNORECASE),
    re.compile(r'(?i)(AIzaSy[a-zA-Z0-9_\-]{33})', re.IGNORECASE),
    re.compile(r'(?i)(sk-[a-zA-Z0-9]{20,})', re.IGNORECASE),
]

def redact_secrets(text: str) -> str:
    if not text:
        return ""
    sanitized = str(text)
    for pattern in SECRET_PATTERNS:
        if pattern.groups == 2:
            sanitized = pattern.sub(r'\1[REDACTED]', sanitized)
        elif pattern.groups == 1:
            sanitized = pattern.sub('[REDACTED]', sanitized)
        else:
            sanitized = pattern.sub('[REDACTED]', sanitized)
    return sanitized

class CentralLogger:
    _instance = None
    _lock = threading.RLock()

    def __new__(cls, *args, **kwargs):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super(CentralLogger, cls).__new__(cls)
                cls._instance._initialized = False
            return cls._instance

    def __init__(self):
        if getattr(self, "_initialized", False):
            return
        with self._lock:
            self.logs_dir = LOGS_DIR
            self.logs_dir.mkdir(parents=True, exist_ok=True)
            self.retention_days = DAILY_LOG_RETENTION_DAYS
            self._write_lock = threading.RLock()
            self._initialized = True

            self._remove_legacy_module_logs()
            self._setup_std_logging_interceptor()
            self._setup_global_exception_hooks()

    def _remove_legacy_module_logs(self):
        """Xóa các file và thư mục con cũ nếu có để đảm bảo chỉ duy nhất YYYY-MM-DD.log trong DATA/logs/."""
        import shutil
        legacy_names = ["app.log", "error.log", "tts.log", "merge.log", "downloader.log", "startup.log", "machine-info.log"]
        for legacy_name in legacy_names:
            p = self.logs_dir / legacy_name
            if p.exists() and p.is_file():
                try:
                    p.unlink()
                except Exception:
                    pass

        legacy_dirs = ["daily", "system", "app", "error", "tts", "merge", "downloader", "startup"]
        for dir_name in legacy_dirs:
            dp = self.logs_dir / dir_name
            if dp.exists() and dp.is_dir():
                try:
                    shutil.rmtree(dp, ignore_errors=True)
                except Exception:
                    pass

    def _get_active_log_file(self) -> Path:
        """Trả về đường dẫn duy nhất cho ngày thực tế hiện tại: DATA/logs/YYYY-MM-DD.log."""
        now = datetime.datetime.now()
        date_str = now.strftime("%Y-%m-%d")
        return self.logs_dir / f"{date_str}.log"

    def _format_timestamp(self) -> str:
        now = datetime.datetime.now()
        return now.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

    def write_machine_info(self, sys_info: Dict[str, Any], host: str = "127.0.0.1", port: int = 8000):
        """Ghi thông tin phần cứng và môi trường khởi động trực tiếp vào file log ngày hiện tại."""
        with self._write_lock:
            try:
                timestamp = self._format_timestamp()
                pid = os.getpid()

                and_info = sys_info.get("android", {})
                cpu_info = sys_info.get("cpu", {})
                mem_info = sys_info.get("memory", {})
                st_info = sys_info.get("storage", {})
                paths = sys_info.get("paths", {})
                deps = sys_info.get("dependencies", {})

                content = (
                    f"==================================================\n"
                    f"KAGEVIETSUB SYSTEM ENVIRONMENT LOG\n"
                    f"Timestamp: {timestamp}\n"
                    f"PID: {pid}\n"
                    f"Version: {sys_info.get('version', 'unknown')}\n"
                    f"Platform: {sys_info.get('platform_display', sys_info.get('platform', 'unknown'))}\n"
                    f"Architecture: {sys_info.get('architecture', 'unknown')}\n"
                    f"Python: {deps.get('python', {}).get('version', sys.version.split()[0])}\n"
                    f"CPU: {cpu_info.get('model', 'unknown')} ({cpu_info.get('logical_cores', 1)} cores)\n"
                    f"RAM: Total {mem_info.get('total_mb', 0)}MB | Avail {mem_info.get('available_mb', 0)}MB\n"
                    f"Storage Free: DATA {st_info.get('data_storage', {}).get('free_gb', 0)}GB | Output {st_info.get('output_storage', {}).get('free_gb', 0)}GB\n"
                    f"Android/Termux: is_android={and_info.get('is_android')} is_termux={and_info.get('is_termux')} termux_ver={and_info.get('termux_version')}\n"
                    f"FFmpeg: {deps.get('ffmpeg', {}).get('installed')} (Path: {deps.get('ffmpeg', {}).get('path')}) | Ver: {deps.get('ffmpeg', {}).get('version', 'unknown')}\n"
                    f"FFprobe: {deps.get('ffprobe', {}).get('installed')} (Path: {deps.get('ffprobe', {}).get('path')}) | Ver: {deps.get('ffprobe', {}).get('version', 'unknown')}\n"
                    f"yt-dlp: {deps.get('ytdlp', {}).get('installed')} (Path: {deps.get('ytdlp', {}).get('path')}) | Ver: {deps.get('ytdlp', {}).get('version', 'unknown')}\n"
                    f"Server Binding: {host}:{port}\n"
                    f"Project Root: {paths.get('project_root')}\n"
                    f"Download Output: {paths.get('download_output')}\n"
                    f"==================================================\n\n"
                )
                safe_content = redact_secrets(content)
                target_file = self._get_active_log_file()
                with open(target_file, "a", encoding="utf-8", buffering=1) as f:
                    f.write(safe_content)
                    f.flush()
            except Exception as e:
                try:
                    sys.stderr.write(f"[LOGGER ERROR] Failed to write machine info: {e}\n")
                except Exception:
                    pass

    def cleanup_old_logs(self, retention_days: Optional[int] = None) -> int:
        if retention_days is None:
            retention_days = self.retention_days

        with self._write_lock:
            removed_count = 0
            try:
                if not self.logs_dir.exists():
                    return 0

                today = datetime.date.today()
                date_file_pattern = re.compile(r"^(\d{4}-\d{2}-\d{2})\.log$")
                active_file = self._get_active_log_file().resolve()

                for entry in os.scandir(self.logs_dir):
                    if not entry.is_file():
                        continue

                    entry_path = Path(entry.path)
                    if entry_path.resolve() == active_file:
                        continue

                    match = date_file_pattern.match(entry.name)
                    if not match:
                        continue

                    date_str = match.group(1)
                    try:
                        file_date = datetime.datetime.strptime(date_str, "%Y-%m-%d").date()
                    except ValueError:
                        continue

                    age_days = (today - file_date).days
                    if age_days > retention_days:
                        try:
                            entry_path.unlink()
                            removed_count += 1
                        except Exception as del_err:
                            self.error("LOGGER", "CLEANUP_FILE_ERROR", f"Failed to delete {entry.name}", exc=del_err)
            except Exception as e:
                self.error("LOGGER", "CLEANUP_ERROR", "Log cleanup exception occurred", exc=e)

            return removed_count

    def _resolve_log_args(self, default_level: str, *args, **kwargs) -> Tuple[str, str, str]:
        kw_module = kwargs.get("module")
        kw_event = kwargs.get("action") or kwargs.get("event")
        kw_msg = kwargs.get("message")

        if len(args) == 0:
            return kw_module or "APP", kw_event or default_level, str(kw_msg or "")
        elif len(args) == 1:
            first = args[0]
            return kw_module or "APP", kw_event or default_level, str(first)
        elif len(args) == 2:
            first, second = args[0], args[1]
            if isinstance(first, str) and "%" in first:
                try:
                    formatted = first % (second,)
                    return kw_module or "APP", kw_event or default_level, formatted
                except (TypeError, ValueError):
                    pass
            return kw_module or "APP", kw_event or str(first), str(second)
        else:
            first = args[0]
            rest = args[1:]
            if isinstance(first, str) and "%" in first:
                try:
                    formatted = first % rest
                    return kw_module or "APP", kw_event or default_level, formatted
                except (TypeError, ValueError):
                    pass
            module = str(args[0])
            event = str(args[1])
            msg = str(args[2])
            if len(args) > 3:
                extra = " ".join(str(a) for a in args[3:])
                msg = f"{msg} {extra}"
            return kw_module or module, kw_event or event, msg

    def log(
        self,
        level: str,
        module: str = "SYSTEM",
        event: str = "EVENT",
        message: str = "",
        job_id: Optional[str] = None,
        request_id: Optional[str] = None,
        task_id: Optional[str] = None,
        state: Optional[str] = None,
        progress: Optional[Any] = None,
        function: Optional[str] = None,
        action: Optional[str] = None,
        exc: Optional[Union[Exception, Tuple[Any, Any, Any]]] = None,
        exc_type: Optional[str] = None,
        error_message: Optional[str] = None,
        **kwargs: Any
    ):
        try:
            timestamp = self._format_timestamp()
            lvl = (level or "INFO").upper()
            mod = (module or "SYSTEM").lower()
            evt = (event or "EVENT").lower()

            tags = []
            tags.append(f"[module={mod}]")
            if function:
                tags.append(f"[function={function}]")
            action_val = action or evt
            tags.append(f"[action={action_val}]")
            if job_id:
                tags.append(f"[job_id={job_id}]")
            if task_id:
                tags.append(f"[task_id={task_id}]")
            if request_id:
                tags.append(f"[request_id={request_id}]")
            if state is not None:
                tags.append(f"[state={state}]")
            if progress is not None:
                tags.append(f"[progress={progress}]")

            parts = []
            if message:
                parts.append(str(message).strip())
            for k, v in kwargs.items():
                if v is not None:
                    parts.append(f"{k}={v}")

            # Exception processing
            tb_str = ""
            if exc is not None:
                if isinstance(exc, tuple) and len(exc) == 3:
                    e_type, e_val, e_tb = exc
                    exc_type_name = e_type.__name__ if hasattr(e_type, "__name__") else str(e_type)
                    exc_msg_str = str(e_val)
                    tb_str = "".join(traceback.format_exception(e_type, e_val, e_tb)).strip()
                elif isinstance(exc, Exception):
                    exc_type_name = type(exc).__name__
                    exc_msg_str = str(exc)
                    tb_str = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__)).strip()
                else:
                    exc_type_name = str(exc_type or "Exception")
                    exc_msg_str = str(error_message or exc)

                tags.append(f"[exception={exc_type_name}]")
                parts.append(f"[message={exc_msg_str}]")
            elif exc_type or error_message:
                if exc_type:
                    tags.append(f"[exception={exc_type}]")
                if error_message:
                    parts.append(f"[message={error_message}]")

            tag_str = " ".join(tags)
            raw_content = " ".join(parts)
            safe_content = redact_secrets(raw_content)

            header_str = f"[{timestamp}]\n[{lvl}]\n{tag_str}"

            if tb_str:
                safe_tb = redact_secrets(tb_str)
                log_line = f"{header_str}\n{safe_content}\n\nTraceback (most recent call last):\n{safe_tb}\n\n"
            else:
                log_line = f"{header_str}\n{safe_content}\n\n"

            with self._write_lock:
                target_file = self._get_active_log_file()
                with open(target_file, "a", encoding="utf-8", buffering=1) as f:
                    f.write(log_line)
                    f.flush()

                if lvl in ["ERROR", "CRITICAL", "EXCEPTION"] or exc is not None:
                    try:
                        sys.stderr.write(log_line)
                        sys.stderr.flush()
                    except Exception:
                        pass

        except Exception as outer_err:
            try:
                sys.stderr.write(f"[LOGGER CRITICAL ERROR] Fail-safe caught log exception: {outer_err}\n")
            except Exception:
                pass

    def debug(self, *args, **kwargs):
        try:
            kw_module = kwargs.pop("module", None)
            kw_event = kwargs.pop("event", None) or kwargs.pop("action", None)
            mod, evt, msg = self._resolve_log_args("DEBUG", *args, **kwargs)
            if kw_module:
                mod = kw_module
            if kw_event:
                evt = kw_event
            self.log("DEBUG", mod, evt, msg, **kwargs)
        except Exception:
            pass

    def info(self, *args, **kwargs):
        try:
            kw_module = kwargs.pop("module", None)
            kw_event = kwargs.pop("event", None) or kwargs.pop("action", None)
            mod, evt, msg = self._resolve_log_args("INFO", *args, **kwargs)
            if kw_module:
                mod = kw_module
            if kw_event:
                evt = kw_event
            self.log("INFO", mod, evt, msg, **kwargs)
        except Exception:
            pass

    def warning(self, *args, **kwargs):
        try:
            kw_module = kwargs.pop("module", None)
            kw_event = kwargs.pop("event", None) or kwargs.pop("action", None)
            mod, evt, msg = self._resolve_log_args("WARNING", *args, **kwargs)
            if kw_module:
                mod = kw_module
            if kw_event:
                evt = kw_event
            self.log("WARNING", mod, evt, msg, **kwargs)
        except Exception:
            pass

    def error(self, *args, **kwargs):
        try:
            exc = kwargs.pop("exc", None) or kwargs.pop("exc_info", None)
            if exc is True:
                exc = sys.exc_info()
            kw_module = kwargs.pop("module", None)
            kw_event = kwargs.pop("event", None) or kwargs.pop("action", None)
            mod, evt, msg = self._resolve_log_args("ERROR", *args, **kwargs)
            if kw_module:
                mod = kw_module
            if kw_event:
                evt = kw_event
            self.log("ERROR", mod, evt, msg, exc=exc, **kwargs)
        except Exception:
            pass

    def critical(self, *args, **kwargs):
        try:
            exc = kwargs.pop("exc", None) or kwargs.pop("exc_info", None)
            if exc is True:
                exc = sys.exc_info()
            kw_module = kwargs.pop("module", None)
            kw_event = kwargs.pop("event", None) or kwargs.pop("action", None)
            mod, evt, msg = self._resolve_log_args("CRITICAL", *args, **kwargs)
            if kw_module:
                mod = kw_module
            if kw_event:
                evt = kw_event
            self.log("CRITICAL", mod, evt, msg, exc=exc, **kwargs)
        except Exception:
            pass

    def exception(self, *args, **kwargs):
        try:
            exc = kwargs.pop("exc", None) or kwargs.pop("exc_info", None)
            if exc is None or exc is True:
                exc = sys.exc_info()
            kw_module = kwargs.pop("module", None)
            kw_event = kwargs.pop("event", None) or kwargs.pop("action", None)
            mod, evt, msg = self._resolve_log_args("EXCEPTION", *args, **kwargs)
            if kw_module:
                mod = kw_module
            if kw_event:
                evt = kw_event
            self.log("ERROR", mod, evt, msg, exc=exc, **kwargs)
        except Exception:
            pass

    def _setup_std_logging_interceptor(self):
        try:
            root_l = logging.getLogger()
            root_l.setLevel(logging.INFO)
            for h in root_l.handlers[:]:
                if isinstance(h, CentralLoggingHandler):
                    return
            handler = CentralLoggingHandler(self)
            root_l.addHandler(handler)
        except Exception:
            pass

    def _setup_global_exception_hooks(self):
        def global_exception_hook(exctype, value, tb):
            if issubclass(exctype, KeyboardInterrupt):
                sys.__excepthook__(exctype, value, tb)
                return
            self.critical(
                "SYSTEM",
                "UNCAUGHT_EXCEPTION",
                f"Uncaught exception: {value}",
                exc=(exctype, value, tb)
            )

        def threading_exception_hook(args):
            if issubclass(args.exc_type, KeyboardInterrupt):
                return
            self.critical(
                "WORKER",
                "THREAD_UNCAUGHT_EXCEPTION",
                f"Uncaught exception in thread '{args.thread.name if args.thread else 'unknown'}': {args.exc_value}",
                exc=(args.exc_type, args.exc_value, args.exc_traceback)
            )

        sys.excepthook = global_exception_hook
        if hasattr(threading, "excepthook"):
            threading.excepthook = threading_exception_hook

    def get_module_logger(self, module_name: str) -> "ModuleLoggerAdapter":
        return ModuleLoggerAdapter(self, module_name)

class CentralLoggingHandler(logging.Handler):
    def __init__(self, central_logger: CentralLogger):
        super().__init__()
        self.central_logger = central_logger

    def emit(self, record: logging.LogRecord):
        try:
            msg = self.format(record)
            exc = record.exc_info if record.exc_info else None
            level = record.levelname
            mod = record.name.lower()
            self.central_logger.log(
                level=level,
                module=mod,
                event="std_log",
                message=msg,
                exc=exc
            )
        except Exception:
            pass

class ModuleLoggerAdapter:
    def __init__(self, central_logger: CentralLogger, module_name: str):
        self._logger = central_logger
        self.module_name = module_name

    def _log_with_level(self, level: str, default_event: str, *args, **kwargs):
        mod = kwargs.pop("module", self.module_name)
        evt = kwargs.pop("action", None) or kwargs.pop("event", None) or default_event
        exc = kwargs.pop("exc", None) or kwargs.pop("exc_info", None)
        if exc is True:
            exc = sys.exc_info()

        if not args:
            msg = str(kwargs.pop("message", ""))
            self._logger.log(level, module=mod, event=evt, message=msg, exc=exc, **kwargs)
            return

        if len(args) == 1:
            msg = str(args[0])
            self._logger.log(level, module=mod, event=evt, message=msg, exc=exc, **kwargs)
            return

        if len(args) == 2:
            first, second = args[0], args[1]
            if isinstance(first, str) and "%" in first:
                try:
                    formatted = first % (second,)
                    self._logger.log(level, module=mod, event=evt, message=formatted, exc=exc, **kwargs)
                    return
                except (TypeError, ValueError):
                    pass
            evt = str(first)
            msg = str(second)
            self._logger.log(level, module=mod, event=evt, message=msg, exc=exc, **kwargs)
            return

        first = args[0]
        rest = args[1:]
        if isinstance(first, str) and "%" in first:
            try:
                formatted = first % rest
                self._logger.log(level, module=mod, event=evt, message=formatted, exc=exc, **kwargs)
                return
            except (TypeError, ValueError):
                pass

        mod = str(args[0])
        evt = str(args[1])
        msg = str(args[2])
        if len(args) > 3:
            extra = " ".join(str(a) for a in args[3:])
            msg = f"{msg} {extra}"
        self._logger.log(level, module=mod, event=evt, message=msg, exc=exc, **kwargs)

    def debug(self, *args, **kwargs):
        self._log_with_level("DEBUG", "DEBUG", *args, **kwargs)

    def info(self, *args, **kwargs):
        self._log_with_level("INFO", "INFO", *args, **kwargs)

    def warning(self, *args, **kwargs):
        self._log_with_level("WARNING", "WARNING", *args, **kwargs)

    def error(self, *args, **kwargs):
        self._log_with_level("ERROR", "ERROR", *args, **kwargs)

    def critical(self, *args, **kwargs):
        self._log_with_level("CRITICAL", "CRITICAL", *args, **kwargs)

    def exception(self, *args, **kwargs):
        if "exc" not in kwargs and "exc_info" not in kwargs:
            kwargs["exc"] = sys.exc_info()
        self._log_with_level("ERROR", "EXCEPTION", *args, **kwargs)

logger = CentralLogger()


