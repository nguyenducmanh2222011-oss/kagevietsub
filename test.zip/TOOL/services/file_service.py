import os
import shutil
import zipfile
import uuid
from pathlib import Path
from typing import List, Optional
from TOOL.config import TEMP_DIR, OUTPUT_DIR, UPLOADS_DIR, KAGE_DOWNLOAD_DIR, get_safe_unique_filepath

class FileService:
    @staticmethod
    def save_upload(file_bytes: bytes, filename: str) -> Path:
        """Save uploaded bytes safely into UPLOADS_DIR with a unique prefix if needed."""
        clean_name = Path(filename).name
        unique_prefix = uuid.uuid4().hex[:8]
        safe_filename = f"{unique_prefix}_{clean_name}"
        destination = UPLOADS_DIR / safe_filename
        with open(destination, "wb") as f:
            f.write(file_bytes)
        return destination

    @staticmethod
    def create_zip(files_to_zip: List[Path], zip_filename: str) -> Path:
        """Create a zip file containing given files in KAGE_DOWNLOAD_DIR."""
        if not zip_filename.endswith(".zip"):
            zip_filename += ".zip"
        zip_path = get_safe_unique_filepath(KAGE_DOWNLOAD_DIR, zip_filename)
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
            for file_path in files_to_zip:
                p = Path(file_path)
                if p.exists() and p.is_file():
                    zipf.write(p, arcname=p.name)
        return zip_path

    @staticmethod
    def get_output_path(filename: str) -> Path:
        """Get output destination path in KAGE_DOWNLOAD_DIR."""
        return get_safe_unique_filepath(KAGE_DOWNLOAD_DIR, filename)

    @staticmethod
    def get_temp_path(filename: str) -> Path:
        """Get temp destination path."""
        return TEMP_DIR / Path(filename).name

    @staticmethod
    def read_text_safe(filepath: Path) -> str:
        """Read a text file trying multiple common encodings."""
        p = Path(filepath)
        for encoding in ["utf-8-sig", "utf-8", "latin-1", "gb18030", "cp1252"]:
            try:
                with open(p, "r", encoding=encoding) as f:
                    return f.read()
            except Exception:
                continue
        with open(p, "rb") as f:
            return f.read().decode("utf-8", errors="replace")

    @staticmethod
    def write_text(filepath: Path, content: str) -> Path:
        """Write string to file in UTF-8."""
        p = Path(filepath)
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(p, "w", encoding="utf-8") as f:
            f.write(content)
        return p
