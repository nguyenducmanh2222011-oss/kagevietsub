import re
import unicodedata
import logging
from typing import Dict, Any, List, Optional, Tuple

logger = logging.getLogger("kagevietsub.language_validator")

# Supported language codes and names
LANG_MAP = {
    "vi": "Vietnamese",
    "vietnamese": "Vietnamese",
    "tiếng việt": "Vietnamese",
    "tieng viet": "Vietnamese",
    "en": "English",
    "english": "English",
    "tiếng anh": "English",
    "tieng anh": "English",
    "zh": "Chinese",
    "chinese": "Chinese",
    "tiếng trung": "Chinese",
    "tieng trung": "Chinese",
    "zh-cn": "Chinese",
    "zh-tw": "Chinese",
    "ja": "Japanese",
    "japanese": "Japanese",
    "tiếng nhật": "Japanese",
    "tieng nhat": "Japanese",
    "ko": "Korean",
    "korean": "Korean",
    "tiếng hàn": "Korean",
    "tieng han": "Korean",
    "fr": "French",
    "french": "French",
    "tiếng pháp": "French",
    "es": "Spanish",
    "spanish": "Spanish",
    "tiếng tây ban nha": "Spanish",
    "de": "German",
    "german": "German",
    "tiếng đức": "German",
    "ru": "Russian",
    "russian": "Russian",
    "tiếng nga": "Russian",
    "th": "Thai",
    "thai": "Thai",
    "tiếng thái": "Thai",
}

# Vietnamese specific diacritic characters
VI_CHARS_REGEX = re.compile(
    r"[àáảãạăằắẳẵặâầấẩẫậèéẻẽẹêềếểễệìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữựỳýỷỹỵđ"
    r"ÀÁẢÃẠĂẰẮẲẴẶÂẦẤẨẪẬÈÉẺẼẸÊỀẾỂỄỆÌÍỈĨỊÒÓỎÕỌÔỒỐỔỖỘƠỜỚỞỠỢÙÚỦŨỤƯỪỨỬỮỰỲÝỶỸỴĐ]"
)

# CJK Ideographs (Chinese Hanzi, Japanese Kanji)
CJK_REGEX = re.compile(r"[\u4e00-\u9fff\u3400-\u4dbf]")

# Japanese Kana (Hiragana & Katakana)
JP_KANA_REGEX = re.compile(r"[\u3040-\u309f\u30a0-\u30ff]")

# Korean Hangul
KO_HANGUL_REGEX = re.compile(r"[\uac00-\ud7af\u1100-\u11ff]")

# Cyrillic
CYRILLIC_REGEX = re.compile(r"[\u0400-\u04ff]")

# Thai
THAI_REGEX = re.compile(r"[\u0e00-\u0e7f]")

# Common distinct stopwords for Latin languages
VI_COMMON_WORDS = {
    "và", "là", "của", "có", "được", "trong", "này", "tôi", "bạn", "không", "để", "với",
    "người", "khi", "một", "đã", "những", "các", "cho", "nhưng", "vì", "thế", "như",
    "cũng", "sẽ", "hay", "gì", "nào", "đâu", "tại", "từ", "rất", "rồi", "ra", "vào",
    "lên", "xuống", "lại", "qua", "thấy", "biết", "làm", "đi", "nói", "ăn", "xem", "về",
    "mà", "hãy", "đừng", "xin", "chào", "cảm", "ơn", "dạ", "vâng", "ừ", "nhé", "nha",
    "nè", "ơi", "thì", "đó", "nó", "họ", "chúng", "ông", "bà", "anh", "chị", "em",
    "con", "cô", "chú", "bác", "cháu", "mình", "ai", "muốn", "phải", "đang", "vẫn",
    "cứ", "chưa", "hơn", "nhất", "luôn", "chỉ", "mới", "vừa", "tất", "cả", "lúc",
    "ngày", "giờ", "năm", "việc", "cái", "chiếc", "cuộc", "bộ", "thực", "sự", "thôi"
}

EN_COMMON_WORDS = {
    "the", "be", "to", "of", "and", "a", "in", "that", "have", "i", "it", "for", "not",
    "on", "with", "he", "as", "you", "do", "at", "this", "but", "his", "by", "from",
    "they", "we", "say", "her", "she", "or", "an", "will", "my", "one", "all", "would",
    "there", "their", "what", "so", "up", "out", "if", "about", "who", "get", "which",
    "go", "me", "when", "make", "can", "like", "time", "no", "just", "him", "know",
    "take", "people", "into", "year", "your", "good", "some", "could", "them", "see",
    "other", "than", "then", "now", "look", "only", "come", "its", "over", "think",
    "also", "back", "after", "use", "two", "how", "our", "work", "first", "well", "way",
    "even", "new", "want", "because", "any", "these", "give", "day", "most", "us", "are",
    "is", "was", "were", "been", "has", "had", "does", "did", "am", "hello", "hi"
}

FR_COMMON_WORDS = {
    "le", "la", "les", "de", "du", "des", "un", "une", "et", "est", "être", "avoir",
    "pour", "dans", "ce", "qui", "que", "sur", "avec", "ne", "pas", "plus", "par",
    "je", "tu", "il", "elle", "nous", "vous", "ils", "elles", "son", "sa", "ses",
    "mais", "ou", "où", "donc", "car", "ni", "bonjour", "merci"
}

ES_COMMON_WORDS = {
    "el", "la", "los", "las", "un", "una", "de", "del", "y", "en", "que", "es", "por",
    "con", "para", "no", "se", "su", "sus", "al", "como", "más", "pero", "le", "ya",
    "o", "fue", "este", "esta", "esto", "todo", "todos", "son", "me", "mi", "te", "tu",
    "hola", "gracias", "bien"
}

DE_COMMON_WORDS = {
    "der", "die", "das", "und", "in", "den", "von", "zu", "das", "mit", "sich", "des",
    "auf", "für", "ist", "im", "dem", "nicht", "ein", "eine", "als", "auch", "es", "an",
    "werden", "aus", "er", "hat", "dass", "sie", "nach", "wird", "bei", "einer", "der",
    "um", "am", "sind", "noch", "wie", "einem", "über", "einen", "so", "zum", "war",
    "hallo", "danke", "gut"
}

SHORT_SAFE_RESPONSES = {
    "vi": {"ừ", "ừm", "dạ", "vâng", "không", "có", "được", "đi", "xin lỗi", "cảm ơn", "chào", "tạm biệt", "đúng", "sai", "sao", "gì", "ai", "hả", "nè", "nhé", "ơi", "thôi", "ồ", "ôi", "á", "à"},
    "en": {"yes", "no", "ok", "okay", "yeah", "yep", "nope", "go", "stop", "sorry", "thanks", "thank you", "hello", "hi", "bye", "sure", "fine", "why", "what", "who", "oh", "ah", "wow"},
    "zh": {"好", "是的", "不是", "对", "行", "走", "谢谢", "对不起", "再见", "你好", "嗯", "啊", "哦", "什么", "谁"},
    "ja": {"はい", "いいえ", "うん", "そう", "ありがとう", "ごめん", "さようなら", "こんにちは", "何", "誰"},
    "ko": {"네", "예", "아니오", "응", "감사합니다", "미안해", "안녕", "뭐", "누구"}
}


class LanguageValidator:
    """
    Lightweight, fast, local language validator and detector.
    Does not use external APIs or heavy C-dependencies.
    Operates on clean text without timestamps, subtitle IDs, or metadata.
    """

    @classmethod
    def normalize_lang_name(cls, lang_input: str) -> str:
        if not lang_input:
            return "Vietnamese"
        key = str(lang_input).strip().lower()
        return LANG_MAP.get(key, key.capitalize())

    @classmethod
    def clean_text_for_detection(cls, text: str) -> str:
        """Strip SRT artifacts, markdown, timestamps, JSON, URLs, numbers."""
        if not text:
            return ""
        
        t = text.strip()
        # Remove markdown code fences
        t = re.sub(r"^```(?:json)?", "", t, flags=re.IGNORECASE)
        t = re.sub(r"```$", "", t)
        
        # Remove SRT timestamps (00:00:00,000 --> 00:00:00,000)
        t = re.sub(r"\d{2}:\d{2}:\d{2}[,\.]\d{3}\s*-->\s*\d{2}:\d{2}:\d{2}[,\.]\d{3}", " ", t)
        
        # Remove HTML/XML tags
        t = re.sub(r"<[^>]+>", " ", t)
        
        # Remove JSON structural patterns {"id": 1, ...}
        t = re.sub(r'\{[^{}]*\}', " ", t)
        
        # Remove URLs
        t = re.sub(r"https?://\S+", " ", t)
        
        # Remove standalone numbers and excessive punctuation
        t = re.sub(r"\b\d+\b", " ", t)
        
        # Collapse whitespaces
        t = re.sub(r"\s+", " ", t).strip()
        return t

    @classmethod
    def detect_language(cls, text: str) -> Tuple[str, float]:
        """
        Detects primary language of text with confidence score (0.0 to 1.0).
        Returns (detected_language_name, confidence).
        """
        cleaned = cls.clean_text_for_detection(text)
        if not cleaned:
            return "UNKNOWN", 0.0

        # Letter extraction
        letters_only = [c for c in cleaned if c.isalpha()]
        total_letters = len(letters_only)
        words = [w.strip(".,!?;:\"'()[]{}<>-~").lower() for w in cleaned.split() if w.strip()]

        if total_letters == 0:
            return "UNKNOWN", 0.0

        # Check for Non-Latin scripts first (high specificity)
        cjk_count = len(CJK_REGEX.findall(cleaned))
        jp_kana_count = len(JP_KANA_REGEX.findall(cleaned))
        ko_hangul_count = len(KO_HANGUL_REGEX.findall(cleaned))
        cyrillic_count = len(CYRILLIC_REGEX.findall(cleaned))
        thai_count = len(THAI_REGEX.findall(cleaned))

        # Japanese: Has Kana or (CJK + Kana)
        if jp_kana_count > 0:
            ratio = (jp_kana_count + cjk_count) / max(1, total_letters)
            conf = min(0.99, max(0.6, ratio))
            return "Japanese", round(conf, 2)

        # Korean: Has Hangul
        if ko_hangul_count > 0:
            ratio = ko_hangul_count / max(1, total_letters)
            conf = min(0.99, max(0.6, ratio))
            return "Korean", round(conf, 2)

        # Chinese: Pure or mostly CJK without Kana
        if cjk_count > 0:
            cjk_ratio = cjk_count / max(1, total_letters)
            if cjk_ratio >= 0.4 or (cjk_count >= 2 and total_letters <= 5):
                conf = min(0.99, max(0.7, cjk_ratio))
                return "Chinese", round(conf, 2)

        # Cyrillic (Russian)
        if cyrillic_count > 0:
            ratio = cyrillic_count / max(1, total_letters)
            if ratio >= 0.4:
                return "Russian", round(min(0.99, max(0.7, ratio)), 2)

        # Thai
        if thai_count > 0:
            ratio = thai_count / max(1, total_letters)
            if ratio >= 0.4:
                return "Thai", round(min(0.99, max(0.7, ratio)), 2)

        # Latin Script Analysis
        # 1. Vietnamese detection (diacritics + tone vowels + unique vocabulary)
        vi_char_count = len(VI_CHARS_REGEX.findall(cleaned))
        vi_word_matches = sum(1 for w in words if w in VI_COMMON_WORDS)
        total_words = len(words)

        if total_words == 0:
            return "UNKNOWN", 0.0

        # If text contains Vietnamese diacritics
        if vi_char_count > 0:
            # Significant Vietnamese markers
            diacritic_ratio = vi_char_count / max(1, total_letters)
            word_ratio = vi_word_matches / max(1, total_words)
            conf = min(0.99, max(0.75, 0.5 + (diacritic_ratio * 1.5) + (word_ratio * 0.5)))
            return "Vietnamese", round(conf, 2)

        # Even without diacritics (or with few), check Vietnamese stopwords
        if vi_word_matches >= 2 or (total_words <= 3 and vi_word_matches >= 1):
            ratio = vi_word_matches / max(1, total_words)
            if ratio >= 0.4:
                return "Vietnamese", round(min(0.95, max(0.7, ratio)), 2)

        # 2. English vs French vs Spanish vs German detection
        en_word_matches = sum(1 for w in words if w in EN_COMMON_WORDS)
        fr_word_matches = sum(1 for w in words if w in FR_COMMON_WORDS)
        es_word_matches = sum(1 for w in words if w in ES_COMMON_WORDS)
        de_word_matches = sum(1 for w in words if w in DE_COMMON_WORDS)

        scores = {
            "English": en_word_matches,
            "French": fr_word_matches,
            "Spanish": es_word_matches,
            "German": de_word_matches
        }

        best_lang, best_score = max(scores.items(), key=lambda item: item[1])

        if best_score > 0:
            ratio = best_score / max(1, total_words)
            conf = min(0.98, max(0.65, 0.4 + ratio * 0.6))
            return best_lang, round(conf, 2)

        # If very short (< 5 chars or <= 1 word without match)
        if total_letters <= 6 or total_words <= 1:
            return "UNKNOWN", 0.0

        # Default fallback for untyped Latin text
        return "UNKNOWN", 0.0

    @classmethod
    def validate_item(
        cls,
        source_text: str,
        translated_text: Optional[str],
        target_lang_input: str
    ) -> Dict[str, Any]:
        """
        Validates whether translated_text matches the target language.
        Returns:
            {
                "result": "PASS" | "FAIL" | "UNKNOWN",
                "target_lang": str,
                "detected_lang": str,
                "confidence": float,
                "reason": str
            }
        """
        target_lang_norm = cls.normalize_lang_name(target_lang_input)

        if not translated_text or not str(translated_text).strip():
            return {
                "result": "FAIL",
                "target_lang": target_lang_norm,
                "detected_lang": "EMPTY",
                "confidence": 1.0,
                "reason": "Bản dịch rỗng"
            }

        clean_trans = cls.clean_text_for_detection(translated_text)
        if not clean_trans:
            return {
                "result": "UNKNOWN",
                "target_lang": target_lang_norm,
                "detected_lang": "UNKNOWN",
                "confidence": 0.0,
                "reason": "Không có text nội dung để kiểm tra"
            }

        # Short text safe check
        lower_raw = clean_trans.lower().strip(".,!?;:\"'()[]{}~- ")
        short_whitelist = SHORT_SAFE_RESPONSES.get(target_lang_input.lower(), set()).union(
            SHORT_SAFE_RESPONSES.get(target_lang_norm.lower(), set())
        )
        if lower_raw in short_whitelist:
            log_msg = f"[LANG CHECK] Target: {target_lang_norm} | Detected: {target_lang_norm} | Confidence: 0.95 | Result: PASS (Short Whitelist)"
            logger.info(log_msg)
            return {
                "result": "PASS",
                "target_lang": target_lang_norm,
                "detected_lang": target_lang_norm,
                "confidence": 0.95,
                "reason": "OK (Từ ngắn hợp lệ)"
            }

        detected_lang, confidence = cls.detect_language(clean_trans)

        # UNKNOWN handling: Do NOT falsely fail short sentences or ambiguous proper names
        if detected_lang == "UNKNOWN" or confidence < 0.4:
            log_msg = f"[LANG CHECK] Target: {target_lang_norm} | Detected: UNKNOWN | Confidence: {confidence} | Result: UNKNOWN"
            logger.info(log_msg)
            return {
                "result": "UNKNOWN",
                "target_lang": target_lang_norm,
                "detected_lang": "UNKNOWN",
                "confidence": confidence,
                "reason": "Không đủ dữ liệu xác định ngôn ngữ (xử lý an toàn)"
            }

        # Exact match -> PASS
        if detected_lang.lower() == target_lang_norm.lower():
            log_msg = f"[LANG CHECK] Target: {target_lang_norm} | Detected: {detected_lang} | Confidence: {confidence} | Result: PASS"
            logger.info(log_msg)
            return {
                "result": "PASS",
                "target_lang": target_lang_norm,
                "detected_lang": detected_lang,
                "confidence": confidence,
                "reason": "OK"
            }

        # Special check: If target is Vietnamese and text contains Vietnamese markers/words mixed with English/Chinese proper names
        if target_lang_norm == "Vietnamese":
            vi_chars = VI_CHARS_REGEX.findall(clean_trans)
            vi_words = [w for w in clean_trans.lower().split() if w in VI_COMMON_WORDS]
            if len(vi_chars) >= 1 or len(vi_words) >= 1:
                log_msg = f"[LANG CHECK] Target: Vietnamese | Detected: Vietnamese (Mixed/Proper Noun) | Confidence: 0.85 | Result: PASS"
                logger.info(log_msg)
                return {
                    "result": "PASS",
                    "target_lang": "Vietnamese",
                    "detected_lang": "Vietnamese",
                    "confidence": 0.85,
                    "reason": "OK (Tiếng Việt kết hợp tên riêng/thuật ngữ)"
                }

        # Definite mismatch -> FAIL
        log_msg = f"[LANG CHECK] Target: {target_lang_norm} | Detected: {detected_lang} | Confidence: {confidence} | Result: FAIL"
        logger.warning(log_msg)
        return {
            "result": "FAIL",
            "target_lang": target_lang_norm,
            "detected_lang": detected_lang,
            "confidence": confidence,
            "reason": f"AI trả về ngôn ngữ '{detected_lang}' thay vì '{target_lang_norm}'"
        }

    @classmethod
    def validate_batch(
        cls,
        batch_items: List[Dict[str, Any]],
        target_lang_input: str
    ) -> Dict[str, Any]:
        """
        Validates an entire batch of translated subtitles.
        Returns:
            {
                "all_valid": bool,
                "has_fail": bool,
                "results": List[Dict[str, Any]],
                "batch_summary": str
            }
        """
        target_lang_norm = cls.normalize_lang_name(target_lang_input)
        item_results = []
        fail_count = 0
        pass_count = 0
        unknown_count = 0

        # Validate each item individually
        for item in batch_items:
            source = item.get("source", "")
            translation = item.get("translation")
            val_res = cls.validate_item(source, translation, target_lang_norm)
            item_results.append({
                "index": item.get("index"),
                "validation": val_res
            })
            if val_res["result"] == "FAIL":
                fail_count += 1
            elif val_res["result"] == "PASS":
                pass_count += 1
            else:
                unknown_count += 1

        # Also aggregate all translations for batch-level confidence
        all_trans_text = " ".join([str(it.get("translation") or "") for it in batch_items if it.get("translation")])
        batch_detected, batch_conf = cls.detect_language(all_trans_text)

        all_valid = (fail_count == 0)
        has_fail = (fail_count > 0)

        # If individual items were unknown due to shortness, but batch as a whole clearly matches target language:
        if has_fail and batch_detected.lower() == target_lang_norm.lower() and batch_conf >= 0.8:
            # Re-evaluate items that failed with low confidence
            for it_res in item_results:
                v = it_res["validation"]
                if v["result"] == "FAIL" and v.get("confidence", 0) < 0.7:
                    v["result"] = "PASS"
                    v["reason"] = "OK (Được xác thực qua ngữ cảnh toàn bộ batch)"
            fail_count = sum(1 for it in item_results if it["validation"]["result"] == "FAIL")
            all_valid = (fail_count == 0)
            has_fail = (fail_count > 0)

        summary = (
            f"[LANG CHECK BATCH] Target: {target_lang_norm} | Batch Detected: {batch_detected} ({batch_conf}) | "
            f"PASS: {pass_count}, UNKNOWN: {unknown_count}, FAIL: {fail_count}"
        )
        logger.info(summary)

        return {
            "all_valid": all_valid,
            "has_fail": has_fail,
            "fail_count": fail_count,
            "pass_count": pass_count,
            "unknown_count": unknown_count,
            "results": item_results,
            "batch_summary": summary
        }
