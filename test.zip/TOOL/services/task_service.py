import os
import sys
import threading
import uuid
import time
import json
from pathlib import Path
from typing import Dict, Any, Optional, Callable, List
from TOOL.config import TEMP_DIR
from TOOL.services.logger import logger

TASK_JOBS_DIR = TEMP_DIR / "task_jobs"
TASK_JOBS_DIR.mkdir(parents=True, exist_ok=True)

class HardwareOptimizer:
    """Tự động phát hiện phần cứng (CPU, RAM, Nền tảng) để điều chỉnh mức Concurrency tối ưu."""
    
    @staticmethod
    def is_android() -> bool:
        from TOOL.services.system_info import SystemInfoDetector
        return SystemInfoDetector.is_android()

    @classmethod
    def get_hardware_profile(cls) -> Dict[str, Any]:
        from TOOL.services.system_info import SystemInfoDetector, calculate_merge_workers
        sys_info = SystemInfoDetector.get_full_system_info()
        cpu_cores = sys_info.get("cpu", {}).get("logical_cores") or 4
        android = sys_info.get("is_android", cls.is_android())
        merge_worker_calc = calculate_merge_workers(sys_info)

        max_tts_workers = 30
        default_tts_workers = 5
        max_speed_workers = min(4, max(2, cpu_cores // 2))
        ffmpeg_threads = merge_worker_calc.get("ffmpeg_threads_per_worker", 2 if android else 4)
        merge_batch_size = 30 if android else 50

        return {
            "is_android": android,
            "device_type": sys_info.get("device_type", "phone" if android else "pc"),
            "cpu_cores": cpu_cores,
            "cpu_model": sys_info.get("cpu", {}).get("model", "unknown"),
            "ram_total_mb": sys_info.get("memory", {}).get("total_mb", 4096),
            "ram_available_mb": sys_info.get("memory", {}).get("available_mb", 2048),
            "max_tts_workers": max_tts_workers,
            "default_tts_workers": default_tts_workers,
            "max_speed_workers": max_speed_workers,
            "merge_workers": merge_worker_calc.get("recommended_workers", 2 if android else 4),
            "max_safe_merge_workers": merge_worker_calc.get("max_safe_workers", 3 if android else 6),
            "ffmpeg_threads": ffmpeg_threads,
            "merge_batch_size": merge_batch_size
        }

class JobControlContext:
    """Quản lý điều khiển luồng (Pause / Resume / Stop / Cancel) bằng Event không khóa CPU."""
    
    def __init__(self, job_id: str):
        self.job_id = job_id
        self._pause_event = threading.Event()
        self._pause_event.set()                                    
        self._stop_event = threading.Event()
        self.cancel_requested = False
        self.pause_requested = False

    def pause(self):
        self.pause_requested = True
        self._pause_event.clear()

    def resume(self):
        self.pause_requested = False
        self._pause_event.set()

    def stop(self):
        self.cancel_requested = True
        self._stop_event.set()
        self._pause_event.set()                                         

    def is_paused(self) -> bool:
        return not self._pause_event.is_set()

    def is_stopped(self) -> bool:
        return self._stop_event.is_set() or self.cancel_requested

    def wait_if_paused(self, timeout: Optional[float] = None) -> bool:
        """Nếu đang pause, worker sẽ chờ tại đây bằng Event mà không tốn CPU."""
        if not self._pause_event.is_set():
            return self._pause_event.wait(timeout=timeout)
        return True

class TaskService:
    def __init__(self):
        self._jobs: Dict[str, Dict[str, Any]] = {}
        self._contexts: Dict[str, JobControlContext] = {}
        self._persist_errors: Dict[str, str] = {}
        self._last_persist_times: Dict[str, float] = {}
        self._lock = threading.RLock()
        self.shutdown_requested = False
        self._active_threads: List[threading.Thread] = []
        self._ensure_jobs_dir()
        self._load_persisted_jobs()

    def _ensure_jobs_dir(self):
        try:
            TASK_JOBS_DIR.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            logger.error(f"Lỗi khi tạo thư mục task_jobs: {e}")

    def _persist_job(self, job_id: str, force: bool = False):
        try:
            job = self._jobs.get(job_id)
            if not job:
                return

            now = time.time()
            last_p = self._last_persist_times.get(job_id, 0.0)
            if not force and (now - last_p) < 0.8:
                return

            self._last_persist_times[job_id] = now
            TASK_JOBS_DIR.mkdir(parents=True, exist_ok=True)

            job_file = TASK_JOBS_DIR / f"{job_id}.json"
            tmp_file = TASK_JOBS_DIR / f"{job_id}.json.tmp"

            safe_job = {}
            for k, v in job.items():
                if k in ["result", "metadata"] and isinstance(v, dict):
                    safe_meta = {}
                    for mk, mv in v.items():
                        if isinstance(mv, (str, int, float, bool, list, type(None))):
                            safe_meta[mk] = mv
                    safe_job[k] = safe_meta
                elif isinstance(v, (str, int, float, bool, list, type(None))):
                    safe_job[k] = v

            with open(tmp_file, "w", encoding="utf-8") as f:
                json.dump(safe_job, f, ensure_ascii=False, indent=2)

            tmp_file.replace(job_file)

            # Sync to Google Drive if mounted
            from TOOL.services.storage_service import StorageService
            StorageService.sync_checkpoint_to_drive(job_id, safe_job)

            if job_id in self._persist_errors:
                del self._persist_errors[job_id]

        except Exception as e:
            err_msg = str(e)
            if self._persist_errors.get(job_id) != err_msg:
                self._persist_errors[job_id] = err_msg
                logger.error(f"Lỗi khi lưu job {job_id}: {err_msg}")

    def _reconcile_job_state(self, job: Dict[str, Any]) -> Dict[str, Any]:
        """Khôi phục và đối chiếu trạng thái thực tế của Job dựa trên file vật lý trên đĩa / Google Drive."""
        jid = job.get("job_id")
        if not jid:
            return job

        from TOOL.services.storage_service import StorageService
        out_dir = StorageService.get_output_dir()
        drive_dir = StorageService.get_drive_dir()

        # 1. Kiểm tra file output âm thanh đã ghép hoàn chỉnh
        saved_p = job.get("saved_path") or job.get("output_path")
        filename = job.get("filename") or job.get("output_filename")

        possible_output_paths = []
        if saved_p:
            possible_output_paths.append(Path(saved_p))
        if filename:
            possible_output_paths.append(out_dir / filename)
            if drive_dir:
                possible_output_paths.append(drive_dir / "outputs" / filename)

        verified_output_file = None
        for p in possible_output_paths:
            try:
                if p.exists() and p.is_file() and p.stat().st_size > 1024:
                    verified_output_file = p
                    break
            except Exception:
                pass

        if verified_output_file:
            job["status"] = "merged"
            job["merge_status"] = "merged"
            job["progress"] = 100
            job["saved_path"] = str(verified_output_file)
            job["message"] = "Đã khôi phục tác vụ hoàn thành từ đĩa cứng."
            if not job.get("download_url") and filename:
                job["download_url"] = f"/api/files/download/{filename}"
            return job

        # 2. Kiểm tra file chunk TTS trong thư mục temp của job
        job_temp_dir = StorageService.get_job_temp_dir(jid)
        chk_file = job_temp_dir / "checkpoint.json"

        if chk_file.exists():
            try:
                with open(chk_file, "r", encoding="utf-8") as f:
                    snapshot = json.load(f)
                    subs = snapshot.get("subtitles") or []
                    if subs:
                        total_subs = len(subs)
                        completed_chunks = 0
                        for s in subs:
                            fn = s.get("audio_filename")
                            if fn and (job_temp_dir / fn).exists() and (job_temp_dir / fn).stat().st_size > 100:
                                completed_chunks += 1

                        if total_subs > 0 and completed_chunks == total_subs:
                            job["status"] = "tts_completed"
                            job["merge_status"] = "idle"
                            job["progress"] = 100
                            job["message"] = f"Đã khôi phục hoàn tất {completed_chunks}/{total_subs} câu TTS. Sẵn sàng ghép audio."
                        elif completed_chunks > 0:
                            job["status"] = "stopped"
                            pct = int(completed_chunks / total_subs * 100)
                            job["progress"] = pct
                            job["message"] = f"Đã khôi phục {completed_chunks}/{total_subs} câu TTS ({pct}%). Sẵn sàng tạo tiếp."
                        else:
                            job["status"] = "stopped"
                            job["message"] = "Tác vụ gián đoạn. Sẵn sàng bắt đầu lại."
            except Exception:
                pass

        if job.get("status") in ["processing", "queued", "merging", "generating"]:
            job["status"] = "stopped"
            job["message"] = "Tác vụ gián đoạn do khởi động lại hệ thống."

        return job

    def _load_persisted_jobs(self):
        try:
            self._ensure_jobs_dir()
            from TOOL.services.storage_service import StorageService

            # Tải từ đĩa cục bộ
            job_files = list(TASK_JOBS_DIR.glob("*.json"))

            # Tải bổ sung từ Google Drive nếu được mount
            drive_dir = StorageService.get_drive_dir()
            if drive_dir:
                drive_chk_dir = drive_dir / "checkpoints"
                if drive_chk_dir.exists():
                    for d_file in drive_chk_dir.glob("*.json"):
                        local_f = TASK_JOBS_DIR / d_file.name
                        if not local_f.exists() or d_file.stat().st_mtime > local_f.stat().st_mtime:
                            try:
                                import shutil
                                shutil.copy2(d_file, local_f)
                            except Exception:
                                pass
                    job_files = list(TASK_JOBS_DIR.glob("*.json"))

            for job_file in job_files:
                try:
                    with open(job_file, "r", encoding="utf-8") as f:
                        job = json.load(f)
                        jid = job.get("job_id")
                        if jid:
                            reconciled = self._reconcile_job_state(job)
                            self._jobs[jid] = reconciled
                except Exception:
                    pass
        except Exception as e:
            logger.error(f"Lỗi khi tải jobs đã lưu: {e}")

    def flush_all_checkpoints(self):
        """Lưu lập tức toàn bộ trạng thái job vào đĩa cục bộ và Google Drive trước khi dừng."""
        with self._lock:
            for jid in list(self._jobs.keys()):
                try:
                    self._persist_job(jid, force=True)
                except Exception:
                    pass

    def can_accept_new_jobs(self) -> bool:
        return not self.shutdown_requested

    def get_control_context(self, job_id: str) -> JobControlContext:
        with self._lock:
            if job_id not in self._contexts:
                self._contexts[job_id] = JobControlContext(job_id)
            return self._contexts[job_id]

    def create_job(self, task_type: str, metadata: Optional[Dict[str, Any]] = None, custom_job_id: Optional[str] = None, job_id: Optional[str] = None) -> str:
        if self.shutdown_requested:
            raise RuntimeError("Máy chủ đang trong quá trình dừng, không nhận thêm tác vụ mới.")

        jid = custom_job_id or job_id or uuid.uuid4().hex[:12]
        with self._lock:
            self._jobs[jid] = {
                "job_id": jid,
                "type": task_type,
                "status": "queued",
                "merge_status": "idle" if task_type in ["tts", "tts_generation"] else None,
                "progress": 0,
                "message": "Task queued...",
                "download_url": None,
                "filename": None,
                "saved_path": None,
                "saved_location": None,
                "created_at": time.time(),
                "completed_at": None,
                "error": None,
                "result": None,
                "metadata": metadata or {}
            }
            self._contexts[jid] = JobControlContext(jid)
            self._persist_job(jid)
        logger.info("TASK_SERVICE", "JOB_CREATED", f"Tạo job mới [{task_type}]", job_id=jid)
        return jid

    def update_job(
        self,
        job_id: str,
        status: Optional[str] = None,
        merge_status: Optional[str] = None,
        progress: Optional[int] = None,
        message: Optional[str] = None,
        download_url: Optional[str] = None,
        filename: Optional[str] = None,
        output_filename: Optional[str] = None,
        saved_path: Optional[str] = None,
        output_path: Optional[str] = None,
        saved_location: Optional[str] = None,
        output_size: Optional[int] = None,
        duration: Optional[float] = None,
        audio_format: Optional[str] = None,
        verified: Optional[bool] = None,
        error: Optional[str] = None,
        result: Optional[Any] = None,
        **kwargs: Any
    ):
        with self._lock:
            if job_id not in self._jobs:
                return
            job = self._jobs[job_id]
            old_status = job.get("status")
            if status is not None:
                job["status"] = status
                if status != old_status:
                    logger.info("TASK_SERVICE", "STATUS_CHANGE", f"Job {job_id} [{old_status} -> {status}]", job_id=job_id, progress=progress or job.get("progress"))
                if status == "paused":
                    self.get_control_context(job_id).pause()
                elif status in ["processing", "generating", "merging"]:
                    self.get_control_context(job_id).resume()
                elif status in ["stopped", "failed", "cancelled", "error"]:
                    self.get_control_context(job_id).stop()

            if merge_status is not None:
                job["merge_status"] = merge_status

            if progress is not None:
                job["progress"] = max(0, min(100, int(progress)))
            if message is not None:
                job["message"] = message
            if download_url is not None:
                job["download_url"] = download_url
            if filename is not None:
                job["filename"] = filename
            if output_filename is not None:
                job["output_filename"] = output_filename
            if saved_path is not None:
                job["saved_path"] = saved_path
            if output_path is not None:
                job["output_path"] = output_path
            if saved_location is not None:
                job["saved_location"] = saved_location
            if output_size is not None:
                job["output_size"] = output_size
            if duration is not None:
                job["duration"] = duration
            if audio_format is not None:
                job["audio_format"] = audio_format
            if verified is not None:
                job["verified"] = verified
            if error is not None:
                job["error"] = error
                logger.error("TASK_SERVICE", "JOB_ERROR", f"Job {job_id} error: {error}", job_id=job_id)
            if result is not None:
                job["result"] = result

            for k, v in kwargs.items():
                if v is not None:
                    job[k] = v

            if status in ["completed", "failed", "stopped", "merged", "error"]:
                job["completed_at"] = time.time()
                if status == "completed":
                    logger.info("TASK_SERVICE", "JOB_COMPLETED", f"Job {job_id} hoàn tất thành công", job_id=job_id, output=saved_location or output_filename)
            force_persist = status in ["completed", "failed", "stopped", "merged", "error", "paused", "merging"]
            self._persist_job(job_id, force=force_persist)

        if status in ["completed", "failed"]:
            try:
                from TOOL.services.cleanup_service import CleanupService
                up_files = []
                meta = self._jobs.get(job_id, {}).get("metadata", {})
                if "upload_paths" in meta:
                    up_files = meta["upload_paths"]
                elif "upload_path" in meta:
                    up_files = [meta["upload_path"]]
                CleanupService.cleanup_job_temp(job_id, uploaded_files=up_files)
            except Exception:
                pass

    def get_job(self, job_id: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            job = self._jobs.get(job_id)
            return dict(job) if job else None

    def list_jobs(self, limit: int = 20) -> list:
        with self._lock:
            items = list(self._jobs.values())
            items.sort(key=lambda x: x["created_at"], reverse=True)
            return [dict(j) for j in items[:limit]]

    def get_active_jobs(self) -> list:
        with self._lock:
            return [dict(j) for j in self._jobs.values() if j.get("status") in ["processing", "queued", "paused", "merging"]]

    def has_active_jobs(self) -> bool:
        with self._lock:
            return any(j.get("status") in ["processing", "queued", "paused", "merging"] for j in self._jobs.values())

    def pause_job(self, job_id: str) -> Dict[str, Any]:
        """Tạm dừng job tức thì không chờ đợi."""
        ctx = self.get_control_context(job_id)
        ctx.pause()
        self.update_job(job_id, status="paused", message="⏸ Tiến trình đã được tạm dừng.")
        return self.get_job(job_id) or {"job_id": job_id, "status": "paused"}

    def resume_job(self, job_id: str) -> Dict[str, Any]:
        """Tiếp tục job tức thì."""
        ctx = self.get_control_context(job_id)
        ctx.resume()
        self.update_job(job_id, status="processing", message="▶ Đang tiếp tục tiến trình...")
        return self.get_job(job_id) or {"job_id": job_id, "status": "processing"}

    def stop_job(self, job_id: str) -> Dict[str, Any]:
        """Dừng job tức thì không chờ đợi."""
        ctx = self.get_control_context(job_id)
        ctx.stop()
        self.update_job(job_id, status="stopped", message="⏹ Tiến trình đã dừng bởi người dùng.")
        return self.get_job(job_id) or {"job_id": job_id, "status": "stopped"}

    def request_shutdown(self, timeout_sec: float = 3.0):
        """Kích hoạt quá trình Graceful Shutdown."""
        self.shutdown_requested = True
        logger.info("TASK_SERVICE", "SHUTDOWN", "[SHUTDOWN] Đã kích hoạt cờ shutdown_requested = True. Dừng nhận job mới.")
        
        with self._lock:
            for job_id, ctx in self._contexts.items():
                ctx.stop()
            for job_id, job in self._jobs.items():
                if job.get("status") in ["processing", "queued", "paused", "merging"]:
                    job["status"] = "stopped"
                    job["message"] = "Server shutting down."

    def run_in_background(self, job_id: str, target: Callable[..., Any], *args, **kwargs):
        def _wrapper():
            current_job = self.get_job(job_id)
            initial_status = current_job.get("status") if current_job else None
            if initial_status not in ["merging", "generating"]:
                self.update_job(job_id, status="processing", progress=5, message="Processing started...")
            try:
                result = target(job_id, *args, **kwargs)
                latest_job = self.get_job(job_id)
                if latest_job and latest_job.get("status") not in ["failed", "completed", "stopped", "merged"]:
                    self.update_job(job_id, status="completed", progress=100, message="Task completed successfully!", result=result)
            except Exception as e:
                logger.exception("TASK_SERVICE", "JOB_ERROR", f"Lỗi background job {job_id}: {e}", exc=e)
                self.update_job(job_id, status="failed", error=str(e), message=f"Lỗi: {str(e)}")

        thread = threading.Thread(target=_wrapper, daemon=True)
        with self._lock:
            self._active_threads.append(thread)
        thread.start()

job_manager = TaskService()

