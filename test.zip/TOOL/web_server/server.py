# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB - DEDICATED WEB SERVER FOR GOOGLE COLAB & BROWSER ACCESS
==============================================================================
Module máy chủ web chuyên dụng chạy trên Google Colab / Linux / PC:
- Tận dụng 100% backend API, Services, Engines và Task Manager của KAGEVIETSUB.
- Cung cấp Generic Upload API, Secure File Download, Realtime Logs & Tunnel.
- Tự động tương thích với cả FastAPI và Standalone Multi-threaded HTTP Server.
==============================================================================
"""

import os
import sys
import time
import json
import gzip
import shutil
import urllib.parse
import threading
from pathlib import Path
from http.server import HTTPServer, SimpleHTTPRequestHandler
from socketserver import ThreadingMixIn
from typing import Dict, Any, Optional

TOOL_DIR = Path(__file__).resolve().parent.parent
PROJECT_ROOT = TOOL_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
if str(TOOL_DIR) not in sys.path:
    sys.path.insert(0, str(TOOL_DIR))

from TOOL.config import (
    DATA_DIR, TEMP_DIR, OUTPUT_DIR, UPLOADS_DIR,
    WEB_DIR, KAGE_DOWNLOAD_DIR, ensure_directories, get_local_version
)
from TOOL.services.storage_service import StorageService
from TOOL.services.logger import logger as central_logger
from TOOL.web_server.adapter import WebServerAdapter
from TOOL.web_server.tunnel import CloudflareTunnel, print_colab_banner

# Tái sử dụng trực tiếp các API handlers từ TOOL/server.py
from TOOL.server import (
    get_health_data, get_all_unified_jobs, get_single_job_unified,
    create_export_zip, re_filename, re_name,
    handle_parse_srt, handle_remove_trailing_punct, handle_remove_leading_ellipsis,
    handle_replace_rules, handle_avoid_overlap, handle_purple_sequence,
    handle_fix_repeat_2_3, handle_fix_repeat_4_5, handle_merge_short,
    handle_all_steps, handle_uppercase, handle_split_srt, handle_save_srt,
    handle_get_translate_providers, handle_check_api_key,
    handle_start_translation, handle_get_translation_status,
    handle_pause_translation, handle_resume_translation,
    handle_stop_translation, handle_retry_translation,
    handle_audio_merge, handle_video_cut, handle_video_merge, handle_video_compress,
    handle_whisper_models, handle_whisper_transcribe, handle_download_whisper_model,
    handle_tts_voices, handle_tts_parse_srt, handle_tts_create_job,
    handle_tts_retry, handle_tts_retry_failed, handle_tts_merge, handle_tts_get_job, handle_tts_get_status,
    handle_tts_pause, handle_tts_resume, handle_tts_stop, handle_tts_preview,
    handle_tts_merge_recovery_folders, handle_tts_merge_recovery_start,
    handle_check_links, handle_get_info, handle_start_download, handle_update_job,
    handle_downloader_status, handle_cancel_job, handle_cancel_all,
    handle_downloader_retry, handle_remove_job, handle_downloader_ready,
    handle_downloader_download_file,
    CleanupService, HardwareOptimizer
)

logger = central_logger.get_module_logger("COLAB_WEB_SERVER")

class ColabWebRequestHandler(SimpleHTTPRequestHandler):
    """
    HTTP Request Handler cho Web Server trên Google Colab & Web.
    Tích hợp Generic Upload, Secure Download, Realtime Logs và toàn bộ API KAGEVIETSUB.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(WEB_DIR) if WEB_DIR.exists() else str(PROJECT_ROOT), **kwargs)

    def _send_cors_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, DELETE")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With")

    def _send_json(self, data: Any, status_code: int = 200):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        accept_enc = self.headers.get("Accept-Encoding", "")

        if "gzip" in accept_enc and len(body) > 512:
            try:
                compressed = gzip.compress(body, compresslevel=6)
                self.send_response(status_code)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Encoding", "gzip")
                self.send_header("Content-Length", str(len(compressed)))
                self.send_header("Vary", "Accept-Encoding")
                self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
                self._send_cors_headers()
                self.end_headers()
                self.wfile.write(compressed)
                return
            except Exception:
                pass

        self.send_response(status_code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self._send_cors_headers()
        self.end_headers()
        self.wfile.write(body)

    def _serve_static_file(self, file_path: Path):
        if not file_path.exists() or not file_path.is_file():
            self.send_error(404, f"File '{file_path.name}' không tồn tại.")
            return

        st = file_path.stat()
        etag = f'"{int(st.st_mtime)}-{st.st_size}"'
        if_none_match = self.headers.get("If-None-Match")
        if if_none_match and if_none_match.strip() == etag:
            self.send_response(304)
            self._send_cors_headers()
            self.end_headers()
            return

        suffix = file_path.suffix.lower()
        mime_types = {
            ".html": "text/html; charset=utf-8",
            ".js": "application/javascript; charset=utf-8",
            ".css": "text/css; charset=utf-8",
            ".json": "application/json; charset=utf-8",
            ".svg": "image/svg+xml",
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".gif": "image/gif",
            ".ico": "image/x-icon",
            ".woff": "font/woff",
            ".woff2": "font/woff2",
            ".ttf": "font/ttf",
            ".txt": "text/plain; charset=utf-8"
        }
        mime = mime_types.get(suffix, "application/octet-stream")

        if suffix in [".js", ".css", ".png", ".svg", ".ico", ".woff", ".woff2"]:
            cache_ctrl = "public, max-age=86400"
        else:
            cache_ctrl = "no-cache"

        try:
            with open(file_path, "rb") as f:
                raw_data = f.read()
        except Exception as e:
            self.send_error(500, f"Error reading file: {e}")
            return

        accept_enc = self.headers.get("Accept-Encoding", "")
        is_compressible = (suffix in [".html", ".js", ".css", ".json", ".svg", ".txt"]) and (len(raw_data) > 256)

        if is_compressible and "gzip" in accept_enc:
            try:
                compressed = gzip.compress(raw_data, compresslevel=6)
                self.send_response(200)
                self.send_header("Content-Type", mime)
                self.send_header("Content-Encoding", "gzip")
                self.send_header("Content-Length", str(len(compressed)))
                self.send_header("ETag", etag)
                self.send_header("Cache-Control", cache_ctrl)
                self.send_header("Vary", "Accept-Encoding")
                self._send_cors_headers()
                self.end_headers()
                self.wfile.write(compressed)
                return
            except Exception:
                pass

        self.send_response(200)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(raw_data)))
        self.send_header("ETag", etag)
        self.send_header("Cache-Control", cache_ctrl)
        self._send_cors_headers()
        self.end_headers()
        self.wfile.write(raw_data)

    def _send_file_download(self, file_path: Path, filename: str, mime_type: str = "application/octet-stream", is_inline: bool = False):
        if not file_path or not file_path.exists() or not file_path.is_file():
            self._send_json({"success": False, "error": f"File '{filename}' không tồn tại trên máy chủ."}, 404)
            return

        file_size = file_path.stat().st_size
        range_header = self.headers.get("Range")
        disposition = "inline" if is_inline else f'attachment; filename="{filename}"'

        if range_header and range_header.strip().startswith("bytes="):
            try:
                ranges = range_header.strip()[6:].split("-")
                start = int(ranges[0]) if ranges[0] else 0
                end = int(ranges[1]) if len(ranges) > 1 and ranges[1] else file_size - 1

                if start >= file_size or end >= file_size or start > end:
                    self.send_response(416)
                    self.send_header("Content-Range", f"bytes */{file_size}")
                    self.send_header("Content-Length", "0")
                    self._send_cors_headers()
                    self.end_headers()
                    return

                length = end - start + 1
                self.send_response(206)
                self.send_header("Content-Type", mime_type)
                self.send_header("Content-Length", str(length))
                self.send_header("Content-Range", f"bytes {start}-{end}/{file_size}")
                self.send_header("Accept-Ranges", "bytes")
                self.send_header("Content-Disposition", disposition)
                self._send_cors_headers()
                self.end_headers()

                with open(file_path, "rb") as f:
                    f.seek(start)
                    remaining = length
                    chunk_size = 64 * 1024
                    while remaining > 0:
                        read_bytes = min(chunk_size, remaining)
                        data = f.read(read_bytes)
                        if not data:
                            break
                        self.wfile.write(data)
                        remaining -= len(data)
                return
            except Exception as ex:
                logger.warning(f"Error serving Range request for {filename}: {ex}")

        # Chuẩn HTTP 200 OK Streaming
        self.send_response(200)
        self.send_header("Content-Type", mime_type)
        self.send_header("Content-Length", str(file_size))
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Disposition", disposition)
        self._send_cors_headers()
        self.end_headers()

        with open(file_path, "rb") as f:
            chunk_size = 64 * 1024
            while True:
                data = f.read(chunk_size)
                if not data:
                    break
                self.wfile.write(data)

    def do_OPTIONS(self):
        self.send_response(204)
        self._send_cors_headers()
        self.end_headers()

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        # 1. API Logs (Realtime & Download)
        if path in ["/api/logs", "/api/logs/realtime", "/api/logs/tail"]:
            query_params = urllib.parse.parse_qs(parsed.query)
            lines = int(query_params.get("lines", [150])[0])
            return self._send_json(WebServerAdapter.get_realtime_logs(lines=lines))

        if path == "/api/logs/download":
            try:
                log_p, log_fn = WebServerAdapter.get_log_download_path()
                return self._send_file_download(log_p, log_fn, "text/plain; charset=utf-8")
            except Exception as e:
                return self._send_json({"success": False, "error": str(e)}, 500)

        # 2. API Download an toàn
        if path.startswith("/api/download/") or path == "/api/download" or path.startswith("/api/files/download"):
            query_params = urllib.parse.parse_qs(parsed.query)
            ident = query_params.get("path", [""])[0] or query_params.get("filename", [""])[0]
            if not ident:
                if path.startswith("/api/download/"):
                    ident = urllib.parse.unquote(path[len("/api/download/"):])
                elif path.startswith("/api/files/download/"):
                    ident = urllib.parse.unquote(path[len("/api/files/download/"):])

            try:
                target_p, fn, mime = WebServerAdapter.resolve_download_file(ident)
                return self._send_file_download(target_p, fn, mime)
            except FileNotFoundError as fnf:
                return self._send_json({"success": False, "error": str(fnf)}, 404)
            except Exception as ex:
                return self._send_json({"success": False, "error": f"Lỗi tải file: {ex}"}, 400)

        # 3. System & Health
        if path == "/api/health":
            return self._send_json(get_health_data())

        if path == "/api/system/info":
            from TOOL.system_check import get_full_system_info
            return self._send_json(get_full_system_info())

        if path == "/api/jobs":
            return self._send_json({"jobs": get_all_unified_jobs()})

        if path.startswith("/api/jobs/"):
            job_id = path[len("/api/jobs/"):]
            job = get_single_job_unified(job_id)
            if not job:
                return self._send_json({"success": False, "error": f"Không tìm thấy job '{job_id}'"}, 404)
            return self._send_json(job)

        if path == "/api/export-project":
            zip_p = create_export_zip()
            return self._send_file_download(zip_p, "KAGEVIETSUB.zip", "application/zip")

        if path == "/api/version":
            return self._send_json({
                "version": get_local_version(),
                "app_name": "KAGEVIETSUB",
                "environment": StorageService.get_platform()
            })

        # 4. SRT, TTS, Whisper, Downloader, DS2API GET Routes
        if path == "/api/srt/translate/providers":
            return self._send_json(handle_get_translate_providers())

        if path.startswith("/api/srt/translate/status/"):
            trans_jid = path[len("/api/srt/translate/status/"):].strip("/")
            return self._send_json(handle_get_translation_status(trans_jid))

        if path == "/api/whisper/models":
            return self._send_json(handle_whisper_models())

        if path == "/api/tts/voices":
            return self._send_json(handle_tts_voices())

        if path == "/api/tts/hardware-profile":
            return self._send_json(HardwareOptimizer.get_hardware_profile())

        if path in ["/api/tts/merge-recovery/folders", "/api/tts/merge-recovery/sources"]:
            try:
                return self._send_json(handle_tts_merge_recovery_folders())
            except Exception as e:
                return self._send_json({"detail": str(e)}, 500)

        if path.startswith("/api/tts/status/") or path == "/api/tts/status" or (path.startswith("/api/tts/") and path.endswith("/status")):
            query_params = urllib.parse.parse_qs(parsed.query)
            inc_subs = query_params.get("include_subtitles", ["false"])[0].lower() in ["true", "1", "yes"]
            if path.startswith("/api/tts/status/"):
                tts_jid = path[len("/api/tts/status/"):].strip("/")
            elif path.startswith("/api/tts/") and path.endswith("/status"):
                tts_jid = path[len("/api/tts/"): -len("/status")].strip("/")
            else:
                tts_jid = query_params.get("job_id", [""])[0]
            try:
                return self._send_json(handle_tts_get_status(tts_jid, include_subtitles=inc_subs))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 404)

        if path.startswith("/api/tts/job/"):
            tts_jid = path[len("/api/tts/job/"):].strip("/")
            try:
                return self._send_json(handle_tts_get_job(tts_jid))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 404)

        if path.startswith("/api/tts/preview/"):
            parts = path[len("/api/tts/preview/"):].split("?")[0].split("/")
            if len(parts) >= 2:
                jid, idx_str = parts[0], parts[1]
                try:
                    idx = int(idx_str)
                    preview_p = handle_tts_preview(jid, idx)
                    if not preview_p.exists():
                        return self._send_json({"detail": "File preview không tồn tại."}, 404)
                    file_size = preview_p.stat().st_size
                    media_type = "audio/wav" if preview_p.suffix.lower() == ".wav" else "audio/mpeg"
                    self.send_response(200)
                    self.send_header("Content-Type", media_type)
                    self.send_header("Content-Length", str(file_size))
                    self.send_header("Accept-Ranges", "bytes")
                    self.send_header("Cache-Control", "public, max-age=3600")
                    self._send_cors_headers()
                    self.end_headers()
                    with open(preview_p, "rb") as f:
                        shutil.copyfileobj(f, self.wfile)
                    return
                except Exception as e:
                    return self._send_json({"detail": str(e)}, 404)

        if path == "/api/downloader/ready":
            return self._send_json(handle_downloader_ready())

        if path.startswith("/api/downloader/download/") or path == "/api/downloader/download":
            query_params = urllib.parse.parse_qs(parsed.query)
            dl_jid = path[len("/api/downloader/download/"):].strip("/") if path.startswith("/api/downloader/download/") else query_params.get("job_id", [""])[0]
            file_type = query_params.get("type", ["media"])[0]
            try:
                dl_path, dl_fn, dl_mime = handle_downloader_download_file(dl_jid, file_type=file_type)
                return self._send_file_download(dl_path, dl_fn, dl_mime)
            except Exception as e:
                return self._send_json({"error": str(e), "detail": str(e)}, 404)

        if path == "/api/downloader/status" or path.startswith("/api/downloader/status/") or path.startswith("/api/downloader/job/"):
            query_params = urllib.parse.parse_qs(parsed.query)
            if path.startswith("/api/downloader/status/"):
                dl_jid = path[len("/api/downloader/status/"):].strip("/")
            elif path.startswith("/api/downloader/job/"):
                dl_jid = path[len("/api/downloader/job/"):].strip("/")
            else:
                dl_jid = query_params.get("job_id", [""])[0]
            return self._send_json(handle_downloader_status(dl_jid if dl_jid else None))

        if path == "/api/ds2api/status":
            from TOOL.services.ds2api_service import ds2api_service
            return self._send_json(ds2api_service.get_status())

        if path == "/api/ds2api/models":
            from TOOL.services.ds2api_service import ds2api_service
            return self._send_json({"models": ds2api_service.get_models()})

        if path == "/api/ds2api/accounts":
            from TOOL.services.ds2api_service import DS2APIConfigManager
            return self._send_json({"accounts": DS2APIConfigManager.get_public_accounts()})

        # Phục vụ Static SPA Web
        target = WEB_DIR / path.lstrip("/")
        if target.exists() and target.is_file():
            return self._serve_static_file(target)
        index_file = WEB_DIR / "index.html"
        if index_file.exists():
            return self._serve_static_file(index_file)
        return super().do_GET()

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        content_type = self.headers.get("Content-Type", "")
        content_length = int(self.headers.get("Content-Length", 0))

        # 1. Xử lý Multipart Form Data (Upload File chung & Video/Audio Modules)
        if "multipart/form-data" in content_type:
            raw_body = self.rfile.read(content_length)
            boundary = content_type.split("boundary=")[1].encode("utf-8")
            parts = raw_body.split(b"--" + boundary)

            form_fields = {}
            uploaded_files = []

            for p in parts:
                if not p or p == b"--\r\n" or p == b"--":
                    continue
                header_part, _, body_part = p.partition(b"\r\n\r\n")
                body_part = body_part.rstrip(b"\r\n")
                header_str = header_part.decode("utf-8", errors="ignore")

                if 'filename="' in header_str:
                    fn_match = re_filename(header_str)
                    if fn_match and body_part:
                        try:
                            saved_info = WebServerAdapter.save_uploaded_file(body_part, fn_match)
                            uploaded_files.append((fn_match, Path(saved_info["saved_path"]), saved_info))
                        except Exception as e:
                            logger.error(f"Lỗi lưu file: {e}", module="UPLOAD", action="SAVE_ERROR", exc=e)
                elif 'name="' in header_str:
                    field_name = re_name(header_str)
                    if field_name:
                        form_fields[field_name] = body_part.decode("utf-8", errors="ignore")

            # Generic Upload API: POST /api/upload hoặc POST /api/files/upload
            if path in ["/api/upload", "/api/files/upload"]:
                if not uploaded_files:
                    return self._send_json({"success": False, "error": "Chưa chọn file để tải lên hoặc file rỗng."}, 400)
                first_info = uploaded_files[0][2]
                all_results = [f[2] for f in uploaded_files]
                return self._send_json({
                    "success": True,
                    "status": "ok",
                    "message": "Upload file thành công",
                    "files": all_results,
                    "first_file": first_info,
                    "file_id": first_info["file_id"],
                    "saved_path": first_info["saved_path"],
                    "filename": first_info["filename"]
                })

            if path == "/api/audio/merge":
                paths = [p for _, p, _ in uploaded_files]
                out_name = form_fields.get("output_filename", "combined.mp3")
                sort_alpha = form_fields.get("sort_alphabetical", "true").lower() == "true"
                try:
                    res = handle_audio_merge(paths, out_name, sort_alpha)
                    return self._send_json(res)
                except Exception as e:
                    return self._send_json({"success": False, "error": str(e), "detail": str(e)}, 400)

            if path == "/api/video/cut":
                if not uploaded_files:
                    return self._send_json({"success": False, "error": "Chưa chọn file video", "detail": "Chưa chọn file video"}, 400)
                fn, p, _ = uploaded_files[0]
                mins = int(form_fields.get("segment_minutes", 5))
                mode = form_fields.get("mode", "copy")
                res = handle_video_cut(p, fn, mins, mode)
                return self._send_json(res)

            if path == "/api/video/merge":
                paths = [p for _, p, _ in uploaded_files]
                out_name = form_fields.get("output_filename", "merged_video.mp4")
                mode = form_fields.get("mode", "lossless")
                caption = form_fields.get("caption") or None
                font_sz = int(form_fields.get("font_size", 24))
                font_col = form_fields.get("font_color", "white")
                pos = form_fields.get("caption_position", "bottom")
                try:
                    res = handle_video_merge(paths, out_name, mode, caption, font_sz, font_col, pos)
                    return self._send_json(res)
                except Exception as e:
                    return self._send_json({"success": False, "error": str(e), "detail": str(e)}, 400)

            if path == "/api/video/compress":
                if not uploaded_files:
                    return self._send_json({"success": False, "error": "Chưa chọn file video", "detail": "Chưa chọn file video"}, 400)
                fn, p, _ = uploaded_files[0]
                crf = int(form_fields.get("crf", 18))
                preset = form_fields.get("preset", "slow")
                codec = form_fields.get("codec", "libx264")
                res = handle_video_compress(p, fn, crf, preset, codec)
                return self._send_json(res)

            if path == "/api/whisper/transcribe":
                if not uploaded_files:
                    return self._send_json({"success": False, "error": "Chưa chọn file âm thanh/video", "detail": "Chưa chọn file âm thanh/video"}, 400)
                fn, p, _ = uploaded_files[0]
                model_sz = form_fields.get("model_size", "large-v3-turbo")
                beam = int(form_fields.get("beam_size", 5))
                lang = form_fields.get("language", "zh")
                mw = int(form_fields.get("max_words", 20))
                md = float(form_fields.get("max_duration", 6.0))
                st = float(form_fields.get("silence_threshold", 0.3))
                res = handle_whisper_transcribe(p, fn, model_sz, beam, lang, mw, md, st)
                return self._send_json(res)

            if path == "/api/video/info":
                if not uploaded_files:
                    return self._send_json({"success": False, "error": "Chưa chọn file", "detail": "Chưa chọn file"}, 400)
                from TOOL.services.ffmpeg_service import FFmpegService
                fn, p, _ = uploaded_files[0]
                info = FFmpegService.get_media_info(p)
                return self._send_json({"filename": fn, "info": info})

        # 2. Xử lý JSON Body Request
        raw_body = self.rfile.read(content_length).decode("utf-8") if content_length > 0 else "{}"
        try:
            payload = json.loads(raw_body) if raw_body else {}
        except Exception:
            payload = {}

        if path in ["/api/upload", "/api/files/upload"]:
            filename = payload.get("filename", "upload.srt")
            content = payload.get("content", "")
            if content:
                try:
                    saved_info = WebServerAdapter.save_uploaded_file(content.encode("utf-8"), filename)
                    return self._send_json(saved_info)
                except Exception as e:
                    return self._send_json({"success": False, "error": str(e)}, 400)
            return self._send_json({"success": False, "error": "Nội dung file rỗng."}, 400)

        if path == "/api/cleanup":
            return self._send_json(CleanupService.cleanup_orphaned_temp())

        # SRT Translation
        if path == "/api/srt/translate/check-api":
            return self._send_json(handle_check_api_key(
                payload.get("provider", "deepseek"),
                payload.get("api_key", ""),
                payload.get("model", "deepseek-chat")
            ))

        if path == "/api/srt/translate/start":
            return self._send_json(handle_start_translation(
                content=payload.get("content", ""),
                filename=payload.get("filename", "subtitle.srt"),
                api_pool=payload.get("api_pool", []),
                source_lang=payload.get("source_lang", "zh"),
                target_lang=payload.get("target_lang", "vi"),
                batch_size=int(payload.get("batch_size", 20)),
                user_prompt=payload.get("user_prompt")
            ))

        if path.startswith("/api/srt/translate/pause/"):
            trans_jid = path[len("/api/srt/translate/pause/"):].strip("/")
            return self._send_json(handle_pause_translation(trans_jid))

        if path.startswith("/api/srt/translate/resume/"):
            trans_jid = path[len("/api/srt/translate/resume/"):].strip("/")
            return self._send_json(handle_resume_translation(trans_jid))

        if path.startswith("/api/srt/translate/stop/"):
            trans_jid = path[len("/api/srt/translate/stop/"):].strip("/")
            return self._send_json(handle_stop_translation(trans_jid))

        if path.startswith("/api/srt/translate/retry/"):
            trans_jid = path[len("/api/srt/translate/retry/"):].strip("/")
            return self._send_json(handle_retry_translation(trans_jid))

        # DS2API Routes
        if path == "/api/ds2api/start":
            from TOOL.services.ds2api_service import ds2api_service
            return self._send_json(ds2api_service.start_service())

        if path == "/api/ds2api/stop":
            from TOOL.services.ds2api_service import ds2api_service
            return self._send_json(ds2api_service.stop_service())

        if path == "/api/ds2api/accounts":
            from TOOL.services.ds2api_service import DS2APIConfigManager
            name = payload.get("name", "")
            login_id = payload.get("login_id") or payload.get("email") or payload.get("mobile") or ""
            password = payload.get("password", "")
            is_mobile = bool(payload.get("is_mobile", False))
            if not login_id or not password:
                return self._send_json({"detail": "Vui lòng nhập đầy đủ tài khoản (Email/SĐT) và mật khẩu."}, 400)
            res = DS2APIConfigManager.add_account(name, login_id, password, is_mobile)
            return self._send_json(res)

        if path == "/api/ds2api/accounts/test":
            from TOOL.services.ds2api_service import ds2api_service
            acc_id = payload.get("account_id", "")
            if not acc_id:
                return self._send_json({"detail": "Thiếu account_id để kiểm tra."}, 400)
            return self._send_json(ds2api_service.test_account(acc_id))

        if path.startswith("/api/ds2api/accounts/delete/") or path == "/api/ds2api/accounts/delete":
            from TOOL.services.ds2api_service import DS2APIConfigManager
            acc_id = path[len("/api/ds2api/accounts/delete/"):].strip("/") if path.startswith("/api/ds2api/accounts/delete/") else payload.get("account_id", "")
            if not acc_id:
                return self._send_json({"detail": "Thiếu account_id để xóa."}, 400)
            ok = DS2APIConfigManager.delete_account(acc_id)
            return self._send_json({"status": "ok" if ok else "error", "message": "Đã xóa tài khoản." if ok else "Không tìm thấy tài khoản."})

        # Whisper Routes
        if path == "/api/whisper/models/download":
            model_id = payload.get("model_id", "")
            try:
                return self._send_json(handle_download_whisper_model(model_id))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/whisper/models/scan":
            return self._send_json(handle_whisper_models())

        # TTS Routes
        if path == "/api/tts/parse-srt":
            srt_cnt = payload.get("srt_content") or payload.get("content") or ""
            try:
                return self._send_json(handle_tts_parse_srt(srt_cnt))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/tts/create-job":
            srt_cnt = payload.get("srt_content") or payload.get("content") or ""
            vc = payload.get("voice", "BV421_vivn_streaming")
            spd = float(payload.get("speed", 1.0))
            thrd = int(payload.get("threads", 5))
            fmt = payload.get("audio_format", "mp3")
            out_fn = payload.get("output_filename")
            try:
                return self._send_json(handle_tts_create_job(srt_cnt, vc, spd, thrd, fmt, out_fn))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/tts/retry":
            jid = payload.get("job_id", "")
            idx = int(payload.get("subtitle_index", 1))
            vc = payload.get("voice")
            spd = float(payload.get("speed")) if payload.get("speed") is not None else None
            try:
                return self._send_json(handle_tts_retry(jid, idx, vc, spd))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path in ["/api/tts/retry-failed", "/api/tts/retry-all", "/api/tts/retry-all-failed"] or (path.startswith("/api/tts/") and path.endswith("/retry-failed")):
            jid = payload.get("job_id", "")
            if not jid and path.startswith("/api/tts/") and path.endswith("/retry-failed"):
                jid = path[len("/api/tts/"):].split("/")[0]
            vc = payload.get("voice")
            spd = float(payload.get("speed")) if payload.get("speed") is not None else None
            thrd = int(payload.get("threads")) if payload.get("threads") is not None else None
            try:
                return self._send_json(handle_tts_retry_failed(jid, vc, spd, thrd))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/tts/merge-recovery/start":
            folder_p = payload.get("folder_path", "") or payload.get("source_id", "")
            srt_c = payload.get("srt_content", "")
            out_fn = payload.get("output_filename", "tts_recovered_audio.mp3")
            fmt = payload.get("audio_format")
            try:
                return self._send_json(handle_tts_merge_recovery_start(folder_p, srt_c, out_fn, fmt))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path in ["/api/tts/merge-recovery/cancel", "/api/tts/merge-recovery/cancel/"] or path.startswith("/api/tts/merge-recovery/cancel/"):
            jid = path[len("/api/tts/merge-recovery/cancel/"):].strip("/") if path.startswith("/api/tts/merge-recovery/cancel/") else payload.get("job_id", "")
            try:
                return self._send_json(handle_tts_stop(jid))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/tts/pause" or (path.startswith("/api/tts/") and path.endswith("/pause")):
            jid = path[len("/api/tts/"): -len("/pause")].strip("/") if path.endswith("/pause") and path != "/api/tts/pause" else payload.get("job_id", "")
            try:
                return self._send_json(handle_tts_pause(jid))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/tts/resume" or (path.startswith("/api/tts/") and path.endswith("/resume")):
            jid = path[len("/api/tts/"): -len("/resume")].strip("/") if path.endswith("/resume") and path != "/api/tts/resume" else payload.get("job_id", "")
            try:
                return self._send_json(handle_tts_resume(jid))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/tts/stop" or (path.startswith("/api/tts/") and path.endswith("/stop")):
            jid = path[len("/api/tts/"): -len("/stop")].strip("/") if path.endswith("/stop") and path != "/api/tts/stop" else payload.get("job_id", "")
            try:
                return self._send_json(handle_tts_stop(jid))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/tts/merge" or (path.startswith("/api/tts/") and path.endswith("/merge")):
            jid = path[len("/api/tts/"): -len("/merge")].strip("/") if path.endswith("/merge") and path != "/api/tts/merge" else payload.get("job_id", "")
            out_fn = payload.get("output_filename")
            fmt = payload.get("audio_format")
            try:
                return self._send_json(handle_tts_merge(jid, out_fn, fmt))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        # Downloader Routes
        if path == "/api/downloader/check-links":
            try:
                return self._send_json(handle_check_links(payload))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/downloader/info":
            try:
                return self._send_json(handle_get_info(payload))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/downloader/start":
            try:
                return self._send_json(handle_start_download(payload))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/downloader/update":
            try:
                return self._send_json(handle_update_job(payload))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/downloader/cancel-all" or path == "/api/downloader/stop-all":
            try:
                return self._send_json(handle_cancel_all())
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path.startswith("/api/downloader/cancel/") or path == "/api/downloader/cancel":
            dl_jid = path[len("/api/downloader/cancel/"):].strip("/") if path.startswith("/api/downloader/cancel/") else payload.get("job_id", "")
            try:
                return self._send_json(handle_cancel_job(dl_jid))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path.startswith("/api/downloader/retry/") or path == "/api/downloader/retry":
            dl_jid = path[len("/api/downloader/retry/"):].strip("/") if path.startswith("/api/downloader/retry/") else payload.get("job_id", "")
            try:
                return self._send_json(handle_downloader_retry(dl_jid, payload))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path.startswith("/api/downloader/remove/") or path == "/api/downloader/remove":
            dl_jid = path[len("/api/downloader/remove/"):].strip("/") if path.startswith("/api/downloader/remove/") else payload.get("job_id", "")
            try:
                return self._send_json(handle_remove_job(dl_jid))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        # SRT Edit Operations
        content = payload.get("content", "")
        rules = payload.get("rules")

        if path == "/api/srt/parse":
            return self._send_json(handle_parse_srt(content))
        if path == "/api/srt/remove-trailing-punctuation":
            return self._send_json(handle_remove_trailing_punct(content))
        if path == "/api/srt/remove-leading-ellipsis":
            return self._send_json(handle_remove_leading_ellipsis(content))
        if path == "/api/srt/replace":
            return self._send_json(handle_replace_rules(content, rules))
        if path == "/api/srt/avoid-overlap":
            return self._send_json(handle_avoid_overlap(content))
        if path == "/api/srt/purple-sequence":
            return self._send_json(handle_purple_sequence(content, rules))
        if path == "/api/srt/fix-repeat-2-3":
            return self._send_json(handle_fix_repeat_2_3(content))
        if path == "/api/srt/fix-repeat-4-5":
            return self._send_json(handle_fix_repeat_4_5(content))
        if path == "/api/srt/merge-short":
            return self._send_json(handle_merge_short(content))
        if path == "/api/srt/all-steps":
            return self._send_json(handle_all_steps(content, rules))
        if path == "/api/srt/uppercase":
            return self._send_json(handle_uppercase(content))
        if path == "/api/srt/save":
            filename = payload.get("filename", "edited.srt")
            try:
                return self._send_json(handle_save_srt(content, filename))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)
        if path == "/api/srt/split":
            s_per = int(payload.get("sentences_per_file", 10))
            base_n = payload.get("base_name", "subtitle")
            try:
                return self._send_json(handle_split_srt(content, s_per, base_n))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        return self._send_json({"detail": f"Endpoint POST '{path}' không tồn tại."}, 404)

class ThreadedColabHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

def start_web_server(host: str = "0.0.0.0", port: int = 8000, enable_tunnel: bool = True):
    """
    Khởi động KAGEVIETSUB Web Server & Cloudflare Tunnel.
    Entry point độc lập cho Google Colab và các môi trường Cloud.
    """
    ensure_directories()
    
    server_address = (host, port)
    httpd = ThreadedColabHTTPServer(server_address, ColabWebRequestHandler)
    
    logger.info(f"Web Server đang chạy trên http://{host}:{port}", module="SERVER", action="STARTED")

    server_thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    server_thread.start()

    tunnel = None
    if enable_tunnel:
        try:
            print("🚀 Đang khởi tạo Cloudflare Quick Tunnel cho Google Colab...")
            tunnel = CloudflareTunnel(port=port, host="127.0.0.1")
            public_url = tunnel.start()
            print_colab_banner(public_url, f"http://127.0.0.1:{port}")
        except Exception as e:
            logger.error(f"Không thể khởi động tunnel: {e}", module="TUNNEL", action="START_ERROR", exc=e)
            print(f"⚠️ Không thể khởi động Cloudflare Tunnel: {e}")
            print(f"👉 Local Web Server vẫn đang chạy tại http://127.0.0.1:{port}")
    else:
        print_colab_banner(f"http://127.0.0.1:{port}", f"http://127.0.0.1:{port}")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n🛑 Đang dừng KAGEVIETSUB Web Server...")
        if tunnel:
            tunnel.stop()
        httpd.shutdown()
        print("✅ Máy chủ đã dừng an toàn.")

if __name__ == "__main__":
    start_web_server()
