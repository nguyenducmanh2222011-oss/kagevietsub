# -*- coding: utf-8 -*-
"""
KAGEVIETSUB - Web Server Adapter Module (Google Colab & Web Access)
"""

from .tunnel import CloudflareTunnel
from .server import start_web_server

__all__ = ["CloudflareTunnel", "start_web_server"]
