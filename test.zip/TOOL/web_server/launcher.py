# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB - GOOGLE COLAB ENVIRONMENT LAUNCHER & INITIALIZER
==============================================================================
Tự động thiết lập môi trường trên Google Colab:
1. Tạo cấu trúc thư mục /content/KAGEVIETSUB/ (uploads, outputs, temp, logs, models)
2. Kiểm tra & cài đặt các gói cần thiết nếu thiếu
3. Khởi chạy Web Server & Cloudflare Tunnel
==============================================================================
"""

import os
import sys
import subprocess
from pathlib import Path

TOOL_DIR = Path(__file__).resolve().parent.parent
PROJECT_ROOT = TOOL_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
if str(TOOL_DIR) not in sys.path:
    sys.path.insert(0, str(TOOL_DIR))

# Đặt cờ môi trường Colab
os.environ["KAGEVIETSUB_ENV"] = "colab"

def setup_colab_directories():
    """Tạo cấu trúc thư mục /content/KAGEVIETSUB"""
    colab_root = Path("/content/KAGEVIETSUB")
    if Path("/content").exists():
        subdirs = ["uploads", "outputs", "temp", "logs", "models", "runtime"]
        for sd in subdirs:
            (colab_root / sd).mkdir(parents=True, exist_ok=True)
        print(f"📁 Đã tạo cấu trúc lưu trữ Colab tại: {colab_root}")

def main():
    print("==================================================")
    print("🚀 ĐANG KHỞI ĐỘNG KAGEVIETSUB TRÊN GOOGLE COLAB...")
    print("==================================================")
    setup_colab_directories()

    from TOOL.web_server.server import start_web_server
    # Khởi chạy server trên 0.0.0.0:8000 và bật Cloudflare Tunnel
    start_web_server(host="0.0.0.0", port=8000, enable_tunnel=True)

if __name__ == "__main__":
    main()
