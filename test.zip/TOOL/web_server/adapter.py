# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB - WEB SERVER ADAPTER & CONTROLLERS (GOOGLE COLAB / WEB UI)
==============================================================================
Tận dụng 100% services, logger, storage và engine hiện có của KAGEVIETSUB.
Xử lý:
- Generic Upload API (multipart/form-data an toàn, chống path traversal)
- Secure Download API (kiểm tra tồn tại, chống truy cập trái phép)
- Realtime Log Stream & Download Log API
==============================================================================
"""

import os
import sys
import uuid
import mimetypes
import datetime
from pathlib import Path
from typing import Dict, Any, Optional, Tuple, List

from TOOL.config import (
    PROJECT_ROOT, DATA_DIR, TEMP_DIR, OUTPUT_DIR, UPLOADS_DIR,
    KAGE_DOWNLOAD_DIR, is_safe_path, get_safe_unique_filepath
)
from TOOL.services.storage_service import StorageService
from TOOL.services.file_service import FileService
from TOOL.services.logger import logger as central_logger

logger = central_logger.get_module_logger("WEB_ADAPTER")

class WebServerAdapter:
    """
    Adapter kết nối Web UI / Google Colab với các Backend Services của KAGEVIETSUB.
    """

    @staticmethod
    def sanitize_filename(raw_name: str) -> str:
        """Làm sạch tên file, chống path traversal."""
        if not raw_name:
            return f"file_{uuid.uuid4().hex[:8]}.dat"
        # Bỏ toàn bộ thư mục cha / path traversal
        clean = Path(raw_name).name.replace("/", "_").replace("\\", "_")
        # Bỏ các ký tự đặc biệt nguy hiểm
        clean = "".join(c for c in clean if c.isalnum() or c in "._- ()[]+").strip()
        if not clean or clean.startswith("."):
            clean = f"upload_{uuid.uuid4().hex[:8]}{Path(raw_name).suffix or '.tmp'}"
        return clean

    @classmethod
    def save_uploaded_file(cls, file_bytes: bytes, filename: str) -> Dict[str, Any]:
        """
        Lưu file upload vào thư mục uploads (trên Colab là /content/KAGEVIETSUB/uploads).
        Kiểm tra tính toàn vẹn và trả về metadata chuẩn.
        """
        if not file_bytes:
            raise ValueError("Nội dung file rỗng (0 bytes).")

        clean_name = cls.sanitize_filename(filename)
        upload_dir = StorageService.get_upload_dir()
        upload_dir.mkdir(parents=True, exist_ok=True)

        file_id = uuid.uuid4().hex
        unique_name = f"{file_id[:8]}_{clean_name}"
        saved_path = upload_dir / unique_name

        with open(saved_path, "wb") as f:
            f.write(file_bytes)

        file_size = saved_path.stat().st_size
        ext = saved_path.suffix.lower()

        if ext in [".srt"]:
            file_type = "srt"
        elif ext in [".mp4", ".mkv", ".mov", ".avi", ".webm", ".flv", ".m4v"]:
            file_type = "video"
        elif ext in [".mp3", ".m4a", ".wav", ".aac", ".flac", ".ogg", ".opus", ".wma"]:
            file_type = "audio"
        else:
            file_type = "other"

        logger.info(
            f"Lưu file thành công: {clean_name} ({file_size} bytes) -> {saved_path}",
            module="UPLOAD",
            action="FILE_SAVED",
            file_id=file_id,
            size=file_size,
            file_type=file_type
        )

        return {
            "success": True,
            "file_id": file_id,
            "filename": clean_name,
            "saved_filename": unique_name,
            "saved_path": str(saved_path),
            "size": file_size,
            "file_type": file_type,
            "created_at": datetime.datetime.now().isoformat()
        }

    @classmethod
    def resolve_download_file(cls, identifier: str) -> Tuple[Path, str, str]:
        """
        Tìm kiếm file kết quả theo job_id, tên file hoặc đường dẫn một cách an toàn.
        Chống path traversal và kiểm tra file thực tế.
        """
        if not identifier:
            raise FileNotFoundError("Chưa chỉ định file cần tải.")

        identifier = identifier.strip()
        raw_name = Path(identifier).name
        
        # Danh sách các thư mục cho phép tìm kiếm file output
        search_dirs = [
            StorageService.get_output_dir(),
            OUTPUT_DIR,
            KAGE_DOWNLOAD_DIR,
            StorageService.get_temp_dir(),
            TEMP_DIR,
            StorageService.get_upload_dir(),
            UPLOADS_DIR,
            DATA_DIR / "logs",
            Path("/content/KAGEVIETSUB/outputs"),
            Path("/content/KAGEVIETSUB/temp"),
            Path("/content/KAGEVIETSUB/uploads"),
            PROJECT_ROOT / "outputs",
            PROJECT_ROOT / "output",
            Path.home() / "Downloads" / "KAGEVIETSUB",
            Path("/storage/emulated/0/Download/KAGEVIETSUB")
        ]

        target_file: Optional[Path] = None

        # 1. Kiểm tra xem identifier có phải là job_id không
        try:
            from TOOL.services.task_service import job_manager
            job = job_manager.get_job(identifier)
            if job:
                for k in ["saved_path", "output_path", "saved_location", "destination_path", "filename", "output_filename"]:
                    val = job.get(k)
                    if val:
                        p = Path(val)
                        if p.is_file() and is_safe_path(p):
                            target_file = p
                            break
                        p_name = p.name
                        for sdir in search_dirs:
                            cand = sdir / p_name
                            if cand.is_file() and is_safe_path(cand):
                                target_file = cand
                                break
                        if target_file:
                            break
        except Exception:
            pass

        if not target_file:
            try:
                from TOOL.downloader.manager import downloader_manager
                dj = downloader_manager.get_job(identifier)
                if dj:
                    for k in ["output_path", "destination_path", "filename", "output_filename"]:
                        val = dj.get(k)
                        if val:
                            p = Path(val)
                            if p.is_file() and is_safe_path(p):
                                target_file = p
                                break
                            p_name = p.name
                            for sdir in search_dirs:
                                cand = sdir / p_name
                                if cand.is_file() and is_safe_path(cand):
                                    target_file = cand
                                    break
                            if target_file:
                                break
            except Exception:
                pass

        # 2. Nếu truyền trực tiếp đường dẫn tuyệt đối hoặc tương đối
        if not target_file:
            cand_path = Path(identifier)
            if cand_path.is_absolute() and is_safe_path(cand_path) and cand_path.is_file():
                target_file = cand_path
            else:
                rel_cand = (PROJECT_ROOT / identifier).resolve()
                if is_safe_path(rel_cand) and rel_cand.is_file():
                    target_file = rel_cand

        # 3. Tìm tên file trong các thư mục hợp lệ
        if not target_file:
            for sdir in search_dirs:
                if not sdir.exists():
                    continue
                cand = sdir / raw_name
                if cand.exists() and cand.is_file() and is_safe_path(cand):
                    target_file = cand
                    break

        if not target_file or not target_file.exists() or not target_file.is_file():
            raise FileNotFoundError(f"File '{raw_name}' không tồn tại trên hệ thống hoặc đã bị dọn dẹp.")

        mime, _ = mimetypes.guess_type(str(target_file))
        if not mime:
            ext = target_file.suffix.lower()
            if ext == ".srt":
                mime = "text/plain; charset=utf-8"
            elif ext == ".mp4":
                mime = "video/mp4"
            elif ext == ".mp3":
                mime = "audio/mpeg"
            elif ext == ".wav":
                mime = "audio/wav"
            elif ext == ".zip":
                mime = "application/zip"
            elif ext == ".log":
                mime = "text/plain; charset=utf-8"
            else:
                mime = "application/octet-stream"

        return target_file, target_file.name, mime

    @classmethod
    def resolve_download_path(cls, identifier: str) -> Optional[Path]:
        """Trả về đối tượng Path tương ứng cho identifier (hoặc None nếu không tìm thấy)."""
        try:
            target, _, _ = cls.resolve_download_file(identifier)
            return target
        except Exception:
            return None

    @classmethod
    def get_realtime_logs(cls, lines: int = 150) -> Dict[str, Any]:
        """
        Đọc các dòng log thực tế từ CentralLogger của hệ thống (file YYYY-MM-DD.log).
        """
        try:
            active_log = central_logger._get_active_log_file()
            if not active_log.exists():
                return {
                    "success": True,
                    "log_file": active_log.name,
                    "lines_count": 0,
                    "logs": [],
                    "raw_text": ""
                }

            with open(active_log, "r", encoding="utf-8", errors="replace") as f:
                all_lines = f.readlines()

            selected_lines = all_lines[-lines:] if len(all_lines) > lines else all_lines
            raw_text = "".join(selected_lines)

            return {
                "success": True,
                "log_file": active_log.name,
                "lines_count": len(selected_lines),
                "total_lines": len(all_lines),
                "raw_text": raw_text,
                "updated_at": datetime.datetime.now().strftime("%H:%M:%S")
            }
        except Exception as e:
            logger.error(f"Lỗi đọc log: {e}", module="LOG", action="READ_ERROR", exc=e)
            return {
                "success": False,
                "error": str(e),
                "raw_text": f"[ERROR] Không thể đọc log: {e}"
            }

    @classmethod
    def get_log_download_path(cls) -> Tuple[Path, str]:
        """Trả về đường dẫn file log hiện tại để tải về."""
        active_log = central_logger._get_active_log_file()
        if not active_log.exists():
            active_log.touch()
        return active_log, f"kagevietsub_{active_log.name}"
