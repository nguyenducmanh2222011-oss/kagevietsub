# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB - CLOUDFLARE TUNNEL MANAGER (GOOGLE COLAB / LINUX / PC)
==============================================================================
Tự động thiết lập Cloudflare Tunnel tạo URL Public an toàn để truy cập Web UI.
==============================================================================
"""

import os
import sys
import time
import shutil
import platform
import subprocess
import threading
import re
import urllib.request
from pathlib import Path
from typing import Optional, Callable

from TOOL.config import PROJECT_ROOT, DATA_DIR
from TOOL.services.logger import logger as central_logger
logger = central_logger.get_module_logger("CLOUDFLARE_TUNNEL")

class CloudflareTunnel:
    """
    Quản lý khởi động và giám sát Cloudflare Quick Tunnel.
    Tự động tải binary cloudflared tương ứng nếu chưa có trong hệ thống.
    """

    def __init__(self, port: int = 8000, host: str = "127.0.0.1"):
        self.port = port
        self.host = host
        self.process: Optional[subprocess.Popen] = None
        self.public_url: Optional[str] = None
        self._stop_event = threading.Event()
        self._log_thread: Optional[threading.Thread] = None

    def _get_cloudflared_path(self) -> Path:
        """Xác định hoặc tải binary cloudflared."""
        # 1. Kiểm tra trong PATH hệ thống
        system_binary = shutil.which("cloudflared")
        if system_binary:
            return Path(system_binary)

        # 2. Kiểm tra trong các thư mục nội bộ
        candidates = [
            DATA_DIR / "bin" / "cloudflared",
            Path("/content") / "cloudflared" if Path("/content").exists() else None,
            PROJECT_ROOT / "TOOL" / "bin" / "cloudflared"
        ]
        for c in candidates:
            if c and c.exists() and os.access(str(c), os.X_OK):
                return c

        # 3. Tự động tải về nếu chưa có
        bin_dir = DATA_DIR / "bin"
        bin_dir.mkdir(parents=True, exist_ok=True)
        target_path = bin_dir / "cloudflared"

        arch = platform.machine().lower()
        system = platform.system().lower()

        if "windows" in system:
            target_path = bin_dir / "cloudflared.exe"
            url = "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe"
        elif "darwin" in system:
            url = "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-darwin-amd64.tgz"
        elif "aarch64" in arch or "arm64" in arch:
            url = "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm64"
        else:
            url = "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64"

        logger.info("TUNNEL", "DOWNLOADING_CLOUDFLARED", f"Tải cloudflared từ {url}...")
        try:
            req = urllib.request.Request(
                url,
                headers={"User-Agent": "KageVietSub-Colab-Downloader/1.0"}
            )
            with urllib.request.urlopen(req, timeout=60) as resp, open(target_path, "wb") as out_f:
                shutil.copyfileobj(resp, out_f)

            # Cấp quyền thực thi
            try:
                os.chmod(target_path, 0o755)
            except Exception:
                pass

            logger.info("TUNNEL", "DOWNLOAD_SUCCESS", f"Đã tải cloudflared vào {target_path}")
            return target_path
        except Exception as e:
            logger.error("TUNNEL", "DOWNLOAD_ERROR", f"Không thể tải cloudflared: {e}", exc=e)
            raise RuntimeError(f"Không thể tải cloudflared tự động: {e}")

    def start(self, timeout: int = 40) -> str:
        """Khởi chạy Cloudflare Quick Tunnel và chờ lấy Public URL."""
        if self.process is not None:
            return self.public_url or ""

        binary = self._get_cloudflared_path()
        cmd = [
            str(binary),
            "tunnel",
            "--url",
            f"http://{self.host}:{self.port}",
            "--metrics",
            "127.0.0.1:0",
            "--no-autoupdate"
        ]

        logger.info("TUNNEL", "STARTING", f"Khởi chạy lệnh: {' '.join(cmd)}")
        self.process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
            universal_newlines=True
        )

        url_found_event = threading.Event()

        def _monitor_output():
            pattern = re.compile(r"https://[a-zA-Z0-9-]+\.trycloudflare\.com")
            # cloudflared in thông tin tunnel vào stderr
            for line in iter(self.process.stderr.readline, ""):
                if self._stop_event.is_set():
                    break
                line_str = line.strip()
                if line_str:
                    logger.debug(f"[cloudflared] {line_str}")
                    match = pattern.search(line_str)
                    if match and not self.public_url:
                        self.public_url = match.group(0)
                        url_found_event.set()

            if self.process:
                self.process.poll()

        self._log_thread = threading.Thread(target=_monitor_output, daemon=True)
        self._log_thread.start()

        # Chờ URL xuất hiện
        ok = url_found_event.wait(timeout=timeout)
        if not ok or not self.public_url:
            self.stop()
            raise TimeoutError("Hết thời gian chờ tạo URL Cloudflare Tunnel (quá 40s).")

        logger.info("TUNNEL", "URL_READY", f"Public URL: {self.public_url}")
        return self.public_url

    def stop(self):
        """Dừng tunnel an toàn."""
        self._stop_event.set()
        if self.process:
            try:
                self.process.terminate()
                self.process.wait(timeout=3)
            except Exception:
                try:
                    self.process.kill()
                except Exception:
                    pass
            self.process = None
        logger.info("TUNNEL", "STOPPED", "Cloudflare Tunnel đã dừng.")

def print_colab_banner(url: str, local_url: str = "http://127.0.0.1:8000"):
    """In banner kết nối dành riêng cho Google Colab."""
    border = "=" * 48
    print("\n" + border)
    print("🎬 KAGEVIETSUB WEB SERVER (GOOGLE COLAB)")
    print(border)
    print("\nTrạng thái: ĐANG CHẠY (RUNNING)")
    print(f"\n🌐 ĐƯỜNG DẪN TRUY CẬP INTERNET (PUBLIC URL):")
    print(f"👉 {url}")
    print(f"\n📍 Local URL (trong Colab): {local_url}")
    print("\n" + border)
    print("Mẹo: Nhấp vào đường dẫn trên để mở giao diện KAGEVIETSUB.")
    print(border + "\n")
