import os
import sys
import json
from pathlib import Path
from typing import Optional

from TOOL.services.storage_service import StorageService

TOOL_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = TOOL_DIR.parent
DATA_DIR = StorageService.get_data_dir()
VERSION_FILE = PROJECT_ROOT / "version.json"

def get_local_version() -> str:
    """Đọc phiên bản hiện tại từ version.json ở thư mục gốc."""
    if VERSION_FILE.exists():
        try:
            with open(VERSION_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                return str(data.get("version", "1.0.0")).strip()
        except Exception:
            pass
    return "1.0.0"

TEMP_DIR = StorageService.get_temp_dir()
TASK_JOBS_DIR = TEMP_DIR / "task_jobs"
TASK_JOBS_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_DIR = StorageService.get_output_dir()
UPLOADS_DIR = StorageService.get_upload_dir()
MODELS_DIR = StorageService.get_models_dir()
LOGS_DIR = DATA_DIR / "logs"

WEB_DIR = TOOL_DIR / "web"

_env_host = os.getenv("KAGE_HOST", os.getenv("DSUB_HOST", "127.0.0.1"))
HOST = "127.0.0.1" if _env_host in ["0.0.0.0", "", None] else _env_host
PORT = int(os.getenv("PORT", os.getenv("KAGE_PORT", os.getenv("DSUB_PORT", "8000"))))

def get_kagevietsub_download_dir() -> Path:
    return StorageService.get_output_dir()

KAGE_DOWNLOAD_DIR = get_kagevietsub_download_dir()

def get_safe_unique_filepath(directory: Optional[Path], filename: str) -> Path:
    """
    Tạo đường dẫn file an toàn không bị ghi đè:
    video.mp4 -> video (1).mp4 -> video (2).mp4
    Chống path traversal (chỉ lấy filename sạch).
    """
    target_dir = (directory or StorageService.get_output_dir()).resolve()
    target_dir.mkdir(parents=True, exist_ok=True)
    safe_name = Path(filename).name.replace("/", "_").replace("\\", "_")
    p = Path(safe_name)
    stem = p.stem
    suffix = p.suffix

    candidate = target_dir / safe_name
    counter = 1
    while candidate.exists():
        candidate = target_dir / f"{stem} ({counter}){suffix}"
        counter += 1
    return candidate

def is_safe_path(target_path: Path) -> bool:
    """
    Kiểm tra bảo mật, chống ../ và path traversal ra ngoài các thư mục được phép.
    """
    try:
        resolved = target_path.resolve()
        allowed_roots = [
            DATA_DIR.resolve(),
            KAGE_DOWNLOAD_DIR.resolve(),
            PROJECT_ROOT.resolve()
        ]

        if Path("/content").exists():
            allowed_roots.append(Path("/content").resolve())
                                                                      
        android_storage = Path("/storage/emulated/0").resolve()
        if android_storage.exists():
            allowed_roots.append(android_storage)
        return any(str(resolved).startswith(str(root)) for root in allowed_roots)
    except Exception:
        return False

DEFAULT_WHISPER_MODEL = "large-v3-turbo"
DEFAULT_BEAM_SIZE = 5
DEFAULT_SPLIT_SENTENCE_MAX_WORDS = 20
DEFAULT_SPLIT_SENTENCE_MAX_DURATION = 6.0
DEFAULT_SILENCE_THRESHOLD = 0.3

def ensure_directories():
    """Tạo tất cả các thư mục cần thiết nếu chưa tồn tại. KHÔNG xóa dữ liệu cũ."""
    StorageService.ensure_all_directories()

ensure_directories()
