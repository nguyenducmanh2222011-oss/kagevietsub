#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB DOWNLOADER - PLATFORM & URL DETECTOR
==============================================================================
- Kiểm tra tính hợp lệ & an toàn của URL (chỉ http/https, chặn SSRF, path traversal)
- Nhận diện nền tảng: Bilibili, Douyin, TikTok, YouTube, hoặc nền tảng hỗ trợ chung
- Chặn tự động tải playlist / channel / collection tránh spam hàng trăm job
- Giải mã shortlink (v.douyin.com, b23.tv)
==============================================================================
"""

import ipaddress
import re
import urllib.parse
from typing import Tuple, Optional
import urllib.request
from TOOL.downloader.url_cleaner import (
    extract_urls,
    clean_and_normalize_url,
    detect_url_platform,
    LEADING_PUNCTUATION,
    TRAILING_PUNCTUATION
)

UNSAFE_HOSTS = {
    "localhost", "127.0.0.1", "0.0.0.0", "::1", "0.0.0.0:8000",
    "127.0.0.1:8000", "localhost:8000", "127.0.0.1:3000", "localhost:3000",
    "169.254.169.254", "metadata.google.internal", "instance-data"
}

def is_safe_url(url: str) -> Tuple[bool, str]:
    """
    Kiểm tra tính an toàn của URL:
    - Bắt buộc giao thức http hoặc https
    - Chặn file://, data://, javascript://, ssh://, ftp://
    - Chặn loopback, private network và cloud metadata nguy hiểm (chống SSRF)
    """
    if not url or not isinstance(url, str):
        return False, "URL rỗng."

    url = url.strip()
    if not (url.startswith("http://") or url.startswith("https://")):
        return False, "❌ Chỉ cho phép giao thức http:// hoặc https://"

    try:
        parsed = urllib.parse.urlparse(url)
        hostname = (parsed.hostname or "").lower().strip()

        if not hostname:
            return False, "❌ URL không có tên miền hợp lệ."

        if hostname in UNSAFE_HOSTS:
            return False, "❌ Không cho phép truy cập địa chỉ nội bộ / localhost / metadata."

        if hostname.endswith(".local") or hostname.endswith(".internal") or hostname.endswith(".localhost"):
            return False, "❌ Không cho phép truy cập tên miền mạng nội bộ."

        # Kiểm tra IP trực tiếp (IPv4 / IPv6)
        try:
            ip_obj = ipaddress.ip_address(hostname)
            if ip_obj.is_private or ip_obj.is_loopback or ip_obj.is_link_local or ip_obj.is_reserved or ip_obj.is_multicast:
                return False, f"❌ Không cho phép truy cập địa chỉ IP nội bộ ({hostname})."
        except ValueError:
            # Là domain name bình thường, không phải raw IP
            pass

        return True, ""
    except Exception as e:
        return False, f"❌ URL không hợp lệ: {str(e)}"

def normalize_url(url: str) -> str:
    """
    Chuẩn hóa URL an toàn:
    - Loại bỏ whitespace thừa và ký tự bao quanh
    - Trích xuất URL http/https sạch
    - Bảo toàn 100% path, query parameters và fragments
    """
    return clean_and_normalize_url(url)

def detect_platform(url: str) -> str:
    """
    Nhận diện nền tảng từ URL:
    - bilibili (bilibili.com, b23.tv)
    - douyin (douyin.com, iesdouyin.com, v.douyin.com)
    - tiktok (tiktok.com)
    - youtube (youtube.com, youtu.be)
    - general (các nền tảng khác mà yt-dlp hỗ trợ)
    - unsupported (nếu không phải URL hợp lệ)
    """
    return detect_url_platform(url)

def is_playlist_or_multi_video(url: str) -> Tuple[bool, str]:
    """
    Kiểm tra xem URL có phải là danh sách phát, kênh, hoặc trang cá nhân không.
    Trả về (True, Cảnh báo) nếu là playlist/channel.
    """
    url_lower = url.lower()

    if "space.bilibili.com" in url_lower or "/favlist" in url_lower or "/channel" in url_lower or "/series" in url_lower:
        return True, "⚠ URL chứa nhiều video (kênh/danh sách). Vui lòng nhập URL video cụ thể."

    if "/user/" in url_lower or "/collection/" in url_lower or "/mix/" in url_lower:
        return True, "⚠ URL chứa nhiều video (trang cá nhân/bộ sưu tập). Vui lòng nhập URL video cụ thể."

    if "playlist?list=" in url_lower or "/channel/" in url_lower or "/c/" in url_lower or "/user/" in url_lower:
        return True, "⚠ URL chứa nhiều video (playlist/kênh). Vui lòng nhập URL video cụ thể."

    return False, ""

def resolve_redirect_url(url: str, timeout: float = 8.0) -> str:
    """
    Giải mã URL rút gọn (như v.douyin.com, b23.tv, youtu.be) bằng cách theo dõi redirect HTTP.
    """
    if not url:
        return ""
    try:
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        }
        if "b23.tv" in url or "bilibili" in url:
            headers["Referer"] = "https://www.bilibili.com/"
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            resolved = resp.geturl()
            return resolved or url
    except Exception:
        return url
