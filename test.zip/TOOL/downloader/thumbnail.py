#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB DOWNLOADER - THUMBNAIL DOWNLOADER
==============================================================================
Tải và xác thực ảnh bìa (thumbnail) độc lập:
- Tải qua URL trực tiếp hoặc yt-dlp
- Lưu file an toàn (.jpg / .webp / .png)
- Đảm bảo nếu tải thumbnail lỗi thì KHÔNG làm hỏng trạng thái COMPLETED của video chính
==============================================================================
"""

import os
import shutil
import urllib.request
import logging
from pathlib import Path
from typing import Optional, Tuple
from TOOL.downloader.verifier import verify_thumbnail

logger = logging.getLogger("downloader.thumbnail")

def download_thumbnail_direct(thumbnail_url: str, output_path: Path, timeout: float = 10.0) -> Tuple[bool, str]:
    """
    Tải trực tiếp ảnh thumbnail từ URL.
    """
    if not thumbnail_url:
        return False, "Không có URL thumbnail."

    try:
        req = urllib.request.Request(
            thumbnail_url,
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "Referer": thumbnail_url
            }
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            content = resp.read()
            if len(content) <= 0:
                return False, "Nội dung thumbnail rỗng (0 KB)."

            output_path.parent.mkdir(parents=True, exist_ok=True)
            with open(output_path, "wb") as f:
                f.write(content)

        is_valid, msg = verify_thumbnail(output_path)
        return is_valid, msg
    except Exception as e:
        logger.warning(f"Không thể tải thumbnail từ {thumbnail_url}: {e}")
        return False, str(e)
