#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB DOWNLOADER - URL CLEANER & EXTRACTOR MODULE
==============================================================================
Tự động trích xuất, làm sạch, chuẩn hóa và xác thực URL từ văn bản thô
trước khi đưa vào pipeline tải video (yt-dlp, metadata, download worker).
==============================================================================
"""

import re
import urllib.parse
from typing import List, Dict, Any, Tuple, Optional

LEADING_PUNCTUATION = "([{'\"<（【「『《“‘"
TRAILING_PUNCTUATION = ".,;:!?)]}'\">，。；：！？）】」』》”’"

URL_PATTERN = re.compile(
    r'https?://[^\s<>\"\'`\[\]\(\)\{\}【】「」『』《》]+',
    re.IGNORECASE
)

PLATFORM_DOMAINS = {
    "bilibili": ["bilibili.com", "b23.tv"],
    "douyin": ["douyin.com", "iesdouyin.com"],
    "tiktok": ["tiktok.com"],
    "youtube": ["youtube.com", "youtu.be"],
    "general": [
        "kuaishou.com", "weibo.com", "facebook.com", "fb.watch",
        "instagram.com", "x.com", "twitter.com", "vimeo.com"
    ]
}

def extract_urls(text: str) -> List[str]:
    """
    Trích xuất toàn bộ URL http:// và https:// từ một đoạn văn bản thô:
    - Tìm tất cả URL http/https bất kể vị trí trong dòng.
    - Không lấy phần title hoặc ký tự trước/sau URL.
    - Loại bỏ dấu ngoặc, dấu ngoặc kép, dấu chấm, dấu phẩy bao quanh URL.
    - Giữ nguyên query string (?key=value...) và fragment (#...).
    - Không tự ý sửa path/query của URL.
    - Từ chối các scheme không an toàn (file://, data:, javascript:, ftp://).
    """
    if not text or not isinstance(text, str):
        return []

    matches = URL_PATTERN.findall(text)
    cleaned_urls: List[str] = []

    for match in matches:
        url = match.strip()
                                                          
        url = url.lstrip(LEADING_PUNCTUATION)
        url = url.rstrip(TRAILING_PUNCTUATION)

        if not (url.startswith("http://") or url.startswith("https://")):
            continue

        try:
            parsed = urllib.parse.urlparse(url)
                                      
            if parsed.hostname:
                cleaned_urls.append(url)
        except Exception:
            continue

    return cleaned_urls

def clean_and_normalize_url(url: str) -> str:
    """
    Chuẩn hóa URL an toàn:
    - Loại bỏ whitespace thừa và dấu câu bao quanh.
    - Chuẩn hóa scheme/hostname về chữ thường.
    - Giữ nguyên path, query string, và fragment.
    """
    if not url or not isinstance(url, str):
        return ""

    url = url.strip()
    url = url.lstrip(LEADING_PUNCTUATION).rstrip(TRAILING_PUNCTUATION)

    extracted = extract_urls(url)
    if extracted:
        url = extracted[0]

    try:
        parsed = urllib.parse.urlparse(url)
        if not parsed.scheme or not parsed.hostname:
            return url

        scheme = parsed.scheme.lower()
        netloc = parsed.netloc.lower()

        normalized = urllib.parse.urlunparse((
            scheme,
            netloc,
            parsed.path,
            parsed.params,
            parsed.query,
            parsed.fragment
        ))
        return normalized
    except Exception:
        return url

def detect_url_platform(url: str) -> str:
    """
    Nhận diện nền tảng từ URL:
    - bilibili (bilibili.com, b23.tv)
    - douyin (douyin.com, iesdouyin.com)
    - tiktok (tiktok.com)
    - youtube (youtube.com, youtu.be)
    - general (các nền tảng được hỗ trợ khác)
    - unsupported (nếu domain không hợp lệ)
    """
    if not url:
        return "unsupported"

    try:
        parsed = urllib.parse.urlparse(url.lower())
        hostname = (parsed.hostname or "").lower()
    except Exception:
        hostname = url.lower()

    if not hostname:
        return "unsupported"

    for platform, domains in PLATFORM_DOMAINS.items():
        if any(d == hostname or hostname.endswith("." + d) for d in domains):
            return platform

    if "." in hostname and not hostname.endswith("."):
        return "general"

    return "unsupported"

def process_raw_inputs(raw_inputs: List[str]) -> Tuple[List[Dict[str, Any]], List[str]]:
    """
    Pipeline xử lý toàn bộ danh sách input từ người dùng:
    RAW INPUT -> URL EXTRACTOR -> URL CLEANER -> VALIDATION -> DEDUPLICATION -> PLATFORM DETECTOR

    Trả về:
    - processed_details: Danh sách chi tiết cho từng dòng/URL (original, url, valid, platform, error)
    - unique_valid_urls: Danh sách các URL sạch, hợp lệ, đã loại trùng lặp theo thứ tự xuất hiện
    """
    from TOOL.downloader.detector import is_safe_url, is_playlist_or_multi_video

    processed_details: List[Dict[str, Any]] = []
    unique_valid_urls: List[str] = []
    seen_urls = set()

    for raw_line in raw_inputs:
        line_str = str(raw_line).strip() if raw_line is not None else ""
        if not line_str:
            continue

        extracted = extract_urls(line_str)

        if not extracted:
                                        
            processed_details.append({
                "original": line_str,
                "url": "",
                "valid": False,
                "platform": "unsupported",
                "error": "INVALID_URL"
            })
            continue

        for ext_url in extracted:
            clean_url = clean_and_normalize_url(ext_url)
            is_safe, safe_msg = is_safe_url(clean_url)
            platform = detect_url_platform(clean_url)

            if not is_safe:
                processed_details.append({
                    "original": line_str,
                    "url": clean_url,
                    "valid": False,
                    "platform": platform,
                    "error": safe_msg or "INVALID_URL"
                })
                continue

            is_multi, multi_msg = is_playlist_or_multi_video(clean_url)
            error_msg = multi_msg if is_multi else None

            processed_details.append({
                "original": line_str,
                "url": clean_url,
                "valid": not is_multi,
                "platform": platform,
                "error": error_msg
            })

            if clean_url not in seen_urls:
                seen_urls.add(clean_url)
                if not is_multi:
                    unique_valid_urls.append(clean_url)

    return processed_details, unique_valid_urls
