#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB DOWNLOADER - API CONTROLLER
==============================================================================
Cung cấp toàn bộ các API endpoint xử lý tác vụ tải:
- POST /api/downloader/check-links
- POST /api/downloader/info
- POST /api/downloader/start
- POST /api/downloader/update
- GET  /api/downloader/status
- GET  /api/downloader/status/<job_id>
- POST /api/downloader/cancel/<job_id>
- POST /api/downloader/cancel-all
- POST /api/downloader/retry/<job_id>
- POST /api/downloader/remove/<job_id>
- GET  /api/downloader/ready
==============================================================================
"""

import shutil
from typing import Dict, Any, List, Optional, Tuple
from TOOL.downloader.manager import downloader_manager
from TOOL.downloader.ytdlp_engine import find_ytdlp_executable, extract_metadata
from TOOL.downloader.detector import is_safe_url, normalize_url, is_playlist_or_multi_video, resolve_redirect_url
from TOOL.downloader.url_cleaner import process_raw_inputs, clean_and_normalize_url

def handle_downloader_ready() -> Dict[str, Any]:
    """Kiểm tra tính sẵn sàng của các thành phần Downloader."""
    ytdlp_cmd = find_ytdlp_executable()
    ffmpeg_bin = shutil.which("ffmpeg")
    ffprobe_bin = shutil.which("ffprobe")

    missing = []
    if not ytdlp_cmd:
        missing.append("yt-dlp")
    if not ffmpeg_bin:
        missing.append("FFmpeg")
    if not ffprobe_bin:
        missing.append("FFprobe")

    is_ready = len(missing) == 0
    return {
        "ready": is_ready,
        "missing": missing,
        "message": "Downloader đã sẵn sàng." if is_ready else f"❌ Downloader chưa sẵn sàng. Thiếu: {', '.join(missing)}",
        "ytdlp_available": ytdlp_cmd is not None,
        "ffmpeg_available": ffmpeg_bin is not None,
        "ffprobe_available": ffprobe_bin is not None
    }

def handle_check_links(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Phân tích các URL từ văn bản người dùng nhập:
    - Trích xuất URL sạch khỏi tiêu đề và ký tự bao quanh
    - Xác thực bảo mật và nhận diện nền tảng
    - Loại bỏ trùng lặp và giữ thứ tự xuất hiện
    - Trả về danh sách chi tiết các URL kèm job được khởi tạo
    """
    raw_urls: List[str] = []
    if "urls" in payload and isinstance(payload["urls"], list):
        raw_urls = [str(u) for u in payload["urls"]]
    elif "links" in payload and isinstance(payload["links"], list):
        raw_urls = [str(u) for u in payload["links"]]
    elif "text" in payload and isinstance(payload["text"], str):
        raw_urls = payload["text"].split("\n")
    elif "url" in payload and isinstance(payload["url"], str):
        raw_urls = [payload["url"]]

    url_details, _ = process_raw_inputs(raw_urls)
    default_opts = {
        "format": payload.get("default_format") or payload.get("format") or "MP4",
        "resolution": payload.get("default_resolution") or payload.get("resolution") or "Auto",
        "download_thumbnail": bool(payload.get("download_thumbnail") if "download_thumbnail" in payload else payload.get("default_thumb", False))
    }
    created_jobs = downloader_manager.check_links(raw_urls, default_opts)

    return {
        "success": True,
        "count": len(created_jobs),
        "jobs": created_jobs,
        "urls": url_details
    }

def handle_get_info(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Trích xuất metadata của 1 URL mà không tạo job."""
    raw_url = (payload.get("url") or "").strip()
    if not raw_url:
        return {"success": False, "error": "URL rỗng."}

    norm_url = clean_and_normalize_url(raw_url)
    if not norm_url:
        return {"success": False, "error": "Không tìm thấy URL hợp lệ trong văn bản."}

    is_safe, msg = is_safe_url(norm_url)
    if not is_safe:
        return {"success": False, "error": msg}

    is_multi, multi_msg = is_playlist_or_multi_video(norm_url)
    if is_multi:
        return {"success": False, "error": multi_msg}

    expanded = resolve_redirect_url(norm_url)
    success, meta, err = extract_metadata(expanded)
    if not success:
        return {"success": False, "error": err}

    return {"success": True, "metadata": meta, "clean_url": norm_url}

def handle_start_download(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Bắt đầu tải một hoặc nhiều job."""
    job_id = payload.get("job_id")
    job_ids = payload.get("job_ids")

    if job_id:
        opts = {
            "format": payload.get("format"),
            "resolution": payload.get("resolution"),
            "download_thumbnail": payload.get("download_thumbnail")
        }
        success = downloader_manager.start_job(job_id, opts)
        return {"success": success, "job_id": job_id}

    if job_ids and isinstance(job_ids, list):
        started_count = 0
        for jid in job_ids:
            if downloader_manager.start_job(jid):
                started_count += 1
        return {"success": True, "started_count": started_count}

    started_count = downloader_manager.start_all_ready_jobs()
    return {"success": True, "started_count": started_count}

def handle_update_job(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Cập nhật tùy chọn định dạng, độ phân giải, thumbnail của job."""
    job_id = payload.get("job_id", "")
    fmt = payload.get("format")
    res = payload.get("resolution")
    thumb = payload.get("download_thumbnail")

    job = downloader_manager.update_job_options(job_id, fmt, res, thumb)
    if not job:
        return {"success": False, "error": f"Không tìm thấy job '{job_id}'"}
    return {"success": True, "job": job}

def handle_get_status(job_id: Optional[str] = None) -> Dict[str, Any]:
    """Lấy trạng thái của 1 job hoặc toàn bộ danh sách job."""
    if job_id:
        job = downloader_manager.get_job(job_id)
        if not job:
            return {"success": False, "error": f"Không tìm thấy job '{job_id}'"}
        return {"success": True, "job": job}

    return {
        "success": True,
        "jobs": downloader_manager.list_jobs()
    }

def handle_cancel_job(job_id: str) -> Dict[str, Any]:
    """Hủy một job."""
    if not job_id:
        return {"success": False, "error": "Thiếu job_id."}
    success = downloader_manager.cancel_job(job_id)
    return {"success": success, "job_id": job_id}

def handle_cancel_all() -> Dict[str, Any]:
    """Hủy tất cả các job đang tải."""
    downloader_manager.cancel_all()
    return {"success": True, "message": "Đã dừng tất cả các tác vụ tải."}

def handle_retry_job(job_id: str, payload: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Thử lại một job bị lỗi hoặc đã hủy."""
    if not job_id:
        return {"success": False, "error": "Thiếu job_id."}
    opts = payload if payload else None
    success = downloader_manager.retry_job(job_id, opts)
    return {"success": success, "job_id": job_id}

def handle_remove_job(job_id: str) -> Dict[str, Any]:
    """Xóa một job khỏi danh sách."""
    if not job_id:
        return {"success": False, "error": "Thiếu job_id."}
    success = downloader_manager.remove_job(job_id)
    return {"success": success, "job_id": job_id}

def handle_downloader_download_file(job_id: str, file_type: str = "media") -> Tuple[Any, str, str]:
    """
    Xác định đường dẫn file tải về thiết bị người dùng (media, thumbnail hoặc log)
    Trả về (Path, filename, mime_type).
    """
    from pathlib import Path
    import mimetypes

    job = downloader_manager.get_job(job_id)
    if not job:
        raise FileNotFoundError(f"Không tìm thấy job tải '{job_id}'.")

    job_dir = downloader_manager._get_job_dir(job_id)

    if file_type == "thumbnail":
        thumb_p_str = job.get("thumbnail_path")
        thumb_p = Path(thumb_p_str) if thumb_p_str else job_dir / "thumbnail.jpg"
        if thumb_p and thumb_p.exists() and thumb_p.is_file():
            return thumb_p, thumb_p.name, "image/jpeg"
        raise FileNotFoundError(f"Job '{job_id}' không có file thumbnail.")

    if file_type == "log":
        log_p = job_dir / "job.log"
        if log_p.exists() and log_p.is_file():
            return log_p, f"job_{job_id[:8]}.log", "text/plain; charset=utf-8"
        raise FileNotFoundError(f"Chưa có nhật ký tải cho job '{job_id}'.")

    # Mặc định file media (MP4 / MP3)
    out_p_str = job.get("output_path") or job.get("destination_path")
    if out_p_str:
        out_p = Path(out_p_str)
        if out_p.exists() and out_p.is_file():
            mime, _ = mimetypes.guess_type(str(out_p))
            if not mime:
                mime = "audio/mpeg" if out_p.suffix.lower() == ".mp3" else "video/mp4"
            return out_p, out_p.name, mime

    # Thử tìm trong job_dir nếu chưa di chuyển xong
    for candidate in job_dir.glob("media_output.*"):
        if candidate.is_file() and not candidate.name.endswith(".part") and not candidate.name.endswith(".ytdl"):
            mime, _ = mimetypes.guess_type(str(candidate))
            if not mime:
                mime = "audio/mpeg" if candidate.suffix.lower() == ".mp3" else "video/mp4"
            return candidate, candidate.name, mime

    raise FileNotFoundError(f"Chưa có file media hoàn chỉnh cho job '{job_id}'.")
