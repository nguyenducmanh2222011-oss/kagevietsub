#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB DOWNLOADER - BATCH TASK MANAGER & DOWNLOAD ENGINE
==============================================================================
- Quản lý vòng đời tác vụ tải đa luồng (Job Isolation):
  QUEUED -> CHECKING -> READY -> DOWNLOADING -> MERGING -> VERIFYING -> COMPLETED / ERROR / CANCELLED
- Quản lý tiến trình độc lập (subprocess.Popen) cho từng job
- Xử lý atomic save sang Download/KAGEVIETSUB/
- Lưu trữ trạng thái bền vững (DATA/temp/downloader/jobs/<job_id>/job.json)
- Tự động dọn dẹp file tạm, KHÔNG BAO GIỜ xóa thư mục Download/KAGEVIETSUB
==============================================================================
"""

import os
import re
import sys
import time
import json
import uuid
import shutil
import logging
import threading
import subprocess
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple

from TOOL.config import DATA_DIR, TEMP_DIR, KAGE_DOWNLOAD_DIR, get_safe_unique_filepath
from TOOL.downloader.detector import is_safe_url, normalize_url, detect_platform, is_playlist_or_multi_video, resolve_redirect_url
from TOOL.downloader.url_cleaner import process_raw_inputs, clean_and_normalize_url
from TOOL.downloader.ytdlp_engine import find_ytdlp_executable, extract_metadata, parse_ytdlp_progress_line
from TOOL.downloader.verifier import verify_mp4, verify_mp3
from TOOL.downloader.thumbnail import download_thumbnail_direct
from TOOL.services.logger import logger as central_logger

logger = central_logger.get_module_logger("DOWNLOADER")

DOWNLOADER_TEMP_DIR = TEMP_DIR / "downloader"
DOWNLOADER_JOBS_DIR = DOWNLOADER_TEMP_DIR / "jobs"
DOWNLOADER_TEMP_DIR.mkdir(parents=True, exist_ok=True)
DOWNLOADER_JOBS_DIR.mkdir(parents=True, exist_ok=True)

class DownloaderJobState:
    QUEUED = "QUEUED"
    CHECKING = "CHECKING"
    READY = "READY"
    DOWNLOADING = "DOWNLOADING"
    MERGING = "MERGING"
    VERIFYING = "VERIFYING"
    COMPLETED = "COMPLETED"
    ERROR = "ERROR"
    CANCELLED = "CANCELLED"

class DownloaderManager:
    """Singleton quản lý toàn bộ các tác vụ tải video KAGEVIETSUB Downloader."""
    _instance = None
    _lock = threading.RLock()

    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super(DownloaderManager, cls).__new__(cls)
                cls._instance._initialized = False
            return cls._instance

    def __init__(self):
        if self._initialized:
            return
        with self._lock:
            self.jobs: Dict[str, Dict[str, Any]] = {}
            self.running_processes: Dict[str, subprocess.Popen] = {}
            self.cancel_events: Dict[str, threading.Event] = {}
            self.max_concurrent_jobs: int = 2
            self.work_queue: List[str] = []
            self.active_workers: int = 0
            self.queue_condition = threading.Condition()
            self._is_shutting_down = False
            self._load_persisted_jobs()
            
            for i in range(self.max_concurrent_jobs):
                t = threading.Thread(target=self._worker_loop, name=f"DownloaderWorker-{i+1}", daemon=True)
                t.start()

            self._initialized = True
            logger.info("DownloaderManager khởi tạo thành công.")

    def _get_job_dir(self, job_id: str) -> Path:
        p = DOWNLOADER_JOBS_DIR / job_id
        p.mkdir(parents=True, exist_ok=True)
        return p

    def _persist_job(self, job_id: str):
        """Lưu trữ metadata của job xuống disk JSON."""
        try:
            job = self.jobs.get(job_id)
            if not job:
                return
            job_file = self._get_job_dir(job_id) / "job.json"
                                                                       
            save_data = {k: v for k, v in job.items() if not k.startswith("_")}
            with open(job_file, "w", encoding="utf-8") as f:
                json.dump(save_data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"Lỗi khi lưu trạng thái job {job_id}: {e}")

    def _load_persisted_jobs(self):
        """Đọc lại các job đã lưu từ phiên trước."""
        try:
            if not DOWNLOADER_JOBS_DIR.exists():
                return
            for job_dir in DOWNLOADER_JOBS_DIR.iterdir():
                if job_dir.is_dir():
                    job_file = job_dir / "job.json"
                    if job_file.exists():
                        try:
                            with open(job_file, "r", encoding="utf-8") as f:
                                data = json.load(f)
                                jid = data.get("id")
                                if jid:
                                                                                                                    
                                    if data.get("status") in [DownloaderJobState.DOWNLOADING, DownloaderJobState.CHECKING, DownloaderJobState.MERGING]:
                                        data["status"] = DownloaderJobState.READY
                                        data["progress"] = 0.0
                                    self.jobs[jid] = data
                        except Exception:
                            pass
        except Exception as e:
            logger.error(f"Lỗi tải job đã lưu: {e}")

    def _format_job_dict(self, job: Dict[str, Any]) -> Dict[str, Any]:
        """Chuẩn hóa dữ liệu job, đảm bảo tương thích 100% với cả frontend cũ và mới."""
        job_id = job.get("id") or job.get("job_id") or ""
        url = job.get("url") or job.get("raw_url") or job.get("original_url") or ""
        thumb = job.get("thumbnail") or job.get("thumbnail_url") or ""
        fmt = job.get("selected_format") or job.get("format") or "MP4"
        res = job.get("selected_resolution") or job.get("resolution") or "Auto"
        prog = float(job.get("progress") if job.get("progress") is not None else (job.get("progress_percent") or 0.0))
        err = job.get("error") or job.get("error_message") or None
        out_path = job.get("output_path") or job.get("destination_path") or ""

        return {
            "id": job_id,
            "job_id": job_id,
            "url": url,
            "raw_url": url,
            "original_url": url,
            "platform": job.get("platform", "general"),
            "title": job.get("title", "Video"),
            "thumbnail": thumb,
            "thumbnail_url": thumb,
            "duration": job.get("duration", 0),
            "duration_formatted": job.get("duration_formatted", "00:00"),
            "selected_format": fmt,
            "format": fmt,
            "selected_resolution": res,
            "resolution": res,
            "available_resolutions": job.get("available_resolutions") or ["Auto"],
            "download_thumbnail": bool(job.get("download_thumbnail", False)),
            "status": job.get("status", DownloaderJobState.QUEUED),
            "progress": prog,
            "progress_percent": prog,
            "speed": job.get("speed", ""),
            "speed_str": job.get("speed", ""),
            "speed_bytes": 0,
            "eta": job.get("eta", ""),
            "eta_seconds": 0,
            "total_size": job.get("total_size", ""),
            "downloaded_size": job.get("downloaded_size", ""),
            "total_bytes": 0,
            "downloaded_bytes": 0,
            "error": err,
            "error_message": err,
            "output_filename": job.get("output_filename", ""),
            "output_path": out_path,
            "destination_path": out_path,
            "thumbnail_path": job.get("thumbnail_path", ""),
            "created_at": job.get("created_at", time.time()),
            "completed_at": job.get("completed_at"),
            "retry_count": job.get("retry_count", 0),
            "auto_start": bool(job.get("auto_start", False))
        }

    def check_links(self, raw_urls: List[str], default_options: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Nhận danh sách URL từ người dùng, làm sạch qua URL Cleaner, validate,
        loại bỏ trùng lặp và tạo các job ở trạng thái CHECKING/READY kèm metadata.
        """
        created_jobs = []
        seen_urls = set()

        opts = default_options or {}
        default_fmt = (opts.get("format") or opts.get("default_format") or "MP4").upper()
        if default_fmt not in ["MP4", "MP3"]:
            default_fmt = "MP4"
        default_res = opts.get("resolution") or opts.get("default_resolution") or "Auto"
        default_thumb = bool(opts.get("download_thumbnail") if "download_thumbnail" in opts else opts.get("default_thumb", False))

        _, unique_clean_urls = process_raw_inputs(raw_urls)

        for clean_url in unique_clean_urls:
            if clean_url in seen_urls:
                continue
            seen_urls.add(clean_url)

            job_id = f"dl_{uuid.uuid4().hex[:10]}"
            is_safe, safe_msg = is_safe_url(clean_url)
            is_multi, multi_msg = is_playlist_or_multi_video(clean_url)
            
            resolved_url = resolve_redirect_url(clean_url) if is_safe else clean_url
            platform = detect_platform(resolved_url)

            job: Dict[str, Any] = {
                "id": job_id,
                "job_id": job_id,
                "url": resolved_url,
                "raw_url": clean_url,
                "original_url": clean_url,
                "platform": platform,
                "title": "Đang kiểm tra thông tin...",
                "thumbnail": "",
                "thumbnail_url": "",
                "duration": 0,
                "duration_formatted": "00:00",
                "selected_format": default_fmt,
                "format": default_fmt,
                "selected_resolution": default_res,
                "resolution": default_res,
                "available_resolutions": ["Auto"],
                "download_thumbnail": default_thumb,
                "status": DownloaderJobState.CHECKING,
                "progress": 0.0,
                "progress_percent": 0.0,
                "speed": "",
                "speed_str": "",
                "eta": "",
                "total_size": "",
                "downloaded_size": "",
                "error": None,
                "error_message": None,
                "output_filename": "",
                "output_path": "",
                "destination_path": "",
                "thumbnail_path": "",
                "created_at": time.time(),
                "completed_at": None,
                "retry_count": 0,
                "auto_start": False
            }

            if not is_safe:
                job["status"] = DownloaderJobState.ERROR
                job["error"] = safe_msg
                job["error_message"] = safe_msg
                job["title"] = "Liên kết không hợp lệ"
            elif is_multi:
                job["status"] = DownloaderJobState.ERROR
                job["error"] = multi_msg
                job["error_message"] = multi_msg
                job["title"] = "URL chứa danh sách phát"

            with self._lock:
                self.jobs[job_id] = job
                self._persist_job(job_id)

            if is_safe and not is_multi:
                threading.Thread(target=self._fetch_metadata_async, args=(job_id,), daemon=True).start()

            created_jobs.append(self._format_job_dict(job))

        return created_jobs

    def _fetch_metadata_async(self, job_id: str):
        """Lấy metadata chi tiết (title, thumbnail, available_resolutions) bất đồng bộ."""
        with self._lock:
            job = self.jobs.get(job_id)
            if not job:
                return
            url = job["url"]

        expanded_url = resolve_redirect_url(url)

        success, meta, err = extract_metadata(expanded_url)
        should_auto_start = False

        with self._lock:
            job = self.jobs.get(job_id)
            if not job:
                return

            if success:
                job["title"] = meta.get("title") or "Video"
                job["thumbnail"] = meta.get("thumbnail") or ""
                job["thumbnail_url"] = job["thumbnail"]
                job["duration"] = meta.get("duration") or 0
                job["duration_formatted"] = meta.get("duration_formatted") or "00:00"
                job["available_resolutions"] = meta.get("available_resolutions") or ["Auto"]
                job["status"] = DownloaderJobState.READY
                job["error"] = None
                job["error_message"] = None
                if job.get("auto_start"):
                    should_auto_start = True
            else:
                job["status"] = DownloaderJobState.ERROR
                job["error"] = err or "Không thể lấy thông tin video."
                job["error_message"] = job["error"]
                job["title"] = "Lỗi nạp thông tin"

            self._persist_job(job_id)

        if should_auto_start:
            self.start_job(job_id)

    def update_job_options(self, job_id: str, format_type: Optional[str] = None, resolution: Optional[str] = None, download_thumbnail: Optional[bool] = None) -> Optional[Dict[str, Any]]:
        """Cập nhật tùy chọn tải cho từng video/job trước khi bấm Tải."""
        with self._lock:
            job = self.jobs.get(job_id)
            if not job:
                return None
            if format_type in ["MP4", "MP3"]:
                job["selected_format"] = format_type
                job["format"] = format_type
            if resolution:
                job["selected_resolution"] = resolution
                job["resolution"] = resolution
            if download_thumbnail is not None:
                job["download_thumbnail"] = bool(download_thumbnail)
            self._persist_job(job_id)
            return self._format_job_dict(job)

    def start_job(self, job_id: str, options: Optional[Dict[str, Any]] = None) -> bool:
        """Đưa một job vào hàng đợi tải (QUEUED)."""
        with self._lock:
            job = self.jobs.get(job_id)
            if not job:
                return False

            if options:
                if "format" in options and options["format"] in ["MP4", "MP3"]:
                    job["selected_format"] = options["format"]
                    job["format"] = options["format"]
                if "resolution" in options and options["resolution"]:
                    job["selected_resolution"] = options["resolution"]
                    job["resolution"] = options["resolution"]
                if "download_thumbnail" in options:
                    job["download_thumbnail"] = bool(options["download_thumbnail"])

            if job["status"] in [DownloaderJobState.DOWNLOADING, DownloaderJobState.MERGING, DownloaderJobState.VERIFYING]:
                return True

            job["status"] = DownloaderJobState.QUEUED
            job["error"] = None
            job["error_message"] = None
            job["progress"] = 0.0
            job["progress_percent"] = 0.0
            job["speed"] = ""
            job["speed_str"] = ""
            job["eta"] = ""
            job["auto_start"] = False
            self._persist_job(job_id)

        with self.queue_condition:
            if job_id not in self.work_queue:
                self.work_queue.append(job_id)
            self.queue_condition.notify()

        return True

    def start_all_ready_jobs(self) -> int:
        """Bắt đầu tải tất cả các job đang ở trạng thái READY, QUEUED hoặc CHECKING."""
        count = 0
        with self._lock:
            job_ids = list(self.jobs.keys())

        for jid in job_ids:
            with self._lock:
                job = self.jobs.get(jid)
                if not job:
                    continue
                                                                                                 
                if job["status"] == DownloaderJobState.CHECKING:
                    job["auto_start"] = True
                    self._persist_job(jid)
                    count += 1
                elif job["status"] in [DownloaderJobState.READY, DownloaderJobState.QUEUED, DownloaderJobState.ERROR, DownloaderJobState.CANCELLED]:
                    self.start_job(jid)
                    count += 1
        return count

    def cancel_job(self, job_id: str) -> bool:
        """Dừng/hủy ngay lập tức một job đang chạy hoặc trong hàng đợi."""
        with self._lock:
            job = self.jobs.get(job_id)
            if not job:
                return False

            if job_id in self.work_queue:
                self.work_queue.remove(job_id)

            if job_id in self.cancel_events:
                self.cancel_events[job_id].set()

            proc = self.running_processes.get(job_id)
            if proc:
                try:
                    proc.terminate()
                    time.sleep(0.2)
                    if proc.poll() is None:
                        proc.kill()
                except Exception as e:
                    logger.warning(f"Lỗi kill process của job {job_id}: {e}")

            job["status"] = DownloaderJobState.CANCELLED
            job["error"] = "Tác vụ đã được dừng bởi người dùng."
            job["speed"] = ""
            job["eta"] = ""
            self._persist_job(job_id)
            return True

    def cancel_all(self) -> bool:
        """Dừng tất cả các job đang chạy hoặc trong hàng đợi."""
        with self._lock:
            job_ids = list(self.jobs.keys())

        for jid in job_ids:
            with self._lock:
                job = self.jobs.get(jid)
                if job and job["status"] in [DownloaderJobState.DOWNLOADING, DownloaderJobState.QUEUED, DownloaderJobState.CHECKING, DownloaderJobState.MERGING]:
                    self.cancel_job(jid)
        return True

    def retry_job(self, job_id: str, options: Optional[Dict[str, Any]] = None) -> bool:
        """Thử lại một job bị lỗi (ERROR) hoặc đã dừng (CANCELLED)."""
        with self._lock:
            job = self.jobs.get(job_id)
            if not job:
                return False
            job["retry_count"] = job.get("retry_count", 0) + 1

        return self.start_job(job_id, options)

    def remove_job(self, job_id: str) -> bool:
        """Xóa job khỏi danh sách và dọn dẹp file tạm của job đó."""
        self.cancel_job(job_id)
        with self._lock:
            if job_id in self.jobs:
                del self.jobs[job_id]

        job_temp = self._get_job_dir(job_id)
        try:
            if job_temp.exists():
                shutil.rmtree(job_temp, ignore_errors=True)
        except Exception:
            pass
        return True

    def get_job(self, job_id: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            job = self.jobs.get(job_id)
            return self._format_job_dict(job) if job else None

    def list_jobs(self) -> List[Dict[str, Any]]:
        with self._lock:
            return [self._format_job_dict(job) for job in self.jobs.values()]

    def _worker_loop(self):
        """Worker thread lấy job từ hàng đợi và tiến hành download tuần tự an toàn."""
        while not self._is_shutting_down:
            job_id = None
            with self.queue_condition:
                while not self.work_queue and not self._is_shutting_down:
                    self.queue_condition.wait(timeout=1.0)
                if self._is_shutting_down:
                    break
                if self.work_queue:
                    job_id = self.work_queue.pop(0)

            if job_id:
                try:
                    self._execute_download_pipeline(job_id)
                except Exception as e:
                    logger.error(f"Lỗi không xử lý được trong worker khi chạy job {job_id}: {e}", exc_info=True)
                    with self._lock:
                        job = self.jobs.get(job_id)
                        if job:
                            job["status"] = DownloaderJobState.ERROR
                            job["error"] = f"Lỗi hệ thống: {str(e)}"
                            self._persist_job(job_id)

    def _execute_download_pipeline(self, job_id: str):
        """
        Quy trình xử lý tải trọn gói:
        1. Chuẩn bị thư mục tạm riêng biệt cho job (DATA/temp/downloader/jobs/<job_id>/)
        2. Kiểm tra dung lượng đĩa trống
        3. Tạo argument list cho yt-dlp theo format (MP4 / MP3) và resolution (KHÔNG DÙNG shell=True)
        4. Subprocess.Popen + đọc realtime output cập nhật progress
        5. Tải thumbnail (nếu enabled)
        6. FFprobe verification (bắt buộc file tồn tại, size > 0, streams, duration > 0)
        7. Atomic move sang Download/KAGEVIETSUB/
        8. Cập nhật COMPLETED
        """
        with self._lock:
            job = self.jobs.get(job_id)
            if not job:
                return
            job["status"] = DownloaderJobState.DOWNLOADING
            job["progress"] = 0.0
            job["error"] = None
            self._persist_job(job_id)
            cancel_event = threading.Event()
            self.cancel_events[job_id] = cancel_event

        job_dir = self._get_job_dir(job_id)
        log_file = job_dir / "job.log"

        try:
            stat = shutil.disk_usage(job_dir)
                                          
            if stat.free < 50 * 1024 * 1024:
                with self._lock:
                    job["status"] = DownloaderJobState.ERROR
                    job["error"] = "❌ Dung lượng bộ nhớ thiết bị không đủ (cần ít nhất 50MB trống)."
                    self._persist_job(job_id)
                return
        except Exception:
            pass

        ytdlp_cmd = find_ytdlp_executable()
        if not ytdlp_cmd:
            with self._lock:
                job["status"] = DownloaderJobState.ERROR
                job["error"] = "❌ Không tìm thấy công cụ yt-dlp trên hệ thống."
                self._persist_job(job_id)
            return

        fmt = (job.get("selected_format") or job.get("format") or "MP4").upper()
        if fmt != "MP3":
            fmt = "MP4"
        res_choice = job.get("selected_resolution") or job.get("resolution") or "Auto"
        url = job.get("url", "")
        
        # Ensure redirect is resolved
        resolved_url = resolve_redirect_url(url)
        if resolved_url and resolved_url != url:
            url = resolved_url
            job["url"] = resolved_url

        platform = job.get("platform") or detect_platform(url)
        job["platform"] = platform

        temp_output_tmpl = str(job_dir / "media_output.%(ext)s")

        args = list(ytdlp_cmd) + [
            "--no-playlist",
            "--no-warnings",
            "--newline",
            "-o", temp_output_tmpl,
            "--socket-timeout", "25",
            "--retries", "10",
            "--fragment-retries", "10",
            "--progress-template", "%(progress._percent_str)s;%(progress._speed_str)s;%(progress._eta_str)s;%(progress._total_bytes_str)s;%(progress._downloaded_bytes_str)s"
        ]

        node_bin = shutil.which("node")
        if node_bin:
            args += ["--js-runtimes", f"node:{node_bin}"]

        if platform == "bilibili" or "bilibili.com" in url.lower() or "b23.tv" in url.lower():
            args += [
                "--referer", "https://www.bilibili.com/",
                "--user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            ]
        elif platform == "douyin" or "douyin.com" in url.lower():
            args += [
                "--referer", "https://www.douyin.com/",
                "--user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            ]
        elif platform == "tiktok" or "tiktok.com" in url.lower():
            args += [
                "--referer", "https://www.tiktok.com/",
                "--user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            ]

        if fmt == "MP3":
            args += [
                "-x",
                "--audio-format", "mp3",
                "--audio-quality", "0"
            ]
        else:
            h_match = re.search(r'(\d+)p', res_choice)
            if h_match and res_choice != "Auto":
                h_val = h_match.group(1)
                format_str = f"bestvideo[height<={h_val}][ext=mp4]+bestaudio[ext=m4a]/bestvideo[height<={h_val}][ext=mp4]+bestaudio/bestvideo[height<={h_val}]+bestaudio[ext=m4a]/bestvideo[height<={h_val}]+bestaudio/best[height<={h_val}][ext=mp4]/best[height<={h_val}]/best"
            else:
                format_str = "bestvideo[ext=mp4]+bestaudio[ext=m4a]/bestvideo[ext=mp4]+bestaudio/bestvideo+bestaudio[ext=m4a]/bestvideo+bestaudio/best[ext=mp4]/best"

            args += [
                "-f", format_str,
                "--merge-output-format", "mp4",
                "--remux-video", "mp4"
            ]

        args.append(url)

        with open(log_file, "a", encoding="utf-8") as f_log:
            f_log.write(f"\n--- Bắt đầu tải [{time.strftime('%Y-%m-%d %H:%M:%S')}] ---\n")
            f_log.write("CMD: " + " ".join(args) + "\n")

        captured_errors = []

        try:
            proc = subprocess.Popen(
                args,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                universal_newlines=True
            )

            with self._lock:
                self.running_processes[job_id] = proc

            while True:
                if cancel_event.is_set():
                    try:
                        proc.terminate()
                    except Exception:
                        pass
                    break

                line = proc.stdout.readline()
                if not line and proc.poll() is not None:
                    break

                if line:
                    with open(log_file, "a", encoding="utf-8") as f_log:
                        f_log.write(line)

                    line_clean = line.strip()
                    if "ERROR:" in line_clean:
                        captured_errors.append(line_clean)

                    prog_info = parse_ytdlp_progress_line(line)
                    if prog_info:
                        with self._lock:
                            if "progress" in prog_info:
                                job["progress"] = prog_info["progress"]
                                job["progress_percent"] = prog_info["progress"]
                            if "speed" in prog_info and prog_info["speed"]:
                                job["speed"] = prog_info["speed"]
                                job["speed_str"] = prog_info["speed"]
                            if "eta" in prog_info and prog_info["eta"]:
                                job["eta"] = prog_info["eta"]
                            if "total" in prog_info and prog_info["total"]:
                                job["total_size"] = prog_info["total"]
                            if "downloaded" in prog_info and prog_info["downloaded"]:
                                job["downloaded_size"] = prog_info["downloaded"]

                    if "[Merger]" in line or "Merging formats" in line or "[ExtractAudio]" in line:
                        with self._lock:
                            job["status"] = DownloaderJobState.MERGING

            returncode = proc.wait()

            with self._lock:
                if job_id in self.running_processes:
                    del self.running_processes[job_id]

            if cancel_event.is_set():
                with self._lock:
                    job["status"] = DownloaderJobState.CANCELLED
                    job["error"] = "Tác vụ đã được dừng bởi người dùng."
                    job["error_message"] = job["error"]
                    self._persist_job(job_id)
                return

            if returncode != 0:
                                         
                error_detail = "Lỗi khi tải từ máy chủ nguồn."
                if captured_errors:
                    for err_line in reversed(captured_errors):
                        if "Sign in to confirm" in err_line:
                            error_detail = "❌ Máy chủ yêu cầu xác thực người dùng / cookies (Bot detection)."
                            break
                        elif "HTTP Error 403" in err_line or "Forbidden" in err_line:
                            error_detail = "❌ Bị chặn truy cập (HTTP 403 Forbidden). Cần cập nhật cookie/referer."
                            break
                        elif "Video unavailable" in err_line or "Private video" in err_line:
                            error_detail = "❌ Video ở chế độ riêng tư hoặc không khả dụng."
                            break
                        elif err_line.startswith("ERROR:"):
                            error_detail = f"❌ {err_line[:120]}"
                            break

                log_err_str = "\n".join(captured_errors) if captured_errors else f"Returncode: {returncode}"
                logger.error(
                    f"\n[Downloader Error]\n"
                    f"URL: {url}\n"
                    f"Platform: {platform}\n"
                    f"Format: {fmt}\n"
                    f"Resolution: {res_choice}\n"
                    f"Command: {' '.join(args)}\n"
                    f"Return code: {returncode}\n"
                    f"Stderr details: {log_err_str}\n"
                )

                with self._lock:
                    job["status"] = DownloaderJobState.ERROR
                    job["error"] = error_detail
                    job["error_message"] = error_detail
                    self._persist_job(job_id)
                return

            with self._lock:
                job["status"] = DownloaderJobState.VERIFYING
                self._persist_job(job_id)

            produced_files = [
                f for f in job_dir.glob("media_output.*")
                if f.is_file() and not f.name.endswith(".part") and not f.name.endswith(".ytdl") and not f.name.endswith(".tmp")
            ]
            target_file = None
            preferred_ext = ".mp3" if fmt == "MP3" else ".mp4"
            
            for pf in produced_files:
                if pf.suffix.lower() == preferred_ext:
                    target_file = pf
                    break

            if not target_file and fmt == "MP4":
                for pf in produced_files:
                    if pf.suffix.lower() in [".mkv", ".m4a", ".mov", ".ts"]:
                        remuxed_file = job_dir / "media_output_remuxed.mp4"
                        try:
                            remux_cmd = ["ffmpeg", "-y", "-i", str(pf), "-c", "copy", str(remuxed_file)]
                            r_res = subprocess.run(remux_cmd, capture_output=True, text=True, timeout=60)
                            if r_res.returncode == 0 and remuxed_file.exists() and remuxed_file.stat().st_size > 0:
                                target_file = remuxed_file
                                break
                        except Exception as remux_err:
                            logger.warning(f"Lỗi remux sang MP4: {remux_err}")

            if not target_file or not target_file.exists():
                with self._lock:
                    job["status"] = DownloaderJobState.ERROR
                    job["error"] = "❌ Không tìm thấy file media (MP4/MP3) đã tải về."
                    job["error_message"] = job["error"]
                    self._persist_job(job_id)
                return

            if target_file.stat().st_size <= 0:
                with self._lock:
                    job["status"] = DownloaderJobState.ERROR
                    job["error"] = "❌ File tải về có dung lượng 0 KB."
                    job["error_message"] = job["error"]
                    self._persist_job(job_id)
                return

            if fmt == "MP3":
                is_valid, msg, details = verify_mp3(target_file)
            else:
                is_valid, msg, details = verify_mp4(target_file, expect_audio=True)

            if not is_valid:
                logger.error(f"[Downloader Verification Failed] Job {job_id}: {msg} | Details: {details}")
                with self._lock:
                    job["status"] = DownloaderJobState.ERROR
                    job["error"] = f"❌ Xác thực file thất bại: {msg}"
                    job["error_message"] = job["error"]
                    self._persist_job(job_id)
                return

            thumb_saved_path = ""
            if job.get("download_thumbnail") and job.get("thumbnail"):
                try:
                    clean_title = sanitize_filename(job.get("title", "thumbnail"))
                    thumb_target = job_dir / f"{clean_title}.jpg"
                    t_success, t_err = download_thumbnail_direct(job["thumbnail"], thumb_target)
                    if t_success and thumb_target.exists() and thumb_target.stat().st_size > 0:
                        final_thumb_path = get_safe_unique_filepath(KAGE_DOWNLOAD_DIR, f"{clean_title}.jpg")
                        shutil.move(str(thumb_target), str(final_thumb_path))
                        thumb_saved_path = str(final_thumb_path)
                    else:
                        logger.warning(f"Không thể tải thumbnail cho job {job_id}: {t_err}")
                except Exception as t_ex:
                    logger.warning(f"Lỗi khi xử lý thumbnail cho job {job_id}: {t_ex}")

            clean_title = sanitize_filename(job.get("title", "video"))
            ext = ".mp3" if fmt == "MP3" else ".mp4"
            final_media_path = get_safe_unique_filepath(KAGE_DOWNLOAD_DIR, f"{clean_title}{ext}")

            shutil.move(str(target_file), str(final_media_path))

            for junk in job_dir.glob("media_output.*"):
                try:
                    junk.unlink()
                except Exception:
                    pass

            with self._lock:
                job["status"] = DownloaderJobState.COMPLETED
                job["progress"] = 100.0
                job["progress_percent"] = 100.0
                job["speed"] = ""
                job["speed_str"] = ""
                job["eta"] = ""
                job["output_filename"] = final_media_path.name
                job["output_path"] = str(final_media_path)
                job["destination_path"] = str(final_media_path)
                job["thumbnail_path"] = thumb_saved_path
                job["completed_at"] = time.time()
                self._persist_job(job_id)

            logger.info(f"Job {job_id} hoàn tất xuất sắc: {final_media_path.name}")

        except Exception as e:
            logger.error(f"Ngoại lệ khi thực thi download job {job_id}: {e}", exc_info=True)
            with self._lock:
                job["status"] = DownloaderJobState.ERROR
                job["error"] = f"Lỗi không xác định: {str(e)}"
                job["error_message"] = job["error"]
                self._persist_job(job_id)

    def shutdown(self):
        """Dừng sạch sẽ toàn bộ background process khi server shutdown."""
        self._is_shutting_down = True
        with self.queue_condition:
            self.queue_condition.notify_all()

        with self._lock:
            for jid, proc in list(self.running_processes.items()):
                try:
                    proc.terminate()
                except Exception:
                    pass

def sanitize_filename(name: str) -> str:
    """Làm sạch tên file, loại bỏ ký tự cấm trên Windows, Linux, Android."""
    if not name:
        return "video"
                                           
    cleaned = re.sub(r'[\\/*?:"<>|]', "_", name)
    cleaned = re.sub(r'[\r\n\t]+', " ", cleaned).strip()
                                      
    if len(cleaned) > 120:
        cleaned = cleaned[:120].strip()
    return cleaned or "video"

downloader_manager = DownloaderManager()
