#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
KAGEVIETSUB DOWNLOADER MODULE
"""

from TOOL.downloader.manager import downloader_manager, DownloaderJobState
from TOOL.downloader.url_cleaner import extract_urls, clean_and_normalize_url, process_raw_inputs, detect_url_platform
from TOOL.downloader.api import (
    handle_check_links, handle_get_info, handle_start_download,
    handle_update_job, handle_get_status, handle_cancel_job,
    handle_cancel_all, handle_retry_job, handle_remove_job,
    handle_downloader_ready
)

__all__ = [
    "downloader_manager",
    "DownloaderJobState",
    "extract_urls",
    "clean_and_normalize_url",
    "process_raw_inputs",
    "detect_url_platform",
    "handle_check_links",
    "handle_get_info",
    "handle_start_download",
    "handle_update_job",
    "handle_get_status",
    "handle_cancel_job",
    "handle_cancel_all",
    "handle_retry_job",
    "handle_remove_job",
    "handle_downloader_ready"
]
