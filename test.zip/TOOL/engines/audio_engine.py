import os
import re
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional
from TOOL.config import OUTPUT_DIR, TEMP_DIR, KAGE_DOWNLOAD_DIR, get_safe_unique_filepath
from TOOL.services.ffmpeg_service import FFmpegService
from TOOL.services.task_service import job_manager

def natural_sort_key(s: Any) -> List[Any]:
    """Natural sorting key: orders numbers numerically (e.g. 1, 2, 10 instead of 1, 10, 2)."""
    return [int(text) if text.isdigit() else text.lower() for text in re.split(r'(\d+)', str(s))]

class AudioEngine:
    @staticmethod
    def extract_index_from_filename(filename: str) -> Optional[int]:
        """Extract leading or embedded sequence number from audio filename."""
        match = re.search(r'(\d+)', Path(filename).stem)
        return int(match.group(1)) if match else None

    @staticmethod
    def check_audio_sequence(audio_paths: List[Path], expected_count: Optional[int] = None) -> Tuple[bool, List[int]]:
        """
        Check for missing audio files in a sequence (e.g. 1..N).
        Returns (is_valid, list_of_missing_indices).
        """
        indices = []
        for p in audio_paths:
            idx = AudioEngine.extract_index_from_filename(p.name)
            if idx is not None:
                indices.append(idx)

        if not indices:
            return True, []

        min_idx = min(indices)
        max_idx = expected_count if (expected_count and expected_count > 0) else max(indices)
        existing_set = set(indices)

        start = 1 if (min_idx <= 1 or expected_count) else min_idx
        missing = [i for i in range(start, max_idx + 1) if i not in existing_set]
        return (len(missing) == 0), missing

    @staticmethod
    def merge_audio_files(
        audio_paths: List[Path],
        output_filename: str = "merged_audio.mp3",
        sort_mode: str = "natural",                                       
        expected_count: Optional[int] = None,
        job_id: Optional[str] = None
    ) -> Tuple[bool, str, Path]:
        """
        Merge audio files into one file and save directly into Download/KAGEVIETSUB/.
        Features natural numeric sorting and missing sequence detection (lenh_ghep_mp3v2).
        """
        if len(audio_paths) < 2:
            raise ValueError("Vui lòng cung cấp ít nhất 2 file âm thanh để ghép.")

        from TOOL.services.storage_service import StorageService
        output_dir = StorageService.get_output_dir()

        if not output_filename.lower().endswith(".mp3"):
            output_filename += ".mp3"

        output_path = get_safe_unique_filepath(output_dir, output_filename)

        files_to_merge = list(audio_paths)
        if sort_mode == "natural":
            files_to_merge.sort(key=lambda p: natural_sort_key(p.name))
        elif sort_mode == "alphabetical":
            files_to_merge.sort(key=lambda p: p.name.lower())

        is_seq_valid, missing = AudioEngine.check_audio_sequence(files_to_merge, expected_count)
        if not is_seq_valid and missing:
            missing_str = ", ".join(str(m) for m in missing[:10])
            if len(missing) > 10:
                missing_str += f"... (+{len(missing)-10} file nữa)"
            err_msg = f"❌ Không tìm thấy file audio số: {missing_str}. Hãy kiểm tra lại file trước khi ghép."
            if job_id:
                job_manager.update_job(job_id, status="failed", error=err_msg, message=err_msg)
            return False, err_msg, output_path

        def _progress(pct, cur_sec, total_sec):
            if job_id:
                job_manager.update_job(
                    job_id,
                    progress=int(pct),
                    message=f"Đang ghép {len(files_to_merge)} file audio ({round(cur_sec, 1)}s / {round(total_sec, 1)}s - {int(pct)}%)..."
                )

        if job_id:
            job_manager.update_job(job_id, progress=15, message=f"Đang chuẩn bị ghép {len(files_to_merge)} file âm thanh...")

        success, err = FFmpegService.concat_audio_files(files_to_merge, output_path, progress_callback=_progress)

        if not success:
            if job_id:
                job_manager.update_job(job_id, status="failed", error=err, message="Lỗi ghép audio.")
            return False, err, output_path

        file_size = os.path.getsize(output_path) if output_path.exists() else 0
        size_mb = round(file_size / (1024 * 1024), 2)
        media_info = FFmpegService.get_media_info(output_path)
        dur = float(media_info.get("duration", 0.0))
        abs_path_str = str(output_path.resolve())
        saved_loc = f"Download/KAGEVIETSUB/{output_path.name}"

        if job_id:
            job_manager.update_job(
                job_id,
                status="completed",
                merge_status="completed",
                progress=100,
                message=f"✓ Đã xử lý xong và lưu vào Download/KAGEVIETSUB/{output_path.name}",
                download_url=f"/api/download/{output_path.name}",
                filename=output_path.name,
                output_filename=output_path.name,
                saved_path=abs_path_str,
                output_path=abs_path_str,
                saved_location=saved_loc,
                output_size=file_size,
                duration=dur,
                verified=True,
                result={
                    "status": "COMPLETED",
                    "output_path": abs_path_str,
                    "output_filename": output_path.name,
                    "output_size": file_size,
                    "duration": dur,
                    "verified": True,
                    "saved_location": saved_loc
                }
            )

        return True, "Success", output_path

