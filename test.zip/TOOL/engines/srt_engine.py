import re
import os
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional
from TOOL.config import OUTPUT_DIR, KAGE_DOWNLOAD_DIR, get_safe_unique_filepath

class SrtEngine:
    @staticmethod
    def parse_srt(text: str) -> List[Dict[str, Any]]:
        """Split SRT text into structured blocks."""
                            
        text = text.replace('\r\n', '\n').replace('\r', '\n')
        raw_blocks = re.split(r'\n\s*\n', text.strip())
        parsed = []
        for block in raw_blocks:
            lines = block.strip().split('\n')
            if len(lines) >= 3:
                idx = lines[0].strip()
                time_line = lines[1].strip()
                content = '\n'.join(lines[2:])
                match = re.match(r'(\d{2}:\d{2}:\d{2},\d{3})\s*-->\s*(\d{2}:\d{2}:\d{2},\d{3})', time_line)
                if match:
                    start = match.group(1)
                    end = match.group(2)
                    parsed.append({'index': idx, 'start': start, 'end': end, 'text': content})
        return parsed

    @staticmethod
    def parse(text: str) -> List[Dict[str, Any]]:
        """Compatibility wrapper alias for parse_srt."""
        return SrtEngine.parse_srt(text)

    @staticmethod
    def blocks_to_srt(blocks: List[Dict[str, Any]]) -> str:
        """Combine structured blocks back to a valid SRT string."""
        out = []
        for i, b in enumerate(blocks, 1):
            out.append(str(i))
            out.append(f"{b['start']} --> {b['end']}")
            out.append(b['text'])
            out.append('')
        return '\n'.join(out)

    @staticmethod
    def time_to_ms(time_str: str) -> int:
        """Convert HH:MM:SS,mmm to milliseconds."""
        try:
            h, m, rest = time_str.split(':')
            s, ms = rest.split(',')
            return int(h) * 3600000 + int(m) * 60000 + int(s) * 1000 + int(ms)
        except Exception:
            return 0

    @staticmethod
    def ms_to_time(ms: int) -> str:
        """Convert milliseconds to HH:MM:SS,mmm."""
        ms = max(0, ms)
        h = ms // 3600000
        ms %= 3600000
        m = ms // 60000
        ms %= 60000
        s = ms // 1000
        ms %= 1000
        return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

    @staticmethod
    def remove_trailing_punctuation(srt_text: str) -> Tuple[str, int]:
        """Remove punctuation ([.,!] or ...) from the end of lines, preserving '?'."""
        blocks = SrtEngine.parse_srt(srt_text)
        if not blocks:
            return srt_text, 0
        changed = 0
        for blk in blocks:
            lines = blk['text'].split('\n')
            new_lines = []
            for line in lines:
                new_line = re.sub(r'([.,!]|\.{3})+(?=\?*$)', '', line.rstrip())
                if new_line != line:
                    changed += 1
                new_lines.append(new_line)
            blk['text'] = '\n'.join(new_lines)
        return SrtEngine.blocks_to_srt(blocks), changed

    @staticmethod
    def remove_leading_ellipsis(srt_text: str) -> Tuple[str, int]:
        """Remove leading ellipsis (...) from the start of lines."""
        blocks = SrtEngine.parse_srt(srt_text)
        if not blocks:
            return srt_text, 0
        changed = 0
        for blk in blocks:
            lines = blk['text'].split('\n')
            new_lines = []
            for line in lines:
                new_line = re.sub(r'^(\.{3})\s*', '', line)
                if new_line != line:
                    changed += 1
                new_lines.append(new_line)
            blk['text'] = '\n'.join(new_lines)
        return SrtEngine.blocks_to_srt(blocks), changed

    @staticmethod
    def apply_sequential_replace(srt_text: str, rules_text: str) -> Tuple[str, int]:
        """
        Replace patterns sequentially based on rules (one per line: 'old -> new').
        Default rules:
        ... -> ,
        . -> ,
        ! -> ,
        vi -> Vi
        xi -> Xi
        " -> 
        """
        content = srt_text
        total_replacements = 0
        lines = rules_text.strip().split('\n')
        for line in lines:
            line = line.strip()
            if not line:
                continue
            parts = line.split('->')
            if len(parts) == 2:
                old = parts[0].strip()
                new = parts[1].strip()
                if old:
                    count = content.count(old)
                    if count > 0:
                        content = content.replace(old, new)
                        total_replacements += count
        return content, total_replacements

    @staticmethod
    def avoid_overlap(srt_text: str) -> Tuple[str, int]:
        """
        Adjust timing to avoid overlapping and improve reading flow:
        If words > 5 and avg duration < 168ms/word:
        delta_ms = word_count * 30ms
        If gap >= delta_ms: extends end of previous block.
        Otherwise delays start of next block.
        If last block: extends end.
        """
        blocks = SrtEngine.parse_srt(srt_text)
        if not blocks:
            return srt_text, 0
        count = 0
        for i in range(len(blocks)):
            b1 = blocks[i]
            words = b1['text'].split()
            word_count = len(words)
            if word_count <= 5:
                continue
            start_ms = SrtEngine.time_to_ms(b1['start'])
            end_ms = SrtEngine.time_to_ms(b1['end'])
            duration = end_ms - start_ms
            if duration <= 0:
                continue
            avg_ms = duration / word_count
            if avg_ms >= 168:
                continue
                                                       
            delta_ms = min(word_count * 30, 200)

            if i + 1 < len(blocks):
                b2 = blocks[i + 1]
                next_start_ms = SrtEngine.time_to_ms(b2['start'])
                next_end_ms = SrtEngine.time_to_ms(b2['end'])
                gap = next_start_ms - end_ms
                if gap >= delta_ms:
                                                                 
                    new_end_ms = end_ms + delta_ms
                    if new_end_ms <= next_start_ms:
                        b1['end'] = SrtEngine.ms_to_time(new_end_ms)
                        count += 1
                else:
                                                                
                    new_start_ms = next_start_ms + delta_ms
                    if next_end_ms - new_start_ms > 0:
                        b2['start'] = SrtEngine.ms_to_time(new_start_ms)
                        count += 1
            else:
                                                           
                new_end_ms = end_ms + delta_ms
                b1['end'] = SrtEngine.ms_to_time(new_end_ms)
                count += 1

        return SrtEngine.blocks_to_srt(blocks), count

    @staticmethod
    def run_purple_sequence(srt_text: str, rules_text: Optional[str] = None) -> Tuple[str, Dict[str, Any]]:
        """
        Execute 3 Purple Steps:
        1. Remove leading ellipsis
        2. Remove trailing punctuation (preserve ?)
        3. Sequential replacement
        """
        if rules_text is None:
            rules_text = "... -> ,\n. -> ,\n! -> ,\nvi -> Vi\nxi -> Xi\n\" -> "

        step1, c1 = SrtEngine.remove_leading_ellipsis(srt_text)
        step2, c2 = SrtEngine.remove_trailing_punctuation(step1)
        step3, c3 = SrtEngine.apply_sequential_replace(step2, rules_text)

        return step3, {
            "leading_ellipsis_removed": c1,
            "trailing_punctuation_removed": c2,
            "replacements_applied": c3
        }

    @staticmethod
    def find_overlap_2_3(text1: str, text2: str) -> Optional[str]:
        words1 = text1.split()
        words2 = text2.split()
        for L in range(3, 1, -1):
            if len(words1) < L or len(words2) < L:
                continue
            if [w.lower() for w in words1[-L:]] == [w.lower() for w in words2[:L]]:
                return ' '.join(words2[:L])
        return None

    @staticmethod
    def find_overlap_4_5(text1: str, text2: str) -> Optional[str]:
        words1 = text1.split()
        words2 = text2.split()
        for L in range(5, 3, -1):
            if len(words1) < L or len(words2) < L:
                continue
            if [w.lower() for w in words1[-L:]] == [w.lower() for w in words2[:L]]:
                return ' '.join(words2[:L])
        return None

    @staticmethod
    def fix_repeated_words_2_3(srt_text: str) -> Tuple[str, int]:
        """Fix repeating 2-3 words at sentence boundaries."""
        blocks = SrtEngine.parse_srt(srt_text)
        if not blocks:
            return srt_text, 0

        fixed = []
        i = 0
        merged_count = 0
        while i < len(blocks):
            if i == len(blocks) - 1:
                fixed.append(blocks[i])
                break
            b1 = blocks[i]
            b2 = blocks[i + 1]
            if SrtEngine.time_to_ms(b1['end']) == SrtEngine.time_to_ms(b2['start']):
                text1 = b1['text'].replace('\n', ' ').strip()
                text2 = b2['text'].replace('\n', ' ').strip()
                if len(text1.split()) >= 5 and len(text2.split()) in [2, 3]:
                    overlap = SrtEngine.find_overlap_2_3(text1, text2)
                    if overlap:
                        words2 = text2.split()
                        overlap_words = overlap.split()
                        if words2 == overlap_words:
                            b1['end'] = b2['end']
                            fixed.append(b1)
                            merged_count += 1
                            i += 2
                            continue
            fixed.append(b1)
            i += 1

        return SrtEngine.blocks_to_srt(fixed), merged_count

    @staticmethod
    def fix_repeated_words_4_5(srt_text: str) -> Tuple[str, int]:
        """Fix repeating 4-5 words at sentence boundaries."""
        blocks = SrtEngine.parse_srt(srt_text)
        if not blocks:
            return srt_text, 0

        fixed = []
        i = 0
        merged_count = 0
        while i < len(blocks):
            if i == len(blocks) - 1:
                fixed.append(blocks[i])
                break
            b1 = blocks[i]
            b2 = blocks[i + 1]
            if SrtEngine.time_to_ms(b1['end']) == SrtEngine.time_to_ms(b2['start']):
                text1 = b1['text'].replace('\n', ' ').strip()
                text2 = b2['text'].replace('\n', ' ').strip()
                if len(text1.split()) > 5 and len(text1.split()) > len(text2.split()):
                    overlap = SrtEngine.find_overlap_4_5(text1, text2)
                    if overlap:
                        new_text2 = text2[len(overlap):].strip()
                        if new_text2 == '':
                            b1['end'] = b2['end']
                            fixed.append(b1)
                            merged_count += 1
                            i += 2
                            continue
                        else:
                            b2['text'] = new_text2
                            fixed.append(b1)
                            merged_count += 1
                            i += 1
                            continue
            fixed.append(b1)
            i += 1

        return SrtEngine.blocks_to_srt(fixed), merged_count

    @staticmethod
    def merge_short_blocks_3_tiers(srt_text: str) -> Tuple[str, int]:
        """Merge short consecutive sentences across 3 thresholds."""
        blocks = SrtEngine.parse_srt(srt_text)
        if not blocks:
            return srt_text, 0

        total_merged = 0

        i = 0
        while i < len(blocks) - 1:
            curr = blocks[i]
            nxt = blocks[i + 1]
            if curr['end'] == nxt['start']:
                w_count = len(nxt['text'].split())
                dur = SrtEngine.time_to_ms(nxt['end']) - SrtEngine.time_to_ms(nxt['start'])
                if (w_count <= 4 and dur <= 400) or (w_count <= 5 and dur <= 300):
                    curr['text'] += ' ' + nxt['text']
                    curr['end'] = nxt['end']
                    total_merged += 1
                    del blocks[i + 1]
                    continue
            i += 1

        i = 0
        while i < len(blocks) - 1:
            curr = blocks[i]
            nxt = blocks[i + 1]
            if curr['end'] == nxt['start']:
                w_count = len(nxt['text'].split())
                dur = SrtEngine.time_to_ms(nxt['end']) - SrtEngine.time_to_ms(nxt['start'])
                if w_count <= 5 and dur <= 350:
                    curr['text'] += ' ' + nxt['text']
                    curr['end'] = nxt['end']
                    total_merged += 1
                    del blocks[i + 1]
                    continue
            i += 1

        i = 0
        while i < len(blocks) - 1:
            curr = blocks[i]
            nxt = blocks[i + 1]
            if curr['end'] == nxt['start']:
                w_count = len(nxt['text'].split())
                dur = SrtEngine.time_to_ms(nxt['end']) - SrtEngine.time_to_ms(nxt['start'])
                if w_count <= 6 and dur <= 300:
                    curr['text'] += ' ' + nxt['text']
                    curr['end'] = nxt['end']
                    total_merged += 1
                    del blocks[i + 1]
                    continue
            i += 1

        return SrtEngine.blocks_to_srt(blocks), total_merged

    @staticmethod
    def merge_short_previous(srt_text: str) -> Tuple[str, int]:
        """Merge adjacent blocks if current duration <= 400ms."""
        blocks = SrtEngine.parse_srt(srt_text)
        if not blocks:
            return srt_text, 0

        merged_count = 0
        changed = True
        while changed:
            changed = False
            i = 0
            while i < len(blocks) - 1:
                curr = blocks[i]
                nxt = blocks[i + 1]
                if SrtEngine.time_to_ms(curr['end']) == SrtEngine.time_to_ms(nxt['start']):
                    dur = SrtEngine.time_to_ms(curr['end']) - SrtEngine.time_to_ms(curr['start'])
                    if dur <= 400:
                        curr['text'] += ' ' + nxt['text']
                        curr['end'] = nxt['end']
                        del blocks[i + 1]
                        merged_count += 1
                        changed = True
                        continue
                i += 1

        return SrtEngine.blocks_to_srt(blocks), merged_count

    @staticmethod
    def run_all_sequence(srt_text: str, rules_text: Optional[str] = None) -> Tuple[str, Dict[str, Any]]:
        """Run all 7 processing steps in precise order."""
        res, c1 = SrtEngine.remove_trailing_punctuation(srt_text)
        res, c2 = SrtEngine.remove_leading_ellipsis(res)
        res, c3 = SrtEngine.apply_sequential_replace(res, rules_text or "... -> ,\n. -> ,\n! -> ,\nvi -> Vi\nxi -> Xi\n\" -> ")
        res, c4 = SrtEngine.fix_repeated_words_2_3(res)
        res, c5 = SrtEngine.merge_short_blocks_3_tiers(res)
        res, c6 = SrtEngine.merge_short_previous(res)
        res, c7 = SrtEngine.fix_repeated_words_4_5(res)

        return res, {
            "trailing_punctuation": c1,
            "leading_ellipsis": c2,
            "rules_applied": c3,
            "fixed_repeat_2_3": c4,
            "merged_3_tiers": c5,
            "merged_short_prev": c6,
            "fixed_repeat_4_5": c7
        }

    @staticmethod
    def uppercase_srt(content: str) -> str:
        """Convert all dialogue text to UPPERCASE while preserving indices and timestamps."""
        lines = content.splitlines()
        new_lines = []
        for line in lines:
            stripped = line.strip()
            if '-->' in stripped or stripped.isdigit() or stripped == '':
                new_lines.append(line)
            else:
                new_lines.append(line.upper())
        return '\n'.join(new_lines)

    @staticmethod
    def split_srt(srt_text: str, sentences_per_file: int, base_name: str = "subtitle") -> Tuple[List[Dict[str, Any]], List[Path]]:
        """Split SRT file into multiple parts (N sentences per file) and save directly into Download/KAGEVIETSUB/."""
        blocks = SrtEngine.parse_srt(srt_text)
        if not blocks:
            raise ValueError("No valid SRT blocks found to split.")

        chunks = [blocks[i:i + sentences_per_file] for i in range(0, len(blocks), sentences_per_file)]
        generated_files = []
        file_paths = []

        for idx, chunk in enumerate(chunks, 1):
            part_name = f"{base_name}_part{idx:03d}.srt"
            part_content = SrtEngine.blocks_to_srt(chunk)
            part_path = get_safe_unique_filepath(KAGE_DOWNLOAD_DIR, part_name)
            with open(part_path, "w", encoding="utf-8") as f:
                f.write(part_content)
            generated_files.append({
                "filename": part_path.name,
                "sentences": len(chunk),
                "path": str(part_path),
                "saved_location": f"Download/KAGEVIETSUB/{part_path.name}"
            })
            file_paths.append(part_path)

        return generated_files, file_paths
