#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
DSUB LOCAL - HIGH-PERFORMANCE SERVER (PYTHON 3.14 + TERMUX ANDROID & PC)
==============================================================================
Hỗ trợ 2 chế độ hoạt động:
1. FastAPI + Uvicorn (Nếu môi trường có sẵn)
2. Standalone Threading HTTP Server (Thuần Python 3.14, 0 dependencies bên ngoài)
Đảm bảo 100% không bao giờ crash do lỗi pydantic-core trên Termux Android.
==============================================================================
"""

import os
import sys
import time
import json
import gzip
import shutil
import zipfile
import platform
import logging
import urllib.parse
import threading
from pathlib import Path
from http.server import HTTPServer, SimpleHTTPRequestHandler
from socketserver import ThreadingMixIn
from typing import Dict, Any, Optional

TOOL_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = TOOL_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
if str(TOOL_DIR) not in sys.path:
    sys.path.insert(0, str(TOOL_DIR))

from TOOL.config import (
    HOST, PORT, DATA_DIR, TEMP_DIR, OUTPUT_DIR, UPLOADS_DIR,
    MODELS_DIR, LOGS_DIR, WEB_DIR, KAGE_DOWNLOAD_DIR, ensure_directories, is_safe_path, get_local_version
)
from TOOL.system_check import is_android, get_full_system_info
from TOOL.services.ffmpeg_service import FFmpegService
from TOOL.services.task_service import job_manager, HardwareOptimizer
from TOOL.services.cleanup_service import CleanupService
from TOOL.services.file_service import FileService
from TOOL.services.storage_service import StorageService

from TOOL.api.srt_api import (
    handle_parse_srt, handle_remove_trailing_punct, handle_remove_leading_ellipsis,
    handle_replace_rules, handle_avoid_overlap, handle_purple_sequence,
    handle_fix_repeat_2_3, handle_fix_repeat_4_5, handle_merge_short,
    handle_all_steps, handle_uppercase, handle_split_srt, handle_save_srt,
    handle_get_translate_providers, handle_check_api_key,
    handle_start_translation, handle_get_translation_status,
    handle_pause_translation, handle_resume_translation,
    handle_stop_translation, handle_retry_translation
)
from TOOL.api.audio_api import handle_audio_merge
from TOOL.api.video_api import handle_video_cut, handle_video_merge, handle_video_compress
from TOOL.api.whisper_api import handle_whisper_models, handle_whisper_transcribe, handle_download_whisper_model
from TOOL.api.tts_api import (
    handle_tts_voices, handle_tts_parse_srt, handle_tts_create_job,
    handle_tts_retry, handle_tts_retry_failed, handle_tts_merge, handle_tts_get_job, handle_tts_get_status,
    handle_tts_pause, handle_tts_resume, handle_tts_stop, handle_tts_preview,
    handle_tts_merge_recovery_folders, handle_tts_merge_recovery_start
)
from TOOL.downloader import (
    downloader_manager, handle_check_links, handle_get_info,
    handle_start_download, handle_update_job, handle_get_status as handle_downloader_status,
    handle_cancel_job, handle_cancel_all, handle_retry_job as handle_downloader_retry,
    handle_remove_job, handle_downloader_ready
)
from TOOL.downloader.api import handle_downloader_download_file
from TOOL.services.logger import logger as central_logger
logger = central_logger.get_module_logger("API_SERVER")

def get_health_data() -> Dict[str, Any]:
    """Tạo dữ liệu phản hồi cho /api/health theo chuẩn yêu cầu."""
    sys_info = get_full_system_info()
    return {
        "status": "ok",
        "app_name": "KAGEVIETSUB",
        "platform": "android" if is_android() else platform.system().lower(),
        "python": platform.python_version(),
        "architecture": platform.machine() or "ARM64",
        "system": {
            "python_version": platform.python_version(),
            "os": platform.system(),
            "platform": sys_info["platform_display"],
            "processor": platform.processor() or platform.machine()
        },
        "components": sys_info["components"],
        "directories": {
            "DATA": str(DATA_DIR),
            "temp_files": len(list(TEMP_DIR.glob("*"))) if TEMP_DIR.exists() else 0,
            "output_files": len(list(OUTPUT_DIR.glob("*"))) if OUTPUT_DIR.exists() else 0
        }
    }

def create_export_zip() -> Path:
    """Tạo gói KAGEVIETSUB.zip xuất toàn bộ project độc lập."""
    export_zip_path = OUTPUT_DIR / "KAGEVIETSUB.zip"
    with zipfile.ZipFile(export_zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(PROJECT_ROOT):
            if "node_modules" in root or ".git" in root or "__pycache__" in root or "dist" in root:
                continue
            for file in files:
                full_path = Path(root) / file
                rel_path = full_path.relative_to(PROJECT_ROOT)
                if file.endswith(".zip"):
                    continue
                zipf.write(full_path, arcname=str(Path("KAGEVIETSUB") / rel_path))
    return export_zip_path

def get_all_unified_jobs():
    task_jobs = job_manager.list_jobs(limit=100)
    try:
        from TOOL.downloader.manager import downloader_manager
        dl_jobs = downloader_manager.list_jobs()
        formatted_dl_jobs = []
        for dj in dl_jobs:
            status = dj.get("status", "QUEUED")
            status_clean = status.lower()
            if status == "COMPLETED":
                status_clean = "completed"
            elif status in ["ERROR", "FAILED", "CANCELLED"]:
                status_clean = "failed"
            elif status in ["DOWNLOADING", "CHECKING", "MERGING", "VERIFYING"]:
                status_clean = "processing"
            elif status in ["READY", "QUEUED"]:
                status_clean = "queued"

            formatted_dl_jobs.append({
                "job_id": dj.get("id") or dj.get("job_id"),
                "type": "downloader",
                "status": status_clean,
                "progress": int(float(dj.get("progress") if dj.get("progress") is not None else (dj.get("progress_percent") or 0))),
                "message": dj.get("speed_str") or dj.get("eta") or dj.get("title") or "Tải video...",
                "filename": dj.get("title") or dj.get("output_filename") or dj.get("url"),
                "created_at": dj.get("created_at") or time.time(),
                "error": dj.get("error") or dj.get("error_message"),
                "saved_location": dj.get("output_path") or dj.get("destination_path")
            })
        all_jobs = task_jobs + formatted_dl_jobs
        all_jobs.sort(key=lambda x: x.get("created_at") or 0, reverse=True)
        return all_jobs
    except Exception:
        return task_jobs

def get_single_job_unified(job_id: str):
    job = job_manager.get_job(job_id)
    if job:
        return job
    try:
        from TOOL.downloader.manager import downloader_manager
        dj = downloader_manager.jobs.get(job_id)
        if dj:
            fmt_job = downloader_manager._format_job_dict(dj)
            status = fmt_job.get("status", "QUEUED")
            status_clean = status.lower()
            if status == "COMPLETED":
                status_clean = "completed"
            elif status in ["ERROR", "FAILED", "CANCELLED"]:
                status_clean = "failed"
            elif status in ["DOWNLOADING", "CHECKING", "MERGING", "VERIFYING"]:
                status_clean = "processing"
            elif status in ["READY", "QUEUED"]:
                status_clean = "queued"

            return {
                "job_id": fmt_job.get("id") or fmt_job.get("job_id"),
                "type": "downloader",
                "status": status_clean,
                "progress": int(float(fmt_job.get("progress") if fmt_job.get("progress") is not None else (fmt_job.get("progress_percent") or 0))),
                "message": fmt_job.get("speed_str") or fmt_job.get("eta") or fmt_job.get("title") or "Tải video...",
                "filename": fmt_job.get("title") or fmt_job.get("output_filename") or fmt_job.get("url"),
                "created_at": fmt_job.get("created_at") or time.time(),
                "error": fmt_job.get("error") or fmt_job.get("error_message"),
                "saved_location": fmt_job.get("output_path") or fmt_job.get("destination_path"),
                "raw_downloader_job": fmt_job
            }
    except Exception:
        pass
    return None

try:
    from fastapi import FastAPI, HTTPException, Request, UploadFile, File, Form
    from fastapi.staticfiles import StaticFiles
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import FileResponse, JSONResponse
    import uvicorn

    from TOOL.api.srt_api import router as srt_router
    from TOOL.api.audio_api import router as audio_router
    from TOOL.api.video_api import router as video_router
    from TOOL.api.whisper_api import router as whisper_router
    from TOOL.api.tts_api import router as tts_router

    fastapi_app = FastAPI(
        title="KAGEVIETSUB",
        description="Studio xử lý phụ đề SRT, Video, Audio và Whisper trên Android & PC",
        version="1.0.0"
    )

    fastapi_app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    fastapi_app.include_router(srt_router)
    fastapi_app.include_router(audio_router)
    fastapi_app.include_router(video_router)
    fastapi_app.include_router(whisper_router)
    fastapi_app.include_router(tts_router)

    @fastapi_app.get("/api/health")
    def api_health():
        return get_health_data()

    @fastapi_app.get("/api/system/info")
    def api_system_info():
        return get_full_system_info()

    @fastapi_app.get("/api/tts/hardware-profile")
    def api_tts_hardware_profile():
        return HardwareOptimizer.get_hardware_profile()

    @fastapi_app.get("/api/jobs/{job_id}")
    def api_get_job(job_id: str):
        job = get_single_job_unified(job_id)
        if not job:
            raise HTTPException(status_code=404, detail=f"Không tìm thấy tác vụ với ID '{job_id}'")
        return job

    @fastapi_app.get("/api/jobs")
    def api_list_jobs():
        return {"jobs": get_all_unified_jobs()}

    @fastapi_app.get("/api/download/{filename}")
    def api_download(filename: str):
        safe_name = Path(filename).name
        file_path = OUTPUT_DIR / safe_name
        if not file_path.exists() or not file_path.is_file():
            temp_path = TEMP_DIR / safe_name
            if temp_path.exists() and temp_path.is_file():
                file_path = temp_path
            else:
                raise HTTPException(status_code=404, detail=f"File '{filename}' không tồn tại.")

        return FileResponse(
            path=str(file_path),
            filename=safe_name,
            media_type="application/octet-stream"
        )

    @fastapi_app.post("/api/cleanup")
    def api_cleanup():
        return CleanupService.clear_temp_folder()

    @fastapi_app.get("/api/version")
    def api_version():
        return {
            "version": get_local_version(),
            "app_name": "KAGEVIETSUB"
        }

    @fastapi_app.get("/api/export-project")
    def api_export_zip():
        zip_path = create_export_zip()
        return FileResponse(
            path=str(zip_path),
            filename="KAGEVIETSUB.zip",
            media_type="application/zip"
        )

    @fastapi_app.get("/api/downloader/ready")
    def api_downloader_ready():
        return handle_downloader_ready()

    @fastapi_app.post("/api/downloader/check-links")
    def api_downloader_check_links(payload: Dict[str, Any] = Body(...)):
        return handle_check_links(payload)

    @fastapi_app.post("/api/downloader/info")
    def api_downloader_info(payload: Dict[str, Any] = Body(...)):
        return handle_get_info(payload)

    @fastapi_app.post("/api/downloader/start")
    def api_downloader_start(payload: Dict[str, Any] = Body(default={})):
        return handle_start_download(payload)

    @fastapi_app.post("/api/downloader/update")
    def api_downloader_update(payload: Dict[str, Any] = Body(...)):
        return handle_update_job(payload)

    @fastapi_app.get("/api/downloader/status")
    def api_downloader_status_all():
        return handle_downloader_status()

    @fastapi_app.get("/api/downloader/status/{job_id}")
    def api_downloader_status_single(job_id: str):
        return handle_downloader_status(job_id)

    @fastapi_app.post("/api/downloader/cancel/{job_id}")
    def api_downloader_cancel(job_id: str):
        return handle_cancel_job(job_id)

    @fastapi_app.post("/api/downloader/cancel-all")
    @fastapi_app.post("/api/downloader/stop-all")
    def api_downloader_cancel_all():
        return handle_cancel_all()

    @fastapi_app.post("/api/downloader/retry/{job_id}")
    def api_downloader_retry_job(job_id: str, payload: Dict[str, Any] = Body(default={})):
        return handle_downloader_retry(job_id, payload)

    @fastapi_app.post("/api/downloader/remove/{job_id}")
    def api_downloader_remove_job(job_id: str):
        return handle_remove_job(job_id)

    if WEB_DIR.exists():
        if (WEB_DIR / "assets").exists():
            fastapi_app.mount("/assets", StaticFiles(directory=str(WEB_DIR / "assets")), name="assets")
        
        @fastapi_app.get("/{full_path:path}")
        async def serve_spa(full_path: str):
            if full_path.startswith("api/"):
                raise HTTPException(status_code=404, detail="API route not found")
            file_path = WEB_DIR / full_path
            if file_path.exists() and file_path.is_file():
                return FileResponse(file_path)
            index_file = WEB_DIR / "index.html"
            if index_file.exists():
                return FileResponse(index_file)
            raise HTTPException(status_code=404, detail="File not found")

    HAS_FASTAPI_SERVER = True
except Exception as e:
    logger.info(f"FastAPI / Uvicorn không khả dụng ({e}). Sử dụng Standalone Multi-threaded Engine.")
    HAS_FASTAPI_SERVER = False
    fastapi_app = None

class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True

class DSubRequestHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(WEB_DIR) if WEB_DIR.exists() else str(PROJECT_ROOT), **kwargs)

    def _send_cors_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, DELETE")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With")

    def _send_json(self, data: Any, status_code: int = 200):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        accept_enc = self.headers.get("Accept-Encoding", "")

        if "gzip" in accept_enc and len(body) > 512:
            try:
                compressed = gzip.compress(body, compresslevel=6)
                self.send_response(status_code)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Encoding", "gzip")
                self.send_header("Content-Length", str(len(compressed)))
                self.send_header("Vary", "Accept-Encoding")
                self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
                self._send_cors_headers()
                self.end_headers()
                self.wfile.write(compressed)
                return
            except Exception:
                pass

        self.send_response(status_code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self._send_cors_headers()
        self.end_headers()
        self.wfile.write(body)

    def _serve_static_file(self, file_path: Path):
        if not file_path.exists() or not file_path.is_file():
            self.send_error(404, f"File '{file_path.name}' không tồn tại.")
            return

        st = file_path.stat()
        etag = f'"{int(st.st_mtime)}-{st.st_size}"'
        if_none_match = self.headers.get("If-None-Match")
        if if_none_match and if_none_match.strip() == etag:
            self.send_response(304)
            self._send_cors_headers()
            self.end_headers()
            return

        suffix = file_path.suffix.lower()
        mime_types = {
            ".html": "text/html; charset=utf-8",
            ".js": "application/javascript; charset=utf-8",
            ".css": "text/css; charset=utf-8",
            ".json": "application/json; charset=utf-8",
            ".svg": "image/svg+xml",
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".gif": "image/gif",
            ".ico": "image/x-icon",
            ".woff": "font/woff",
            ".woff2": "font/woff2",
            ".ttf": "font/ttf",
            ".txt": "text/plain; charset=utf-8"
        }
        mime = mime_types.get(suffix, "application/octet-stream")

        if suffix in [".js", ".css", ".png", ".svg", ".ico", ".woff", ".woff2"]:
            cache_ctrl = "public, max-age=86400"
        else:
            cache_ctrl = "no-cache"

        try:
            with open(file_path, "rb") as f:
                raw_data = f.read()
        except Exception as e:
            self.send_error(500, f"Error reading file: {e}")
            return

        accept_enc = self.headers.get("Accept-Encoding", "")
        is_compressible = (suffix in [".html", ".js", ".css", ".json", ".svg", ".txt"]) and (len(raw_data) > 256)

        if is_compressible and "gzip" in accept_enc:
            try:
                compressed = gzip.compress(raw_data, compresslevel=6)
                self.send_response(200)
                self.send_header("Content-Type", mime)
                self.send_header("Content-Encoding", "gzip")
                self.send_header("Content-Length", str(len(compressed)))
                self.send_header("ETag", etag)
                self.send_header("Cache-Control", cache_ctrl)
                self.send_header("Vary", "Accept-Encoding")
                self._send_cors_headers()
                self.end_headers()
                self.wfile.write(compressed)
                return
            except Exception:
                pass

        self.send_response(200)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(raw_data)))
        self.send_header("ETag", etag)
        self.send_header("Cache-Control", cache_ctrl)
        self._send_cors_headers()
        self.end_headers()
        self.wfile.write(raw_data)

    def _send_file_download(self, file_path: Path, filename: str, mime_type: str = "application/octet-stream", is_inline: bool = False):
        if not file_path or not file_path.exists() or not file_path.is_file():
            self._send_json({"error": f"File '{filename}' không tồn tại."}, 404)
            return

        file_size = file_path.stat().st_size
        range_header = self.headers.get("Range")
        disposition = "inline" if is_inline else f'attachment; filename="{filename}"'

        if range_header and range_header.strip().startswith("bytes="):
            try:
                ranges = range_header.strip()[6:].split("-")
                start = int(ranges[0]) if ranges[0] else 0
                end = int(ranges[1]) if len(ranges) > 1 and ranges[1] else file_size - 1

                if start >= file_size or end >= file_size or start > end:
                    self.send_response(416)
                    self.send_header("Content-Range", f"bytes */{file_size}")
                    self.send_header("Content-Length", "0")
                    self._send_cors_headers()
                    self.end_headers()
                    return

                length = end - start + 1
                self.send_response(206)
                self.send_header("Content-Type", mime_type)
                self.send_header("Content-Length", str(length))
                self.send_header("Content-Range", f"bytes {start}-{end}/{file_size}")
                self.send_header("Accept-Ranges", "bytes")
                self.send_header("Content-Disposition", disposition)
                self._send_cors_headers()
                self.end_headers()

                with open(file_path, "rb") as f:
                    f.seek(start)
                    remaining = length
                    chunk_size = 64 * 1024
                    while remaining > 0:
                        read_bytes = min(chunk_size, remaining)
                        data = f.read(read_bytes)
                        if not data:
                            break
                        self.wfile.write(data)
                        remaining -= len(data)
                return
            except Exception as ex:
                logger.warning(f"Error serving Range request for {filename}: {ex}")

        # Chuẩn HTTP 200 OK Streaming
        self.send_response(200)
        self.send_header("Content-Type", mime_type)
        self.send_header("Content-Length", str(file_size))
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Disposition", disposition)
        self._send_cors_headers()
        self.end_headers()

        with open(file_path, "rb") as f:
            chunk_size = 64 * 1024
            while True:
                data = f.read(chunk_size)
                if not data:
                    break
                self.wfile.write(data)

    def do_OPTIONS(self):
        self.send_response(204)
        self._send_cors_headers()
        self.end_headers()

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path == "/api/health":
            return self._send_json(get_health_data())

        if path == "/api/system/info":
            return self._send_json(get_full_system_info())

        if path == "/api/jobs":
            return self._send_json({"jobs": get_all_unified_jobs()})

        if path.startswith("/api/jobs/"):
            job_id = path[len("/api/jobs/"):]
            job = get_single_job_unified(job_id)
            if not job:
                return self._send_json({"detail": f"Không tìm thấy job '{job_id}'"}, 404)
            return self._send_json(job)

        if path.startswith("/api/download/"):
            raw_filename = urllib.parse.unquote(path[len("/api/download/"):])
                                          
            if ".." in raw_filename or "/" in raw_filename or "\\" in raw_filename:
                return self._send_json({"detail": "Yêu cầu đường dẫn không an toàn."}, 400)
            safe_name = Path(raw_filename).name
            target = KAGE_DOWNLOAD_DIR / safe_name
            if not target.exists():
                target = OUTPUT_DIR / safe_name
            if not target.exists():
                target = TEMP_DIR / safe_name
            return self._send_file_download(target, safe_name)

        if path == "/api/export-project":
            zip_p = create_export_zip()
            return self._send_file_download(zip_p, "KAGEVIETSUB.zip", "application/zip")

        if path == "/api/srt/translate/providers":
            return self._send_json(handle_get_translate_providers())

        if path.startswith("/api/srt/translate/status/"):
            trans_jid = path[len("/api/srt/translate/status/"):].strip("/")
            return self._send_json(handle_get_translation_status(trans_jid))

        if path == "/api/ds2api/status":
            from TOOL.services.ds2api_service import ds2api_service
            return self._send_json(ds2api_service.get_status())

        if path == "/api/ds2api/models":
            from TOOL.services.ds2api_service import ds2api_service
            return self._send_json({"models": ds2api_service.get_models()})

        if path == "/api/ds2api/accounts":
            from TOOL.services.ds2api_service import DS2APIConfigManager
            return self._send_json({"accounts": DS2APIConfigManager.get_public_accounts()})

        if path == "/api/whisper/models":
            return self._send_json(handle_whisper_models())

        if path == "/api/tts/voices":
            return self._send_json(handle_tts_voices())

        if path == "/api/tts/hardware-profile":
            return self._send_json(HardwareOptimizer.get_hardware_profile())

        if path in ["/api/tts/merge-recovery/folders", "/api/tts/merge-recovery/sources"]:
            try:
                return self._send_json(handle_tts_merge_recovery_folders())
            except Exception as e:
                return self._send_json({"detail": str(e)}, 500)

        if path.startswith("/api/tts/status/") or path == "/api/tts/status" or (path.startswith("/api/tts/") and path.endswith("/status")):
            query_params = urllib.parse.parse_qs(parsed.query)
            inc_subs = query_params.get("include_subtitles", ["false"])[0].lower() in ["true", "1", "yes"]
            if path.startswith("/api/tts/status/"):
                tts_jid = path[len("/api/tts/status/"):].strip("/")
            elif path.startswith("/api/tts/") and path.endswith("/status"):
                tts_jid = path[len("/api/tts/"): -len("/status")].strip("/")
            else:
                tts_jid = query_params.get("job_id", [""])[0]
            try:
                return self._send_json(handle_tts_get_status(tts_jid, include_subtitles=inc_subs))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 404)

        if path.startswith("/api/tts/job/"):
            tts_jid = path[len("/api/tts/job/"):].strip("/")
            try:
                return self._send_json(handle_tts_get_job(tts_jid))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 404)

        if path.startswith("/api/tts/preview/"):
            parts = path[len("/api/tts/preview/"):].split("?")[0].split("/")
            if len(parts) >= 2:
                jid, idx_str = parts[0], parts[1]
                try:
                    idx = int(idx_str)
                    preview_p = handle_tts_preview(jid, idx)
                    if not preview_p.exists():
                        return self._send_json({"detail": "File preview không tồn tại."}, 404)
                    file_size = preview_p.stat().st_size
                    media_type = "audio/wav" if preview_p.suffix.lower() == ".wav" else "audio/mpeg"
                    self.send_response(200)
                    self.send_header("Content-Type", media_type)
                    self.send_header("Content-Length", str(file_size))
                    self.send_header("Accept-Ranges", "bytes")
                    self.send_header("Cache-Control", "public, max-age=3600")
                    self._send_cors_headers()
                    self.end_headers()
                    with open(preview_p, "rb") as f:
                        shutil.copyfileobj(f, self.wfile)
                    return
                except Exception as e:
                    return self._send_json({"detail": str(e)}, 404)

        if path == "/api/downloader/ready":
            return self._send_json(handle_downloader_ready())

        if path.startswith("/api/downloader/download/") or path == "/api/downloader/download":
            query_params = urllib.parse.parse_qs(parsed.query)
            dl_jid = path[len("/api/downloader/download/"):].strip("/") if path.startswith("/api/downloader/download/") else query_params.get("job_id", [""])[0]
            file_type = query_params.get("type", ["media"])[0]
            try:
                dl_path, dl_fn, dl_mime = handle_downloader_download_file(dl_jid, file_type=file_type)
                return self._send_file_download(dl_path, dl_fn, dl_mime)
            except Exception as e:
                return self._send_json({"error": str(e), "detail": str(e)}, 404)

        if path == "/api/downloader/status" or path.startswith("/api/downloader/status/") or path.startswith("/api/downloader/job/"):
            query_params = urllib.parse.parse_qs(parsed.query)
            if path.startswith("/api/downloader/status/"):
                dl_jid = path[len("/api/downloader/status/"):].strip("/")
            elif path.startswith("/api/downloader/job/"):
                dl_jid = path[len("/api/downloader/job/"):].strip("/")
            else:
                dl_jid = query_params.get("job_id", [""])[0]
            return self._send_json(handle_downloader_status(dl_jid if dl_jid else None))

        if path == "/api/version":
            return self._send_json({
                "version": get_local_version(),
                "app_name": "KAGEVIETSUB"
            })

        if path == "/api/storage/info":
            return self._send_json({
                "status": "ok",
                "platform": StorageService.get_platform(),
                "root": str(StorageService.get_root()),
                "data_dir": str(StorageService.get_data_dir()),
                "upload_dir": str(StorageService.get_upload_dir()),
                "output_dir": str(StorageService.get_output_dir()),
                "temp_dir": str(StorageService.get_temp_dir()),
                "models_dir": str(StorageService.get_models_dir())
            })

        if path == "/api/files/scan":
            upload_dir = StorageService.get_upload_dir()
            output_dir = StorageService.get_output_dir()
            data_dir = StorageService.get_data_dir()
            
            srt_files = []
            video_files = []
            audio_files = []
            all_files = []

            scanned_paths = set()
            scan_roots = [upload_dir, output_dir, data_dir / "temp"]
            for base in scan_roots:
                if not base.exists():
                    continue
                try:
                    for p in base.rglob("*"):
                        if p.is_file() and p.stat().st_size > 0 and not p.name.startswith("."):
                            res_path = str(p.resolve())
                            if res_path in scanned_paths:
                                continue
                            scanned_paths.add(res_path)
                            
                            ext = p.suffix.lower()
                            rel_loc = str(p.relative_to(PROJECT_ROOT)) if p.is_relative_to(PROJECT_ROOT) else p.name
                            item_info = {
                                "filename": p.name,
                                "filepath": str(p),
                                "relative_location": rel_loc,
                                "size": p.stat().st_size,
                                "modified_at": p.stat().st_mtime,
                                "ext": ext
                            }
                            
                            if ext in [".srt"]:
                                item_info["type"] = "srt"
                                srt_files.append(item_info)
                            elif ext in [".mp4", ".mkv", ".mov", ".avi", ".webm", ".flv", ".m4v"]:
                                item_info["type"] = "video"
                                video_files.append(item_info)
                            elif ext in [".mp3", ".m4a", ".wav", ".aac", ".flac", ".ogg", ".opus", ".wma"]:
                                item_info["type"] = "audio"
                                audio_files.append(item_info)
                            else:
                                item_info["type"] = "other"
                            
                            all_files.append(item_info)
                except Exception as ex:
                    logger.debug(f"Scan directory skip {base}: {ex}")

            return self._send_json({
                "status": "ok",
                "platform": StorageService.get_platform(),
                "srt_files": srt_files,
                "video_files": video_files,
                "audio_files": audio_files,
                "all_files": all_files
            })

        if path == "/api/logs" or path == "/api/logs/realtime":
            try:
                from TOOL.web_server.adapter import WebServerAdapter
                query_params = urllib.parse.parse_qs(parsed.query)
                lines = int(query_params.get("lines", ["150"])[0])
                res = WebServerAdapter.get_realtime_logs(lines=lines)
                return self._send_json(res)
            except Exception as e:
                return self._send_json({"error": str(e), "raw_text": f"Lỗi đọc log: {e}"}, 500)

        if path == "/api/logs/download":
            try:
                from TOOL.web_server.adapter import WebServerAdapter
                log_p = WebServerAdapter.get_latest_log_path()
                if not log_p or not log_p.exists():
                    return self._send_json({"error": "Chưa có file log ngày hôm nay"}, 404)
                self.send_response(200)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.send_header("Content-Disposition", f'attachment; filename="{log_p.name}"')
                self.send_header("Content-Length", str(log_p.stat().st_size))
                self._send_cors_headers()
                self.end_headers()
                with open(log_p, "rb") as f:
                    shutil.copyfileobj(f, self.wfile)
                return
            except Exception as e:
                return self._send_json({"error": str(e)}, 500)

        if path == "/api/download" or path.startswith("/api/download/") or path == "/api/files/download" or path.startswith("/api/files/download/"):
            query_params = urllib.parse.parse_qs(parsed.query)
            target_param = query_params.get("path", [""])[0] or query_params.get("filename", [""])[0] or query_params.get("file", [""])[0]
            if not target_param:
                if path.startswith("/api/download/"):
                    target_param = urllib.parse.unquote(path[len("/api/download/"):])
                elif path.startswith("/api/files/download/"):
                    target_param = urllib.parse.unquote(path[len("/api/files/download/"):])
            
            if target_param:
                from TOOL.web_server.adapter import WebServerAdapter
                target_path = WebServerAdapter.resolve_download_path(target_param)
                
                if target_path and is_safe_path(target_path) and target_path.exists() and target_path.is_file():
                    filename = target_path.name
                    file_size = target_path.stat().st_size
                    self.send_response(200)
                    self.send_header("Content-Type", "application/octet-stream")
                    self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
                    self.send_header("Content-Length", str(file_size))
                    self._send_cors_headers()
                    self.end_headers()
                    with open(target_path, "rb") as f:
                        shutil.copyfileobj(f, self.wfile)
                    return
                else:
                    return self._send_json({"error": "File không tồn tại hoặc không hợp lệ", "detail": f"Không tìm thấy: {target_param}"}, 404)

        target = WEB_DIR / path.lstrip("/")
        if target.exists() and target.is_file():
            return self._serve_static_file(target)
        index_file = WEB_DIR / "index.html"
        if index_file.exists():
            return self._serve_static_file(index_file)
        return super().do_GET()

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        content_type = self.headers.get("Content-Type", "")
        content_length = int(self.headers.get("Content-Length", 0))

        if "multipart/form-data" in content_type:
            raw_body = self.rfile.read(content_length)
            boundary = content_type.split("boundary=")[1].encode("utf-8")
            parts = raw_body.split(b"--" + boundary)

            form_fields = {}
            uploaded_files = []

            for p in parts:
                if not p or p == b"--\r\n" or p == b"--":
                    continue
                header_part, _, body_part = p.partition(b"\r\n\r\n")
                body_part = body_part.rstrip(b"\r\n")
                header_str = header_part.decode("utf-8", errors="ignore")

                if 'filename="' in header_str:
                    fn_match = re_filename(header_str)
                    if fn_match and body_part:
                        saved_p = FileService.save_upload(body_part, fn_match)
                        uploaded_files.append((fn_match, saved_p))
                elif 'name="' in header_str:
                    field_name = re_name(header_str)
                    if field_name:
                        form_fields[field_name] = body_part.decode("utf-8", errors="ignore")

            if path == "/api/audio/merge":
                paths = [p for _, p in uploaded_files]
                out_name = form_fields.get("output_filename", "combined.mp3")
                sort_alpha = form_fields.get("sort_alphabetical", "true").lower() == "true"
                try:
                    res = handle_audio_merge(paths, out_name, sort_alpha)
                    return self._send_json(res)
                except Exception as e:
                    return self._send_json({"detail": str(e)}, 400)

            if path == "/api/video/cut":
                if not uploaded_files:
                    return self._send_json({"detail": "Chưa chọn file video"}, 400)
                fn, p = uploaded_files[0]
                mins = int(form_fields.get("segment_minutes", 5))
                mode = form_fields.get("mode", "copy")
                res = handle_video_cut(p, fn, mins, mode)
                return self._send_json(res)

            if path == "/api/video/merge":
                paths = [p for _, p in uploaded_files]
                out_name = form_fields.get("output_filename", "merged_video.mp4")
                mode = form_fields.get("mode", "lossless")
                caption = form_fields.get("caption") or None
                font_sz = int(form_fields.get("font_size", 24))
                font_col = form_fields.get("font_color", "white")
                pos = form_fields.get("caption_position", "bottom")
                try:
                    res = handle_video_merge(paths, out_name, mode, caption, font_sz, font_col, pos)
                    return self._send_json(res)
                except Exception as e:
                    return self._send_json({"detail": str(e)}, 400)

            if path == "/api/video/compress":
                if not uploaded_files:
                    return self._send_json({"detail": "Chưa chọn file video"}, 400)
                fn, p = uploaded_files[0]
                crf = int(form_fields.get("crf", 18))
                preset = form_fields.get("preset", "slow")
                codec = form_fields.get("codec", "libx264")
                res = handle_video_compress(p, fn, crf, preset, codec)
                return self._send_json(res)

            if path == "/api/whisper/transcribe":
                if not uploaded_files:
                    return self._send_json({"detail": "Chưa chọn file âm thanh/video"}, 400)
                fn, p = uploaded_files[0]
                model_sz = form_fields.get("model_size", "large-v3-turbo")
                beam = int(form_fields.get("beam_size", 5))
                lang = form_fields.get("language", "zh")
                mw = int(form_fields.get("max_words", 20))
                md = float(form_fields.get("max_duration", 6.0))
                st = float(form_fields.get("silence_threshold", 0.3))
                res = handle_whisper_transcribe(p, fn, model_sz, beam, lang, mw, md, st)
                return self._send_json(res)

            if path == "/api/video/info":
                if not uploaded_files:
                    return self._send_json({"detail": "Chưa chọn file"}, 400)
                fn, p = uploaded_files[0]
                info = FFmpegService.get_media_info(p)
                return self._send_json({"filename": fn, "info": info})

            if path == "/api/files/upload":
                if not uploaded_files:
                    return self._send_json({"detail": "Chưa chọn file upload"}, 400)
                files_result = []
                for fn, p in uploaded_files:
                    ext = p.suffix.lower()
                    if ext in [".srt"]:
                        ftype = "srt"
                    elif ext in [".mp4", ".mkv", ".mov", ".avi", ".webm", ".flv", ".m4v"]:
                        ftype = "video"
                    elif ext in [".mp3", ".m4a", ".wav", ".aac", ".flac", ".ogg", ".opus", ".wma"]:
                        ftype = "audio"
                    else:
                        ftype = "other"
                    files_result.append({
                        "filename": fn,
                        "saved_path": str(p),
                        "saved_location": f"DATA/uploads/{p.name}",
                        "size": p.stat().st_size if p.exists() else 0,
                        "file_type": ftype
                    })
                return self._send_json({
                    "status": "ok",
                    "message": "Upload file thành công",
                    "files": files_result,
                    "first_file": files_result[0]
                })

        raw_body = self.rfile.read(content_length).decode("utf-8") if content_length > 0 else "{}"
        try:
            payload = json.loads(raw_body) if raw_body else {}
        except Exception:
            payload = {}

        if path == "/api/cleanup":
            return self._send_json(CleanupService.cleanup_orphaned_temp())

        if path == "/api/srt/translate/check-api":
            return self._send_json(handle_check_api_key(
                payload.get("provider", "deepseek"),
                payload.get("api_key", ""),
                payload.get("model", "deepseek-chat")
            ))

        if path == "/api/srt/translate/start":
            return self._send_json(handle_start_translation(
                content=payload.get("content", ""),
                filename=payload.get("filename", "subtitle.srt"),
                api_pool=payload.get("api_pool", []),
                source_lang=payload.get("source_lang", "zh"),
                target_lang=payload.get("target_lang", "vi"),
                batch_size=int(payload.get("batch_size", 20)),
                user_prompt=payload.get("user_prompt")
            ))

        if path.startswith("/api/srt/translate/pause/"):
            trans_jid = path[len("/api/srt/translate/pause/"):].strip("/")
            return self._send_json(handle_pause_translation(trans_jid))

        if path.startswith("/api/srt/translate/resume/"):
            trans_jid = path[len("/api/srt/translate/resume/"):].strip("/")
            return self._send_json(handle_resume_translation(trans_jid))

        if path.startswith("/api/srt/translate/stop/"):
            trans_jid = path[len("/api/srt/translate/stop/"):].strip("/")
            return self._send_json(handle_stop_translation(trans_jid))

        if path.startswith("/api/srt/translate/retry/"):
            trans_jid = path[len("/api/srt/translate/retry/"):].strip("/")
            return self._send_json(handle_retry_translation(trans_jid))

        if path == "/api/ds2api/start":
            from TOOL.services.ds2api_service import ds2api_service
            return self._send_json(ds2api_service.start_service())

        if path == "/api/ds2api/stop":
            from TOOL.services.ds2api_service import ds2api_service
            return self._send_json(ds2api_service.stop_service())

        if path == "/api/ds2api/accounts":
            from TOOL.services.ds2api_service import DS2APIConfigManager
            name = payload.get("name", "")
            login_id = payload.get("login_id") or payload.get("email") or payload.get("mobile") or ""
            password = payload.get("password", "")
            is_mobile = bool(payload.get("is_mobile", False))
            if not login_id or not password:
                return self._send_json({"detail": "Vui lòng nhập đầy đủ tài khoản (Email/SĐT) và mật khẩu."}, 400)
            res = DS2APIConfigManager.add_account(name, login_id, password, is_mobile)
            return self._send_json(res)

        if path == "/api/ds2api/accounts/test":
            from TOOL.services.ds2api_service import ds2api_service
            acc_id = payload.get("account_id", "")
            if not acc_id:
                return self._send_json({"detail": "Thiếu account_id để kiểm tra."}, 400)
            return self._send_json(ds2api_service.test_account(acc_id))

        if path.startswith("/api/ds2api/accounts/delete/") or path == "/api/ds2api/accounts/delete":
            from TOOL.services.ds2api_service import DS2APIConfigManager
            acc_id = path[len("/api/ds2api/accounts/delete/"):].strip("/") if path.startswith("/api/ds2api/accounts/delete/") else payload.get("account_id", "")
            if not acc_id:
                return self._send_json({"detail": "Thiếu account_id để xóa."}, 400)
            ok = DS2APIConfigManager.delete_account(acc_id)
            return self._send_json({"status": "ok" if ok else "error", "message": "Đã xóa tài khoản." if ok else "Không tìm thấy tài khoản."})

        if path == "/api/files/upload":
            filename = payload.get("filename", "upload.srt")
            content = payload.get("content", "")
            if content:
                dest = FileService.save_upload(content.encode("utf-8"), filename)
                ext = dest.suffix.lower()
                ftype = "srt" if ext == ".srt" else ("video" if ext in [".mp4", ".mkv", ".mov"] else "audio" if ext in [".mp3", ".wav", ".m4a"] else "other")
                return self._send_json({
                    "status": "ok",
                    "message": "Upload content thành công",
                    "filename": filename,
                    "saved_path": str(dest),
                    "saved_location": f"DATA/uploads/{dest.name}",
                    "size": dest.stat().st_size if dest.exists() else 0,
                    "file_type": ftype
                })
            return self._send_json({"detail": "Nội dung hoặc file upload rỗng"}, 400)

        if path == "/api/whisper/models/download":
            model_id = payload.get("model_id", "")
            try:
                return self._send_json(handle_download_whisper_model(model_id))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/whisper/models/scan":
            return self._send_json(handle_whisper_models())

        if path == "/api/tts/parse-srt":
            srt_cnt = payload.get("srt_content") or payload.get("content") or ""
            try:
                return self._send_json(handle_tts_parse_srt(srt_cnt))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/tts/create-job":
            srt_cnt = payload.get("srt_content") or payload.get("content") or ""
            vc = payload.get("voice", "BV421_vivn_streaming")
            spd = float(payload.get("speed", 1.0))
            thrd = int(payload.get("threads", 5))
            fmt = payload.get("audio_format", "mp3")
            out_fn = payload.get("output_filename")
            try:
                return self._send_json(handle_tts_create_job(srt_cnt, vc, spd, thrd, fmt, out_fn))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/tts/retry":
            jid = payload.get("job_id", "")
            idx = int(payload.get("subtitle_index", 1))
            vc = payload.get("voice")
            spd = float(payload.get("speed")) if payload.get("speed") is not None else None
            try:
                return self._send_json(handle_tts_retry(jid, idx, vc, spd))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path in ["/api/tts/retry-failed", "/api/tts/retry-all", "/api/tts/retry-all-failed"] or (path.startswith("/api/tts/") and path.endswith("/retry-failed")):
            jid = payload.get("job_id", "")
            if not jid and path.startswith("/api/tts/") and path.endswith("/retry-failed"):
                jid = path[len("/api/tts/"):].split("/")[0]
            vc = payload.get("voice")
            spd = float(payload.get("speed")) if payload.get("speed") is not None else None
            thrd = int(payload.get("threads")) if payload.get("threads") is not None else None
            try:
                return self._send_json(handle_tts_retry_failed(jid, vc, spd, thrd))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/tts/merge-recovery/start":
            folder_p = payload.get("folder_path", "") or payload.get("source_id", "")
            srt_c = payload.get("srt_content", "")
            out_fn = payload.get("output_filename", "tts_recovered_audio.mp3")
            fmt = payload.get("audio_format")
            try:
                return self._send_json(handle_tts_merge_recovery_start(folder_p, srt_c, out_fn, fmt))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path in ["/api/tts/merge-recovery/cancel", "/api/tts/merge-recovery/cancel/"] or path.startswith("/api/tts/merge-recovery/cancel/"):
            jid = path[len("/api/tts/merge-recovery/cancel/"):].strip("/") if path.startswith("/api/tts/merge-recovery/cancel/") else payload.get("job_id", "")
            try:
                return self._send_json(handle_tts_stop(jid))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/tts/pause" or (path.startswith("/api/tts/") and path.endswith("/pause")):
            jid = path[len("/api/tts/"): -len("/pause")].strip("/") if path.endswith("/pause") and path != "/api/tts/pause" else payload.get("job_id", "")
            try:
                return self._send_json(handle_tts_pause(jid))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/tts/resume" or (path.startswith("/api/tts/") and path.endswith("/resume")):
            jid = path[len("/api/tts/"): -len("/resume")].strip("/") if path.endswith("/resume") and path != "/api/tts/resume" else payload.get("job_id", "")
            try:
                return self._send_json(handle_tts_resume(jid))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/tts/stop" or (path.startswith("/api/tts/") and path.endswith("/stop")):
            jid = path[len("/api/tts/"): -len("/stop")].strip("/") if path.endswith("/stop") and path != "/api/tts/stop" else payload.get("job_id", "")
            try:
                return self._send_json(handle_tts_stop(jid))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/downloader/check-links":
            try:
                return self._send_json(handle_check_links(payload))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/downloader/info":
            try:
                return self._send_json(handle_get_info(payload))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/downloader/start":
            try:
                return self._send_json(handle_start_download(payload))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/downloader/update":
            try:
                return self._send_json(handle_update_job(payload))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/downloader/cancel-all" or path == "/api/downloader/stop-all":
            try:
                return self._send_json(handle_cancel_all())
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path.startswith("/api/downloader/cancel/") or path == "/api/downloader/cancel":
            dl_jid = path[len("/api/downloader/cancel/"):].strip("/") if path.startswith("/api/downloader/cancel/") else payload.get("job_id", "")
            try:
                return self._send_json(handle_cancel_job(dl_jid))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path.startswith("/api/downloader/retry/") or path == "/api/downloader/retry":
            dl_jid = path[len("/api/downloader/retry/"):].strip("/") if path.startswith("/api/downloader/retry/") else payload.get("job_id", "")
            try:
                return self._send_json(handle_downloader_retry(dl_jid, payload))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path.startswith("/api/downloader/remove/") or path == "/api/downloader/remove":
            dl_jid = path[len("/api/downloader/remove/"):].strip("/") if path.startswith("/api/downloader/remove/") else payload.get("job_id", "")
            try:
                return self._send_json(handle_remove_job(dl_jid))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/shutdown":
            try:
                threading.Thread(target=perform_graceful_shutdown, daemon=True).start()
                return self._send_json({"status": "ok", "message": "Máy chủ đang tiến hành dừng an toàn..."})
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/tts/merge" or (path.startswith("/api/tts/") and path.endswith("/merge")):
            jid = path[len("/api/tts/"): -len("/merge")].strip("/") if path.endswith("/merge") and path != "/api/tts/merge" else payload.get("job_id", "")
            out_fn = payload.get("output_filename")
            fmt = payload.get("audio_format")
            try:
                return self._send_json(handle_tts_merge(jid, out_fn, fmt))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        content = payload.get("content", "")
        rules = payload.get("rules")

        if path == "/api/srt/parse":
            return self._send_json(handle_parse_srt(content))
        if path == "/api/srt/remove-trailing-punctuation":
            return self._send_json(handle_remove_trailing_punct(content))
        if path == "/api/srt/remove-leading-ellipsis":
            return self._send_json(handle_remove_leading_ellipsis(content))
        if path == "/api/srt/replace":
            return self._send_json(handle_replace_rules(content, rules))
        if path == "/api/srt/avoid-overlap":
            return self._send_json(handle_avoid_overlap(content))
        if path == "/api/srt/purple-sequence":
            return self._send_json(handle_purple_sequence(content, rules))
        if path == "/api/srt/fix-repeat-2-3":
            return self._send_json(handle_fix_repeat_2_3(content))
        if path == "/api/srt/fix-repeat-4-5":
            return self._send_json(handle_fix_repeat_4_5(content))
        if path == "/api/srt/merge-short":
            return self._send_json(handle_merge_short(content))
        if path == "/api/srt/all-steps":
            return self._send_json(handle_all_steps(content, rules))
        if path == "/api/srt/uppercase":
            return self._send_json(handle_uppercase(content))
        if path == "/api/srt/save":
            filename = payload.get("filename", "edited.srt")
            try:
                return self._send_json(handle_save_srt(content, filename))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)
        if path == "/api/srt/split":
            s_per = int(payload.get("sentences_per_file", 10))
            base_n = payload.get("base_name", "subtitle")
            try:
                return self._send_json(handle_split_srt(content, s_per, base_n))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        return self._send_json({"detail": f"Endpoint POST '{path}' không tồn tại."}, 404)

def re_filename(headers: str) -> Optional[str]:
    import re
    m = re.search(r'filename="([^"]+)"', headers)
    return m.group(1) if m else None

def re_name(headers: str) -> Optional[str]:
    import re
    m = re.search(r'name="([^"]+)"', headers)
    return m.group(1) if m else None

_shutdown_in_progress = False

def perform_graceful_shutdown():
    """Thực hiện quy trình dừng server an toàn 3 bước."""
    global _shutdown_in_progress
    if _shutdown_in_progress:
        return
    _shutdown_in_progress = True

    print("\n==================================================")
    print("KAGEVIETSUB")
    print("Đang dừng server...\n")
    print("[1/3] Dừng nhận job mới...")
    job_manager.request_shutdown(timeout_sec=2.0)
    downloader_manager.shutdown()
    time.sleep(0.5)

    print("[2/3] Dọn file tạm...")
    CleanupService.run_shutdown_cleanup()
    print("✓ Đã dọn file tạm")

    print("[3/3] Đóng server...")
    time.sleep(0.3)
    try:
        pid_file = DATA_DIR / "runtime" / "kagevietsub.pid"
        if pid_file.exists():
            pid_file.unlink(missing_ok=True)
    except Exception:
        pass
    print("✓ Server đã dừng")
    print("==================================================\n")

def run_server(host: str = HOST, port: int = PORT):
    ensure_directories()
    CleanupService.cleanup_orphaned_temp()

    from TOOL.services.system_info import SystemInfoDetector
    try:
        SystemInfoDetector.log_startup_session(host, port)
    except Exception as e:
        logger.warning(f"Lỗi ghi startup log: {e}")

    if HAS_FASTAPI_SERVER and fastapi_app is not None:
        try:
            logger.info(f"Khởi chạy FastAPI + Uvicorn tại http://{host}:{port}")
            print(f"\n[✓] KAGEVIETSUB SERVER ONLINE: http://{host}:{port}")
            uvicorn.run(fastapi_app, host=host, port=port, log_level="warning")
            perform_graceful_shutdown()
            return
        except KeyboardInterrupt:
            perform_graceful_shutdown()
            return
        except Exception as e:
            logger.warning(f"Uvicorn gặp lỗi ({e}). Tự động chuyển sang Standalone Server.")

    logger.info(f"Khởi chạy Standalone Multi-Threaded Engine tại http://{host}:{port}")
    server = ThreadedHTTPServer((host, port), DSubRequestHandler)
    print(f"\n[✓] KAGEVIETSUB SERVER ONLINE: http://{host}:{port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.server_close()
        perform_graceful_shutdown()

if __name__ == "__main__":
    run_server()
