#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB - SYSTEM & ENVIRONMENT CHECK
==============================================================================
Kiểm tra tính tương thích môi trường:
- Python 3.14+
- Hệ điều hành (Android / Termux / Linux / Windows / macOS)
- Kiến trúc CPU (ARM64 / x86_64)
- FFmpeg & FFprobe
- FastAPI, Uvicorn, Starlette
- Các Engine: SRT, Audio, Video, TTS
- Các thành phần OPTIONAL: Whisper AI, OCR
==============================================================================
"""

import os
import sys
import time
import shutil
import platform
import subprocess
from pathlib import Path
from typing import Dict, Any, Optional

TOOL_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = TOOL_DIR.parent

if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
if str(TOOL_DIR) not in sys.path:
    sys.path.insert(0, str(TOOL_DIR))

try:
    from TOOL.cli_ui import Colors, Icons, print_step, print_banner
except ImportError:
    class Colors:
        RESET = BOLD = DIM = GREEN = YELLOW = RED = CYAN = WHITE = GRAY = BRIGHT_CYAN = BRIGHT_WHITE = ""
    class Icons:
        CHECK = "✓"
        CROSS = "✕"
        WARN = "!"
        INFO = "●"
        CIRCLE_OPT = "○"
        ARROW = "→"

def is_android() -> bool:
    """Xác định xem môi trường có phải Android / Termux hay không."""
    if os.environ.get("TERMUX_VERSION") or os.environ.get("PREFIX", "").startswith("/data/data/com.termux"):
        return True
    if Path("/data/data/com.termux").exists():
        return True
    system_str = platform.system().lower()
    if "android" in system_str or "android" in platform.platform().lower():
        return True
    try:
        if hasattr(os, "uname") and "android" in os.uname().release.lower():
            return True
    except Exception:
        pass
    return False

def check_python_version() -> Dict[str, Any]:
    """Kiểm tra phiên bản Python."""
    major, minor, micro = sys.version_info.major, sys.version_info.minor, sys.version_info.micro
    version_str = f"{major}.{minor}.{micro}"
    is_314 = (major == 3 and minor == 14)
    is_supported = (major == 3 and minor >= 8)
    return {
        "version": version_str,
        "is_314": is_314,
        "is_supported": is_supported,
        "executable": sys.executable
    }

def check_ffmpeg() -> Dict[str, Any]:
    """Kiểm tra cài đặt FFmpeg và FFprobe."""
    ffmpeg_path = shutil.which("ffmpeg")
    ffprobe_path = shutil.which("ffprobe")
    ffmpeg_version = "Unknown"

    if ffmpeg_path:
        try:
            res = subprocess.run([ffmpeg_path, "-version"], capture_output=True, text=True, timeout=5)
            first_line = res.stdout.split("\n")[0] if res.stdout else ""
            ffmpeg_version = first_line.split("version")[1].split()[0] if "version" in first_line else "Available"
        except Exception:
            ffmpeg_version = "Available"

    return {
        "ffmpeg_installed": ffmpeg_path is not None,
        "ffprobe_installed": ffprobe_path is not None,
        "ffmpeg_path": ffmpeg_path,
        "ffprobe_path": ffprobe_path,
        "ffmpeg_version": ffmpeg_version
    }

def check_gpu_acceleration() -> Dict[str, Any]:
    """Kiểm tra tăng tốc phần cứng (NVIDIA NVENC). Bỏ qua trên Android."""
    if is_android():
        return {
            "nvenc_available": False,
            "status": "CPU (Software libx264/AAC - Chuẩn Android)",
            "encoder": "libx264"
        }
    try:
        res = subprocess.run(["ffmpeg", "-encoders"], capture_output=True, text=True, timeout=5)
        has_nvenc = "h264_nvenc" in res.stdout
        return {
            "nvenc_available": has_nvenc,
            "status": "NVIDIA NVENC (GPU)" if has_nvenc else "CPU (Software libx264)",
            "encoder": "h264_nvenc" if has_nvenc else "libx264"
        }
    except Exception:
        return {
            "nvenc_available": False,
            "status": "CPU (libx264)",
            "encoder": "libx264"
        }

REQUIRED_DEPENDENCIES = [
    {"module": "starlette", "package": "starlette", "desc": "ASGI web framework"},
    {"module": "uvicorn", "package": "uvicorn", "desc": "ASGI server engine"},
    {"module": "multipart", "package": "python-multipart", "desc": "Xử lý tải file multipart"},
    {"module": "requests", "package": "requests", "desc": "Kết nối mạng & CapCut TTS"},
    {"module": "colorama", "package": "colorama", "desc": "Màu sắc terminal"},
    {"module": "yt_dlp", "package": "yt-dlp", "desc": "Tải video đa nền tảng"},
]

def check_required_dependencies() -> Dict[str, Any]:
    """Kiểm tra các thư viện Python bắt buộc để chạy KAGEVIETSUB."""
    installed = []
    missing = []
    for item in REQUIRED_DEPENDENCIES:
        mod_name = item["module"]
        if mod_name == "yt_dlp":
            try:
                __import__("yt_dlp")
                installed.append(item)
            except ImportError:
                if shutil.which("yt-dlp") or (TOOL_DIR / "bin" / "yt-dlp").exists():
                    installed.append(item)
                else:
                    missing.append(item)
        elif mod_name == "multipart":
            try:
                __import__("multipart")
                installed.append(item)
            except ImportError:
                try:
                    __import__("python_multipart")
                    installed.append(item)
                except ImportError:
                    missing.append(item)
        else:
            try:
                __import__(mod_name)
                installed.append(item)
            except ImportError:
                missing.append(item)

    return {
        "all_installed": len(missing) == 0,
        "installed": installed,
        "missing": missing,
        "total": len(REQUIRED_DEPENDENCIES),
        "installed_count": len(installed),
        "missing_count": len(missing)
    }

def check_frameworks() -> Dict[str, Any]:
    """Kiểm tra các thư viện server (FastAPI, Uvicorn, Starlette)."""
    results = {}
    
    try:
        import fastapi
        results["fastapi"] = {"available": True, "version": getattr(fastapi, "__version__", "unknown")}
    except ImportError:
        results["fastapi"] = {"available": False, "version": None}

    try:
        import uvicorn
        results["uvicorn"] = {"available": True, "version": getattr(uvicorn, "__version__", "unknown")}
    except ImportError:
        results["uvicorn"] = {"available": False, "version": None}

    try:
        import starlette
        results["starlette"] = {"available": True, "version": getattr(starlette, "__version__", "unknown")}
    except ImportError:
        results["starlette"] = {"available": False, "version": None}

    try:
        import pydantic
        results["pydantic"] = {"available": True, "version": getattr(pydantic, "__version__", "unknown")}
    except ImportError:
        results["pydantic"] = {"available": False, "version": None}

    return results

def check_optional_components() -> Dict[str, Any]:
    """Kiểm tra các thành phần OPTIONAL (Whisper AI, OCR)."""
    results = {}

    try:
        import faster_whisper
        results["whisper"] = {"available": True, "type": "faster-whisper", "status": "Ready"}
    except ImportError:
        try:
            import whisper
            results["whisper"] = {"available": True, "type": "openai-whisper", "status": "Ready"}
        except ImportError:
            results["whisper"] = {
                "available": False,
                "type": None,
                "status": "unavailable (OPTIONAL - Không bắt buộc)"
            }

    try:
        import rapidocr_onnxruntime
        results["ocr"] = {"available": True, "type": "rapidocr", "status": "Ready"}
    except ImportError:
        results["ocr"] = {
            "available": False,
            "type": None,
            "status": "unavailable (OPTIONAL - Không bắt buộc)"
        }

    return results

_system_info_cache: Optional[Dict[str, Any]] = None
_system_info_cache_time: float = 0.0

def get_full_system_info(force_refresh: bool = False) -> Dict[str, Any]:
    """Tổng hợp toàn bộ thông tin hệ thống dạng Dictionary (có cache 30s để tăng tốc độ phản hồi API)."""
    global _system_info_cache, _system_info_cache_time
    now = time.time()
    if not force_refresh and _system_info_cache is not None and (now - _system_info_cache_time) < 30.0:
        return _system_info_cache

    from TOOL.services.system_info import SystemInfoDetector, calculate_merge_workers

    py_info = check_python_version()
    ff_info = check_ffmpeg()
    gpu_info = check_gpu_acceleration()
    fw_info = check_frameworks()
    opt_info = check_optional_components()
    dep_info = check_required_dependencies()
    android_env = is_android()

    cpu_inf = SystemInfoDetector.get_cpu_info()
    mem_inf = SystemInfoDetector.get_memory_info()
    dev_type = SystemInfoDetector.get_device_type()

    if android_env:
        platform_name = "Android / Termux"
        os_name = "Android"
    else:
        platform_name = f"{platform.system()} ({platform.release()})"
        os_name = platform.system()

    can_start = py_info["is_supported"] and dep_info["all_installed"]

    ytdlp_found = shutil.which("yt-dlp") is not None or (TOOL_DIR / "bin" / "yt-dlp").exists()

    merge_calc = calculate_merge_workers({
        "platform": "android" if android_env else platform.system().lower(),
        "device_type": dev_type,
        "cpu": cpu_inf,
        "memory": mem_inf
    })

    from TOOL.services.storage_service import StorageService
    from TOOL.config import HOST, PORT

    output_dir_str = str(StorageService.get_output_dir().resolve())
    st_inf = SystemInfoDetector.get_storage_info()
    free_gb = st_inf.get("output_storage", {}).get("free_gb", 0.0)

    result = {
        "status": "ok",
        "platform": "android" if android_env else platform.system().lower(),
        "device_type": dev_type,
        "os": os_name,
        "platform_display": platform_name,
        "is_android": android_env,
        "python": py_info["version"],
        "python_version": py_info["version"],
        "python_info": py_info,
        "cpu": cpu_inf,
        "memory": mem_inf,
        "cpu_count": cpu_inf.get("logical_cores", 4),
        "ram_total": mem_inf.get("total_mb", 0),
        "ram_available": mem_inf.get("available_mb", 0),
        "storage_free": free_gb,
        "output_directory": output_dir_str,
        "server": f"{HOST}:{PORT}",
        "architecture": platform.machine() or "unknown",
        "ffmpeg": ff_info["ffmpeg_installed"],
        "ffprobe": ff_info["ffprobe_installed"],
        "merge_optimization": merge_calc,
        "can_start": can_start,
        "components": {
            "ffmpeg": ff_info,
            "gpu": gpu_info,
            "frameworks": fw_info,
            "dependencies": dep_info,
            "srt_engine": {"available": True, "status": "Ready"},
            "audio_engine": {"available": ff_info["ffmpeg_installed"], "status": "Ready" if ff_info["ffmpeg_installed"] else "Requires FFmpeg"},
            "video_engine": {"available": ff_info["ffmpeg_installed"], "status": "Ready" if ff_info["ffmpeg_installed"] else "Requires FFmpeg"},
            "tts_engine": {"available": True, "status": "Ready"},
            "downloader": {
                "available": ytdlp_found and ff_info["ffprobe_installed"],
                "ytdlp_installed": ytdlp_found,
                "status": "Ready" if (ytdlp_found and ff_info["ffprobe_installed"]) else ("Requires yt-dlp" if not ytdlp_found else "Requires FFprobe")
            },
            "optional": opt_info
        }
    }
    _system_info_cache = result
    _system_info_cache_time = now
    return result

def print_system_check_report():
    """In báo cáo chẩn đoán hệ thống chuẩn KAGEVIETSUB ra Terminal/Console."""
    info = get_full_system_info()
    py = info["python_info"]
    ff = info["components"]["ffmpeg"]
    fw = info["components"]["frameworks"]
    dep = info["components"]["dependencies"]
    opt = info["components"]["optional"]

    C = Colors
    I = Icons

    print()
    print(f"  {C.BRIGHT_CYAN}{C.BOLD}KAGEVIETSUB SYSTEM CHECK{C.RESET}")
    print(f"  {C.GRAY}{'─' * 46}{C.RESET}")
    
    print(f"  {C.CYAN}SYSTEM{C.RESET}")
    print(f"  {C.GRAY}├─{C.RESET} Platform      : {C.WHITE}{info['platform_display']}{C.RESET}")
    py_color = C.GREEN if py["is_supported"] else C.RED
    py_mark = f"{C.GREEN}{I.CHECK}{C.RESET}" if py["is_supported"] else f"{C.RED}{I.CROSS}{C.RESET}"
    print(f"  {C.GRAY}├─{C.RESET} Python        : {py_color}{py['version']}{C.RESET} ({py_mark})")
    print(f"  {C.GRAY}├─{C.RESET} Architecture  : {C.WHITE}{info['architecture']}{C.RESET}")
    dep_str = f"{C.GREEN}{I.CHECK} Ready ({dep['installed_count']}/{dep['total']}){C.RESET}" if dep["all_installed"] else f"{C.RED}{I.CROSS} Thiếu {dep['missing_count']} thư viện{C.RESET}"
    print(f"  {C.GRAY}├─{C.RESET} Dependencies  : {dep_str}")
    ff_str = f"{C.GREEN}{I.CHECK} Ready{C.RESET}" if ff["ffmpeg_installed"] else f"{C.YELLOW}{I.WARN} Missing (Video/Audio needs FFmpeg){C.RESET}"
    print(f"  {C.GRAY}└─{C.RESET} FFmpeg        : {ff_str}")

    print()
    print(f"  {C.CYAN}SERVICES{C.RESET}")
    print(f"  {C.GRAY}├─{C.RESET} SRT Engine    : {C.GREEN}{I.CHECK} Ready{C.RESET}")
    audio_str = f"{C.GREEN}{I.CHECK} Ready{C.RESET}" if ff["ffmpeg_installed"] else f"{C.YELLOW}{I.WARN} Requires FFmpeg{C.RESET}"
    print(f"  {C.GRAY}├─{C.RESET} Audio Engine  : {audio_str}")
    video_str = f"{C.GREEN}{I.CHECK} Ready{C.RESET}" if ff["ffmpeg_installed"] else f"{C.YELLOW}{I.WARN} Requires FFmpeg{C.RESET}"
    print(f"  {C.GRAY}├─{C.RESET} Video Engine  : {video_str}")
    print(f"  {C.GRAY}├─{C.RESET} TTS Engine    : {C.GREEN}{I.CHECK} Ready{C.RESET}")
    whisper_str = f"{C.GREEN}{I.CHECK} Ready{C.RESET}" if opt["whisper"]["available"] else f"{C.GRAY}{I.CIRCLE_OPT} Optional{C.RESET}"
    print(f"  {C.GRAY}└─{C.RESET} Whisper AI    : {whisper_str}")

    print()
    if info["can_start"]:
        print(f"  {C.GREEN}{I.CHECK} {C.BRIGHT_WHITE}KAGEVIETSUB is ready to launch.{C.RESET}")
    else:
        print(f"  {C.RED}{I.CROSS} {C.BRIGHT_RED}Hệ thống chưa sẵn sàng khởi chạy!{C.RESET}")
        if not dep["all_installed"]:
            print(f"  {C.YELLOW}👉 Vui lòng cài các thư viện cần thiết bằng lệnh:{C.RESET}")
            print(f"     {C.GREEN}{C.BOLD}sh setup.sh{C.RESET}")
    print(f"  {C.GRAY}{'─' * 46}{C.RESET}\n")

if __name__ == "__main__":
    print_banner()
    print_system_check_report()
