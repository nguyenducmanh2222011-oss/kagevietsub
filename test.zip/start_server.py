#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB - GOOGLE COLAB & CLOUD DEDICATED LAUNCHER
==============================================================================
Khởi chạy KAGEVIETSUB trên Google Colab / Linux GPU / Cloud:
    python start_server.py
    python start_server.py --port 8000
    python start_server.py --no-tunnel

Đặc tính:
- Tự động phát hiện môi trường Google Colab và tăng tốc phần cứng GPU (NVIDIA CUDA).
- Tự động tạo và cấu hình thư mục lưu trữ `/content/KAGEVIETSUB/` để dễ quản lý file.
- Tự động thiết lập Cloudflare Quick Tunnel (Link Public HTTPS an toàn).
- Tái sử dụng trọn bộ Backend, Task Manager và API KAGEVIETSUB hiện có.
==============================================================================
"""

import os
import sys
import time
import shutil
import signal
import argparse
import platform
import subprocess
from pathlib import Path

# Thiết lập đường dẫn gốc
ROOT_DIR = Path(__file__).resolve().parent
TOOL_DIR = ROOT_DIR / "TOOL"
DATA_DIR = ROOT_DIR / "DATA"

if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))
if str(TOOL_DIR) not in sys.path:
    sys.path.insert(0, str(TOOL_DIR))

from TOOL.config import (
    ensure_directories, get_local_version,
    OUTPUT_DIR, TEMP_DIR, UPLOADS_DIR, LOGS_DIR, MODELS_DIR
)
from TOOL.services.logger import logger as central_logger
from TOOL.services.storage_service import StorageService

logger = central_logger.get_module_logger("COLAB_LAUNCHER")

def is_colab_environment() -> bool:
    """Kiểm tra xem mã nguồn đang thực thi trên Google Colab hay không."""
    if os.path.exists("/content") and (
        os.path.exists("/opt/colab") or
        "COLAB_GPU" in os.environ or
        "COLAB_RELEASE_TAG" in os.environ or
        "GCS_READ_CACHE" in os.environ
    ):
        return True
    try:
        import google.colab
        return True
    except ImportError:
        pass
    return False

def get_gpu_info() -> str:
    """Lấy thông tin card đồ họa NVIDIA (nếu có)."""
    try:
        res = subprocess.run(
            ["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader"],
            capture_output=True, text=True, check=True
        )
        gpu_str = res.stdout.strip()
        if gpu_str:
            return gpu_str.replace("\n", " | ")
    except Exception:
        pass
    return "Không có GPU rời (Đang dùng CPU Mode)"

def setup_colab_environment():
    """Thiết lập cấu hình và thư mục riêng biệt cho Google Colab."""
    print("⚡ Đang cấu hình môi trường Google Colab...")
    ensure_directories()
    
    # Thiết lập thư mục lưu trữ output cho người dùng dễ dàng truy cập từ sidebar /content
    content_output = Path("/content/KAGEVIETSUB")
    if is_colab_environment():
        try:
            content_output.mkdir(parents=True, exist_ok=True)
            # Tạo symlink hoặc liên kết nếu cần
            print(f"📁 Thư mục xuất file Colab: {content_output}")
        except Exception as e:
            logger.warning(f"Không thể tạo /content/KAGEVIETSUB: {e}", module="COLAB", action="MKDIR_CONTENT_ERROR")

def print_startup_banner(port: int, is_colab: bool, gpu_info: str):
    """In banner thông tin trạng thái khởi động."""
    version = get_local_version()
    env_str = "Google Colab (Cloud GPU)" if is_colab else f"Standalone Server ({platform.system()} {platform.machine()})"
    
    print("\n" + "=" * 64)
    print(f"        🚀 KAGEVIETSUB WEB SERVER - v{version}")
    print("=" * 64)
    print(f"  • Môi trường    : {env_str}")
    print(f"  • Phần cứng     : {gpu_info}")
    print(f"  • Cổng Local    : http://127.0.0.1:{port}")
    print(f"  • Thư mục DATA  : {DATA_DIR}")
    print(f"  • Thư mục LOGS  : {LOGS_DIR}")
    print("=" * 64 + "\n")

def is_port_in_use(port: int, host: str = "127.0.0.1") -> bool:
    """Kiểm tra xem cổng có đang bị ứng dụng khác chiếm giữ hay không."""
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1)
        return s.connect_ex((host, port)) == 0

def free_port_if_needed(port: int):
    """Giải phóng cổng nếu bị chiếm bởi tiến trình cũ."""
    if not is_port_in_use(port):
        return
    print(f"⚠️ Cổng {port} đang bị chiếm, đang tự động giải phóng...")
    try:
        if platform.system().lower() == "linux":
            if Path("/proc").exists():
                port_hex = f"{port:04X}"
                target_inodes = set()
                for tcp_file in ["/proc/net/tcp", "/proc/net/tcp6"]:
                    p = Path(tcp_file)
                    if p.exists():
                        try:
                            lines = p.read_text().splitlines()[1:]
                            for l in lines:
                                parts = l.strip().split()
                                if len(parts) >= 10:
                                    if parts[1].endswith(f":{port_hex}") and parts[3] == "0A":
                                        target_inodes.add(parts[9])
                        except Exception:
                            pass
                if target_inodes:
                    for proc_dir in Path("/proc").glob("[0-9]*"):
                        pid_str = proc_dir.name
                        if pid_str.isdigit() and int(pid_str) != os.getpid():
                            fd_dir = proc_dir / "fd"
                            if fd_dir.exists() and os.access(str(fd_dir), os.R_OK):
                                try:
                                    for fd in fd_dir.iterdir():
                                        try:
                                            target = os.readlink(str(fd))
                                            for inode in target_inodes:
                                                if f"[{inode}]" in target:
                                                    os.kill(int(pid_str), signal.SIGKILL)
                                        except (OSError, PermissionError):
                                            pass
                                except (OSError, PermissionError):
                                    pass
            if shutil.which("fuser"):
                subprocess.run(["fuser", "-k", f"{port}/tcp"], capture_output=True, timeout=5)
            time.sleep(0.5)
    except Exception as e:
        logger.warning(f"Không thể tự giải phóng cổng {port}: {e}", module="PORT", action="FREE_PORT_FAIL")

def main():
    parser = argparse.ArgumentParser(description="KAGEVIETSUB Server Launcher for Google Colab & Web")
    parser.add_argument("--host", default="0.0.0.0", help="Địa chỉ host lắng nghe (mặc định: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=8000, help="Cổng máy chủ (mặc định: 8000)")
    parser.add_argument("--no-tunnel", action="store_true", help="Vô hiệu hóa Cloudflare Quick Tunnel")
    args = parser.parse_args()

    # Đăng ký signal handler để lưu checkpoint khi bị tắt hoặc dừng
    def _graceful_shutdown(sig, frame):
        print("\n🛑 Nhận tín hiệu dừng, đang lưu khẩn cấp trạng thái checkpoint...")
        try:
            from TOOL.services.task_service import task_service
            task_service.flush_all_checkpoints()
            print("✅ Đã lưu checkpoint thành công trước khi thoát.")
        except Exception as ex:
            print(f"⚠️ Lỗi lưu checkpoint: {ex}")
        sys.exit(0)

    try:
        signal.signal(signal.SIGINT, _graceful_shutdown)
        signal.signal(signal.SIGTERM, _graceful_shutdown)
    except Exception:
        pass

    is_colab = is_colab_environment()
    gpu_info = get_gpu_info()
    
    logger.info(f"Khởi động start_server.py (Colab={is_colab}, GPU={gpu_info})", module="STARTUP", action="COLAB_START")
    
    free_port_if_needed(args.port)
    setup_colab_environment()
    print_startup_banner(args.port, is_colab, gpu_info)

    # Khởi chạy web server thông qua module TOOL.web_server
    try:
        from TOOL.web_server.server import start_web_server
        start_web_server(host=args.host, port=args.port, enable_tunnel=not args.no_tunnel)
    except Exception as e:
        logger.error(f"Lỗi nghiêm trọng khi khởi chạy server: {e}", module="STARTUP", action="SERVER_CRASH", exc=e)
        print(f"\n❌ LỖI KHỞI ĐỘNG MÁY CHỦ: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
