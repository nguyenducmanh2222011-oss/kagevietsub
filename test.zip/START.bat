@echo off
title KAGEVIETSUB
cd /d "%~dp0"
cls
python START.py %*
if errorlevel 1 (
    echo.
    echo [!] Gap loi khi khoi dong bang python. Thu lai voi py...
    py START.py %*
)
pause
