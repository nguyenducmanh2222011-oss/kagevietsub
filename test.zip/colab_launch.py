# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB - GOOGLE COLAB 1-CLICK LAUNCHER
==============================================================================
Sử dụng trên Google Colab:
!python colab_launch.py
==============================================================================
"""

import os
import sys
from pathlib import Path

# Thêm đường dẫn project
ROOT_DIR = Path(__file__).resolve().parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

if __name__ == "__main__":
    from TOOL.web_server.launcher import main
    main()
