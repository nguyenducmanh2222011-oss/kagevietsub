#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Unit tests for Audio Engine
"""

import unittest
import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from TOOL.engines.audio_engine import AudioEngine

class TestAudioEngine(unittest.TestCase):
    def test_audio_engine_validation(self):
        # Empty list should raise ValueError
        with self.assertRaises(ValueError):
            AudioEngine.merge_audio_files([])

        # Less than 2 files should raise ValueError
        with self.assertRaises(ValueError):
            AudioEngine.merge_audio_files([Path("sample1.mp3")])

if __name__ == "__main__":
    unittest.main()
