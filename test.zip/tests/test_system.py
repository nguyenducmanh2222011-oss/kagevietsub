#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Unit tests for System Check and Environment Detection
"""

import unittest
import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from TOOL.system_check import (
    is_android, check_python_version, check_ffmpeg,
    check_gpu_acceleration, check_frameworks, get_full_system_info
)

class TestSystemCheck(unittest.TestCase):
    def test_python_version(self):
        py_info = check_python_version()
        self.assertTrue(py_info["is_supported"])
        self.assertIn(".", py_info["version"])

    def test_ffmpeg_detection(self):
        ff_info = check_ffmpeg()
        self.assertIn("ffmpeg_installed", ff_info)
        self.assertIn("ffprobe_installed", ff_info)

    def test_full_system_info(self):
        info = get_full_system_info()
        self.assertEqual(info["status"], "ok")
        self.assertIn("platform", info)
        self.assertIn("python", info)
        self.assertIn("architecture", info)
        self.assertIn("components", info)

if __name__ == "__main__":
    unittest.main()
