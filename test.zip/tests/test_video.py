#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Unit tests for Video Engine
"""

import unittest
import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from TOOL.engines.video_engine import VideoEngine

class TestVideoEngine(unittest.TestCase):
    def test_video_merge_validation(self):
        with self.assertRaises(ValueError):
            VideoEngine.merge_video_files([])

        with self.assertRaises(ValueError):
            VideoEngine.merge_video_files([Path("sample.mp4")])

if __name__ == "__main__":
    unittest.main()
