#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Unit tests for API Handlers and Job Manager
"""

import unittest
import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from TOOL.api.srt_api import (
    handle_parse_srt, handle_remove_trailing_punct, handle_remove_leading_ellipsis,
    handle_replace_rules, handle_avoid_overlap, handle_purple_sequence,
    handle_uppercase, handle_split_srt
)
from TOOL.services.task_service import job_manager
from TOOL.server import get_health_data

SAMPLE_SRT = """1
00:00:01,000 --> 00:00:03,000
...Test sentence.

2
00:00:03,100 --> 00:00:04,500
Second line!
"""

class TestApiHandlers(unittest.TestCase):
    def test_health_data(self):
        health = get_health_data()
        self.assertEqual(health["status"], "ok")
        self.assertIn("platform", health)
        self.assertIn("python", health)
        self.assertIn("components", health)

    def test_srt_handlers(self):
        parsed = handle_parse_srt(SAMPLE_SRT)
        self.assertEqual(parsed["total"], 2)

        no_dots = handle_remove_leading_ellipsis(SAMPLE_SRT)
        self.assertFalse(no_dots["content"].startswith("..."))

        upper = handle_uppercase(SAMPLE_SRT)
        self.assertIn("TEST SENTENCE.", upper["content"])

        split_res = handle_split_srt(SAMPLE_SRT, sentences_per_file=1, base_name="test_sub")
        self.assertEqual(len(split_res["files"]), 2)

    def test_job_manager(self):
        jid = job_manager.create_job("test_type", {"key": "val"})
        job = job_manager.get_job(jid)
        self.assertIsNotNone(job)
        self.assertEqual(job["type"], "test_type")

        job_manager.update_job(jid, progress=50, message="Halfway")
        updated = job_manager.get_job(jid)
        self.assertEqual(updated["progress"], 50)
        self.assertEqual(updated["message"], "Halfway")

if __name__ == "__main__":
    unittest.main()
