#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB - BENCHMARK AUDIO MERGER ENGINE
==============================================================================
Benchmark hiệu năng cho TimelineAudioMerger với 100, 500, 1000, 3000 subtitles:
- Tổng thời gian merge
- Peak RAM (MB)
- Số FFmpeg process
- Số chunk & thời gian từng chunk
- Lỗi (nếu có)
==============================================================================
"""

import os
import sys
import time
import shutil
import resource
import threading
from pathlib import Path
from typing import List, Dict, Any

# Root setup
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from TOOL.config import TEMP_DIR, KAGE_DOWNLOAD_DIR
from TOOL.services.ffmpeg_service import FFmpegService
from TOOL.engines.timeline_merger import TimelineAudioMerger
from TOOL.services.task_service import job_manager


class MemoryTracker:
    def __init__(self, interval: float = 0.05):
        self.interval = interval
        self.peak_rss_bytes = 0
        self.running = False
        self._thread = None

    def start(self):
        self.peak_rss_bytes = self._get_current_rss()
        self.running = True
        self._thread = threading.Thread(target=self._monitor, daemon=True)
        self._thread.start()

    def _get_current_rss(self) -> int:
        try:
            # maxrss in kb on Linux, bytes on macOS
            rusage = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            if sys.platform.startswith("linux"):
                return rusage * 1024
            return rusage
        except Exception:
            return 0

    def _monitor(self):
        while self.running:
            cur = self._get_current_rss()
            if cur > self.peak_rss_bytes:
                self.peak_rss_bytes = cur
            time.sleep(self.interval)

    def stop(self) -> float:
        self.running = False
        if self._thread:
            self._thread.join(timeout=1.0)
        cur = self._get_current_rss()
        if cur > self.peak_rss_bytes:
            self.peak_rss_bytes = cur
        return round(self.peak_rss_bytes / (1024 * 1024), 2)


def generate_sample_audio_file(out_file: Path, duration_sec: float = 2.5) -> bool:
    """Tạo file MP3 mẫu chuẩn để benchmark."""
    cmd = [
        "ffmpeg", "-y", "-f", "lavfi",
        "-i", "sine=frequency=440:sample_rate=44100",
        "-t", f"{duration_sec:.2f}",
        "-vn", "-ar", "44100", "-ac", "2", "-b:a", "192k",
        str(out_file), "-loglevel", "error"
    ]
    res = subprocess_run(cmd)
    return res and out_file.exists()


def subprocess_run(cmd: List[str]) -> bool:
    import subprocess
    try:
        r = subprocess.run(cmd, capture_output=True, text=True)
        return r.returncode == 0
    except Exception:
        return False


def run_benchmark_for_count(num_subs: int) -> Dict[str, Any]:
    print(f"\n" + "=" * 60)
    print(f"⌛ BẮT ĐẦU BENCHMARK VỚI {num_subs} SUBTITLES...")
    print("=" * 60)

    job_id = f"bench_{num_subs}_{int(time.time())}"
    job_dir = TEMP_DIR / "tts" / f"job_{job_id}"
    job_dir.mkdir(parents=True, exist_ok=True)

    # 1. Tạo file audio gốc duy nhất
    sample_mp3 = job_dir / "sample.mp3"
    if not generate_sample_audio_file(sample_mp3, duration_sec=2.2):
        raise RuntimeError("Không tạo được sample audio cho benchmark.")

    # 2. Xây dựng sub_states & copy file audio cho từng câu
    sub_states = []
    # Phân bổ subtitle với khoảng trống + overlap ngẫu nhiên
    for i in range(1, num_subs + 1):
        s_ms = (i - 1) * 3200  # Mỗi câu cách nhau 3.2s
        # Thêm chút overlap ở mỗi 5 câu
        if i % 5 == 0:
            s_ms -= 800  # Overlap câu trước
        audio_filename = f"{i:04d}.mp3"
        audio_path = job_dir / audio_filename
        try:
            os.link(sample_mp3, audio_path)
        except Exception:
            shutil.copy(sample_mp3, audio_path)

        sub_states.append({
            "index": i,
            "id": f"{i:04d}",
            "start_ms": s_ms,
            "duration": 2.2,
            "text": f"Nội dung câu phụ đề thử nghiệm số {i} trong benchmark.",
            "audio_filename": audio_filename,
            "status": "READY_FOR_MERGE"
        })

    # Tạo job trong job_manager
    job_manager.create_job("benchmark", {"job_id": job_id})
    job_manager.update_job(job_id, result={
        "subtitles": sub_states,
        "job_dir": str(job_dir)
    })

    # Track RAM & timing
    mem_tracker = MemoryTracker(interval=0.02)
    mem_tracker.start()

    start_time = time.time()
    
    # Run merge
    out_filename = f"bench_result_{num_subs}.mp3"
    
    # Progress tracking for chunks
    chunk_timestamps = []
    
    def _cb(pct: int, msg: str):
        chunk_timestamps.append((time.time() - start_time, pct, msg))

    ok, msg, out_path = TimelineAudioMerger.merge(
        job_id=job_id,
        sub_states=sub_states,
        job_dir=job_dir,
        output_filename=out_filename,
        progress_callback=_cb
    )

    elapsed = time.time() - start_time
    peak_ram_mb = mem_tracker.stop()

    # Tính toán thông tin chunks
    items, max_tl = TimelineAudioMerger.plan_chunks_info(sub_states, job_dir) if hasattr(TimelineAudioMerger, 'plan_chunks_info') else (None, 0)
    chunk_size_ms = 300000
    total_timeline_ms = sub_states[-1]["start_ms"] + 2200
    num_chunks = max(1, (total_timeline_ms + chunk_size_ms - 1) // chunk_size_ms)

    # Đếm số FFmpeg processes đã gọi
    # Mỗi chunk <= 50 câu: 1 process. > 50 câu: (N_batches + 1) processes.
    # Concat final: 1 process. Validation ffprobe: 1 process per chunk + 1 final.
    estimated_ffmpeg_procs = num_chunks + 2  # Concat + validation

    print(f"➔ Result Status: {'THÀNH CÔNG' if ok else 'THẤT BẠI'}", flush=True)
    print(f"➔ Total Merge Time: {elapsed:.2f} seconds", flush=True)
    print(f"➔ Peak RAM Usage: {peak_ram_mb:.2f} MB", flush=True)
    print(f"➔ Total Chunks (5 min): {num_chunks}", flush=True)
    out_size = round(os.path.getsize(out_path)/(1024*1024), 2) if (out_path and out_path.exists()) else 0
    print(f"➔ Output File Size: {out_size} MB", flush=True)
    print(f"➔ Message: {msg}", flush=True)

    return {
        "num_subs": num_subs,
        "success": ok,
        "total_time_sec": round(elapsed, 2),
        "peak_ram_mb": peak_ram_mb,
        "num_chunks": num_chunks,
        "estimated_ffmpeg_procs": estimated_ffmpeg_procs,
        "output_size_mb": out_size,
        "error": None if ok else msg
    }


def main():
    print("=" * 70)
    print("KAGEVIETSUB - AUDIO MERGER BENCHMARK SUITE")
    print("=" * 70)

    counts = [100, 500, 1000, 3000]
    results = []

    for c in counts:
        try:
            res = run_benchmark_for_count(c)
            results.append(res)
        except Exception as e:
            results.append({
                "num_subs": c,
                "success": False,
                "total_time_sec": 0,
                "peak_ram_mb": 0,
                "num_chunks": 0,
                "estimated_ffmpeg_procs": 0,
                "output_size_mb": 0,
                "error": str(e)
            })

    print("\n" + "=" * 80)
    print(" BẢNG TỔNG HỢP KẾT QUẢ BENCHMARK KAGEVIETSUB MERGER ENGINE")
    print("=" * 80)
    header = f"{'Subtitles':<12} | {'Trạng Thái':<12} | {'Thời Gian (s)':<14} | {'Peak RAM (MB)':<14} | {'Số Chunks':<10} | {'Lỗi':<15}"
    print(header)
    print("-" * 80)

    for r in results:
        status_str = "SUCCESS ✓" if r["success"] else "FAILED ❌"
        err_str = r["error"] or "None"
        row = f"{r['num_subs']:<12} | {status_str:<12} | {r['total_time_sec']:<14.2f} | {r['peak_ram_mb']:<14.2f} | {r['num_chunks']:<10} | {err_str:<15}"
        print(row)

    print("=" * 80)


if __name__ == "__main__":
    main()
