#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB - BENCHMARK PIPELINE TTS + SPEED ENGINE
==============================================================================
Thực hiện Benchmark đo lường hiệu năng của hệ thống TTS + Speed Worker:
1. Quy mô: 100 câu, 500 câu, 1000 câu phụ đề.
2. Tốc độ: 1.0x (Fast Path), 1.25x, 1.5x, 0.8x.
3. Đo đạc các chỉ số:
   - Tổng thời gian hoàn thành (s)
   - Tốc độ xử lý trung bình (câu/giây)
   - Peak RAM tiêu thụ (MB)
   - Tỉ lệ thành công (%)
==============================================================================
"""

import os
import sys
import time
import shutil
import resource
import threading
import subprocess
from pathlib import Path
from typing import List, Dict, Any

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from TOOL.config import TEMP_DIR
from TOOL.engines.tts_engine import TTSEngine


class MemoryTracker:
    def __init__(self, interval: float = 0.05):
        self.interval = interval
        self.peak_rss_bytes = 0
        self.running = False
        self._thread = None

    def start(self):
        self.peak_rss_bytes = self._get_current_rss()
        self.running = True
        self._thread = threading.Thread(target=self._monitor, daemon=True)
        self._thread.start()

    def _get_current_rss(self) -> int:
        try:
            rusage = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            if sys.platform.startswith("linux"):
                return rusage * 1024
            return rusage
        except Exception:
            return 0

    def _monitor(self):
        while self.running:
            cur = self._get_current_rss()
            if cur > self.peak_rss_bytes:
                self.peak_rss_bytes = cur
            time.sleep(self.interval)

    def stop(self) -> float:
        self.running = False
        if self._thread:
            self._thread.join(timeout=0.5)
        return self.peak_rss_bytes / (1024 * 1024)


def generate_mock_subtitles(count: int) -> List[Dict[str, Any]]:
    subs = []
    for i in range(1, count + 1):
        subs.append({
            "id": f"{i:04d}",
            "start": f"00:00:{i:02d},000",
            "end": f"00:00:{i+1:02d},000",
            "text": f"Đây là câu phụ đề kiểm thử số {i} với nội dung tự động."
        })
    return subs


def benchmark_run(sub_count: int, speed: float, threads: int = 5):
    print(f"\n---> CHẠY BENCHMARK: {sub_count} Câu phụ đề | Speed {speed}x | {threads} Threads")
    subs = generate_mock_subtitles(sub_count)
    job_id = f"bench_{sub_count}_{int(speed*100)}_{int(time.time())}"
    job_dir = TEMP_DIR / "tts" / f"job_{job_id}"
    job_dir.mkdir(parents=True, exist_ok=True)

    # Pre-populate raw 1.0x audio files to simulate fast local pipeline or cached audio
    print(f" -> Khởi tạo {sub_count} raw audio 1.0x mẫu...")
    sample_mp3 = job_dir / "sample.mp3"
    cmd = [
        "ffmpeg", "-y", "-f", "lavfi",
        "-i", "sine=frequency=440:sample_rate=44100",
        "-t", "1.0",
        "-vn", "-ar", "44100", "-ac", "2", "-b:a", "192k",
        str(sample_mp3), "-loglevel", "error"
    ]
    subprocess.run(cmd, check=True)

    for sub in subs:
        raw_p = job_dir / f"raw_{sub['id']}.mp3"
        shutil.copy(sample_mp3, raw_p)

    tracker = MemoryTracker()
    tracker.start()
    t0 = time.time()

    job = TTSEngine.process_tts_job(
        job_id=job_id,
        subtitles=subs,
        voice="BV421_vivn_streaming",
        speed=speed,
        threads=threads
    )

    total_time = time.time() - t0
    peak_ram = tracker.stop()

    res = job["result"]
    completed = res["completed"]
    failed = res["failed"]
    throughput = completed / total_time if total_time > 0 else 0

    print(f" [✓] HOÀN THÀNH IN {total_time:.2f}s | Speed: {throughput:.1f} câu/s | Peak RAM: {peak_ram:.1f} MB | Thành công: {completed}/{sub_count}")

    # Cleanup
    shutil.rmtree(job_dir, ignore_errors=True)
    return {
        "sub_count": sub_count,
        "speed": speed,
        "total_time": total_time,
        "throughput": throughput,
        "peak_ram": peak_ram,
        "completed": completed,
        "failed": failed
    }


def main():
    print("=" * 80)
    print("KAGEVIETSUB - PIPELINE TTS & SPEED ENGINE BENCHMARK SUITE")
    print("=" * 80)

    test_cases = [
        (100, 1.0),
        (100, 1.25),
        (100, 1.5),
        (100, 0.8),
        (500, 1.0),
        (500, 1.25),
        (500, 1.5),
        (500, 0.8),
        (1000, 1.0),
        (1000, 1.25),
        (1000, 1.5),
        (1000, 0.8),
    ]

    results = []
    for count, sp in test_cases:
        res = benchmark_run(count, sp, threads=5)
        results.append(res)

    print("\n" + "=" * 80)
    print("BẢNG TỔNG HỢP KẾT QUẢ BENCHMARK PIPELINE SPEED TTS")
    print("=" * 80)
    print(f"{'SỐ CÂU':<10} | {'SPEED':<8} | {'THỜI GIAN (s)':<15} | {'TỐC ĐỘ (câu/s)':<16} | {'PEAK RAM (MB)':<15} | {'TRẠNG THÁI':<10}")
    print("-" * 80)
    for r in results:
        print(f"{r['sub_count']:<10} | {r['speed']:<8.2f} | {r['total_time']:<15.2f} | {r['throughput']:<16.1f} | {r['peak_ram']:<15.1f} | {r['completed']}/{r['sub_count']}")
    print("=" * 80)


if __name__ == "__main__":
    main()
