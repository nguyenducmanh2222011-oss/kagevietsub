#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Unit tests for SRT Engine on Python 3.14
"""

import unittest
import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from TOOL.engines.srt_engine import SrtEngine

SAMPLE_SRT = """1
00:00:01,000 --> 00:00:03,000
...Xin chào các bạn.

2
00:00:03,100 --> 00:00:05,000
Hôm nay hôm nay chúng ta học tiếng Trung!

3
00:00:05,050 --> 00:00:06,000
Tốt.

4
00:00:06,010 --> 00:00:07,000
Bạn có khỏe không?
"""

class TestSrtEngine(unittest.TestCase):
    def test_parse_srt(self):
        blocks = SrtEngine.parse_srt(SAMPLE_SRT)
        self.assertEqual(len(blocks), 4)
        self.assertEqual(blocks[0]["start"], "00:00:01,000")
        self.assertEqual(blocks[0]["end"], "00:00:03,000")
        self.assertIn("Xin chào", blocks[0]["text"])

    def test_remove_leading_ellipsis(self):
        res, count = SrtEngine.remove_leading_ellipsis(SAMPLE_SRT)
        self.assertGreaterEqual(count, 1)
        self.assertFalse(res.startswith("..."))

    def test_remove_trailing_punctuation(self):
        res, count = SrtEngine.remove_trailing_punctuation(SAMPLE_SRT)
        # Should keep question mark ? on last block but remove . and !
        self.assertIn("?", res)

    def test_uppercase_srt(self):
        res = SrtEngine.uppercase_srt(SAMPLE_SRT)
        self.assertIn("XIN CHÀO CÁC BẠN.", res)
        self.assertIn("00:00:01,000 --> 00:00:03,000", res)

    def test_split_srt(self):
        files_info, file_paths = SrtEngine.split_srt(SAMPLE_SRT, sentences_per_file=2, base_name="test_split")
        self.assertEqual(len(files_info), 2)
        self.assertTrue(file_paths[0].exists())

    def test_avoid_overlap(self):
        res, count = SrtEngine.avoid_overlap(SAMPLE_SRT)
        self.assertIsInstance(res, str)
        self.assertGreaterEqual(count, 0)

    def test_run_purple_sequence(self):
        res, stats = SrtEngine.run_purple_sequence(SAMPLE_SRT)
        self.assertIsInstance(res, str)
        self.assertIn("leading_ellipsis_removed", stats)
        self.assertIn("trailing_punctuation_removed", stats)

    def test_run_all_sequence(self):
        res, stats = SrtEngine.run_all_sequence(SAMPLE_SRT)
        self.assertIsInstance(res, str)
        self.assertIn("leading_ellipsis", stats)
        self.assertIn("trailing_punctuation", stats)

if __name__ == "__main__":
    unittest.main()
