#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB - TEST SUITE: 5 BÀI TEST TTS WORKERS
==============================================================================
Thực hiện kiểm thử 5 bài test TTS Concurrency & Speed Pipeline.
==============================================================================
"""

import os
import sys
import time
import json
import shutil
import zipfile
import hashlib
from pathlib import Path
from typing import Dict, Any, List

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from TOOL.config import TEMP_DIR, DATA_DIR, KAGE_DOWNLOAD_DIR, get_local_version
from TOOL.engines.tts_engine import TTSEngine, WorkerTracker, JobStateTracker
from TOOL.services.task_service import job_manager


# ==============================================================================
# PHẦN 1: 5 BÀI TEST TTS WORKER CONCURRENCY KHI SPEED != 1.0x
# ==============================================================================

def run_tts_worker_test(test_num: int, req_workers: int, speed: float):
    print(f"\n[TTS TEST {test_num}] Workers = {req_workers}, Speed = {speed}x...")
    job_id = f"test_tts_w{req_workers}_s{int(speed*100)}_{int(time.time()*1000)}"

    # Tạo 2 câu phụ đề mẫu đã có sẵn file raw để test nhanh tốc độ worker
    job_dir = TEMP_DIR / "tts" / f"job_{job_id}"
    job_dir.mkdir(parents=True, exist_ok=True)

    subs = [
        {"id": "0001", "start": "00:00:01,000", "end": "00:00:03,000", "text": "Thử nghiệm câu 1."},
        {"id": "0002", "start": "00:00:04,000", "end": "00:00:06,000", "text": "Thử nghiệm câu 2."}
    ]

    # Tạo file raw giả lập để pass validation
    sample_mp3 = job_dir / "sample.mp3"
    import subprocess
    cmd = [
        "ffmpeg", "-y", "-f", "lavfi",
        "-i", "sine=frequency=440:sample_rate=44100",
        "-t", "1.0",
        "-vn", "-ar", "44100", "-ac", "2", "-b:a", "192k",
        str(sample_mp3), "-loglevel", "error"
    ]
    subprocess.run(cmd, check=True)
    shutil.copy(sample_mp3, job_dir / "raw_0001.mp3")
    shutil.copy(sample_mp3, job_dir / "raw_0002.mp3")

    # Bắt output stdout để kiểm tra định dạng log bắt buộc
    import io
    from contextlib import redirect_stdout
    f_out = io.StringIO()
    with redirect_stdout(f_out):
        job = TTSEngine.process_tts_job(
            job_id=job_id,
            subtitles=subs,
            voice="BV421_vivn_streaming",
            speed=speed,
            threads=req_workers
        )

    output_str = f_out.getvalue()
    res = job["result"]

    # Kiểm tra log bắt buộc
    expected_req_line = f"Requested TTS workers: {req_workers}"
    expected_act_line = f"Actual TTS workers: {req_workers}"
    speed_fmt = f"{speed:.2f}".rstrip("0").rstrip(".") + "x"
    expected_spd_line = f"Speed: {speed_fmt}"

    assert expected_req_line in output_str, f"Missing log line: '{expected_req_line}' in output:\n{output_str}"
    assert expected_act_line in output_str, f"Missing log line: '{expected_act_line}' in output:\n{output_str}"
    assert expected_spd_line in output_str, f"Missing log line: '{expected_spd_line}' in output:\n{output_str}"

    # Kiểm tra kết quả trạng thái
    assert res["requested_workers"] == req_workers, f"Requested: {res['requested_workers']} != {req_workers}"
    assert res["actual_workers"] == req_workers, f"Actual: {res['actual_workers']} != {req_workers}"
    assert res["tts_workers"] == req_workers, f"TTS workers: {res['tts_workers']} != {req_workers}"
    assert res["completed"] == 2, f"Expected 2 completed, got {res['completed']}"

    print(f" -> Logged correctly:\n    {expected_req_line}\n    {expected_act_line}\n    {expected_spd_line}")
    print(f" [✓] TTS TEST {test_num} PASS")
    shutil.rmtree(job_dir, ignore_errors=True)


def run_all_tts_tests():
    print("=" * 70)
    print("KIỂM THỬ 5 BÀI TEST TTS WORKER CONCURRENCY (SPEED != 1.0x)")
    print("=" * 70)

    # 1. Workers = 5, Speed = 1.0x -> Requested = 5, Actual = 5
    run_tts_worker_test(1, 5, 1.0)

    # 2. Workers = 5, Speed = 1.5x -> Requested = 5, Actual = 5
    run_tts_worker_test(2, 5, 1.5)

    # 3. Workers = 10, Speed = 1.5x -> Requested = 10, Actual = 10
    run_tts_worker_test(3, 10, 1.5)

    # 4. Workers = 20, Speed = 0.75x -> Requested = 20, Actual = 20
    run_tts_worker_test(4, 20, 0.75)

    # 5. Workers = 30, Speed = 2.0x -> Requested = 30, Actual = 30
    run_tts_worker_test(5, 30, 2.0)

    print("\n" + "=" * 70)
    print("TẤT CẢ 5 BÀI TEST TTS WORKER ĐÃ HOÀN THÀNH 100% THÀNH CÔNG!")
    print("=" * 70)


if __name__ == "__main__":
    run_all_tts_tests()
