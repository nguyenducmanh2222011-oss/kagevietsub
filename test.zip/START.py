#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB - SINGLE LAUNCHER (PYTHON 3.14 + TERMUX ANDROID & PC)
==============================================================================
Khởi chạy duy nhất:
    python START.py  (trên Android Termux, Linux, Windows, macOS)
Tùy chọn CLI:
    python START.py --check       (Kiểm tra toàn bộ hệ thống)
    python START.py --debug       (Bật chế độ debug chi tiết)
    python START.py --no-browser  (Không tự động mở trình duyệt)
    python START.py --port 8000   (Tùy chỉnh cổng máy chủ)
==============================================================================
"""

import os
import sys
import socket
import shutil
import subprocess
import platform
import threading
import time
import signal
import atexit
import errno
import re
import argparse
import webbrowser
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent
TOOL_DIR = ROOT_DIR / "TOOL"
DATA_DIR = ROOT_DIR / "DATA"
LOGS_DIR = DATA_DIR / "logs"
RUNTIME_DIR = DATA_DIR / "runtime"
PID_FILE = RUNTIME_DIR / "kagevietsub.pid"

DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8000
PORT_RELEASE_TIMEOUT = 5.0

if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))
if str(TOOL_DIR) not in sys.path:
    sys.path.insert(0, str(TOOL_DIR))

from TOOL.cli_ui import (
    Colors, Icons, print_banner, print_step, print_server_card,
    print_info, print_success, print_warning, print_error,
    set_terminal_title, clear_screen
)
from TOOL.system_check import (
    is_android, check_python_version, check_ffmpeg,
    check_required_dependencies, print_system_check_report, get_full_system_info
)

from TOOL.services.logger import logger

def ensure_data_folders():
    for sub in ["temp", "temp/task_jobs", "output", "uploads", "models", "logs", "runtime"]:
        (DATA_DIR / sub).mkdir(parents=True, exist_ok=True)

def write_pid_file():
    try:
        RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
        PID_FILE.write_text(str(os.getpid()), encoding="utf-8")
        logger.info("STARTUP", "PID", f"pid={os.getpid()}")
    except Exception as e:
        logger.warning("STARTUP", "PID_WRITE_ERROR", exc=e)

def remove_pid_file():
    try:
        if PID_FILE.exists():
            PID_FILE.unlink(missing_ok=True)
            logger.info("SHUTDOWN", "PID_REMOVED", f"pid={os.getpid()}")
    except Exception:
        pass

atexit.register(remove_pid_file)

def get_lan_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return DEFAULT_HOST

def is_port_in_use(host: str, port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.4)
        try:
            res = s.connect_ex((host, port))
            if res == 0:
                return True
        except Exception:
            pass
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind((host, port))
            return False
    except OSError:
        return True

def is_pid_alive(pid: int) -> bool:
    if pid <= 0 or pid == os.getpid():
        return False
    try:
        if platform.system() == "Windows":
            res = subprocess.run(["tasklist", "/FI", f"PID eq {pid}"], capture_output=True, text=True, timeout=2)
            return str(pid) in res.stdout
        else:
            os.kill(pid, 0)
            status_file = Path(f"/proc/{pid}/status")
            if status_file.exists():
                try:
                    for line in status_file.read_text().splitlines():
                        if line.startswith("State:"):
                            state = line.split()[1]
                            if state in ("Z", "X", "zombie"):
                                return False
                except Exception:
                    pass
            return True
    except (OSError, ProcessLookupError):
        return False
    except Exception:
        return False

def get_process_cmdline(pid: int) -> str:
    if pid <= 0:
        return ""
    if platform.system() != "Windows":
        cmdline_file = Path(f"/proc/{pid}/cmdline")
        if cmdline_file.exists():
            try:
                raw = cmdline_file.read_bytes()
                cmd = raw.replace(b"\x00", b" ").decode("utf-8", errors="ignore").strip()
                if cmd:
                    return cmd
            except Exception:
                pass
        try:
            res = subprocess.run(["ps", "-p", str(pid), "-o", "args="], capture_output=True, text=True, timeout=2)
            if res.returncode == 0 and res.stdout.strip():
                return res.stdout.strip()
        except Exception:
            pass
    else:
        try:
            res = subprocess.run(
                ["powershell", "-NoProfile", "-Command", f"(Get-CimInstance Win32_Process -Filter 'ProcessId = {pid}').CommandLine"],
                capture_output=True, text=True, timeout=2
            )
            if res.returncode == 0 and res.stdout.strip():
                return res.stdout.strip()
        except Exception:
            pass
        try:
            res = subprocess.run(["wmic", "process", "where", f"ProcessId={pid}", "get", "CommandLine"], capture_output=True, text=True, timeout=2)
            lines = [l.strip() for l in res.stdout.splitlines() if l.strip() and "CommandLine" not in l]
            if lines:
                return lines[0]
        except Exception:
            pass
    return ""

def is_kagevietsub_process(pid: int, cmdline: str) -> bool:
    if pid == os.getpid():
        return False
    cmd_lower = cmdline.lower() if cmdline else ""
    root_str = str(ROOT_DIR).lower()

    kage_indicators = [
        "kagevietsub",
        "start.py",
        "tool/server.py",
        "tool\\server.py",
        "server.py",
        root_str
    ]

    for indicator in kage_indicators:
        if indicator in cmd_lower:
            return True

    if platform.system() != "Windows":
        cwd_link = Path(f"/proc/{pid}/cwd")
        if cwd_link.exists():
            try:
                real_cwd = os.readlink(str(cwd_link))
                if real_cwd.lower() == root_str or real_cwd.lower().startswith(root_str):
                    return True
            except Exception:
                pass

    if PID_FILE.exists():
        try:
            stored_pid = int(PID_FILE.read_text().strip())
            if stored_pid == pid and ("python" in cmd_lower or not cmdline):
                return True
        except Exception:
            pass

    return False

def find_pids_listening_on_port(port: int, host: str = DEFAULT_HOST) -> list:
    found_pids = set()

    if shutil.which("ss"):
        try:
            res = subprocess.run(["ss", "-tulpn"], capture_output=True, text=True, timeout=2)
            if res.returncode == 0:
                for line in res.stdout.splitlines():
                    if f":{port}" in line:
                        for m in re.finditer(r'pid=(\d+)', line):
                            pid_val = int(m.group(1))
                            if pid_val != os.getpid():
                                found_pids.add(pid_val)
        except Exception:
            pass

    if not found_pids and shutil.which("lsof"):
        try:
            res = subprocess.run(["lsof", "-nP", f"-iTCP:{port}", "-sTCP:LISTEN", "-t"], capture_output=True, text=True, timeout=2)
            if res.returncode == 0:
                for line in res.stdout.splitlines():
                    line = line.strip()
                    if line.isdigit() and int(line) != os.getpid():
                        found_pids.add(int(line))
        except Exception:
            pass

    if not found_pids and shutil.which("netstat"):
        try:
            cmd = ["netstat", "-tlpn"] if platform.system() != "Windows" else ["netstat", "-ano", "-p", "tcp"]
            res = subprocess.run(cmd, capture_output=True, text=True, timeout=2)
            if res.returncode == 0:
                if platform.system() == "Windows":
                    for line in res.stdout.splitlines():
                        parts = line.split()
                        if len(parts) >= 5 and f":{port}" in parts[1] and parts[3].upper() == "LISTENING":
                            if parts[4].isdigit() and int(parts[4]) != os.getpid():
                                found_pids.add(int(parts[4]))
                else:
                    for line in res.stdout.splitlines():
                        if f":{port}" in line and "LISTEN" in line:
                            m = re.search(r'(\d+)/', line)
                            if m and int(m.group(1)) != os.getpid():
                                found_pids.add(int(m.group(1)))
        except Exception:
            pass

    if not found_pids and platform.system() != "Windows" and Path("/proc").exists():
        try:
            port_hex = f"{port:04X}"
            target_inodes = set()
            for tcp_file in ["/proc/net/tcp", "/proc/net/tcp6"]:
                p = Path(tcp_file)
                if p.exists():
                    lines = p.read_text().splitlines()[1:]
                    for l in lines:
                        parts = l.strip().split()
                        if len(parts) >= 10:
                            local_addr = parts[1]
                            state = parts[3]
                            inode = parts[9]
                            if local_addr.endswith(f":{port_hex}") and state == "0A":
                                target_inodes.add(inode)
            if target_inodes:
                for proc_dir in Path("/proc").glob("[0-9]*"):
                    pid_str = proc_dir.name
                    if pid_str.isdigit() and int(pid_str) != os.getpid():
                        fd_dir = proc_dir / "fd"
                        if fd_dir.exists() and os.access(str(fd_dir), os.R_OK):
                            try:
                                for fd in fd_dir.iterdir():
                                    try:
                                        target = os.readlink(str(fd))
                                        for inode in target_inodes:
                                            if f"socket:[{inode}]" in target or f"[{inode}]" in target:
                                                found_pids.add(int(pid_str))
                                    except (OSError, PermissionError):
                                        pass
                            except (OSError, PermissionError):
                                pass
        except Exception:
            pass

    if not found_pids and platform.system() == "Windows":
        try:
            ps_cmd = f"Get-NetTCPConnection -LocalPort {port} -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess"
            res = subprocess.run(["powershell", "-NoProfile", "-Command", ps_cmd], capture_output=True, text=True, timeout=2)
            if res.returncode == 0:
                for line in res.stdout.splitlines():
                    line = line.strip()
                    if line.isdigit() and int(line) != os.getpid():
                        found_pids.add(int(line))
        except Exception:
            pass

    if not found_pids and PID_FILE.exists():
        try:
            old_pid = int(PID_FILE.read_text().strip())
            if old_pid != os.getpid() and is_pid_alive(old_pid):
                found_pids.add(old_pid)
        except Exception:
            pass

    return list(found_pids)

def terminate_process_tree(pid: int, timeout_sec: float = PORT_RELEASE_TIMEOUT) -> bool:
    if pid <= 0 or not is_pid_alive(pid):
        return True

    try:
        if platform.system() == "Windows":
            subprocess.run(["taskkill", "/PID", str(pid)], capture_output=True, timeout=2)
        else:
            os.kill(pid, signal.SIGTERM)
    except Exception:
        pass

    start_time = time.time()
    while time.time() - start_time < timeout_sec:
        if not is_pid_alive(pid):
            return True
        time.sleep(0.2)

    try:
        if platform.system() == "Windows":
            subprocess.run(["taskkill", "/F", "/PID", str(pid)], capture_output=True, timeout=2)
        else:
            os.kill(pid, signal.SIGKILL)
    except Exception:
        pass

    time.sleep(0.4)
    return not is_pid_alive(pid)

def ensure_port_available(host: str, port: int) -> bool:
    print(f"\n[START]\nChecking port: {host}:{port}")
    logger.info("PROCESS", "PORT_CHECK", f"host={host} port={port}")

    if not is_port_in_use(host, port):
        print(f"[PORT]\n{host}:{port} is available\n")
        logger.info("PROCESS", "PORT_FREE", f"port={port}")
        return True

    print(f"[PORT]\n{host}:{port} is busy\n")
    logger.warning("PROCESS", "PORT_BUSY", f"port={port}")

    pids = find_pids_listening_on_port(port, host)
    if not pids:
        print_error(f"Port {port} đang bị chiếm nhưng không thể xác định PID.", reason="Không thể tự động giải phóng port.")
        print(f" {Colors.YELLOW}Vui lòng dừng ứng dụng đang chạy hoặc đổi port khác:{Colors.RESET}")
        print(f"    {Colors.GREEN}python START.py --port 8001{Colors.RESET}\n")
        logger.error("PROCESS", "PORT_PID_UNKNOWN", f"port={port}")
        return False

    for pid in pids:
        cmdline = get_process_cmdline(pid)
        print(f"[PROCESS]\nPID: {pid}")
        print(f"[PROCESS]\nCommand: {cmdline or 'Unknown'}\n")
        logger.info("PROCESS", "PID_INSPECT", f"pid={pid} cmdline={cmdline or 'Unknown'}")

        if is_kagevietsub_process(pid, cmdline):
            print(f"[PROCESS]\nOld KAGEVIETSUB process detected\n")
            print(f"[PROCESS]\nTerminating PID {pid}\n")
            logger.info("PROCESS", "OLD_SERVER", f"pid={pid}")
            logger.info("PROCESS", "TERMINATE", f"pid={pid}")

            success = terminate_process_tree(pid, timeout_sec=PORT_RELEASE_TIMEOUT)
            if not success:
                print_error(f"Không thể giải phóng port {port}.", reason=f"Process PID {pid} không thể dừng sau timeout.")
                logger.error("PROCESS", "TERMINATE_FAILED", f"pid={pid} port={port}")
                return False
            logger.info("PROCESS", "KILLED", f"pid={pid}")
        else:
            print(f" {Colors.RED}{Icons.CROSS}{Colors.RESET} {Colors.BRIGHT_RED}{Colors.BOLD}PORT {port} BUSY{Colors.RESET}")
            print(f" {Colors.WHITE}Port {port} đang được sử dụng bởi process khác.{Colors.RESET}")
            print(f" {Colors.GRAY}PID: {pid}{Colors.RESET}")
            print(f" {Colors.GRAY}PROCESS: {cmdline or 'Unknown'}{Colors.RESET}")
            print(f" {Colors.YELLOW}KAGEVIETSUB không can thiệp process của ứng dụng khác. Vui lòng chọn port khác:{Colors.RESET}")
            print(f"    {Colors.GREEN}python START.py --port 8001{Colors.RESET}\n")
            logger.error("PROCESS", "FOREIGN_PROCESS", f"port={port} pid={pid} cmdline={cmdline or 'Unknown'}")
            return False

    start_wait = time.time()
    port_released = False
    while time.time() - start_wait < PORT_RELEASE_TIMEOUT:
        if not is_port_in_use(host, port):
            port_released = True
            break
        time.sleep(0.3)

    if port_released:
        print(f"[PORT]\nPort released\n")
        logger.info("PROCESS", "PORT_RELEASED", f"port={port}")
        return True
    else:
        print_error(f"Không thể giải phóng port {port}.", reason=f"Port {port} vẫn đang bị chiếm.")
        logger.error("PROCESS", "RELEASE_TIMEOUT", f"port={port}")
        return False

def open_browser(url: str, delay: float = 0.8):
    """Mở trình duyệt sau khi máy chủ bắt đầu chạy."""
    def _open():
        time.sleep(delay)
        try:
            if is_android() and shutil.which("termux-open-url"):
                import subprocess
                subprocess.run(["termux-open-url", url], capture_output=True)
            else:
                webbrowser.open_new_tab(url)
        except Exception:
            pass
    t = threading.Thread(target=_open, daemon=True)
    t.start()

def parse_arguments():
    """Phân tích tham số dòng lệnh."""
    parser = argparse.ArgumentParser(
        description="KAGEVIETSUB - Bộ công cụ Video, SRT, Audio & TTS",
        add_help=True
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="Kiểm tra tương thích hệ thống và thoát"
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Kích hoạt chế độ debug hiển thị chi tiết lỗi"
    )
    parser.add_argument(
        "--no-browser",
        action="store_true",
        help="Không tự động mở trình duyệt web khi khởi chạy"
    )
    parser.add_argument(
        "--port",
        type=int,
        default=int(os.getenv("PORT", os.getenv("KAGE_PORT", os.getenv("DSUB_PORT", "8000")))),
        help="Cổng kết nối máy chủ (mặc định 8000)"
    )
    return parser.parse_args()

def main():
    args = parse_arguments()
    set_terminal_title("KAGEVIETSUB")
    ensure_data_folders()

    if args.check:
        clear_screen()
        print_banner()
        print_system_check_report()
        sys.exit(0)

    clear_screen()
    print_banner()

    port = args.port
    host = "127.0.0.1"
    debug_mode = args.debug

    try:
        logger.cleanup_old_logs()
    except Exception as e:
        logger.error("LOGGER", "CLEANUP_STARTUP_ERROR", exc=e)

    logger.info("STARTUP", "SYSTEM", "KAGEVIETSUB starting")
    
    from TOOL.services.storage_service import StorageService
    from TOOL.config import get_local_version
    
    ver = get_local_version()
    logger.info("STARTUP", "VERSION", f"version={ver}")
    logger.info("STARTUP", "PLATFORM", f"platform={'android_termux' if is_android() else platform.system().lower()}")
    logger.info("STARTUP", "ARCH", f"architecture={platform.machine() or 'unknown'}")
    logger.info("STARTUP", "PYTHON", f"version={platform.python_version()}")

    sys_info = get_full_system_info()
    logger.write_machine_info(sys_info, host=host, port=port)

    cpu_cores = sys_info.get("cpu", {}).get("logical_cores") or os.cpu_count() or 1
    logger.info("STARTUP", "CPU", f"logical_processors={cpu_cores} model={sys_info.get('cpu', {}).get('model', 'unknown')}")
    logger.info("STARTUP", "RAM", f"total_mb={sys_info.get('memory', {}).get('total_mb', 0)} available_mb={sys_info.get('memory', {}).get('available_mb', 0)}")
    st_free_mb = sys_info.get("storage", {}).get("free_mb")
    if st_free_mb == "STORAGE_CHECK_ERROR":
        logger.warning("STARTUP", "STORAGE", "free_mb=STORAGE_CHECK_ERROR (Khong the doc dung luong o dis/quyen truy cap bị gioi han)")
    else:
        logger.info("STARTUP", "STORAGE", f"free_mb={st_free_mb if st_free_mb is not None else 0}")

    logger.info("STARTUP", "PATHS", f"project_root={ROOT_DIR} DATA={DATA_DIR} temp={DATA_DIR / 'temp'} models={DATA_DIR / 'models'} output={DATA_DIR / 'output'} download_kage={StorageService.get_output_dir()}")

    py_info = check_python_version()
    if py_info["is_supported"]:
        py_title = f"Checking Python {py_info['version']}"
        print_step(1, 8, py_title, status="ok")
    else:
        print_step(1, 8, f"Checking Python {py_info['version']}", status="fail", reason="Yêu cầu Python >= 3.8")
        logger.error("STARTUP", "PYTHON_CHECK_FAIL", f"version={py_info['version']}")
        if not debug_mode:
            sys.exit(1)

    dep_check = check_required_dependencies()
    if not dep_check["all_installed"]:
        print_step(2, 8, "Checking dependencies", status="fail", reason=f"Thiếu {dep_check['missing_count']} thư viện")
        logger.error("STARTUP", "DEPENDENCY_MISSING", f"missing_count={dep_check['missing_count']}")
        print()
        print(f" {Colors.RED}{Icons.CROSS}{Colors.RESET} {Colors.BRIGHT_RED}{Colors.BOLD}LỖI: CHƯA CÀI ĐỦ THƯ VIỆN CẦN THIẾT ĐỂ CHẠY TOOL!{Colors.RESET}")
        print(f" {Colors.GRAY}{'─' * 62}{Colors.RESET}")
        print(f" {Colors.WHITE}Các thư viện còn thiếu trên hệ thống ({dep_check['missing_count']} thư viện):{Colors.RESET}")
        for item in dep_check["missing"]:
            print(f"   {Colors.RED}•{Colors.RESET} {Colors.YELLOW}{item['package']}{Colors.RESET} {Colors.GRAY}({item['desc']}){Colors.RESET}")
        print(f"\n {Colors.CYAN}{'═' * 62}{Colors.RESET}")
        print(f" {Colors.BRIGHT_WHITE}{Colors.BOLD}👉 Vui lòng cài các thư viện cần thiết bằng lệnh:{Colors.RESET}")
        print(f"    {Colors.GREEN}{Colors.BOLD}sh setup.sh{Colors.RESET}")
        print(f" {Colors.CYAN}{'═' * 62}{Colors.RESET}\n")
        sys.exit(1)
    else:
        print_step(2, 8, "Checking dependencies", status="ok")
        logger.info("STARTUP", "DEPENDENCY_OK", "all_dependencies_installed")

    ff_info = check_ffmpeg()
    if ff_info["ffmpeg_installed"]:
        print_step(3, 8, "Checking FFmpeg", status="ok")
        logger.info("STARTUP", "FFMPEG", f"installed=true path={shutil.which('ffmpeg')}")
    else:
        print_step(3, 8, "Checking FFmpeg", status="warn")
        logger.warning("STARTUP", "FFMPEG", "installed=false")
        if is_android():
            print(f"        {Colors.GRAY}Gợi ý: Cài đặt FFmpeg trên Termux bằng lệnh: {Colors.CYAN}pkg install ffmpeg -y{Colors.RESET}")
        else:
            print(f"        {Colors.GRAY}Gợi ý: Thêm FFmpeg vào PATH hệ thống để kích hoạt đầy đủ Video/Audio Engine{Colors.RESET}")

    try:
        from TOOL import config
        print_step(4, 8, "Checking configuration", status="ok")
        logger.info("STARTUP", "CONFIG", "config_loaded")
    except Exception as e:
        print_step(4, 8, "Checking configuration", status="fail", reason=str(e))
        logger.error("STARTUP", "CONFIG_FAIL", exc=e)
        if debug_mode:
            raise

    try:
        from TOOL.engines import srt_engine
        print_step(5, 8, "Checking SRT Engine", status="ok")
        logger.info("STARTUP", "SRT_ENGINE", "initialized")
    except Exception as e:
        print_step(5, 8, "Checking SRT Engine", status="fail", reason=str(e))
        logger.error("STARTUP", "SRT_ENGINE_FAIL", exc=e)
        if debug_mode:
            raise

    try:
        from TOOL.engines import audio_engine
        print_step(6, 8, "Checking Audio Engine", status="ok")
        logger.info("STARTUP", "AUDIO_ENGINE", "initialized")
    except Exception as e:
        print_step(6, 8, "Checking Audio Engine", status="fail", reason=str(e))
        logger.error("STARTUP", "AUDIO_ENGINE_FAIL", exc=e)
        if debug_mode:
            raise

    try:
        from TOOL.engines import video_engine
        print_step(7, 8, "Checking Video Engine", status="ok")
        logger.info("STARTUP", "VIDEO_ENGINE", "initialized")
    except Exception as e:
        print_step(7, 8, "Checking Video Engine", status="fail", reason=str(e))
        logger.error("STARTUP", "VIDEO_ENGINE_FAIL", exc=e)
        if debug_mode:
            raise

    try:
        from TOOL.services.cleanup_service import CleanupService
        CleanupService.cleanup_orphaned_temp()
        logger.info("STARTUP", "TEMP_CLEANUP", "orphaned_temp_cleaned")
    except Exception as e:
        logger.warning("STARTUP", "TEMP_CLEANUP_WARN", exc=e)

    print_step(8, 8, "Starting server (Localhost Only)", status="ok")

    max_attempts = 2

    for attempt in range(max_attempts):
        if not ensure_port_available(host, port):
            logger.error("STARTUP", "PORT_UNAVAILABLE", f"port={port}")
            sys.exit(1)

        print(f"[START]\nStarting KAGEVIETSUB\n")
        logger.info("STARTUP", "SERVER_STARTING", f"host={host} port={port}")
        print(f"[SERVER]\nhttp://{host}:{port}\n")

        local_url = f"http://{host}:{port}"
        print_server_card(local_url=local_url, port=port)

        if not args.no_browser and attempt == 0:
            open_browser(local_url)

        write_pid_file()

        try:
            from TOOL.server import run_server
            logger.info("SERVER", "RUNNING", f"url={local_url}")
            run_server(host=host, port=port)
            break
        except KeyboardInterrupt:
            print(f"\n {Colors.CYAN}{Icons.INFO}{Colors.RESET} {Colors.BRIGHT_WHITE}KAGEVIETSUB đã dừng an toàn. Hẹn gặp lại!{Colors.RESET}\n")
            logger.info("SHUTDOWN", "START", "shutdown requested by user (KeyboardInterrupt)")
            remove_pid_file()
            logger.info("SHUTDOWN", "COMPLETE", "KAGEVIETSUB stopped")
            sys.exit(0)
        except OSError as e:
            remove_pid_file()
            if e.errno in (errno.EADDRINUSE, 98, 10048) or "address already in use" in str(e).lower():
                if attempt < max_attempts - 1:
                    print_warning(f"Port {port} bị chiếm trong quá trình bind (Address already in use). Đang thử giải phóng lại...")
                    logger.warning("SERVER", "BIND_CONFLICT", f"port={port} attempt={attempt + 1}")
                    time.sleep(1.0)
                    continue
                else:
                    print_error("Lỗi bind port máy chủ", reason=str(e))
                    logger.critical("SERVER", "BIND_FATAL", f"port={port}", exc=e)
                    sys.exit(1)
            else:
                print_error("Lỗi khi khởi chạy máy chủ", reason=str(e))
                logger.critical("SERVER", "OS_ERROR", exc=e)
                if debug_mode:
                    import traceback
                    traceback.print_exc()
                sys.exit(1)
        except Exception as e:
            remove_pid_file()
            print_error("Lỗi khi khởi chạy máy chủ", reason=str(e))
            logger.critical("SERVER", "FATAL_EXCEPTION", exc=e)
            if debug_mode:
                import traceback
                traceback.print_exc()
            sys.exit(1)

if __name__ == "__main__":
    main()
