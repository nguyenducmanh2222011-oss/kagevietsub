import express from "express";
import path from "path";
import fs from "fs";
import { spawn } from "child_process";
import multer from "multer";
import { createRequire } from "module";
import { createServer as createViteServer } from "vite";

const require = createRequire(import.meta.url);
const archiver = require("archiver");

const app = express();
const PORT = 3000;
const ROOT_DIR = process.cwd();
const DATA_DIR = path.join(ROOT_DIR, "DATA");
const TEMP_DIR = path.join(DATA_DIR, "temp");
const OUTPUT_DIR = path.join(DATA_DIR, "output");
const UPLOADS_DIR = path.join(DATA_DIR, "uploads");
const MODELS_DIR = path.join(DATA_DIR, "models");
const LOGS_DIR = path.join(DATA_DIR, "logs");

// Ensure data folders exist
[DATA_DIR, TEMP_DIR, OUTPUT_DIR, UPLOADS_DIR, MODELS_DIR, LOGS_DIR].forEach((dir) => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
});

// Multer storage configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (req, file, cb) => {
    const cleanName = file.originalname.replace(/[^a-zA-Z0-9._-]/g, "_");
    cb(null, `${Date.now()}_${cleanName}`);
  },
});
const upload = multer({ storage });

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

// In-memory Job Queue
interface Job {
  job_id: string;
  type: string;
  status: "queued" | "processing" | "completed" | "completed_with_errors" | "failed";
  progress: number;
  message: string;
  download_url: string | null;
  saved_location?: string | null;
  filename: string | null;
  created_at: number;
  completed_at: number | null;
  error: string | null;
  result: any;
  metadata?: any;
}
const jobs = new Map<string, Job>();

function createJob(type: string, metadata: any = {}): string {
  const jobId = Math.random().toString(36).substring(2, 14);
  jobs.set(jobId, {
    job_id: jobId,
    type,
    status: "queued",
    progress: 0,
    message: "Tác vụ đã được tạo...",
    download_url: null,
    filename: null,
    created_at: Date.now(),
    completed_at: null,
    error: null,
    result: null,
    metadata,
  });
  return jobId;
}

function updateJob(jobId: string, updates: Partial<Job>) {
  const current = jobs.get(jobId);
  if (current) {
    jobs.set(jobId, { ...current, ...updates });
  }
}

// Helper: Run Python snippet
function runPythonCode(code: string): Promise<any> {
  return new Promise((resolve, reject) => {
    const py = spawn("python3", ["-c", code], {
      cwd: ROOT_DIR,
      env: { ...process.env, PYTHONPATH: ROOT_DIR },
    });
    let stdout = "";
    let stderr = "";
    py.stdout.on("data", (data) => (stdout += data.toString()));
    py.stderr.on("data", (data) => (stderr += data.toString()));
    py.on("close", (code) => {
      if (code !== 0) {
        reject(new Error(stderr || `Python exited with code ${code}`));
      } else {
        const trimmed = stdout.trim();
        try {
          resolve(JSON.parse(trimmed));
        } catch {
          const match = trimmed.match(/(\{[\s\S]*\}|\[[\s\S]*\])/);
          if (match) {
            try {
              resolve(JSON.parse(match[0]));
              return;
            } catch {}
          }
          resolve(trimmed);
        }
      }
    });
  });
}

// -------------------------------------------------------------
// API ROUTES
// -------------------------------------------------------------

// 1. Health Check
app.get("/api/health", async (req, res) => {
  try {
    const code = `
import json, platform, shutil
from TOOL.services.ffmpeg_service import FFmpegService
ffmpeg_ok = FFmpegService.is_ffmpeg_installed()
ffprobe_ok = FFmpegService.is_ffprobe_installed()
nvenc_ok = FFmpegService.check_nvenc_support()
whisper_ok = False
try:
    import faster_whisper
    whisper_ok = True
except ImportError:
    whisper_ok = False

print(json.dumps({
    "status": "healthy",
    "system": {
        "python_version": platform.python_version(),
        "os": platform.system(),
        "platform": platform.platform()
    },
    "components": {
        "ffmpeg": {"installed": ffmpeg_ok, "status": "Ready" if ffmpeg_ok else "Missing"},
        "ffprobe": {"installed": ffprobe_ok, "status": "Ready" if ffprobe_ok else "Missing"},
        "nvenc_gpu": {"available": nvenc_ok, "status": "Supported" if nvenc_ok else "CPU Only"},
        "whisper_engine": {"available": whisper_ok, "status": "Ready" if whisper_ok else "Standard Mode"},
        "srt_engine": {"status": "Ready"},
        "audio_engine": {"status": "Ready" if ffmpeg_ok else "Needs FFmpeg"},
        "video_engine": {"status": "Ready" if ffmpeg_ok else "Needs FFmpeg"}
    }
}))
    `;
    const result = await runPythonCode(code);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 2. SRT Endpoints
app.post("/api/srt/parse", async (req, res) => {
  const { content } = req.body;
  const pyCode = `
import json
from TOOL.engines.srt_engine import SrtEngine
content = ${JSON.stringify(content || "")}
blocks = SrtEngine.parse_srt(content)
print(json.dumps({"blocks": blocks, "total": len(blocks)}))
  `;
  try {
    const result = await runPythonCode(pyCode);
    res.json(result);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.post("/api/srt/remove-trailing-punctuation", async (req, res) => {
  const { content } = req.body;
  const pyCode = `
import json
from TOOL.engines.srt_engine import SrtEngine
content = ${JSON.stringify(content || "")}
res, count = SrtEngine.remove_trailing_punctuation(content)
print(json.dumps({"content": res, "changed_lines": count}))
  `;
  try {
    const result = await runPythonCode(pyCode);
    res.json(result);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.post("/api/srt/remove-leading-ellipsis", async (req, res) => {
  const { content } = req.body;
  const pyCode = `
import json
from TOOL.engines.srt_engine import SrtEngine
content = ${JSON.stringify(content || "")}
res, count = SrtEngine.remove_leading_ellipsis(content)
print(json.dumps({"content": res, "changed_lines": count}))
  `;
  try {
    const result = await runPythonCode(pyCode);
    res.json(result);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.post("/api/srt/replace", async (req, res) => {
  const { content, rules } = req.body;
  const pyCode = `
import json
from TOOL.engines.srt_engine import SrtEngine
content = ${JSON.stringify(content || "")}
rules = ${JSON.stringify(rules || "... -> ,\\n. -> ,\\n! -> ,\\nvi -> Vi\\nxi -> Xi\\n\\\" -> ")}
res, count = SrtEngine.apply_sequential_replace(content, rules)
print(json.dumps({"content": res, "total_replacements": count}))
  `;
  try {
    const result = await runPythonCode(pyCode);
    res.json(result);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.post("/api/srt/avoid-overlap", async (req, res) => {
  const { content } = req.body;
  const pyCode = `
import json
from TOOL.engines.srt_engine import SrtEngine
content = ${JSON.stringify(content || "")}
res, count = SrtEngine.avoid_overlap(content)
print(json.dumps({"content": res, "adjusted_sentences": count}))
  `;
  try {
    const result = await runPythonCode(pyCode);
    res.json(result);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.post("/api/srt/purple-sequence", async (req, res) => {
  const { content, rules } = req.body;
  const pyCode = `
import json
from TOOL.engines.srt_engine import SrtEngine
content = ${JSON.stringify(content || "")}
rules = ${JSON.stringify(rules || "... -> ,\\n. -> ,\\n! -> ,\\nvi -> Vi\\nxi -> Xi\\n\\\" -> ")}
res, stats = SrtEngine.run_purple_sequence(content, rules)
print(json.dumps({"content": res, "stats": stats}))
  `;
  try {
    const result = await runPythonCode(pyCode);
    res.json(result);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.post("/api/srt/fix-repeat-2-3", async (req, res) => {
  const { content } = req.body;
  const pyCode = `
import json
from TOOL.engines.srt_engine import SrtEngine
content = ${JSON.stringify(content || "")}
res, count = SrtEngine.fix_repeated_words_2_3(content)
print(json.dumps({"content": res, "merged_count": count}))
  `;
  try {
    const result = await runPythonCode(pyCode);
    res.json(result);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.post("/api/srt/fix-repeat-4-5", async (req, res) => {
  const { content } = req.body;
  const pyCode = `
import json
from TOOL.engines.srt_engine import SrtEngine
content = ${JSON.stringify(content || "")}
res, count = SrtEngine.fix_repeated_words_4_5(content)
print(json.dumps({"content": res, "merged_count": count}))
  `;
  try {
    const result = await runPythonCode(pyCode);
    res.json(result);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.post("/api/srt/merge-short", async (req, res) => {
  const { content } = req.body;
  const pyCode = `
import json
from TOOL.engines.srt_engine import SrtEngine
content = ${JSON.stringify(content || "")}
res1, c1 = SrtEngine.merge_short_blocks_3_tiers(content)
res2, c2 = SrtEngine.merge_short_previous(res1)
print(json.dumps({"content": res2, "total_merged": c1 + c2}))
  `;
  try {
    const result = await runPythonCode(pyCode);
    res.json(result);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.post("/api/srt/all-steps", async (req, res) => {
  const { content, rules } = req.body;
  const pyCode = `
import json
from TOOL.engines.srt_engine import SrtEngine
content = ${JSON.stringify(content || "")}
rules = ${JSON.stringify(rules || "... -> ,\\n. -> ,\\n! -> ,\\nvi -> Vi\\nxi -> Xi\\n\\\" -> ")}
res, stats = SrtEngine.run_all_sequence(content, rules)
print(json.dumps({"content": res, "stats": stats}))
  `;
  try {
    const result = await runPythonCode(pyCode);
    res.json(result);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.post("/api/srt/uppercase", async (req, res) => {
  const { content } = req.body;
  const pyCode = `
import json
from TOOL.engines.srt_engine import SrtEngine
content = ${JSON.stringify(content || "")}
res = SrtEngine.uppercase_srt(content)
print(json.dumps({"content": res}))
  `;
  try {
    const result = await runPythonCode(pyCode);
    res.json(result);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.post("/api/srt/split", async (req, res) => {
  const { content, sentences_per_file, base_name } = req.body;
  const pyCode = `
import json
from TOOL.engines.srt_engine import SrtEngine
content = ${JSON.stringify(content || "")}
n = ${parseInt(sentences_per_file || "10", 10)}
name = ${JSON.stringify(base_name || "subtitle")}
files, zip_path = SrtEngine.split_srt(content, n, name)
print(json.dumps({
    "files": files,
    "zip_filename": zip_path.name,
    "download_url": f"/api/download/{zip_path.name}",
    "saved_location": f"KAGEVIETSUB/{zip_path.name}"
}))
  `;
  try {
    const result = await runPythonCode(pyCode);
    res.json(result);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.post("/api/srt/save", (req, res) => {
  const { content, filename } = req.body;
  if (!content) {
    return res.status(400).json({ error: "Thiếu nội dung SRT." });
  }
  const safeName = path.basename(filename || "subtitle.srt");
  const saveDir = path.join(ROOT_DIR, "KAGEVIETSUB");
  if (!fs.existsSync(saveDir)) {
    fs.mkdirSync(saveDir, { recursive: true });
  }
  const filePath = path.join(saveDir, safeName);
  try {
    fs.writeFileSync(filePath, content, "utf-8");
    res.json({
      status: "saved",
      filename: safeName,
      saved_location: `KAGEVIETSUB/${safeName}`,
      full_path: filePath,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 3. Audio Merge Endpoint
app.post("/api/audio/merge", upload.array("files"), async (req, res) => {
  const files = req.files as Express.Multer.File[];
  if (!files || files.length < 2) {
    return res.status(400).json({ error: "Cần ít nhất 2 file âm thanh để ghép." });
  }

  const outputName = (req.body.output_filename || "combined.mp3").replace(/[^a-zA-Z0-9._-]/g, "_");
  const sortAlpha = req.body.sort_alphabetical === "true" || req.body.sort_alphabetical === true;
  const jobId = createJob("audio_merge", { filesCount: files.length });

  // Process asynchronously
  setTimeout(async () => {
    updateJob(jobId, { status: "processing", progress: 20, message: `Đang chuẩn bị ghép ${files.length} file...` });
    const filePaths = files.map((f) => f.path);
    const pyCode = `
import json
from pathlib import Path
from TOOL.engines.audio_engine import AudioEngine
paths = [Path(p) for p in ${JSON.stringify(filePaths)}]
out_name = ${JSON.stringify(outputName)}
sort_a = ${sortAlpha ? "True" : "False"}
ok, err, out_p = AudioEngine.merge_audio_files(paths, out_name, sort_a)
if not ok:
    raise RuntimeError(err)
print(json.dumps({
    "filename": out_p.name,
    "size_mb": round(out_p.stat().st_size / (1024*1024), 2)
}))
    `;
    try {
      updateJob(jobId, { progress: 60, message: "FFmpeg đang nối file âm thanh..." });
      const result = await runPythonCode(pyCode);
      updateJob(jobId, {
        status: "completed",
        progress: 100,
        message: "Ghép âm thanh thành công!",
        filename: result.filename,
        download_url: `/api/download/${result.filename}`,
        saved_location: `KAGEVIETSUB/${result.filename}`,
        result,
      });
    } catch (err: any) {
      updateJob(jobId, { status: "failed", error: err.message, message: `Lỗi ghép audio: ${err.message}` });
    }
  }, 100);

  res.json({ jobId, job_id: jobId, status: "queued", message: `Đã đưa ${files.length} file vào hàng đợi.` });
});

// 4. Video Cut Endpoint
app.post("/api/video/cut", upload.single("file"), async (req, res) => {
  const file = req.file;
  if (!file) {
    return res.status(400).json({ error: "Chưa tải lên file video." });
  }
  const segmentMinutes = parseInt(req.body.segment_minutes || "5", 10);
  const mode = req.body.mode || "copy";
  const jobId = createJob("video_cut", { filename: file.originalname, segmentMinutes });

  setTimeout(async () => {
    updateJob(jobId, { status: "processing", progress: 15, message: `Đang cắt video thành các đoạn ${segmentMinutes} phút...` });
    const pyCode = `
import json
from pathlib import Path
from TOOL.engines.video_engine import VideoEngine
res = VideoEngine.cut_video_segments(Path(${JSON.stringify(file.path)}), segment_minutes=${segmentMinutes}, mode=${JSON.stringify(mode)})
print(json.dumps(res))
    `;
    try {
      updateJob(jobId, { progress: 50, message: "Đang xử lý phân đoạn và đóng gói ZIP..." });
      const result = await runPythonCode(pyCode);
      updateJob(jobId, {
        status: "completed",
        progress: 100,
        message: `Đã cắt thành công ${result.total_segments} đoạn!`,
        filename: result.zip_filename,
        download_url: `/api/download/${result.zip_filename}`,
        saved_location: `KAGEVIETSUB/${result.zip_filename}`,
        result,
      });
    } catch (err: any) {
      updateJob(jobId, { status: "failed", error: err.message, message: `Lỗi cắt video: ${err.message}` });
    }
  }, 100);

  res.json({ jobId, job_id: jobId, status: "queued", message: "Đã tạo tác vụ cắt video." });
});

// 5. Video Merge Endpoint
app.post("/api/video/merge", upload.array("files"), async (req, res) => {
  const files = req.files as Express.Multer.File[];
  if (!files || files.length < 2) {
    return res.status(400).json({ error: "Cần ít nhất 2 file video để ghép." });
  }
  const outputFilename = (req.body.output_filename || "merged_video.mp4").replace(/[^a-zA-Z0-9._-]/g, "_");
  const mode = req.body.mode || "lossless";
  const caption = req.body.caption || null;
  const fontSize = parseInt(req.body.font_size || "24", 10);
  const fontColor = req.body.font_color || "white";
  const captionPos = req.body.caption_position || "bottom";

  const jobId = createJob("video_merge", { filesCount: files.length, mode });

  setTimeout(async () => {
    updateJob(jobId, { status: "processing", progress: 20, message: `Đang ghép ${files.length} video (chế độ: ${mode})...` });
    const filePaths = files.map((f) => f.path);
    const pyCode = `
import json
from pathlib import Path
from TOOL.engines.video_engine import VideoEngine
paths = [Path(p) for p in ${JSON.stringify(filePaths)}]
res = VideoEngine.merge_video_files(
    paths,
    output_filename=${JSON.stringify(outputFilename)},
    mode=${JSON.stringify(mode)},
    caption=${JSON.stringify(caption)},
    font_size=${fontSize},
    font_color=${JSON.stringify(fontColor)},
    caption_position=${JSON.stringify(captionPos)}
)
print(json.dumps(res))
    `;
    try {
      updateJob(jobId, { progress: 65, message: "Đang hoàn tất xử lý video..." });
      const result = await runPythonCode(pyCode);
      updateJob(jobId, {
        status: "completed",
        progress: 100,
        message: "Ghép video thành công!",
        filename: result.filename,
        download_url: `/api/download/${result.filename}`,
        saved_location: `KAGEVIETSUB/${result.filename}`,
        result,
      });
    } catch (err: any) {
      updateJob(jobId, { status: "failed", error: err.message, message: `Lỗi ghép video: ${err.message}` });
    }
  }, 100);

  res.json({ jobId, job_id: jobId, status: "queued", message: `Đã đưa ${files.length} video vào hàng đợi.` });
});

// 6. Video Compress Endpoint
app.post("/api/video/compress", upload.single("file"), async (req, res) => {
  const file = req.file;
  if (!file) {
    return res.status(400).json({ error: "Chưa tải lên video." });
  }
  const crf = parseInt(req.body.crf || "23", 10);
  const preset = req.body.preset || "slow";
  const codec = req.body.codec || "libx264";
  const jobId = createJob("video_compress", { filename: file.originalname, crf });

  setTimeout(async () => {
    updateJob(jobId, { status: "processing", progress: 20, message: `Đang nén video (CRF=${crf}, preset=${preset})...` });
    const pyCode = `
import json
from pathlib import Path
from TOOL.engines.video_engine import VideoEngine
res = VideoEngine.compress_video_file(
    Path(${JSON.stringify(file.path)}),
    crf=${crf},
    preset=${JSON.stringify(preset)},
    codec=${JSON.stringify(codec)}
)
print(json.dumps(res))
    `;
    try {
      updateJob(jobId, { progress: 70, message: "Đang lưu video nén..." });
      const result = await runPythonCode(pyCode);
      updateJob(jobId, {
        status: "completed",
        progress: 100,
        message: `Nén thành công! Giảm -${result.saved_percent}% dung lượng.`,
        filename: result.filename,
        download_url: `/api/download/${result.filename}`,
        saved_location: `KAGEVIETSUB/${result.filename}`,
        result,
      });
    } catch (err: any) {
      updateJob(jobId, { status: "failed", error: err.message, message: `Lỗi nén video: ${err.message}` });
    }
  }, 100);

  res.json({ jobId, job_id: jobId, status: "queued", message: "Đã tạo tác vụ nén video." });
});

// 7. Video Info
app.post("/api/video/info", upload.single("file"), async (req, res) => {
  const file = req.file;
  if (!file) return res.status(400).json({ error: "Chưa tải lên file." });
  const pyCode = `
import json
from pathlib import Path
from TOOL.services.ffmpeg_service import FFmpegService
info = FFmpegService.get_media_info(Path(${JSON.stringify(file.path)}))
print(json.dumps(info))
  `;
  try {
    const result = await runPythonCode(pyCode);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 8. Whisper Endpoints
app.get("/api/whisper/models", (req, res) => {
  res.json({
    models: [
      { id: "large-v3-turbo", name: "Large v3 Turbo (Khuyên dùng)", recommended: true },
      { id: "large-v3", name: "Large v3 (Chính xác tối đa)" },
      { id: "medium", name: "Medium (Cân bằng)" },
      { id: "small", name: "Small (Nhanh)" },
      { id: "base", name: "Base (Nhẹ)" },
      { id: "tiny", name: "Tiny (Siêu nhẹ)" },
    ],
  });
});

app.post("/api/whisper/transcribe", upload.single("file"), async (req, res) => {
  const file = req.file;
  if (!file) return res.status(400).json({ error: "Chưa tải file media." });

  const modelSize = req.body.model_size || "large-v3-turbo";
  const maxWords = parseInt(req.body.max_words || "20", 10);
  const maxDuration = parseFloat(req.body.max_duration || "6.0");
  const silenceThreshold = parseFloat(req.body.silence_threshold || "0.3");

  const jobId = createJob("whisper_transcribe", { filename: file.originalname, modelSize });

  setTimeout(async () => {
    updateJob(jobId, { status: "processing", progress: 20, message: "Đang boost audio 25dB và chạy lọc Whisper..." });
    const pyCode = `
import json
from pathlib import Path
from TOOL.engines.whisper_engine import WhisperEngine
res = WhisperEngine.transcribe_audio_to_srt(
    Path(${JSON.stringify(file.path)}),
    model_size=${JSON.stringify(modelSize)},
    max_words=${maxWords},
    max_duration=${maxDuration},
    silence_threshold=${silenceThreshold}
)
print(json.dumps(res))
    `;
    try {
      updateJob(jobId, { progress: 65, message: "Đang lọc watermark, tiếng Anh và tách câu ngắn..." });
      const result = await runPythonCode(pyCode);
      updateJob(jobId, {
        status: "completed",
        progress: 100,
        message: `Trích xuất hoàn tất (${result.segments_count} câu)!`,
        filename: result.filename,
        download_url: `/api/download/${result.filename}`,
        saved_location: `KAGEVIETSUB/${result.filename}`,
        result,
      });
    } catch (err: any) {
      updateJob(jobId, { status: "failed", error: err.message, message: `Lỗi Whisper: ${err.message}` });
    }
  }, 100);

  res.json({ jobId, job_id: jobId, status: "queued", message: "Đã tạo tác vụ nhận diện Whisper." });
});

// 9. Job Tracking
app.get("/api/jobs/:id", (req, res) => {
  const job = jobs.get(req.params.id);
  if (!job) return res.status(404).json({ error: "Không tìm thấy tác vụ." });
  res.json(job);
});

app.get("/api/jobs", (req, res) => {
  const jobList = Array.from(jobs.values()).sort((a, b) => b.created_at - a.created_at);
  res.json({ jobs: jobList.slice(0, 20) });
});

// 10. File Download
app.get("/api/download/:filename", (req, res) => {
  const safeName = path.basename(req.params.filename);
  const possiblePaths = [
    path.join(OUTPUT_DIR, safeName),
    path.join(TEMP_DIR, safeName),
    path.join(UPLOADS_DIR, safeName),
    path.join(ROOT_DIR, safeName),
    path.join("/storage/emulated/0/Download/KAGEVIETSUB", safeName)
  ];
  const foundPath = possiblePaths.find((p) => fs.existsSync(p) && fs.statSync(p).isFile());
  if (!foundPath) {
    return res.status(404).json({ error: `File '${safeName}' không tồn tại trên hệ thống.` });
  }
  res.download(foundPath, safeName);
});

// 11. Cleanup
app.post("/api/cleanup", (req, res) => {
  let cleanedCount = 0;
  let cleanedBytes = 0;
  [TEMP_DIR, UPLOADS_DIR].forEach((folder) => {
    if (fs.existsSync(folder)) {
      fs.readdirSync(folder).forEach((file) => {
        try {
          const p = path.join(folder, file);
          const st = fs.statSync(p);
          if (st.isFile()) {
            cleanedBytes += st.size;
            fs.unlinkSync(p);
            cleanedCount++;
          }
        } catch {}
      });
    }
  });
  res.json({ cleaned_files: cleanedCount, freed_mb: Math.round((cleanedBytes / (1024 * 1024)) * 100) / 100 });
});

// 11.5. TTS Studio [BETA] Endpoints
app.get("/api/tts/voices", (req, res) => {
  const pyCode = `
import json
from TOOL.engines.tts_engine import TTSEngine
voices = TTSEngine.get_voices()
print(json.dumps({"voices": voices}))
  `;
  runPythonCode(pyCode)
    .then((result) => res.json(result))
    .catch((err) => res.status(500).json({ error: err.message }));
});

app.post("/api/tts/parse-srt", (req, res) => {
  const { srt_content } = req.body;
  if (!srt_content) return res.status(400).json({ error: "Nội dung phụ đề rỗng." });
  const pyCode = `
import json
from TOOL.engines.tts_engine import TTSEngine
subs = TTSEngine.parse_srt(r'''${srt_content.replace(/\\/g, "\\\\").replace(/'''/g, "\\'\\'\\'")}''')
print(json.dumps({"subtitles": subs, "total": len(subs)}))
  `;
  runPythonCode(pyCode)
    .then((result) => res.json(result))
    .catch((err) => res.status(500).json({ error: err.message }));
});

app.post("/api/tts/create-job", (req, res) => {
  let { srt_content, voice = "BV421_vivn_streaming", speed = 1.0, threads = 5, output_filename = "tts_final_audio.mp3", audio_format = "mp3" } = req.body;
  if (!srt_content) return res.status(400).json({ error: "Nội dung SRT rỗng." });

  audio_format = String(audio_format || "mp3").toLowerCase().trim().replace(".", "");
  if (audio_format !== "wav" && audio_format !== "mp3") audio_format = "mp3";

  if (audio_format === "wav") {
    if (!output_filename.toLowerCase().endsWith(".wav")) {
      output_filename = output_filename.replace(/\.[^/.]+$/, "") + ".wav";
    }
  } else {
    if (!output_filename.toLowerCase().endsWith(".mp3")) {
      output_filename = output_filename.replace(/\.[^/.]+$/, "") + ".mp3";
    }
  }

  const safeThreads = Math.max(1, Math.min(30, parseInt(threads, 10) || 5));
  const safeSpeed = Math.max(0.5, Math.min(2.0, parseFloat(speed) || 1.0));
  const jobId = createJob("tts_generate", { voice, speed: safeSpeed, threads: safeThreads, output_filename, audio_format });

  setTimeout(async () => {
    updateJob(jobId, { status: "processing", progress: 5, message: `Khởi tạo xử lý TTS (${audio_format.toUpperCase()}) với ${safeThreads} luồng...` });
    const pyCode = `
import json
from TOOL.engines.tts_engine import TTSEngine

def on_prog(done, total, cur_sub):
    pass

res = TTSEngine.process_tts_job(
    job_id=${JSON.stringify(jobId)},
    srt_content=r'''${srt_content.replace(/\\/g, "\\\\").replace(/'''/g, "\\'\\'\\'")}''',
    voice=${JSON.stringify(voice)},
    speed=${safeSpeed},
    threads=${safeThreads},
    output_filename=${JSON.stringify(output_filename)},
    audio_format=${JSON.stringify(audio_format)}
)
print(json.dumps(res))
    `;
    try {
      const result = await runPythonCode(pyCode);
      const isComplete = result.failed === 0;
      updateJob(jobId, {
        status: isComplete ? "completed" : "completed_with_errors",
        progress: 100,
        message: isComplete ? "Đã tạo giọng đọc TTS thành công cho tất cả câu!" : `Đã hoàn thành với ${result.failed} câu bị lỗi.`,
        filename: result.final_audio,
        download_url: result.final_audio ? `/api/download/${result.final_audio}` : null,
        saved_location: result.saved_location || null,
        result,
      });
    } catch (err: any) {
      updateJob(jobId, { status: "failed", error: err.message, message: `Lỗi tạo TTS: ${err.message}` });
    }
  }, 50);

  res.json({ jobId, job_id: jobId, status: "queued", audio_format, message: `Đã đưa tác vụ TTS (${audio_format.toUpperCase()}, ${safeThreads} luồng) vào hàng đợi.` });
});

app.post("/api/tts/retry", async (req, res) => {
  const { job_id, subtitle_index, voice = "BV421_vivn_streaming", speed = 1.0 } = req.body;
  if (!job_id || subtitle_index === undefined) return res.status(400).json({ error: "Thiếu job_id hoặc subtitle_index." });

  const pyCode = `
import json
from TOOL.engines.tts_engine import TTSEngine
res = TTSEngine.retry_single_subtitle(
    job_id=${JSON.stringify(job_id)},
    subtitle_index=${parseInt(subtitle_index, 10)},
    voice=${JSON.stringify(voice)},
    speed=${parseFloat(speed) || 1.0}
)
print(json.dumps(res))
  `;
  try {
    const result = await runPythonCode(pyCode);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

const handleTTSMergeAction = async (req: express.Request, res: express.Response) => {
  const jobId = req.params.jobId || req.body.job_id;
  let { output_filename = "tts_final_audio.mp3", audio_format } = req.body;
  if (!jobId) return res.status(400).json({ error: "Thiếu job_id." });

  const existingJob = jobs.get(jobId);
  if (!audio_format) {
    audio_format = existingJob?.metadata?.audio_format || (output_filename.toLowerCase().endsWith(".wav") ? "wav" : "mp3");
  }
  audio_format = String(audio_format).toLowerCase().trim().replace(".", "");
  if (audio_format !== "wav" && audio_format !== "mp3") audio_format = "mp3";

  if (audio_format === "wav") {
    if (!output_filename.toLowerCase().endsWith(".wav")) {
      output_filename = output_filename.replace(/\.[^/.]+$/, "") + ".wav";
    }
  } else {
    if (!output_filename.toLowerCase().endsWith(".mp3")) {
      output_filename = output_filename.replace(/\.[^/.]+$/, "") + ".mp3";
    }
  }

  const pyCode = `
import json
from TOOL.engines.tts_engine import TTSEngine
res = TTSEngine.merge_tts_job_audio(
    job_id=${JSON.stringify(jobId)},
    output_filename=${JSON.stringify(output_filename)},
    audio_format=${JSON.stringify(audio_format)}
)
print(json.dumps(res))
  `;
  try {
    const result = await runPythonCode(pyCode);
    updateJob(jobId, {
      status: "completed",
      progress: 100,
      message: "Ghép audio theo timeline SRT thành công!",
      filename: result.filename,
      download_url: `/api/download/${result.filename}`,
      saved_location: result.saved_location,
      result,
    });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
};

app.post("/api/tts/merge", handleTTSMergeAction);
app.post("/api/tts/:jobId/merge", handleTTSMergeAction);

const handleTTSJobStatus = (req: express.Request, res: express.Response) => {
  const jobId = req.params.jobId;
  const memJob = jobs.get(jobId);

  // Check state.json on disk if exists
  const diskStatePaths = [
    path.join(DATA_DIR, "temp", "tts", jobId, "state.json"),
    path.join(DATA_DIR, "temp", jobId, "state.json"),
  ];
  for (const p of diskStatePaths) {
    if (fs.existsSync(p)) {
      try {
        const raw = fs.readFileSync(p, "utf-8");
        const stateObj = JSON.parse(raw);
        return res.json({ ...(memJob || {}), ...stateObj, job_id: jobId });
      } catch {}
    }
  }

  if (memJob) return res.json(memJob);
  return res.status(404).json({ error: "Không tìm thấy job TTS." });
};

app.get("/api/tts/status/:jobId", handleTTSJobStatus);
app.get("/api/tts/job/:jobId", handleTTSJobStatus);
app.get("/api/jobs/:jobId", handleTTSJobStatus);

app.get(["/api/tts/merge-recovery/folders", "/api/tts/merge-recovery/sources"], async (req, res) => {
  const pyCode = `
import json
from TOOL.api.tts_api import handle_tts_merge_recovery_folders
print(json.dumps(handle_tts_merge_recovery_folders()))
  `;
  try {
    const result = await runPythonCode(pyCode);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/tts/merge-recovery/status/:jobId", handleTTSJobStatus);

app.post(["/api/tts/merge-recovery/cancel", "/api/tts/merge-recovery/cancel/:jobId"], async (req, res) => {
  const jobId = req.params.jobId || req.body?.job_id;
  if (!jobId) {
    return res.status(400).json({ error: "Thiếu job_id." });
  }
  const pyCode = `
import json
from TOOL.api.tts_api import handle_tts_stop
print(json.dumps(handle_tts_stop(${JSON.stringify(jobId)})))
  `;
  try {
    const result = await runPythonCode(pyCode);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/tts/merge-recovery/start", async (req, res) => {
  const folder_path = req.body?.folder_path || req.body?.source_id;
  const { srt_content, output_filename = "tts_recovered_audio.mp3", audio_format = "mp3" } = req.body;
  if (!folder_path || !srt_content) {
    return res.status(400).json({ error: "Thiếu folder_path/source_id hoặc srt_content." });
  }
  const pyCode = `
import json
from TOOL.api.tts_api import handle_tts_merge_recovery_start
res = handle_tts_merge_recovery_start(
    folder_path=${JSON.stringify(folder_path)},
    srt_content=r'''${srt_content.replace(/\\/g, "\\\\").replace(/'''/g, "\\'\\'\\'")}''',
    output_filename=${JSON.stringify(output_filename)},
    audio_format=${JSON.stringify(audio_format)}
)
print(json.dumps(res))
  `;
  try {
    const result = await runPythonCode(pyCode);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 11.6. SRT AI Translation & DS2API Endpoints
app.get("/api/srt/translate/providers", async (req, res) => {
  const pyCode = `
import json
from TOOL.api.srt_api import handle_get_translate_providers
print(json.dumps(handle_get_translate_providers()))
  `;
  try {
    const result = await runPythonCode(pyCode);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/srt/translate/check-api", async (req, res) => {
  const { provider = "deepseek", api_key = "", model = "deepseek-chat" } = req.body;
  const pyCode = `
import json
from TOOL.api.srt_api import handle_check_api_key
print(json.dumps(handle_check_api_key(${JSON.stringify(provider)}, ${JSON.stringify(api_key)}, ${JSON.stringify(model)})))
  `;
  try {
    const result = await runPythonCode(pyCode);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/srt/translate/start", async (req, res) => {
  const { content = "", filename = "subtitle.srt", api_pool = [], source_lang = "zh", target_lang = "vi", batch_size = 20, user_prompt } = req.body;
  const pyCode = `
import json
from TOOL.api.srt_api import handle_start_translation
print(json.dumps(handle_start_translation(
    content=${JSON.stringify(content)},
    filename=${JSON.stringify(filename)},
    api_pool=${JSON.stringify(api_pool)},
    source_lang=${JSON.stringify(source_lang)},
    target_lang=${JSON.stringify(target_lang)},
    batch_size=${parseInt(batch_size, 10) || 20},
    user_prompt=${user_prompt ? JSON.stringify(user_prompt) : "None"}
)))
  `;
  try {
    const result = await runPythonCode(pyCode);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/srt/translate/status/:jobId", async (req, res) => {
  const jobId = req.params.jobId;
  const pyCode = `
import json
from TOOL.api.srt_api import handle_get_translation_status
print(json.dumps(handle_get_translation_status(${JSON.stringify(jobId)})))
  `;
  try {
    const result = await runPythonCode(pyCode);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/ds2api/status", async (req, res) => {
  const pyCode = `
import json
from TOOL.services.ds2api_service import ds2api_service
print(json.dumps(ds2api_service.get_status()))
  `;
  try {
    const result = await runPythonCode(pyCode);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/ds2api/models", async (req, res) => {
  const pyCode = `
import json
from TOOL.services.ds2api_service import ds2api_service
print(json.dumps({"models": ds2api_service.get_models()}))
  `;
  try {
    const result = await runPythonCode(pyCode);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/ds2api/accounts", async (req, res) => {
  const pyCode = `
import json
from TOOL.services.ds2api_service import DS2APIConfigManager
print(json.dumps({"accounts": DS2APIConfigManager.get_public_accounts()}))
  `;
  try {
    const result = await runPythonCode(pyCode);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/ds2api/start", async (req, res) => {
  const pyCode = `
import json
from TOOL.services.ds2api_service import ds2api_service
print(json.dumps(ds2api_service.start_service()))
  `;
  try {
    const result = await runPythonCode(pyCode);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/ds2api/stop", async (req, res) => {
  const pyCode = `
import json
from TOOL.services.ds2api_service import ds2api_service
print(json.dumps(ds2api_service.stop_service()))
  `;
  try {
    const result = await runPythonCode(pyCode);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/ds2api/accounts", async (req, res) => {
  const { name = "", login_id = "", email = "", mobile = "", password = "", is_mobile = false } = req.body;
  const actualLogin = login_id || email || mobile;
  if (!actualLogin || !password) {
    return res.status(400).json({ error: "Vui lòng nhập đầy đủ tài khoản và mật khẩu." });
  }
  const pyCode = `
import json
from TOOL.services.ds2api_service import DS2APIConfigManager
print(json.dumps(DS2APIConfigManager.add_account(
    name=${JSON.stringify(name)},
    login_id=${JSON.stringify(actualLogin)},
    password=${JSON.stringify(password)},
    is_mobile=${is_mobile ? "True" : "False"}
)))
  `;
  try {
    const result = await runPythonCode(pyCode);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/ds2api/accounts/test", async (req, res) => {
  const { account_id } = req.body;
  if (!account_id) return res.status(400).json({ error: "Thiếu account_id" });
  const pyCode = `
import json
from TOOL.services.ds2api_service import ds2api_service
print(json.dumps(ds2api_service.test_account(${JSON.stringify(account_id)})))
  `;
  try {
    const result = await runPythonCode(pyCode);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete("/api/ds2api/accounts/:id", async (req, res) => {
  const accountId = req.params.id;
  const pyCode = `
import json
from TOOL.services.ds2api_service import DS2APIConfigManager
ok = DS2APIConfigManager.delete_account(${JSON.stringify(accountId)})
print(json.dumps({"status": "ok" if ok else "error", "success": ok}))
  `;
  try {
    const result = await runPythonCode(pyCode);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/ds2api/accounts/delete", async (req, res) => {
  const { account_id } = req.body;
  if (!account_id) return res.status(400).json({ error: "Thiếu account_id" });
  const pyCode = `
import json
from TOOL.services.ds2api_service import DS2APIConfigManager
ok = DS2APIConfigManager.delete_account(${JSON.stringify(account_id)})
print(json.dumps({"status": "ok" if ok else "error", "success": ok}))
  `;
  try {
    const result = await runPythonCode(pyCode);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 12. Export DSUB-LOCAL package
app.get("/api/export-project", async (req, res) => {
  const zipPath = path.join(OUTPUT_DIR, "DSUB-LOCAL.zip");
  try {
    const pyScript = `
import zipfile, os

out_zip = '${zipPath}'
with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as z:
    for root, dirs, files in os.walk('TOOL'):
        if '__pycache__' in root:
            continue
        for f in files:
            fp = os.path.join(root, f)
            arcname = os.path.join('DSUB-LOCAL', fp)
            z.write(fp, arcname)
    for root, dirs, files in os.walk('src'):
        for f in files:
            fp = os.path.join(root, f)
            arcname = os.path.join('DSUB-LOCAL', fp)
            z.write(fp, arcname)
    for f in ['START.py', 'START.bat', 'requirements.txt', 'requirements-windows.txt', 'requirements-android.txt', 'README.md', 'package.json', 'server.ts', 'index.html', 'vite.config.ts', 'tsconfig.json']:
        if os.path.exists(f):
            z.write(f, os.path.join('DSUB-LOCAL', f))
    for sub in ['temp', 'output', 'uploads', 'models', 'logs']:
        z.writestr(f'DSUB-LOCAL/DATA/{sub}/.gitkeep', '')
`;
    await runPythonCode(pyScript);
    if (fs.existsSync(zipPath) && fs.statSync(zipPath).size > 0) {
      res.download(zipPath, "DSUB-LOCAL.zip");
    } else {
      res.status(500).json({ error: "Không thể tạo file zip." });
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// -------------------------------------------------------------
// Vite Middleware / Static Serving
// -------------------------------------------------------------
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`DSUB LOCAL Server running on http://localhost:${PORT}`);
  });
}

startServer();
