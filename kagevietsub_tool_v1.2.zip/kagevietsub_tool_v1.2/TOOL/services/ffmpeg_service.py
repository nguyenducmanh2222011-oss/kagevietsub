import os
import shutil
import subprocess
import json
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
from TOOL.config import TEMP_DIR, OUTPUT_DIR

class FFmpegService:
    @staticmethod
    def is_ffmpeg_installed() -> bool:
        """Check if FFmpeg executable is available."""
        return shutil.which("ffmpeg") is not None

    @staticmethod
    def is_ffprobe_installed() -> bool:
        """Check if FFprobe executable is available."""
        return shutil.which("ffprobe") is not None

    @staticmethod
    def check_nvenc_support() -> bool:
        """Check if NVIDIA GPU hardware encoding (h264_nvenc) is available."""
        try:
            res = subprocess.run(["ffmpeg", "-encoders"], capture_output=True, text=True)
            return "h264_nvenc" in res.stdout
        except Exception:
            return False

    @staticmethod
    def get_media_info(filepath: Path) -> Dict[str, Any]:
        """Extract media stream information using ffprobe."""
        path_str = str(filepath)
        cmd = [
            "ffprobe", "-v", "quiet", "-print_format", "json",
            "-show_streams", "-show_format", path_str
        ]
        try:
            res = subprocess.run(cmd, capture_output=True, text=True)
            if res.returncode != 0:
                return {"duration": 0.0, "has_video": False, "has_audio": False}
            data = json.loads(res.stdout)
            streams = data.get("streams", [])
            fmt = data.get("format", {})
            duration = float(fmt.get("duration", 0.0))

            video_stream = next((s for s in streams if s.get("codec_type") == "video"), None)
            audio_stream = next((s for s in streams if s.get("codec_type") == "audio"), None)

            fps = 0.0
            if video_stream and "avg_frame_rate" in video_stream:
                rate = video_stream["avg_frame_rate"]
                if "/" in rate:
                    num, den = rate.split("/")
                    fps = float(num) / float(den) if float(den) != 0 else 0.0
                else:
                    fps = float(rate or 0.0)

            return {
                "duration": duration,
                "size_mb": round(os.path.getsize(filepath) / (1024 * 1024), 2) if filepath.exists() else 0,
                "has_video": video_stream is not None,
                "has_audio": audio_stream is not None,
                "width": video_stream.get("width", 0) if video_stream else 0,
                "height": video_stream.get("height", 0) if video_stream else 0,
                "video_codec": video_stream.get("codec_name", "None") if video_stream else "None",
                "audio_codec": audio_stream.get("codec_name", "None") if audio_stream else "None",
                "fps": round(fps, 2)
            }
        except Exception as e:
            return {"duration": 0.0, "error": str(e)}

    @staticmethod
    def prepare_audio_for_whisper(input_file: Path, output_wav: Path) -> Tuple[bool, str]:
        """
        Boost audio 25dB + acompressor:
        -vn -acodec pcm_s16le -ar 16000 -ac 1 -af "volume=25dB, acompressor=threshold=-30dB:ratio=3:attack=5:release=50"
        """
        cmd = [
            "ffmpeg", "-y", "-i", str(input_file),
            "-vn", "-acodec", "pcm_s16le", "-ar", "16000", "-ac", "1",
            "-af", "volume=25dB, acompressor=threshold=-30dB:ratio=3:attack=5:release=50",
            str(output_wav), "-loglevel", "error"
        ]
        res = subprocess.run(cmd, capture_output=True, text=True)
        return (res.returncode == 0, res.stderr)

    @staticmethod
    def run_ffmpeg_with_progress(cmd: List[str], total_duration: Optional[float] = None, progress_callback = None) -> Tuple[bool, str]:
        """
        Execute FFmpeg command and parse time=HH:MM:SS.dd to track real progress.
        """
        import re
        duration_pattern = re.compile(r'time=(\d+):(\d+):(\d+\.\d+)')
        stderr_lines = []

        try:
            process = subprocess.Popen(cmd, stderr=subprocess.PIPE, stdout=subprocess.DEVNULL, universal_newlines=True)
            while True:
                line = process.stderr.readline()
                if not line:
                    break
                stderr_lines.append(line)

                match = duration_pattern.search(line)
                if match and total_duration and total_duration > 0:
                    h, m, s = match.groups()
                    current_seconds = int(h) * 3600 + int(m) * 60 + float(s)
                    percent = min(99.0, (current_seconds / total_duration) * 100.0)
                    if progress_callback:
                        progress_callback(percent, current_seconds, total_duration)

            process.wait()
            success = (process.returncode == 0)
            return success, "".join(stderr_lines)
        except Exception as e:
            return False, str(e)

    @staticmethod
    def concat_audio_files(audio_files: List[Path], output_path: Path, progress_callback = None) -> Tuple[bool, str]:
        """Merge multiple audio files into one single audio file using concat demuxer."""
        concat_list_file = TEMP_DIR / f"audio_concat_{os.getpid()}.txt"
        with open(concat_list_file, "w", encoding="utf-8") as f:
            for p in audio_files:
                escaped = str(p.resolve()).replace("'", "'\\''")
                f.write(f"file '{escaped}'\n")

        # Calculate total duration if possible
        total_duration = 0.0
        for f in audio_files:
            info = FFmpegService.get_media_info(f)
            total_duration += info.get("duration", 0.0)

        cmd = [
            "ffmpeg", "-y", "-f", "concat", "-safe", "0",
            "-i", str(concat_list_file),
            "-c:a", "libmp3lame", "-b:a", "192k",
            str(output_path)
        ]

        if total_duration > 0 and progress_callback:
            success, stderr = FFmpegService.run_ffmpeg_with_progress(cmd, total_duration, progress_callback)
        else:
            res = subprocess.run(cmd, capture_output=True, text=True)
            success = (res.returncode == 0)
            stderr = res.stderr

        if concat_list_file.exists():
            concat_list_file.unlink()
        return (success, stderr)

    @staticmethod
    def cut_video_segment(
        input_file: Path,
        start_seconds: float,
        duration_seconds: float,
        output_path: Path,
        mode: str = "copy"
    ) -> Tuple[bool, str]:
        """Cut a specific segment of a video file."""
        if mode == "copy":
            cmd = [
                "ffmpeg", "-y", "-ss", str(start_seconds),
                "-i", str(input_file),
                "-t", str(duration_seconds),
                "-c", "copy", "-avoid_negative_ts", "make_zero",
                str(output_path)
            ]
        else:
            cmd = [
                "ffmpeg", "-y", "-ss", str(start_seconds),
                "-i", str(input_file),
                "-t", str(duration_seconds),
                "-c:v", "libx264", "-c:a", "aac",
                str(output_path)
            ]
        res = subprocess.run(cmd, capture_output=True, text=True)
        return (res.returncode == 0, res.stderr)

    @staticmethod
    def concat_videos_lossless(video_files: List[Path], output_path: Path) -> Tuple[bool, str]:
        """Concatenate videos without re-encoding."""
        concat_file = TEMP_DIR / f"video_concat_{os.getpid()}.txt"
        with open(concat_file, "w", encoding="utf-8") as f:
            for vf in video_files:
                escaped = str(vf.resolve()).replace("'", "'\\''")
                f.write(f"file '{escaped}'\n")

        cmd = [
            "ffmpeg", "-y",
            "-f", "concat", "-safe", "0",
            "-i", str(concat_file),
            "-c", "copy",
            str(output_path)
        ]
        res = subprocess.run(cmd, capture_output=True, text=True)
        if concat_file.exists():
            concat_file.unlink()
        return (res.returncode == 0, res.stderr)

    @staticmethod
    def build_video_filter_complex(num_videos: int, has_audio_flags: List[bool]) -> str:
        """
        Build safe filter_complex handling videos with or without audio (from tool_gop_videov03.5).
        Synthesizes silent stereo audio if video has no audio.
        Normalizes video dimensions: scale=trunc(iw/2)*2:trunc(ih/2)*2, format=yuv420p.
        Normalizes audio: aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=stereo.
        """
        filter_parts = []
        for i in range(num_videos):
            if not has_audio_flags[i]:
                # Synthesize silent audio for video without audio stream
                filter_parts.append(
                    f"[{i}:v:0]scale=trunc(iw/2)*2:trunc(ih/2)*2,format=yuv420p[v{i}];"
                    f"anullsrc=channel_layout=stereo:sample_rate=44100[a{i}]"
                )
            else:
                filter_parts.append(
                    f"[{i}:v:0]scale=trunc(iw/2)*2:trunc(ih/2)*2,format=yuv420p[v{i}];"
                    f"[{i}:a:0]aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=stereo[a{i}]"
                )

        video_inputs = "".join([f"[v{i}]" for i in range(num_videos)])
        audio_inputs = "".join([f"[a{i}]" for i in range(num_videos)])

        filter_complex = ";".join(filter_parts)
        filter_complex += f";{video_inputs}concat=n={num_videos}:v=1:a=0[vout];"
        filter_complex += f"{audio_inputs}concat=n={num_videos}:v=0:a=1[aout]"
        return filter_complex

    @staticmethod
    def concat_videos_reencode(
        video_files: List[Path],
        output_path: Path,
        use_gpu: bool = False,
        crf: int = 23,
        preset: str = "fast",
        progress_callback = None
    ) -> Tuple[bool, str]:
        """Concatenate videos with re-encoding, handling missing audio streams safely."""
        num_videos = len(video_files)
        has_audio_flags = []
        total_duration = 0.0

        for vf in video_files:
            info = FFmpegService.get_media_info(vf)
            has_audio_flags.append(info.get("has_audio", True))
            total_duration += info.get("duration", 0.0)

        inputs = []
        for vf in video_files:
            inputs.extend(["-i", str(vf.resolve())])

        filter_complex = FFmpegService.build_video_filter_complex(num_videos, has_audio_flags)

        # GPU NVENC presets from tool_gop_videov03.5
        can_use_gpu = use_gpu and FFmpegService.check_nvenc_support()
        if can_use_gpu:
            cmd = [
                "ffmpeg", "-y",
                "-fflags", "+genpts",
                *inputs,
                "-filter_complex", filter_complex,
                "-map", "[vout]", "-map", "[aout]",
                "-c:v", "h264_nvenc",
                "-preset", "p1",
                "-cq", str(crf or 23),
                "-c:a", "aac",
                "-b:a", "192k",
                str(output_path)
            ]
        else:
            cmd = [
                "ffmpeg", "-y",
                "-fflags", "+genpts",
                *inputs,
                "-filter_complex", filter_complex,
                "-map", "[vout]", "-map", "[aout]",
                "-c:v", "libx264",
                "-preset", preset or "fast",
                "-crf", str(crf or 23),
                "-c:a", "aac",
                "-b:a", "192k",
                str(output_path)
            ]

        if total_duration > 0 and progress_callback:
            return FFmpegService.run_ffmpeg_with_progress(cmd, total_duration, progress_callback)
        else:
            res = subprocess.run(cmd, capture_output=True, text=True)
            return (res.returncode == 0, res.stderr)

    @staticmethod
    def add_caption_to_video(
        input_video: Path,
        caption_text: str,
        output_path: Path,
        font_size: int = 24,
        font_color: str = "white",
        position: str = "bottom",
        use_gpu: bool = False,
        progress_callback = None
    ) -> Tuple[bool, str]:
        """Add text caption overlay onto a video with standard bounding box."""
        escaped_text = caption_text.replace("\\", "\\\\").replace(":", "\\:").replace("'", "\\'")
        if position == "bottom":
            y_pos = "h-th-50"
        elif position == "top":
            y_pos = "50"
        elif position == "center":
            y_pos = "(h-th)/2"
        else:
            y_pos = "h-th-50"

        drawtext_filter = (
            f"drawtext=text='{escaped_text}':"
            f"fontsize={font_size}:"
            f"fontcolor={font_color}:"
            f"x=(w-tw)/2:"
            f"y={y_pos}:"
            f"box=1:boxcolor=black@0.5:boxborderw=10"
        )

        can_use_gpu = use_gpu and FFmpegService.check_nvenc_support()
        codec = "h264_nvenc" if can_use_gpu else "libx264"
        cmd = [
            "ffmpeg", "-y", "-i", str(input_video),
            "-vf", drawtext_filter,
            "-c:v", codec, "-crf" if codec == "libx264" else "-cq", "23",
            "-preset", "p1" if codec == "h264_nvenc" else "fast",
            "-c:a", "copy",
            str(output_path)
        ]

        info = FFmpegService.get_media_info(input_video)
        total_duration = info.get("duration", 0.0)
        if total_duration > 0 and progress_callback:
            return FFmpegService.run_ffmpeg_with_progress(cmd, total_duration, progress_callback)
        else:
            res = subprocess.run(cmd, capture_output=True, text=True)
            return (res.returncode == 0, res.stderr)

    @staticmethod
    def compress_video(
        input_video: Path,
        output_path: Path,
        crf: int = 18,
        preset: str = "slow",
        codec: str = "libx264"
    ) -> Tuple[bool, str]:
        """Compress video using given CRF and preset."""
        cmd = [
            "ffmpeg", "-y", "-i", str(input_video),
            "-c:v", codec,
            "-preset", preset,
            "-crf", str(crf),
            "-c:a", "copy",
            "-movflags", "+faststart",
            str(output_path)
        ]
        res = subprocess.run(cmd, capture_output=True, text=True)
        return (res.returncode == 0, res.stderr)
