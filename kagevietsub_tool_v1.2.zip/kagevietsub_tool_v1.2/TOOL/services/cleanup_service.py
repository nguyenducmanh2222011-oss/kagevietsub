import time
import shutil
import logging
from pathlib import Path
from typing import List, Optional
from TOOL.config import TEMP_DIR, UPLOADS_DIR, OUTPUT_DIR, MODELS_DIR, KAGE_DOWNLOAD_DIR

logger = logging.getLogger("kagevietsub.cleanup")

class CleanupService:
    @staticmethod
    def cleanup_orphaned_temp():
        """
        Quét và dọn dẹp các thư mục temp và uploads mồ côi khi khởi động lại sau crash.
        TUYỆT ĐỐI KHÔNG xóa DATA/models/, DATA/output/ và Download/KAGEVIETSUB/.
        """
        cleaned_count = 0
        cleaned_bytes = 0

        # 1. Dọn dẹp TEMP_DIR
        if TEMP_DIR.exists():
            for item in list(TEMP_DIR.iterdir()):
                try:
                    # Đảm bảo an toàn: chỉ xóa bên trong TEMP_DIR
                    if not str(item.resolve()).startswith(str(TEMP_DIR.resolve())):
                        continue
                    if item.is_file():
                        cleaned_bytes += item.stat().st_size
                        item.unlink()
                        cleaned_count += 1
                    elif item.is_dir():
                        for sub in item.rglob("*"):
                            if sub.is_file():
                                cleaned_bytes += sub.stat().st_size
                        shutil.rmtree(item, ignore_errors=True)
                        cleaned_count += 1
                except Exception as e:
                    logger.debug(f"Bỏ qua file temp: {e}")

        # 2. Dọn dẹp UPLOADS_DIR mồ côi (chỉ file tạm trong uploads)
        if UPLOADS_DIR.exists():
            for item in list(UPLOADS_DIR.iterdir()):
                try:
                    if not str(item.resolve()).startswith(str(UPLOADS_DIR.resolve())):
                        continue
                    if item.is_file():
                        cleaned_bytes += item.stat().st_size
                        item.unlink()
                        cleaned_count += 1
                    elif item.is_dir():
                        shutil.rmtree(item, ignore_errors=True)
                        cleaned_count += 1
                except Exception as e:
                    logger.debug(f"Bỏ qua file upload mồ côi: {e}")

        logger.info(f"Crash recovery cleanup: {cleaned_count} items ({round(cleaned_bytes / (1024*1024), 2)} MB) đã được dọn an toàn.")
        return {"cleaned_files": cleaned_count, "freed_mb": round(cleaned_bytes / (1024 * 1024), 2)}

    @staticmethod
    def cleanup_job_temp(job_id: str, uploaded_files: Optional[List[Path]] = None):
        """
        Dọn dẹp thư mục temp và uploads tạm thời của một job sau khi hoàn tất.
        """
        # Xóa thư mục temp riêng của job
        job_temp_dir = TEMP_DIR / f"job_{job_id}"
        if job_temp_dir.exists() and str(job_temp_dir.resolve()).startswith(str(TEMP_DIR.resolve())):
            shutil.rmtree(job_temp_dir, ignore_errors=True)

        # Xóa các file trung gian mang tên job_id
        if TEMP_DIR.exists():
            for item in TEMP_DIR.glob(f"*{job_id}*"):
                try:
                    if item.is_file():
                        item.unlink()
                    elif item.is_dir():
                        shutil.rmtree(item, ignore_errors=True)
                except Exception:
                    pass

        # Xóa các file upload tạm nếu được cung cấp
        if uploaded_files:
            for up_file in uploaded_files:
                try:
                    p = Path(up_file)
                    # Chỉ xóa nếu file thực sự nằm trong UPLOADS_DIR (không xóa file người dùng trên điện thoại!)
                    if p.exists() and str(p.resolve()).startswith(str(UPLOADS_DIR.resolve())):
                        p.unlink()
                except Exception:
                    pass

    @staticmethod
    def cleanup_old_files(max_age_hours: int = 24):
        """Clean up files in temp/ and uploads/ older than max_age_hours."""
        now = time.time()
        cutoff = now - (max_age_hours * 3600)
        cleaned_count = 0
        cleaned_bytes = 0

        for folder in [TEMP_DIR, UPLOADS_DIR]:
            if not folder.exists():
                continue
            for item in folder.iterdir():
                try:
                    # Bảo vệ tuyệt đối, không được xóa ngoài folder
                    if not str(item.resolve()).startswith(str(folder.resolve())):
                        continue
                    if item.is_file() and item.stat().st_mtime < cutoff:
                        cleaned_bytes += item.stat().st_size
                        item.unlink()
                        cleaned_count += 1
                except Exception:
                    pass
        return {"cleaned_files": cleaned_count, "freed_mb": round(cleaned_bytes / (1024 * 1024), 2)}

    @staticmethod
    def clear_temp_folder():
        """Clear all temporary files inside TEMP_DIR and UPLOADS_DIR safely."""
        return CleanupService.cleanup_orphaned_temp()

