import threading
import uuid
import time
from typing import Dict, Any, Optional, Callable

class TaskService:
    def __init__(self):
        self._jobs: Dict[str, Dict[str, Any]] = {}
        self._lock = threading.Lock()

    def create_job(self, task_type: str, metadata: Optional[Dict[str, Any]] = None) -> str:
        job_id = uuid.uuid4().hex[:12]
        with self._lock:
            self._jobs[job_id] = {
                "job_id": job_id,
                "type": task_type,
                "status": "queued",
                "progress": 0,
                "message": "Task queued...",
                "download_url": None,
                "filename": None,
                "saved_path": None,
                "saved_location": "KAGEVIETSUB/",
                "created_at": time.time(),
                "completed_at": None,
                "error": None,
                "result": None,
                "metadata": metadata or {}
            }
        return job_id

    def update_job(
        self,
        job_id: str,
        status: Optional[str] = None,
        progress: Optional[int] = None,
        message: Optional[str] = None,
        download_url: Optional[str] = None,
        filename: Optional[str] = None,
        saved_path: Optional[str] = None,
        saved_location: Optional[str] = None,
        error: Optional[str] = None,
        result: Optional[Any] = None
    ):
        with self._lock:
            if job_id not in self._jobs:
                return
            job = self._jobs[job_id]
            if status is not None:
                job["status"] = status
            if progress is not None:
                job["progress"] = max(0, min(100, int(progress)))
            if message is not None:
                job["message"] = message
            if download_url is not None:
                job["download_url"] = download_url
            if filename is not None:
                job["filename"] = filename
            if saved_path is not None:
                job["saved_path"] = saved_path
            if saved_location is not None:
                job["saved_location"] = saved_location
            elif filename is not None and not job.get("saved_location"):
                job["saved_location"] = f"KAGEVIETSUB/{filename}"
            if error is not None:
                job["error"] = error
            if result is not None:
                job["result"] = result
            if status in ["completed", "failed"]:
                job["completed_at"] = time.time()

        # Tự động dọn dẹp file temp của job khi xong hoặc lỗi
        if status in ["completed", "failed"]:
            try:
                from TOOL.services.cleanup_service import CleanupService
                up_files = []
                meta = self._jobs.get(job_id, {}).get("metadata", {})
                if "upload_paths" in meta:
                    up_files = meta["upload_paths"]
                elif "upload_path" in meta:
                    up_files = [meta["upload_path"]]
                CleanupService.cleanup_job_temp(job_id, uploaded_files=up_files)
            except Exception:
                pass

    def get_job(self, job_id: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            return self._jobs.get(job_id)

    def list_jobs(self, limit: int = 20) -> list:
        with self._lock:
            items = list(self._jobs.values())
            items.sort(key=lambda x: x["created_at"], reverse=True)
            return items[:limit]

    def run_in_background(self, job_id: str, target: Callable[..., Any], *args, **kwargs):
        def _wrapper():
            self.update_job(job_id, status="processing", progress=5, message="Processing started...")
            try:
                result = target(job_id, *args, **kwargs)
                if self._jobs[job_id]["status"] not in ["failed", "completed"]:
                    self.update_job(job_id, status="completed", progress=100, message="Task completed successfully!", result=result)
            except Exception as e:
                self.update_job(job_id, status="failed", error=str(e), message=f"Error: {str(e)}")

        thread = threading.Thread(target=_wrapper, daemon=True)
        thread.start()

# Global singleton
job_manager = TaskService()
