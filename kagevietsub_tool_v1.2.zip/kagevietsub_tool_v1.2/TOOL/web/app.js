/**
 * ==============================================================================
 * KAGEVIETSUB - LOCALHOST FRONTEND CONTROLLER (VANILLA JS • 100% PREVIEW PARITY)
 * ==============================================================================
 */

document.addEventListener("DOMContentLoaded", () => {
    // -------------------------------------------------------------
    // SVG ICONS TEMPLATES (Matching Lucide Icons in Preview)
    // -------------------------------------------------------------
    const ICONS = {
        check: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`,
        copy: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>`,
        loader: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="animate-spin"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>`,
        checkCircle: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/></svg>`,
        alertCircle: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/></svg>`,
        download: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>`,
        trash: `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/></svg>`,
        chevronDown: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m6 9 6 6 6-6"/></svg>`,
        chevronUp: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m18 15-6-6-6 6"/></svg>`
    };

    // -------------------------------------------------------------
    // NAVIGATION CONTROLLER
    // -------------------------------------------------------------
    function switchMainTab(mainTabId, subTabId) {
        // Update main tab panes
        document.querySelectorAll(".tab-pane").forEach(pane => {
            pane.classList.toggle("active", pane.id === `main-tab-${mainTabId}`);
        });

        // Update nav buttons (both desktop and mobile)
        document.querySelectorAll("[data-main-tab]").forEach(btn => {
            btn.classList.toggle("active", btn.getAttribute("data-main-tab") === mainTabId);
        });

        // If specific sub-tab requested
        if (subTabId) {
            switchSubTab(subTabId);
        } else if (mainTabId === "audio") {
            if (typeof fetchWhisperModels === "function") {
                fetchWhisperModels(true);
            }
        }

        // Scroll to top
        window.scrollTo({ top: 0, behavior: "smooth" });
    }

    function switchSubTab(subTabId) {
        // Determine section container from subTabId prefix
        let prefix = "srt";
        if (subTabId.startsWith("audio")) prefix = "audio";
        else if (subTabId.startsWith("video")) prefix = "video";

        const section = document.getElementById(`main-tab-${prefix}`);
        if (!section) return;

        section.querySelectorAll(".sub-pane").forEach(p => {
            p.classList.toggle("active", p.id === `sub-pane-${subTabId}`);
        });

        section.querySelectorAll("[data-sub-tab]").forEach(btn => {
            btn.classList.toggle("active", btn.getAttribute("data-sub-tab") === subTabId);
        });

        if (subTabId === "audio-whisper") {
            if (typeof fetchWhisperModels === "function") {
                fetchWhisperModels(true);
            }
        }
    }

    // Attach click listeners for main navigation
    document.querySelectorAll("[data-main-tab]").forEach(btn => {
        btn.addEventListener("click", () => {
            const tab = btn.getAttribute("data-main-tab");
            switchMainTab(tab);
        });
    });

    // Attach click listeners for sub-tabs
    document.querySelectorAll("[data-sub-tab]").forEach(btn => {
        btn.addEventListener("click", () => {
            const subTab = btn.getAttribute("data-sub-tab");
            switchSubTab(subTab);
        });
    });

    // Logo click goes home
    document.getElementById("brand-logo")?.addEventListener("click", () => switchMainTab("home"));

    // Banner button goes to settings
    document.getElementById("btn-home-check-health")?.addEventListener("click", () => {
        switchMainTab("settings");
        checkHealth();
    });

    // Quick Action Cards on Home View (8 Actions)
    document.querySelectorAll(".action-card[data-action]").forEach(card => {
        card.addEventListener("click", () => {
            const action = card.getAttribute("data-action");
            switch (action) {
                case "srt":
                    switchMainTab("srt", "srt-editor");
                    break;
                case "whisper":
                    switchMainTab("audio", "audio-whisper");
                    break;
                case "audio-merge":
                    switchMainTab("audio", "audio-merge");
                    break;
                case "video-cut":
                    switchMainTab("video", "video-cut");
                    break;
                case "video-merge":
                    switchMainTab("video", "video-merge");
                    break;
                case "video-compress":
                    switchMainTab("video", "video-compress");
                    break;
                case "srt-split":
                    switchMainTab("srt", "srt-split");
                    break;
                case "srt-upper":
                    switchMainTab("srt", "srt-upper");
                    break;
            }
        });
    });


    // -------------------------------------------------------------
    // JOB PROGRESS COMPONENT (Matching JobProgressCard.tsx)
    // -------------------------------------------------------------
    function renderJobCardHTML(job) {
        const status = job.status || "processing";
        const progress = job.progress !== undefined ? job.progress : 0;
        const isCompleted = status === "completed";
        const isFailed = status === "failed";
        const isProcessing = !isCompleted && !isFailed;

        let iconBoxClass = "processing";
        let iconSvg = ICONS.loader;
        let percentClass = "processing";
        let barClass = "processing";

        if (isCompleted) {
            iconBoxClass = "completed";
            iconSvg = ICONS.checkCircle;
            percentClass = "completed";
            barClass = "completed";
        } else if (isFailed) {
            iconBoxClass = "failed";
            iconSvg = ICONS.alertCircle;
            percentClass = "failed";
            barClass = "failed";
        }

        const typeLabels = {
            "whisper_transcribe": "Trích xuất Whisper AI",
            "audio_merge": "Ghép File Audio",
            "video_cut": "Cắt Đoạn Video",
            "video_merge": "Ghép Video & Caption",
            "video_compress": "Nén Video"
        };
        const title = typeLabels[job.type] || job.type || "Tác vụ hệ thống";
        const filename = job.filename ? `File: ${job.filename}` : "";
        const shortId = job.job_id ? job.job_id.substring(0, 8) : "";

        return `
            <div class="job-progress-card" id="job-card-${job.job_id}">
                <div class="job-card-header">
                    <div class="job-card-left">
                        <div class="job-icon-box ${iconBoxClass}">${iconSvg}</div>
                        <div>
                            <div class="job-title">${title}</div>
                            <div class="job-meta">ID: ${shortId} ${filename ? `• ${filename}` : ""}</div>
                        </div>
                    </div>
                    <span class="job-percent ${percentClass}">${progress}%</span>
                </div>

                <div class="progress-track">
                    <div class="progress-bar ${barClass}" style="width: ${progress}%"></div>
                </div>

                <div style="font-size: 11px; color: ${isFailed ? "#fb7185" : "#94a3b8"}; display: flex; align-items: center; justify-content: space-between;">
                    <span>${job.message || (isCompleted ? "Xử lý thành công!" : "Đang xử lý...")}</span>
                    <span style="text-transform: capitalize; font-weight: 600;">${status}</span>
                </div>

                ${isCompleted ? `
                    <div class="job-card-footer" style="display:flex; flex-wrap:wrap; align-items:center; justify-content:space-between; gap:8px;">
                        <div style="display:flex; align-items:center; gap:6px; font-size:12px; color:#34d399; font-weight:600;">
                            ${ICONS.checkCircle}
                            <span>✓ Đã xử lý xong</span>
                        </div>
                        <div style="display:flex; align-items:center; gap:6px; padding:4px 10px; background:#0e1322; border:1px solid rgba(16,185,129,0.25); border-radius:10px; font-size:11px; font-family:var(--font-mono); color:#cbd5e1;">
                            <span style="color:#64748b;">📁 Đã lưu vào:</span>
                            <strong style="color:#6ee7b7;">${job.saved_location || (job.filename ? `KAGEVIETSUB/${job.filename}` : "KAGEVIETSUB/")}</strong>
                        </div>
                    </div>
                ` : ""}

                ${isFailed && job.error ? `
                    <div style="padding: 8px 12px; background: rgba(244,63,94,0.1); border: 1px solid rgba(244,63,94,0.25); border-radius: 8px; font-size: 11px; color: #fb7185;">
                        <b>Lỗi:</b> ${job.error}
                    </div>
                ` : ""}
            </div>
        `;
    }

    async function pollJob(jobId, targetContainer, onComplete) {
        if (!targetContainer) return;
        targetContainer.style.display = "block";
        targetContainer.innerHTML = renderJobCardHTML({ job_id: jobId, status: "processing", progress: 5, message: "Khởi tạo tác vụ..." });

        const interval = setInterval(async () => {
            try {
                const res = await fetch(`/api/jobs/${jobId}`);
                if (!res.ok) throw new Error("Không thể kết nối tác vụ");
                const job = await res.json();

                targetContainer.innerHTML = renderJobCardHTML(job);
                updateGlobalActiveJobs();

                if (job.status === "completed") {
                    clearInterval(interval);
                    if (onComplete) onComplete(job);
                } else if (job.status === "failed") {
                    clearInterval(interval);
                }
            } catch (err) {
                targetContainer.innerHTML = `
                    <div class="status-toast error">
                        <span>Lỗi kiểm tra tiến trình: ${err.message}</span>
                    </div>
                `;
                clearInterval(interval);
            }
        }, 1000);
    }

    // Global Active Jobs Tracker
    async function updateGlobalActiveJobs() {
        try {
            const res = await fetch("/api/jobs");
            if (!res.ok) return;
            const data = await res.json();
            const jobs = data.jobs || [];
            const runningJobs = jobs.filter(j => j.status === "processing");

            // 1. Header Status Area
            const statusArea = document.getElementById("header-status-area");
            if (statusArea) {
                if (runningJobs.length > 0) {
                    statusArea.innerHTML = `
                        <div class="header-job-pill" onclick="document.querySelector('[data-main-tab=home]').click();">
                            ${ICONS.loader}
                            <span>${runningJobs.length} Tác vụ đang chạy</span>
                        </div>
                    `;
                } else {
                    statusArea.innerHTML = `
                        <div class="header-status-pill">
                            <span class="pulse-dot"></span>
                            <span>127.0.0.1:8000 Online</span>
                        </div>
                    `;
                }
            }

            // 2. Home View Jobs Widget
            const homeSection = document.getElementById("home-jobs-section");
            const homeList = document.getElementById("home-jobs-list");
            if (homeSection && homeList) {
                if (jobs.length > 0) {
                    homeSection.style.display = "block";
                    homeList.innerHTML = jobs.slice(0, 4).map(j => renderJobCardHTML(j)).join("");
                } else {
                    homeSection.style.display = "none";
                }
            }

            // 3. Settings View Jobs List
            const settingsList = document.getElementById("settings-jobs-list");
            if (settingsList) {
                if (jobs.length > 0) {
                    settingsList.innerHTML = jobs.slice(0, 6).map(j => renderJobCardHTML(j)).join("");
                } else {
                    settingsList.innerHTML = `<div style="font-size:12px; color:#64748b;">Chưa có tác vụ nào được thực thi.</div>`;
                }
            }
        } catch (e) {
            // silent fail on offline
        }
    }

    document.getElementById("btn-home-refresh-jobs")?.addEventListener("click", updateGlobalActiveJobs);
    setInterval(updateGlobalActiveJobs, 4000);
    updateGlobalActiveJobs();


    // -------------------------------------------------------------
    // 1. SRT STUDIO: EDITOR CONTROLLER
    // -------------------------------------------------------------
    const srtEditor = document.getElementById("srt-editor-textarea");
    const srtLineCount = document.getElementById("srt-line-count");
    const srtCharCount = document.getElementById("srt-char-count");
    const srtFileInput = document.getElementById("srt-file-input");
    const srtFilenameInput = document.getElementById("srt-filename-input");
    const srtStatusBanner = document.getElementById("srt-status-banner");
    const srtLogConsole = document.getElementById("srt-log-console");
    const btnRulesToggle = document.getElementById("btn-toggle-rules");
    const srtRulesAccordion = document.getElementById("srt-rules-accordion");
    const rulesChevron = document.getElementById("rules-chevron");
    const srtRulesInput = document.getElementById("srt-rules-input");

    // Initialize Default Content (Matching Preview initialContent)
    const SAMPLE_SRT = `1\n00:00:01,000 --> 00:00:03,500\n...Chào mừng bạn đến với KAGEVIETSUB.\n\n2\n00:00:03,500 --> 00:00:05,200\nỨng dụng chỉnh sửa phụ đề tự động trên điện thoại!\n\n3\n00:00:05,200 --> 00:00:07,000\nvi sao lai khong thu ngay?`;
    const DEFAULT_RULES = `... -> ,\n. -> ,\n! -> ,\nvi -> Vi\nxi -> Xi\n" -> `;

    if (srtEditor && !srtEditor.value.trim()) {
        srtEditor.value = SAMPLE_SRT;
    }
    if (srtRulesInput && !srtRulesInput.value.trim()) {
        srtRulesInput.value = DEFAULT_RULES;
    }

    function updateSrtStats() {
        if (!srtEditor) return;
        const val = srtEditor.value;
        const lines = val ? val.split("\n").length : 0;
        const chars = val.length;
        if (srtLineCount) srtLineCount.textContent = lines;
        if (srtCharCount) srtCharCount.textContent = chars;
    }
    srtEditor?.addEventListener("input", updateSrtStats);
    updateSrtStats();

    // Copy SRT Button
    const btnCopy = document.getElementById("btn-copy-srt");
    btnCopy?.addEventListener("click", () => {
        if (!srtEditor || !srtEditor.value) return;
        navigator.clipboard.writeText(srtEditor.value).then(() => {
            btnCopy.innerHTML = `${ICONS.check} <span>Đã sao chép!</span>`;
            setTimeout(() => {
                btnCopy.innerHTML = `${ICONS.copy} <span>Sao chép</span>`;
            }, 2000);
            logSrt("Đã sao chép nội dung SRT vào bộ nhớ tạm.", "success");
        });
    });

    // File Upload
    srtFileInput?.addEventListener("change", (e) => {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (evt) => {
            srtEditor.value = evt.target.result;
            updateSrtStats();
            if (srtFilenameInput) {
                srtFilenameInput.value = file.name;
            }
            logSrt(`Đã mở file: ${file.name} (${file.size} bytes)`, "success");
            setSrtStatus(`Đã tải file ${file.name}`, "success");
        };
        reader.readAsText(file, "utf-8");
    });

    // Save SRT directly to KAGEVIETSUB
    document.getElementById("btn-download-srt")?.addEventListener("click", async () => {
        const content = srtEditor.value;
        if (!content.trim()) {
            setSrtStatus("Nội dung SRT trống!", "warn");
            return;
        }
        let fname = srtFilenameInput.value.trim() || "edited_subtitles.srt";
        if (!fname.toLowerCase().endsWith(".srt")) fname += ".srt";

        setSrtStatus("Đang lưu file...", "info");
        try {
            const res = await fetch("/api/srt/save", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ content, filename: fname })
            });
            const data = await res.json();
            if (data.status === "saved") {
                const loc = data.saved_location || `KAGEVIETSUB/${fname}`;
                logSrt(`Đã lưu file thành công vào: ${loc}`, "success");
                setSrtStatus(`✓ Đã xử lý xong! Đã lưu vào ${loc}`, "success");
                const resContainer = document.getElementById("srt-save-result-container");
                if (resContainer) {
                    resContainer.style.display = "block";
                    resContainer.innerHTML = `
                        <div style="display:flex; flex-wrap:wrap; align-items:center; justify-content:space-between; gap:8px; padding:10px 14px; background:#0d1017; border:1px solid rgba(16,185,129,0.3); border-radius:12px; margin-top:8px;">
                            <div style="display:flex; align-items:center; gap:6px; font-size:12px; color:#34d399; font-weight:600;">
                                ${ICONS.checkCircle}
                                <span>✓ Đã xử lý xong</span>
                            </div>
                            <div style="display:flex; align-items:center; gap:6px; padding:4px 10px; background:#0e1322; border:1px solid rgba(16,185,129,0.25); border-radius:10px; font-size:11px; font-family:var(--font-mono); color:#cbd5e1;">
                                <span style="color:#64748b;">📁 Đã lưu vào:</span>
                                <strong style="color:#6ee7b7;">${loc}</strong>
                            </div>
                        </div>
                    `;
                }
            } else {
                setSrtStatus(data.detail || "Không thể lưu file.", "error");
            }
        } catch (err) {
            setSrtStatus(`Lỗi lưu file: ${err.message}`, "error");
        }
    });

    // Rules Accordion Toggle
    btnRulesToggle?.addEventListener("click", () => {
        const isHidden = srtRulesAccordion.style.display === "none";
        srtRulesAccordion.style.display = isHidden ? "block" : "none";
        if (rulesChevron) {
            rulesChevron.innerHTML = isHidden ? `<path d="m18 15-6-6-6 6"/>` : `<path d="m6 9 6 6 6-6"/>`;
        }
    });

    function setSrtStatus(msg, type = "info") {
        if (!srtStatusBanner) return;
        srtStatusBanner.className = `status-toast ${type}`;
        srtStatusBanner.innerHTML = `<span>${msg}</span>`;
    }

    function logSrt(text, type = "info") {
        if (!srtLogConsole) return;
        const time = new Date().toLocaleTimeString("vi-VN", { hour12: false });
        const line = document.createElement("div");
        line.className = `log-line ${type}`;
        line.textContent = `[${time}] ${text}`;
        srtLogConsole.appendChild(line);
        srtLogConsole.scrollTop = srtLogConsole.scrollHeight;
    }

    // Generic SRT Action Caller
    async function handleSrtAction(endpoint, extraPayload = {}, successMsgFn) {
        const content = srtEditor.value;
        if (!content.trim()) {
            setSrtStatus("Vui lòng dán hoặc mở file SRT trước khi xử lý!", "warn");
            return;
        }

        setSrtStatus("Đang xử lý phụ đề...", "info");
        try {
            const res = await fetch(endpoint, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ content, ...extraPayload })
            });
            if (!res.ok) {
                const errData = await res.json().catch(() => ({}));
                throw new Error(errData.detail || `Lỗi máy chủ (${res.status})`);
            }
            const data = await res.json();
            if (data.content) {
                srtEditor.value = data.content;
                updateSrtStats();
            }
            const msg = successMsgFn ? successMsgFn(data) : "Xử lý thành công!";
            setSrtStatus(msg, "success");
            logSrt(msg, "success");
        } catch (err) {
            setSrtStatus(`Lỗi: ${err.message}`, "error");
            logSrt(`Lỗi: ${err.message}`, "error");
        }
    }

    // 2 Highlight Workflows
    document.getElementById("btn-purple-seq")?.addEventListener("click", () => {
        const rules = srtRulesInput.value;
        handleSrtAction(
            "/api/srt/purple-sequence",
            { rules },
            d => `Hoàn thành 3 Bước (Tím)! (Xóa ...: ${d.stats?.leading_ellipsis_removed || 0}, Dấu cuối: ${d.stats?.trailing_punctuation_removed || 0}, Thay thế: ${d.stats?.replacements_applied || 0})`
        );
    });

    document.getElementById("btn-all-seq")?.addEventListener("click", () => {
        const rules = srtRulesInput.value;
        handleSrtAction(
            "/api/srt/all-steps",
            { rules },
            d => `Hoàn thành tuần tự tất cả 7 bước chuẩn hoá SRT!`
        );
    });

    // 7 Individual Operations
    document.getElementById("btn-remove-punct")?.addEventListener("click", () => {
        handleSrtAction(
            "/api/srt/remove-trailing-punctuation",
            {},
            d => `Đã xóa dấu câu cuối cho ${d.changed_lines || 0} dòng (giữ lại dấu ?).`
        );
    });

    document.getElementById("btn-remove-ellipsis")?.addEventListener("click", () => {
        handleSrtAction(
            "/api/srt/remove-leading-ellipsis",
            {},
            d => `Đã xóa '...' ở đầu câu cho ${d.changed_lines || 0} dòng.`
        );
    });

    document.getElementById("btn-avoid-overlap")?.addEventListener("click", () => {
        handleSrtAction(
            "/api/srt/avoid-overlap",
            {},
            d => `Đã điều chỉnh mốc thời gian tránh đè chữ cho ${d.adjusted_sentences || 0} câu.`
        );
    });

    document.getElementById("btn-merge-short")?.addEventListener("click", () => {
        handleSrtAction(
            "/api/srt/merge-short",
            {},
            d => `Đã gộp ${d.total_merged || 0} câu phụ đề ngắn (<0.4s).`
        );
    });

    document.getElementById("btn-fix-repeat-23")?.addEventListener("click", () => {
        handleSrtAction(
            "/api/srt/fix-repeat-2-3",
            {},
            d => `Đã sửa và gộp lặp 2-3 từ (${d.merged_count || 0} vị trí).`
        );
    });

    document.getElementById("btn-fix-repeat-45")?.addEventListener("click", () => {
        handleSrtAction(
            "/api/srt/fix-repeat-4-5",
            {},
            d => `Đã sửa và gộp lặp 4-5 từ (${d.merged_count || 0} vị trí).`
        );
    });

    document.getElementById("btn-apply-replace")?.addEventListener("click", () => {
        const rules = srtRulesInput.value;
        handleSrtAction(
            "/api/srt/replace",
            { rules },
            d => `Đã áp dụng quy tắc thay thế cho ${d.total_replacements || 0} từ/dấu.`
        );
    });


    // -------------------------------------------------------------
    // 2. SRT SPLIT CONTROLLER
    // -------------------------------------------------------------
    let srtSplitFileObj = null;
    const srtSplitDrop = document.getElementById("srt-split-dropzone");
    const srtSplitInput = document.getElementById("srt-split-file");
    const srtSplitBadge = document.getElementById("srt-split-selected-file");

    srtSplitDrop?.addEventListener("click", () => srtSplitInput.click());
    srtSplitInput?.addEventListener("change", (e) => {
        srtSplitFileObj = e.target.files[0];
        if (srtSplitFileObj) {
            srtSplitBadge.style.display = "inline-flex";
            srtSplitBadge.textContent = `File đã chọn: ${srtSplitFileObj.name} (${(srtSplitFileObj.size / 1024).toFixed(1)} KB)`;
        }
    });

    document.getElementById("btn-run-srt-split")?.addEventListener("click", async () => {
        let content = srtEditor.value;
        if (srtSplitFileObj) {
            content = await srtSplitFileObj.text();
        }
        if (!content.trim()) {
            alert("Vui lòng chọn file SRT hoặc nhập nội dung vào trình sửa!");
            return;
        }

        const count = parseInt(document.getElementById("srt-split-count").value) || 10;
        const prefix = document.getElementById("srt-split-prefix").value || "split_srt";
        const resBox = document.getElementById("srt-split-result");
        resBox.style.display = "block";
        resBox.innerHTML = `<div class="status-toast info">${ICONS.loader} <span>Đang tách file và nén ZIP...</span></div>`;

        try {
            const res = await fetch("/api/srt/split", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ content, sentences_per_file: count, base_name: prefix })
            });
            const data = await res.json();
            if (data.download_url) {
                resBox.innerHTML = `
                    <div class="status-toast success">
                        <span>Đã tách thành công ${data.files.length} files nhỏ!</span>
                    </div>
                    <div style="margin-top:10px;">
                        <a href="${data.download_url}" class="btn btn-emerald" style="width:100%;" download>
                            ${ICONS.download}
                            <span>Tải Gói ZIP (${data.zip_filename})</span>
                        </a>
                    </div>
                `;
            } else {
                resBox.innerHTML = `<div class="status-toast error"><span>Lỗi: ${data.detail || "Không thể tách file"}</span></div>`;
            }
        } catch (err) {
            resBox.innerHTML = `<div class="status-toast error"><span>Lỗi kết nối: ${err.message}</span></div>`;
        }
    });


    // -------------------------------------------------------------
    // 3. SRT UPPERCASE CONTROLLER
    // -------------------------------------------------------------
    let srtUpperFileObj = null;
    const srtUpperDrop = document.getElementById("srt-upper-dropzone");
    const srtUpperInput = document.getElementById("srt-upper-file");
    const srtUpperBadge = document.getElementById("srt-upper-selected-file");

    srtUpperDrop?.addEventListener("click", () => srtUpperInput.click());
    srtUpperInput?.addEventListener("change", (e) => {
        srtUpperFileObj = e.target.files[0];
        if (srtUpperFileObj) {
            srtUpperBadge.style.display = "inline-flex";
            srtUpperBadge.textContent = `File đã chọn: ${srtUpperFileObj.name}`;
        }
    });

    document.getElementById("btn-run-srt-upper")?.addEventListener("click", async () => {
        let content = srtEditor.value;
        let fname = "uppercase.srt";
        if (srtUpperFileObj) {
            content = await srtUpperFileObj.text();
            fname = srtUpperFileObj.name.replace(/\.srt$/i, "") + "_UPPER.srt";
        }
        if (!content.trim()) {
            alert("Vui lòng chọn file hoặc nhập phụ đề!");
            return;
        }

        const resBox = document.getElementById("srt-upper-result");
        resBox.style.display = "block";
        resBox.innerHTML = `<div class="status-toast info">${ICONS.loader} <span>Đang chuyển sang chữ HOA...</span></div>`;

        try {
            const res = await fetch("/api/srt/uppercase", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ content })
            });
            const data = await res.json();
            if (data.content) {
                const blob = new Blob([data.content], { type: "text/plain;charset=utf-8" });
                const url = URL.createObjectURL(blob);
                resBox.innerHTML = `
                    <div class="status-toast success">
                        <span>Chuyển đổi hoàn tất thành chữ in HOA!</span>
                    </div>
                    <div style="margin-top:10px;">
                        <a href="${url}" download="${fname}" class="btn btn-emerald" style="width:100%;">
                            ${ICONS.download}
                            <span>Tải file '${fname}'</span>
                        </a>
                    </div>
                `;
            }
        } catch (err) {
            resBox.innerHTML = `<div class="status-toast error"><span>Lỗi: ${err.message}</span></div>`;
        }
    });


    // -------------------------------------------------------------
    // 4. AUDIO STUDIO: WHISPER AI & MODEL MANAGEMENT
    // -------------------------------------------------------------
    let whisperFileObj = null;
    const whisperDrop = document.getElementById("whisper-dropzone");
    const whisperInput = document.getElementById("whisper-file");
    const whisperBadge = document.getElementById("whisper-selected");

    whisperDrop?.addEventListener("click", () => whisperInput.click());
    whisperInput?.addEventListener("change", (e) => {
        whisperFileObj = e.target.files[0];
        if (whisperFileObj) {
            whisperBadge.style.display = "inline-flex";
            whisperBadge.textContent = `File: ${whisperFileObj.name} (${(whisperFileObj.size / 1024 / 1024).toFixed(1)} MB)`;
        }
    });

    // --- WHISPER MODEL SCAN & MODAL STATE ---
    let currentWhisperModelsData = null;
    let isWhisperDownloading = false;
    let whisperDlPollInterval = null;

    const WHISPER_SUPPORTED_SPECS = [
        { id: "large-v3-turbo", name: "large-v3-turbo", size_mb: 1600, min_ram: "4GB RAM", speed: "Nhanh & Tốt", rec: true, desc: "Khuyên dùng cho PC / Server (Tối ưu tốc độ và chất lượng)" },
        { id: "large-v3", name: "large-v3", size_mb: 3100, min_ram: "8GB RAM", speed: "Chậm", rec: false, desc: "Chính xác cao nhất nhưng ngốn nhiều RAM & CPU" },
        { id: "medium", name: "medium", size_mb: 1500, min_ram: "4GB RAM", speed: "Trung bình", rec: false, desc: "Cân bằng tốc độ và độ chính xác" },
        { id: "small", name: "small", size_mb: 460, min_ram: "2GB RAM", speed: "Nhanh", rec: true, desc: "Rất nhẹ, tối ưu cho Android (Termux) & máy tính yếu" },
        { id: "base", name: "base", size_mb: 145, min_ram: "1GB RAM", speed: "Rất nhanh", rec: false, desc: "Siêu nhẹ, tải nhanh, phù hợp máy cấu hình tối thiểu" },
        { id: "tiny", name: "tiny", size_mb: 75, min_ram: "512MB RAM", speed: "Cực nhanh", rec: false, desc: "Nhẹ nhất nhưng độ chính xác tiếng Trung cơ bản" }
    ];

    // WHISPER READINESS HELPER (Section XXIII & XXIV)
    function requireWhisper() {
        if (!currentWhisperModelsData || !currentWhisperModelsData.available || !currentWhisperModelsData.models || currentWhisperModelsData.models.length === 0) {
            openWhisperModal("prompt");
            return false;
        }
        return true;
    }

    // MODAL VIEW SWITCHER
    function openWhisperModal(view = "prompt") {
        const modal = document.getElementById("whisper-model-modal");
        const viewPrompt = document.getElementById("whisper-modal-view-prompt");
        const viewDownloader = document.getElementById("whisper-modal-view-downloader");
        const titleEl = document.getElementById("whisper-modal-title");
        const readyCloseBtn = document.getElementById("btn-modal-ready-close");
        const promptCloseBtn = document.getElementById("btn-modal-prompt-close");

        if (!modal) return;
        modal.style.display = "flex";

        if (view === "prompt") {
            if (viewPrompt) viewPrompt.style.display = "block";
            if (viewDownloader) viewDownloader.style.display = "none";
            if (titleEl) titleEl.textContent = "Whisper AI chưa sẵn sàng";
            if (promptCloseBtn) {
                promptCloseBtn.style.display = "block";
            }
        } else {
            if (viewPrompt) viewPrompt.style.display = "none";
            if (viewDownloader) viewDownloader.style.display = "block";
            if (titleEl) titleEl.textContent = "Quản Lý & Tải Whisper AI Models";
            if (readyCloseBtn) {
                readyCloseBtn.style.display = "inline-flex";
            }
            renderWhisperSpecsList();
        }
    }

    function closeWhisperModal() {
        const modal = document.getElementById("whisper-model-modal");
        if (modal) modal.style.display = "none";
    }

    // RENDER STATUS BANNER & SELECT DROPDOWN
    function renderWhisperModelStatus(data) {
        const statusContainer = document.getElementById("whisper-model-status-container");
        const modelSelect = document.getElementById("whisper-model");
        const validNote = document.getElementById("whisper-model-valid-note");
        const modelCountEl = document.getElementById("whisper-model-count");
        const btnRun = document.getElementById("btn-run-whisper");
        const btnRunText = document.getElementById("btn-run-whisper-text");

        // Update modal directory text
        const dirEl = document.getElementById("whisper-modal-dir");
        const promptPathEl = document.getElementById("whisper-modal-prompt-path");
        const manualDirEl = document.getElementById("whisper-manual-dir-code");
        const dirPath = data.models_dir || "DATA/models/";
        if (dirEl) dirEl.textContent = dirPath;
        if (promptPathEl) promptPathEl.textContent = dirPath;
        if (manualDirEl) manualDirEl.textContent = dirPath;

        if (modelCountEl) modelCountEl.textContent = data.total_valid_count || 0;

        if (data.available && data.models && data.models.length > 0) {
            // ĐÃ CÓ MODEL HỢP LỆ TRONG DATA/models/
            const currentSelected = modelSelect?.value;
            let activeModel = data.models.find(m => m.id === currentSelected);
            if (!activeModel) {
                const defId = data.default_model || data.models[0].id;
                activeModel = data.models.find(m => m.id === defId) || data.models[0];
            }

            if (statusContainer) {
                statusContainer.innerHTML = `
                    <div class="status-badge-ready">
                        <div style="display:flex; align-items:center; gap:8px;">
                            <span class="pulse-dot" style="background:#10b981;"></span>
                            <strong style="color:#ffffff;">Whisper AI:</strong>
                            <span style="color:#34d399; font-weight:700;">● Sẵn sàng</span>
                            <span style="color:#64748b;">•</span>
                            <span style="color:#cbd5e1;">Model: <strong style="color:#c084fc;">${activeModel.name}</strong></span>
                        </div>
                        <div style="font-size:11px; color:#34d399; display:inline-flex; align-items:center; gap:4px; font-weight:600;">
                            <span>✓ Đã tải (${activeModel.path})</span>
                        </div>
                    </div>
                `;
            }

            // Populate SELECT with ONLY existing valid models
            if (modelSelect) {
                modelSelect.innerHTML = "";
                data.models.forEach(m => {
                    const opt = document.createElement("option");
                    opt.value = m.id;
                    opt.textContent = `✓ ${m.name} (~${m.size_mb} MB • ${m.min_ram} • ${m.speed})`;
                    if (m.id === activeModel.id) opt.selected = true;
                    modelSelect.appendChild(opt);
                });
            }

            if (validNote) {
                validNote.innerHTML = `<span style="color:#34d399; font-weight:600;">✓ Có ${data.total_valid_count} model hợp lệ</span>`;
            }

            if (btnRun) {
                btnRun.disabled = false;
                btnRun.style.opacity = "1";
                btnRun.style.cursor = "pointer";
            }
            if (btnRunText) {
                btnRunText.textContent = "🎙 Bắt Đầu Nhận Diện Phụ Đề Whisper";
            }

            // Close modal if it was open on prompt view
            const modal = document.getElementById("whisper-model-modal");
            const viewPrompt = document.getElementById("whisper-modal-view-prompt");
            if (modal && modal.style.display === "flex" && viewPrompt?.style.display === "block") {
                closeWhisperModal();
            }
        } else {
            // CHƯA CÓ MODEL NÀO HỢP LỆ TRONG DATA/models/
            if (statusContainer) {
                statusContainer.innerHTML = `
                    <div class="status-badge-locked">
                        <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:10px;">
                            <div>
                                <div style="font-weight:700; color:#fbbf24; font-size:13px; display:flex; align-items:center; gap:6px;">
                                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#fbbf24" stroke-width="2"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                                    <span>Whisper AI chưa sẵn sàng</span>
                                </div>
                                <div style="color:#cbd5e1; font-size:12px; margin-top:4px; line-height:1.4;">
                                    Chưa tìm thấy Whisper AI Model trong <code style="padding:2px 6px; background:#0b0e17; border-radius:4px; color:#c084fc; font-family:monospace; font-size:11px; border:1px solid rgba(168,85,247,0.2);">${dirPath}</code>. Chức năng Whisper đang bị tạm khóa.
                                </div>
                            </div>
                            <button class="btn btn-purple-gradient" id="btn-status-go-download" type="button" style="padding:6px 14px; font-size:12px;">
                                Đi đến tải Model
                            </button>
                        </div>
                    </div>
                `;
                document.getElementById("btn-status-go-download")?.addEventListener("click", () => {
                    openWhisperModal("downloader");
                });
            }

            if (modelSelect) {
                modelSelect.innerHTML = `<option value="" disabled selected>⚠ Chưa có model nào trong DATA/models/</option>`;
            }

            if (validNote) {
                validNote.innerHTML = `<span style="color:#fbbf24; font-weight:600;">⚠ Chưa có model hợp lệ</span>`;
            }

            if (btnRun) {
                btnRun.disabled = false;
                btnRun.style.opacity = "0.6";
                btnRun.style.cursor = "pointer";
            }
            if (btnRunText) {
                btnRunText.textContent = "⚠ Whisper AI chưa sẵn sàng (Bấm để mở popup)";
            }
        }
    }

    // RENDER SPECS LIST INSIDE DOWNLOADER MODAL
    function renderWhisperSpecsList() {
        const listEl = document.getElementById("whisper-specs-list");
        const countTag = document.getElementById("whisper-valid-count-tag");
        const invalidSec = document.getElementById("whisper-invalid-section");
        const unsupportedSec = document.getElementById("whisper-unsupported-section");

        if (!listEl) return;
        const validModels = currentWhisperModelsData?.models || [];
        const specs = (currentWhisperModelsData?.supported_specs && currentWhisperModelsData.supported_specs.length > 0)
            ? currentWhisperModelsData.supported_specs
            : WHISPER_SUPPORTED_SPECS;

        if (countTag) {
            countTag.textContent = `Đã cài: ${validModels.length} / ${specs.length}`;
        }

        listEl.innerHTML = "";
        specs.forEach(spec => {
            const isInstalled = validModels.some(m => m.id === spec.id);
            const card = document.createElement("div");
            card.className = `model-spec-card ${isInstalled ? "downloaded" : ""}`;

            card.innerHTML = `
                <div style="flex:1;">
                    <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
                        <span style="font-weight:700; font-size:13px; color:#ffffff;">${spec.name}</span>
                        ${spec.rec || spec.recommended_for ? `<span class="spec-badge-rec">KHUYÊN DÙNG</span>` : ""}
                    </div>
                    <div class="spec-meta">
                        <span>Dung lượng: <strong style="color:#cbd5e1;">~${spec.size_mb} MB</strong></span>
                        <span>•</span>
                        <span>Yêu cầu: <strong style="color:#cbd5e1;">${spec.min_ram}</strong></span>
                        <span>•</span>
                        <span>Tốc độ: <strong style="color:#cbd5e1;">${spec.speed}</strong></span>
                    </div>
                    <div style="font-size:11px; color:#94a3b8; margin-top:3px;">
                        ${spec.description || spec.desc || ""}
                    </div>
                </div>
                <div>
                    ${isInstalled ? `
                        <div class="spec-badge-ready">
                            <span>✓ Đã tải (Sẵn sàng)</span>
                        </div>
                    ` : `
                        <button class="spec-btn-download" data-dl-model="${spec.id}" ${isWhisperDownloading ? "disabled" : ""}>
                            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>
                            <span>Tải (~${spec.size_mb} MB)</span>
                        </button>
                    `}
                </div>
            `;
            listEl.appendChild(card);
        });

        // Attach download buttons
        listEl.querySelectorAll("[data-dl-model]").forEach(btn => {
            btn.addEventListener("click", () => {
                const modelId = btn.getAttribute("data-dl-model");
                startDownloadWhisperModel(modelId);
            });
        });

        // Show invalid models if any
        if (invalidSec) {
            const invalidModels = currentWhisperModelsData?.invalid_models || [];
            if (invalidModels.length > 0) {
                invalidSec.style.display = "block";
                invalidSec.innerHTML = `
                    <div style="font-weight:700; color:#ef4444; font-size:12px; margin-bottom:4px;">
                        ⚠ Phát hiện ${invalidModels.length} thư mục model bị lỗi / tải dở dang:
                    </div>
                    <div style="display:flex; flex-direction:column; gap:4px; font-size:11px; color:#fca5a5;">
                        ${invalidModels.map(inv => `<div>• <strong>${inv.folder_name}</strong>: ${inv.reason}</div>`).join("")}
                    </div>
                `;
            } else {
                invalidSec.style.display = "none";
            }
        }

        // Show unsupported models if any
        if (unsupportedSec) {
            const unsupportedModels = currentWhisperModelsData?.unsupported_models || [];
            if (unsupportedModels.length > 0) {
                unsupportedSec.style.display = "block";
                unsupportedSec.innerHTML = `
                    <div style="font-weight:700; color:#94a3b8; font-size:12px; margin-bottom:4px;">
                        ℹ Thư mục lạ không thuộc Whisper (bị bỏ qua):
                    </div>
                    <div style="display:flex; flex-direction:column; gap:4px; font-size:11px; color:#94a3b8;">
                        ${unsupportedModels.map(u => `<div>• <strong>${u.folder_name}</strong>: ${u.reason}</div>`).join("")}
                    </div>
                `;
            } else {
                unsupportedSec.style.display = "none";
            }
        }
    }

    // FETCH / SCAN MODELS FROM BACKEND
    async function fetchWhisperModels(triggerPopupIfMissing = false, isScan = false) {
        try {
            const endpoint = isScan ? "/api/whisper/models/scan" : "/api/whisper/models";
            const res = await fetch(endpoint);
            const data = await res.json();
            currentWhisperModelsData = data;

            renderWhisperModelStatus(data);

            if (!data.available) {
                // Chưa có model nào hợp lệ trong DATA/models/
                if (triggerPopupIfMissing) {
                    openWhisperModal("prompt");
                }
            } else {
                // Đã có ít nhất 1 model hợp lệ -> Popup KHÔNG ĐƯỢC PHÉP xuất hiện
                const readyCloseBtn = document.getElementById("btn-modal-ready-close");
                if (readyCloseBtn) readyCloseBtn.style.display = "inline-flex";
            }

            // If downloader view is currently open, re-render it
            const viewDownloader = document.getElementById("whisper-modal-view-downloader");
            if (viewDownloader && viewDownloader.style.display === "block") {
                renderWhisperSpecsList();
            }
        } catch (err) {
            console.error("Lỗi quét Whisper models:", err);
        }
    }

    // DOWNLOAD MODEL HANDLER
    async function startDownloadWhisperModel(modelId) {
        if (isWhisperDownloading) {
            alert("Đang có một tiến trình tải model khác. Vui lòng chờ hoàn tất.");
            return;
        }

        const progBox = document.getElementById("whisper-dl-progress-box");
        const progMsg = document.getElementById("whisper-dl-progress-msg");
        const progPct = document.getElementById("whisper-dl-progress-pct");
        const progBar = document.getElementById("whisper-dl-progress-bar");
        const errBox = document.getElementById("whisper-dl-error-box");

        if (errBox) errBox.style.display = "none";
        if (progBox) progBox.style.display = "block";
        if (progMsg) progMsg.textContent = `Bắt đầu tải model ${modelId}...`;
        if (progPct) progPct.textContent = "0%";
        if (progBar) progBar.style.width = "0%";

        isWhisperDownloading = true;
        renderWhisperSpecsList();

        try {
            const res = await fetch("/api/whisper/models/download", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ model_id: modelId })
            });
            const resData = await res.json();
            if (!res.ok) {
                throw new Error(resData.detail || "Không thể khởi tạo tiến trình tải.");
            }

            const jobId = resData.job_id;
            if (whisDlPollInterval) clearInterval(whisDlPollInterval);

            whisDlPollInterval = setInterval(async () => {
                try {
                    const jRes = await fetch(`/api/jobs/${jobId}`);
                    const job = await jRes.json();

                    if (progMsg) progMsg.textContent = job.message || `Đang tải model ${modelId}...`;
                    if (progPct) progPct.textContent = `${job.progress || 0}%`;
                    if (progBar) progBar.style.width = `${job.progress || 0}%`;

                    if (job.status === "completed") {
                        clearInterval(whisDlPollInterval);
                        isWhisperDownloading = false;
                        if (progMsg) progMsg.textContent = `✓ Đã tải xong model ${modelId}!`;
                        // Re-scan models
                        await fetchWhisperModels(false, true);
                        renderWhisperSpecsList();
                        setTimeout(() => {
                            if (progBox) progBox.style.display = "none";
                        }, 3000);
                    } else if (job.status === "failed") {
                        clearInterval(whisDlPollInterval);
                        isWhisperDownloading = false;
                        if (errBox) {
                            errBox.style.display = "block";
                            errBox.textContent = `Tải model thất bại: ${job.error || job.message || "Lỗi không xác định"}`;
                        }
                        if (progBox) progBox.style.display = "none";
                        renderWhisperSpecsList();
                    }
                } catch (e) {
                    console.error("Lỗi thăm dò tiến trình download:", e);
                }
            }, 1000);
        } catch (err) {
            isWhisperDownloading = false;
            if (errBox) {
                errBox.style.display = "block";
                errBox.textContent = `Lỗi: ${err.message}`;
            }
            if (progBox) progBox.style.display = "none";
            renderWhisperSpecsList();
        }
    }

    // MODAL BUTTON LISTENERS
    document.getElementById("btn-open-whisper-modal")?.addEventListener("click", () => {
        openWhisperModal("downloader");
    });
    document.getElementById("btn-modal-close")?.addEventListener("click", closeWhisperModal);
    document.getElementById("btn-modal-prompt-close")?.addEventListener("click", closeWhisperModal);
    document.getElementById("btn-modal-ready-close")?.addEventListener("click", closeWhisperModal);
    document.getElementById("btn-modal-go-download")?.addEventListener("click", () => {
        openWhisperModal("downloader");
    });
    document.getElementById("btn-modal-back-to-prompt")?.addEventListener("click", () => {
        openWhisperModal("prompt");
    });
    document.getElementById("btn-modal-refresh")?.addEventListener("click", () => {
        fetchWhisperModels(false, true);
    });

    // Close on backdrop click (Section XIX: Click outside closes popup)
    document.getElementById("whisper-model-modal")?.addEventListener("click", (e) => {
        if (e.target.id === "whisper-model-modal") {
            closeWhisperModal();
        }
    });

    // Close button (X) in header
    document.getElementById("btn-modal-close")?.addEventListener("click", closeWhisperModal);

    // RUN WHISPER TRANSCRIBE BUTTON
    document.getElementById("btn-run-whisper")?.addEventListener("click", async () => {
        if (!requireWhisper()) {
            return;
        }

        if (!whisperFileObj) {
            alert("Vui lòng chọn file âm thanh hoặc video!");
            return;
        }

        const selectedModel = document.getElementById("whisper-model").value;
        if (!selectedModel) {
            alert("Vui lòng chọn một model Whisper hợp lệ đã tải!");
            return;
        }

        const formData = new FormData();
        formData.append("file", whisperFileObj);
        formData.append("model_size", selectedModel);
        formData.append("max_words", document.getElementById("whisper-max-words").value);
        formData.append("max_duration", document.getElementById("whisper-max-dur").value);

        const progContainer = document.getElementById("whisper-progress");
        const resBox = document.getElementById("whisper-result-box");
        if (resBox) resBox.style.display = "none";

        try {
            const res = await fetch("/api/whisper/transcribe", { method: "POST", body: formData });
            const data = await res.json();
            if (!res.ok) {
                throw new Error(data.detail || "Không thể khởi tạo phiên nhận diện giọng nói.");
            }
            if (data.job_id) {
                pollJob(data.job_id, progContainer, (job) => {
                    if (resBox) resBox.style.display = "block";
                    const result = job.result || {};
                    const stats = result.stats || {};
                    const statsEl = document.getElementById("whisper-stats");
                    if (statsEl) {
                        statsEl.innerHTML = `
                            <span>${result.segments_count || 0} câu • Lọc Watermark: ${stats.watermark_filtered || 0} • Lọc Anh: ${stats.english_filtered || 0} • Lọc Thở/Cười: ${(stats.sigh_removed || 0) + (stats.laugh_removed || 0)}</span>
                        `;
                    }
                    const textEl = document.getElementById("whisper-preview-text");
                    if (textEl) textEl.textContent = result.content || "";

                    const btnDl = document.getElementById("btn-download-whisper-srt");
                    if (btnDl) {
                        btnDl.onclick = () => { window.location.href = job.download_url; };
                    }
                    const btnSend = document.getElementById("btn-send-whisper-to-editor");
                    if (btnSend) {
                        btnSend.onclick = () => {
                            if (srtEditor) {
                                srtEditor.value = result.content || "";
                                updateSrtStats();
                            }
                            switchMainTab("srt", "srt-editor");
                            logSrt("Đã nạp phụ đề từ Whisper vào Trình Sửa Phụ Đề.", "success");
                        };
                    }
                });
            }
        } catch (err) {
            alert(`Lỗi khởi tạo: ${err.message}`);
        }
    });

    // Run initial scan in background on load
    fetchWhisperModels(false);


    // -------------------------------------------------------------
    // 5. AUDIO STUDIO: AUDIO MERGE
    // -------------------------------------------------------------
    let audioFileList = [];
    const audioDrop = document.getElementById("audio-dropzone");
    const audioInput = document.getElementById("audio-files-input");
    const audioListEl = document.getElementById("audio-file-list");
    const audioCountEl = document.getElementById("audio-count");

    audioDrop?.addEventListener("click", () => audioInput.click());
    audioInput?.addEventListener("change", (e) => {
        for (const file of e.target.files) {
            audioFileList.push(file);
        }
        renderAudioList();
    });

    document.getElementById("btn-clear-audio-list")?.addEventListener("click", () => {
        audioFileList = [];
        renderAudioList();
    });

    function renderAudioList() {
        if (!audioListEl) return;
        audioListEl.innerHTML = "";
        if (audioCountEl) audioCountEl.textContent = audioFileList.length;
        audioFileList.forEach((f, idx) => {
            const item = document.createElement("div");
            item.className = "file-list-item";
            item.innerHTML = `
                <div style="display:flex; align-items:center; gap:8px;">
                    <span style="color:#64748b; font-family:var(--font-mono);">${idx + 1}.</span>
                    <span>${f.name}</span>
                </div>
                <div style="display:flex; align-items:center; gap:8px;">
                    <span style="color:#64748b; font-size:11px;">${(f.size / 1024 / 1024).toFixed(2)} MB</span>
                    <button class="file-list-remove" data-idx="${idx}">${ICONS.trash}</button>
                </div>
            `;
            item.querySelector(".file-list-remove")?.addEventListener("click", () => {
                audioFileList.splice(idx, 1);
                renderAudioList();
            });
            audioListEl.appendChild(item);
        });
    }

    document.getElementById("btn-run-audio-merge")?.addEventListener("click", async () => {
        if (audioFileList.length < 2) {
            alert("Vui lòng chọn ít nhất 2 file âm thanh!");
            return;
        }

        const formData = new FormData();
        audioFileList.forEach(f => formData.append("files", f));
        formData.append("output_filename", document.getElementById("audio-output-name").value || "combined.mp3");
        formData.append("sort_alphabetical", document.getElementById("audio-sort-alpha").checked);

        const prog = document.getElementById("audio-job-progress");
        try {
            const res = await fetch("/api/audio/merge", { method: "POST", body: formData });
            const data = await res.json();
            if (data.job_id) {
                pollJob(data.job_id, prog);
            }
        } catch (err) {
            alert(`Lỗi: ${err.message}`);
        }
    });


    // -------------------------------------------------------------
    // 6. VIDEO STUDIO: VIDEO CUT
    // -------------------------------------------------------------
    let videoCutFileObj = null;
    const videoCutDrop = document.getElementById("video-cut-dropzone");
    const videoCutInput = document.getElementById("video-cut-file");
    const videoCutBadge = document.getElementById("video-cut-selected");

    videoCutDrop?.addEventListener("click", () => videoCutInput.click());
    videoCutInput?.addEventListener("change", (e) => {
        videoCutFileObj = e.target.files[0];
        if (videoCutFileObj) {
            videoCutBadge.style.display = "inline-flex";
            videoCutBadge.textContent = `Video: ${videoCutFileObj.name} (${(videoCutFileObj.size / 1024 / 1024).toFixed(1)} MB)`;
        }
    });

    document.getElementById("btn-run-video-cut")?.addEventListener("click", async () => {
        if (!videoCutFileObj) {
            alert("Vui lòng chọn file video!");
            return;
        }

        const formData = new FormData();
        formData.append("file", videoCutFileObj);
        formData.append("segment_minutes", document.getElementById("video-cut-minutes").value || 5);
        formData.append("mode", document.getElementById("video-cut-mode").value || "copy");

        const prog = document.getElementById("video-cut-progress");
        try {
            const res = await fetch("/api/video/cut", { method: "POST", body: formData });
            const data = await res.json();
            if (data.job_id) {
                pollJob(data.job_id, prog);
            }
        } catch (err) {
            alert(`Lỗi: ${err.message}`);
        }
    });


    // -------------------------------------------------------------
    // 7. VIDEO STUDIO: VIDEO MERGE & CAPTION
    // -------------------------------------------------------------
    let videoMergeFiles = [];
    const videoMergeDrop = document.getElementById("video-merge-dropzone");
    const videoMergeInput = document.getElementById("video-merge-files");
    const videoMergeList = document.getElementById("video-merge-list");
    const captionCheckbox = document.getElementById("video-enable-caption");
    const captionBox = document.getElementById("caption-settings");

    videoMergeDrop?.addEventListener("click", () => videoMergeInput.click());
    videoMergeInput?.addEventListener("change", (e) => {
        for (const f of e.target.files) videoMergeFiles.push(f);
        renderVideoMergeList();
    });

    captionCheckbox?.addEventListener("change", (e) => {
        if (captionBox) captionBox.style.display = e.target.checked ? "block" : "none";
    });

    function renderVideoMergeList() {
        if (!videoMergeList) return;
        videoMergeList.innerHTML = "";
        videoMergeFiles.forEach((f, idx) => {
            const item = document.createElement("div");
            item.className = "file-list-item";
            item.innerHTML = `
                <div style="display:flex; align-items:center; gap:8px;">
                    <span style="color:#64748b; font-family:var(--font-mono);">${idx + 1}.</span>
                    <span>${f.name}</span>
                </div>
                <div style="display:flex; align-items:center; gap:8px;">
                    <span style="color:#64748b; font-size:11px;">${(f.size / 1024 / 1024).toFixed(1)} MB</span>
                    <button class="file-list-remove" data-idx="${idx}">${ICONS.trash}</button>
                </div>
            `;
            item.querySelector(".file-list-remove")?.addEventListener("click", () => {
                videoMergeFiles.splice(idx, 1);
                renderVideoMergeList();
            });
            videoMergeList.appendChild(item);
        });
    }

    document.getElementById("btn-run-video-merge")?.addEventListener("click", async () => {
        if (videoMergeFiles.length < 2) {
            alert("Vui lòng chọn ít nhất 2 video để ghép!");
            return;
        }

        const formData = new FormData();
        videoMergeFiles.forEach(f => formData.append("files", f));
        formData.append("output_filename", document.getElementById("video-merge-output").value || "merged_video.mp4");
        formData.append("mode", document.getElementById("video-merge-mode").value);

        if (captionCheckbox?.checked) {
            formData.append("caption", document.getElementById("video-caption-text").value);
            formData.append("font_size", document.getElementById("video-caption-size").value);
            formData.append("font_color", document.getElementById("video-caption-color").value);
            formData.append("caption_position", document.getElementById("video-caption-pos").value);
        }

        const prog = document.getElementById("video-merge-progress");
        try {
            const res = await fetch("/api/video/merge", { method: "POST", body: formData });
            const data = await res.json();
            if (data.job_id) {
                pollJob(data.job_id, prog);
            }
        } catch (err) {
            alert(`Lỗi: ${err.message}`);
        }
    });


    // -------------------------------------------------------------
    // 8. VIDEO STUDIO: VIDEO COMPRESS
    // -------------------------------------------------------------
    let videoCompressFile = null;
    const videoCompDrop = document.getElementById("video-compress-dropzone");
    const videoCompInput = document.getElementById("video-compress-file");
    const videoCompBadge = document.getElementById("video-compress-selected");

    videoCompDrop?.addEventListener("click", () => videoCompInput.click());
    videoCompInput?.addEventListener("change", (e) => {
        videoCompressFile = e.target.files[0];
        if (videoCompressFile) {
            videoCompBadge.style.display = "inline-flex";
            videoCompBadge.textContent = `Video: ${videoCompressFile.name} (${(videoCompressFile.size / 1024 / 1024).toFixed(1)} MB)`;
        }
    });

    document.getElementById("btn-run-video-compress")?.addEventListener("click", async () => {
        if (!videoCompressFile) {
            alert("Vui lòng chọn video cần nén!");
            return;
        }

        const formData = new FormData();
        formData.append("file", videoCompressFile);
        formData.append("crf", document.getElementById("video-compress-crf").value);
        formData.append("preset", document.getElementById("video-compress-preset").value);
        formData.append("codec", document.getElementById("video-compress-codec").value);

        const prog = document.getElementById("video-compress-progress");
        try {
            const res = await fetch("/api/video/compress", { method: "POST", body: formData });
            const data = await res.json();
            if (data.job_id) {
                pollJob(data.job_id, prog);
            }
        } catch (err) {
            alert(`Lỗi: ${err.message}`);
        }
    });


    // -------------------------------------------------------------
    // 9. SETTINGS & HEALTH CHECK
    // -------------------------------------------------------------
    async function checkHealth() {
        const sysEl = document.getElementById("health-sys-info");
        const ffmpegEl = document.getElementById("health-ffmpeg-info");
        const dataEl = document.getElementById("health-data-info");

        if (sysEl) sysEl.innerHTML = `<div style="color:#94a3b8; font-size:11px;">Đang kiểm tra...</div>`;

        try {
            const res = await fetch("/api/health");
            if (!res.ok) throw new Error("Máy chủ phản hồi lỗi");
            const data = await res.json();

            if (sysEl) {
                sysEl.innerHTML = `
                    <div class="status-tile-row"><span class="status-tile-label">Hệ điều hành:</span> <span>${data.system?.platform || "Linux"}</span></div>
                    <div class="status-tile-row"><span class="status-tile-label">Python:</span> <span>${data.system?.python_version || "3.10"}</span></div>
                    <div class="status-tile-row"><span class="status-tile-label">Trạng thái:</span> <span style="color:#34d399; font-weight:600;">Sẵn sàng</span></div>
                `;
            }

            if (ffmpegEl) {
                ffmpegEl.innerHTML = `
                    <div class="status-tile-row"><span class="status-tile-label">FFmpeg:</span> <span style="color:#34d399;">${data.components?.ffmpeg?.status}</span></div>
                    <div class="status-tile-row"><span class="status-tile-label">FFprobe:</span> <span style="color:#34d399;">${data.components?.ffprobe?.status}</span></div>
                    <div class="status-tile-row"><span class="status-tile-label">GPU NVENC:</span> <span>${data.components?.nvenc_gpu?.status}</span></div>
                `;
            }

            if (dataEl) {
                dataEl.innerHTML = `
                    <div class="status-tile-row"><span class="status-tile-label">Thư mục DATA:</span> <span style="font-family:var(--font-mono); font-size:11px;">${data.directories?.DATA}</span></div>
                    <div class="status-tile-row"><span class="status-tile-label">File tạm (temp):</span> <span>${data.directories?.temp_files} files</span></div>
                    <div class="status-tile-row"><span class="status-tile-label">File xuất (out):</span> <span>${data.directories?.output_files} files</span></div>
                `;
            }
        } catch (err) {
            if (sysEl) sysEl.innerHTML = `<div style="color:#fb7185; font-size:11px;">Không kết nối được server Python: ${err.message}</div>`;
        }
    }

    document.getElementById("btn-refresh-health")?.addEventListener("click", checkHealth);

    document.getElementById("btn-cleanup-temp")?.addEventListener("click", async () => {
        try {
            const res = await fetch("/api/cleanup", { method: "POST" });
            const data = await res.json();
            alert(`Đã dọn dẹp ${data.cleaned_files || 0} file tạm thời (giải phóng ${data.freed_mb || 0} MB bộ nhớ).`);
            checkHealth();
        } catch (err) {
            alert(`Lỗi dọn dẹp: ${err.message}`);
        }
    });

    // Initial Health Check
    checkHealth();
});
