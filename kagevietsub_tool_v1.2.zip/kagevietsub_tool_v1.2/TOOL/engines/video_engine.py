import os
import shutil
import zipfile
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional
from TOOL.config import OUTPUT_DIR, TEMP_DIR, KAGE_DOWNLOAD_DIR, get_safe_unique_filepath
from TOOL.services.ffmpeg_service import FFmpegService
from TOOL.services.task_service import job_manager

class VideoEngine:
    @staticmethod
    def cut_video_segments(
        input_video: Path,
        segment_minutes: int = 5,
        mode: str = "copy",
        output_dir_name: Optional[str] = None,
        job_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """Cut video into segments of segment_minutes each, and create a ZIP file in Download/KAGEVIETSUB/."""
        info = FFmpegService.get_media_info(input_video)
        duration = info.get("duration", 0.0)
        if duration <= 0:
            raise ValueError(f"Could not read video duration or video is empty: {input_video}")

        segment_seconds = segment_minutes * 60.0
        num_segments = int(duration // segment_seconds) + (1 if duration % segment_seconds > 0 else 0)

        base_stem = input_video.stem
        ext = input_video.suffix or ".mp4"

        segment_files = []
        folder_name = output_dir_name or f"{base_stem}_cut_segments"
        out_folder = KAGE_DOWNLOAD_DIR / folder_name
        out_folder.mkdir(parents=True, exist_ok=True)

        for i in range(num_segments):
            start = i * segment_seconds
            seg_dur = duration - start if i == num_segments - 1 else segment_seconds
            part_filename = f"{base_stem}_part{i+1:03d}{ext}"
            part_path = out_folder / part_filename

            if job_id:
                pct = int(((i) / num_segments) * 85) + 5
                job_manager.update_job(
                    job_id,
                    progress=pct,
                    message=f"Đang cắt đoạn {i+1}/{num_segments} ({round(start, 1)}s -> {round(start+seg_dur, 1)}s)..."
                )

            success, err = FFmpegService.cut_video_segment(input_video, start, seg_dur, part_path, mode=mode)
            if not success:
                # Fallback to re-encode if copy failed
                if mode == "copy":
                    success, err = FFmpegService.cut_video_segment(input_video, start, seg_dur, part_path, mode="reencode")

            if success and part_path.exists():
                segment_files.append(part_path)

        # Create zip directly in Download/KAGEVIETSUB/
        zip_filename = f"{base_stem}_cut_segments.zip"
        zip_path = get_safe_unique_filepath(KAGE_DOWNLOAD_DIR, zip_filename)
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
            for sf in segment_files:
                zipf.write(sf, arcname=sf.name)

        result_data = {
            "total_segments": len(segment_files),
            "zip_filename": zip_path.name,
            "zip_path": str(zip_path),
            "saved_location": f"KAGEVIETSUB/{zip_path.name}",
            "files": [f.name for f in segment_files],
            "duration": duration
        }

        if job_id:
            job_manager.update_job(
                job_id,
                status="completed",
                progress=100,
                message=f"✓ Đã cắt xong {len(segment_files)} đoạn và lưu vào KAGEVIETSUB/",
                download_url=f"/api/download/{zip_path.name}",
                filename=zip_path.name,
                saved_path=str(zip_path),
                saved_location=f"KAGEVIETSUB/{zip_path.name}",
                result=result_data
            )

        return result_data

    @staticmethod
    def merge_video_files(
        video_paths: List[Path],
        output_filename: str = "merged_video.mp4",
        mode: str = "lossless",
        caption: Optional[str] = None,
        font_size: int = 24,
        font_color: str = "white",
        caption_position: str = "bottom",
        sort_mode: str = "natural",
        job_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """Merge multiple videos directly into Download/KAGEVIETSUB/ using logic from tool_gop_videov03.5."""
        if len(video_paths) < 2:
            raise ValueError("Vui lòng cung cấp ít nhất 2 video để ghép.")

        files_to_merge = list(video_paths)
        if sort_mode == "natural":
            from TOOL.engines.audio_engine import natural_sort_key
            files_to_merge.sort(key=lambda p: natural_sort_key(p.name))
        elif sort_mode == "alphabetical":
            files_to_merge.sort(key=lambda p: p.name.lower())

        output_path = get_safe_unique_filepath(KAGE_DOWNLOAD_DIR, output_filename)
        if job_id:
            job_manager.update_job(job_id, progress=10, message=f"Đang phân tích {len(files_to_merge)} video...")

        def _progress(pct, cur_sec, total_sec):
            if job_id:
                # Scale percent to 10..90
                scaled = int(10 + (pct * 0.8))
                job_manager.update_job(
                    job_id,
                    progress=scaled,
                    message=f"Đang ghép video ({round(cur_sec, 1)}s / {round(total_sec, 1)}s - {int(pct)}%)..."
                )

        success = False
        error_msg = ""

        if mode == "lossless":
            success, error_msg = FFmpegService.concat_videos_lossless(files_to_merge, output_path)
            if not success:
                if job_id:
                    job_manager.update_job(job_id, progress=25, message="Lossless thất bại hoặc định dạng không đồng nhất, chuyển sang mã hóa Re-encode (Chuẩn v03.5)...")
                use_gpu = FFmpegService.check_nvenc_support()
                success, error_msg = FFmpegService.concat_videos_reencode(files_to_merge, output_path, use_gpu=use_gpu, progress_callback=_progress)
        elif mode == "gpu":
            success, error_msg = FFmpegService.concat_videos_reencode(files_to_merge, output_path, use_gpu=True, progress_callback=_progress)
        else: # cpu
            success, error_msg = FFmpegService.concat_videos_reencode(files_to_merge, output_path, use_gpu=False, progress_callback=_progress)

        if not success:
            if job_id:
                job_manager.update_job(job_id, status="failed", error=error_msg, message="Lỗi ghép video.")
            raise RuntimeError(f"Video merge failed: {error_msg}")

        # Add caption if requested
        if caption and caption.strip():
            if job_id:
                job_manager.update_job(job_id, progress=92, message="Đang chèn phụ đề lên video...")
            captioned_temp = TEMP_DIR / f"cap_{output_path.name}"
            use_gpu_cap = (mode != "cpu") and FFmpegService.check_nvenc_support()
            cap_success, cap_err = FFmpegService.add_caption_to_video(
                output_path,
                caption.strip(),
                captioned_temp,
                font_size=font_size,
                font_color=font_color,
                position=caption_position,
                use_gpu=use_gpu_cap
            )
            if cap_success and captioned_temp.exists():
                shutil.move(str(captioned_temp), str(output_path))

        info = FFmpegService.get_media_info(output_path)
        result_data = {
            "filename": output_path.name,
            "path": str(output_path),
            "saved_location": f"KAGEVIETSUB/{output_path.name}",
            "size_mb": info.get("size_mb", 0),
            "duration": info.get("duration", 0),
            "resolution": f"{info.get('width', 0)}x{info.get('height', 0)}",
            "fps": info.get("fps", 0)
        }

        if job_id:
            job_manager.update_job(
                job_id,
                status="completed",
                progress=100,
                message=f"✓ Đã xử lý xong và lưu vào KAGEVIETSUB/{output_path.name}",
                download_url=f"/api/download/{output_path.name}",
                filename=output_path.name,
                saved_path=str(output_path),
                saved_location=f"KAGEVIETSUB/{output_path.name}",
                result=result_data
            )

        return result_data

    @staticmethod
    def compress_video_file(
        input_video: Path,
        output_filename: Optional[str] = None,
        crf: int = 18,
        preset: str = "slow",
        codec: str = "libx264",
        job_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """Compress a video and save directly into Download/KAGEVIETSUB/."""
        if not output_filename:
            output_filename = f"{input_video.stem}_compressed.mp4"

        output_path = get_safe_unique_filepath(KAGE_DOWNLOAD_DIR, output_filename)
        size_before_mb = round(os.path.getsize(input_video) / (1024 * 1024), 2)

        if job_id:
            job_manager.update_job(job_id, progress=25, message=f"Đang nén video (CRF {crf})...")

        success, err = FFmpegService.compress_video(input_video, output_path, crf=crf, preset=preset, codec=codec)
        if not success:
            if job_id:
                job_manager.update_job(job_id, status="failed", error=err, message="Lỗi nén video.")
            raise RuntimeError(f"Video compression failed: {err}")

        size_after_mb = round(os.path.getsize(output_path) / (1024 * 1024), 2)
        saved_pct = round((1 - (size_after_mb / size_before_mb)) * 100, 1) if size_before_mb > 0 else 0

        result_data = {
            "filename": output_path.name,
            "path": str(output_path),
            "saved_location": f"KAGEVIETSUB/{output_path.name}",
            "size_before_mb": size_before_mb,
            "size_after_mb": size_after_mb,
            "saved_percent": saved_pct
        }

        if job_id:
            job_manager.update_job(
                job_id,
                status="completed",
                progress=100,
                message=f"✓ Đã nén xong (-{saved_pct}%) và lưu vào KAGEVIETSUB/{output_path.name}",
                download_url=f"/api/download/{output_path.name}",
                filename=output_path.name,
                saved_path=str(output_path),
                saved_location=f"KAGEVIETSUB/{output_path.name}",
                result=result_data
            )

        return result_data
