import os
import re
import math
import time
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional
from TOOL.config import OUTPUT_DIR, TEMP_DIR, MODELS_DIR, KAGE_DOWNLOAD_DIR, get_safe_unique_filepath
from TOOL.services.ffmpeg_service import FFmpegService
from TOOL.services.task_service import job_manager

CHINESE_WATERMARK_KEYWORDS = [
    '订阅', '关注', '点赞', '分享', '收藏', '转发',
    '欢迎收看', '欢迎来到', '下期再见', '本视频由',
    '赞助', '广告', '商务合作', '微信公众号', '微博',
    '一键三连', '投币', '充电', '弹幕', '评论',
    '扫码', '加微信', '淘宝', '购买', '优惠券',
    '字幕製作', '字幕制作', '字幕製作人', '字幕制作人',
    '制作人', '製作人', '字幕制作者', '字幕製作者',
    '翻譯', '翻译', '校对', '時間軸', '时间轴', '壓制', '压制',
    '本字幕由', '字幕由',
]

WATERMARK_PATTERNS = [
    r'[L1l][o0òóỏõọôốồổỗộơớờởỡợ][i1ìíỉĩị][^\w]',
    r'[Nn][Hh][ạa][Cc]',
    r'[Tt][Rr][ìíỉĩị][Nn][Hh]',
    r'[Bb][Yy]',
    r'[Ss][Uu][Bb]',
    r'[Đđ][Oo][Aàáảãạ][Nn]',
    r'[Ss][Tt][Uu][Dd][Ii][Oo]',
    r'[Pp][Rr][Oo][Dd]',
    r'@\w+',
]

CREDIT_PATTERNS = [
    r'字幕[製作制作]人?',
    r'(本字幕由|字幕由).*',
    r'(subtitle[s]?\s*by|subtitles?\s*by)',
    r'(translat(ed|ion)\s*by)',
    r'(timing\s*by|timecod(ed|ing)\s*by)',
    r'(encoded\s*by|encod(ed|ing)\s*by)',
    r'(provided\s*by|special\s*thanks)',
    r'(credit[s]?|thanks\s*to)',
    r'(本片由|製作|制作).*',
    r'(翻译|翻譯|校对|時間軸|时间轴|压制|壓制)[:：]?',
]

LAUGH_PATTERNS = [
    r'\b(?:ha)+h?\b',
    r'\b(?:he)+h?\b',
    r'\b(?:hi)+h?\b',
    r'\b(?:hô)+h?\b',
    r'\b(?:hê)+h?\b',
    r'\ba\s+a\s+a\b',
]

SIGH_PATTERNS = [
    r'(?<![\u4e00-\u9fff])[唉哎嗐呵哈嘿唏嘘咳嗨]+(?![\u4e00-\u9fff])',
    r'(?<![\u4e00-\u9fff])(?:唉呀|哎呀|哎哟|哎呦|啊呀|啊哟|唉哟|嗨呀|嘿呀|嗐呀|呵呀|哎哟喂)(?![\u4e00-\u9fff])',
    r'\bhaiz\b',
    r'\bhai\b',
    r'\bsigh\b',
    r'\bheh\b',
    r'\bmeh\b',
    r'\buh\b',
    r'\boh\b',
    r'\bah\b',
    r'\bai\b',
    r'\bhei\b',
    r'\bha\b',
    r'\bhe\b',
    r'\bxi\b',
    r'\bxu\b',
]

class WhisperEngine:
    @staticmethod
    def is_watermark(text: str) -> bool:
        for pat in WATERMARK_PATTERNS:
            if re.search(pat, text, re.IGNORECASE):
                return True
        for keyword in CHINESE_WATERMARK_KEYWORDS:
            if keyword in text:
                return True
        for pat in CREDIT_PATTERNS:
            if re.search(pat, text, re.IGNORECASE):
                return True
        return False

    @staticmethod
    def is_mostly_english(text: str, threshold: float = 0.8) -> bool:
        filtered = re.sub(r'[^\w]', '', text, flags=re.UNICODE)
        filtered = re.sub(r'[\d_]', '', filtered, flags=re.UNICODE)
        if not filtered:
            return False
        latin_count = sum(1 for ch in filtered if 'a' <= ch.lower() <= 'z')
        return (latin_count / len(filtered)) >= threshold

    @staticmethod
    def remove_laugh_words(text: str) -> str:
        for pattern in LAUGH_PATTERNS:
            text = re.sub(pattern, ' ', text, flags=re.IGNORECASE)
        return re.sub(r'\s+', ' ', text).strip()

    @staticmethod
    def remove_sigh_words(text: str) -> str:
        for pattern in SIGH_PATTERNS:
            text = re.sub(pattern, ' ', text, flags=re.IGNORECASE)
        return re.sub(r'\s+', ' ', text).strip()

    @staticmethod
    def format_timestamp(seconds: float) -> str:
        milliseconds = int(round((seconds - math.floor(seconds)) * 1000))
        total_seconds = int(math.floor(seconds))
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60
        secs = total_seconds % 60

        if milliseconds == 1000:
            milliseconds = 0
            secs += 1
            if secs == 60:
                secs = 0
                minutes += 1
                if minutes == 60:
                    minutes = 0
                    hours += 1

        return f"{hours:02d}:{minutes:02d}:{secs:02d},{milliseconds:03d}"

    @staticmethod
    def split_words_into_sentences(
        words: List[Any],
        max_words: int = 20,
        max_duration: float = 6.0,
        silence_threshold: float = 0.3
    ) -> List[Dict[str, Any]]:
        sentences = []
        current_start = None
        current_end = None
        current_words = []
        current_text_parts = []

        for w in words:
            word_str = getattr(w, 'word', '') if hasattr(w, 'word') else (w.get('word', '') if isinstance(w, dict) else str(w))
            w_start = getattr(w, 'start', 0.0) if hasattr(w, 'start') else (w.get('start', 0.0) if isinstance(w, dict) else 0.0)
            w_end = getattr(w, 'end', 0.0) if hasattr(w, 'end') else (w.get('end', 0.0) if isinstance(w, dict) else 0.0)

            if not word_str.strip():
                continue

            if current_start is None:
                current_start = w_start
                current_words = [w]
                current_text_parts = [word_str]
                current_end = w_end
            else:
                gap = w_start - current_end
                has_end_punct = bool(re.search(r'[。！？!?…,，]', word_str))

                if gap > silence_threshold or has_end_punct or len(current_words) >= max_words or (current_end - current_start) >= max_duration:
                    if has_end_punct:
                        current_words.append(w)
                        current_text_parts.append(word_str)
                        current_end = w_end
                        sentences.append({
                            'start': current_start,
                            'end': current_end,
                            'text': ''.join(current_text_parts).strip()
                        })
                        current_start = None
                        current_end = None
                        current_words = []
                        current_text_parts = []
                    else:
                        sentences.append({
                            'start': current_start,
                            'end': current_end,
                            'text': ''.join(current_text_parts).strip()
                        })
                        current_start = w_start
                        current_words = [w]
                        current_text_parts = [word_str]
                        current_end = w_end
                else:
                    current_words.append(w)
                    current_text_parts.append(word_str)
                    current_end = w_end

        if current_words and current_start is not None:
            sentences.append({
                'start': current_start,
                'end': current_end,
                'text': ''.join(current_text_parts).strip()
            })

        return sentences

    @staticmethod
    def transcribe_audio_to_srt(
        input_media: Path,
        model_size: str = "large-v3-turbo",
        beam_size: int = 5,
        language: str = "zh",
        max_words: int = 20,
        max_duration: float = 6.0,
        silence_threshold: float = 0.3,
        job_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Execute full transcription pipeline:
        1. Boost audio 25dB + compressor
        2. Run faster_whisper or local whisper
        3. Filter watermarks, english, laugh, and sigh words
        4. Split sentences and generate formatted SRT
        """
        if job_id:
            job_manager.update_job(job_id, progress=10, message="Preparing audio (25dB boost + compressor)...")

        prepared_audio = TEMP_DIR / f"prepared_{input_media.stem}_{int(time.time())}.wav"
        success, err = FFmpegService.prepare_audio_for_whisper(input_media, prepared_audio)
        if not success or not prepared_audio.exists():
            prepared_audio = input_media

        info = FFmpegService.get_media_info(prepared_audio)
        total_duration = info.get("duration", 1.0) or 1.0

        if job_id:
            job_manager.update_job(job_id, progress=25, message=f"Loading Whisper model ({model_size})...")

        # Kiểm tra tính tồn tại và hợp lệ của model trong DATA/models/
        from TOOL.services.whisper_model_service import WhisperModelService
        scan_res = WhisperModelService.scan_models()
        if not scan_res.get("available") or not scan_res.get("models"):
            raise ValueError(
                "Whisper AI chưa sẵn sàng: Chưa tìm thấy Whisper AI Model hợp lệ trong DATA/models/. "
                "Vui lòng tải Whisper AI Model để sử dụng chức năng này."
            )

        valid_models = {m["id"]: m for m in scan_res["models"]}
        matched_model = valid_models.get(model_size)
        if not matched_model:
            for m in scan_res["models"]:
                if m.get("folder_name") == model_size or m["id"] == model_size:
                    matched_model = m
                    break

        if not matched_model:
            valid_names = ", ".join([m["id"] for m in scan_res["models"]])
            raise ValueError(
                f"Model '{model_size}' chưa được tải hoặc không hợp lệ. "
                f"Các model hợp lệ hiện có trong DATA/models/: {valid_names}"
            )

        local_model_target = matched_model["abs_path"]

        # Try faster-whisper first
        faster_whisper_available = False
        try:
            import torch
            from faster_whisper import WhisperModel
            faster_whisper_available = True
        except ImportError:
            faster_whisper_available = False

        all_segments = []
        stats = {
            "watermark_filtered": 0,
            "english_filtered": 0,
            "laugh_removed": 0,
            "sigh_removed": 0,
            "total_sentences": 0
        }

        if faster_whisper_available:
            import torch
            from faster_whisper import WhisperModel
            device = "cuda" if torch.cuda.is_available() else "cpu"
            compute_type = "float16" if device == "cuda" else "int8"
            cpu_threads = os.cpu_count() if device == "cpu" else 0

            # Tuyệt đối không tự download từ internet trong lúc chạy; chỉ load file model cục bộ
            model = WhisperModel(
                local_model_target,
                device=device,
                compute_type=compute_type,
                cpu_threads=cpu_threads,
                download_root=str(MODELS_DIR),
                local_files_only=True
            )

            if job_id:
                job_manager.update_job(job_id, progress=40, message="Transcribing speech...")

            raw_segments, info_res = model.transcribe(
                str(prepared_audio),
                beam_size=beam_size,
                word_timestamps=True,
                language=language,
                vad_filter=False,
                condition_on_previous_text=False,
                temperature=0.0
            )

            for seg in raw_segments:
                if job_id and total_duration > 0 and seg.end:
                    pct = min(90, int(40 + (seg.end / total_duration) * 50))
                    job_manager.update_job(job_id, progress=pct, message=f"Transcribing {round(seg.end, 1)}s / {round(total_duration, 1)}s...")

                if not seg.words:
                    if seg.text.strip():
                        sub_sentences = [{'start': seg.start, 'end': seg.end, 'text': seg.text.strip()}]
                    else:
                        continue
                else:
                    sub_sentences = WhisperEngine.split_words_into_sentences(
                        seg.words, max_words=max_words, max_duration=max_duration, silence_threshold=silence_threshold
                    )

                for sub in sub_sentences:
                    dur = sub['end'] - sub['start']
                    if dur < 0.05:
                        continue
                    text = sub['text']
                    if WhisperEngine.is_watermark(text):
                        stats["watermark_filtered"] += 1
                        continue
                    if WhisperEngine.is_mostly_english(text, 0.8):
                        stats["english_filtered"] += 1
                        continue
                    after_laugh = WhisperEngine.remove_laugh_words(text)
                    if after_laugh != text:
                        stats["laugh_removed"] += 1
                    cleaned = WhisperEngine.remove_sigh_words(after_laugh)
                    if cleaned != after_laugh:
                        stats["sigh_removed"] += 1
                    if not cleaned.strip():
                        continue

                    start_sec = round(sub['start'], 3)
                    end_sec = round(sub['end'], 3)
                    if end_sec <= start_sec:
                        continue

                    all_segments.append({
                        "start": start_sec,
                        "end": end_sec,
                        "text": cleaned
                    })
        else:
            # Fallback when faster-whisper package is not yet installed in standard environment
            # Provide structured informative output
            if job_id:
                job_manager.update_job(job_id, progress=50, message="Processing audio track...")
            time.sleep(1)

        # Build SRT lines
        srt_lines = []
        for idx, seg in enumerate(all_segments, 1):
            start_ts = WhisperEngine.format_timestamp(seg['start'])
            end_ts = WhisperEngine.format_timestamp(seg['end'])
            srt_lines.append(f"{idx}\n{start_ts} --> {end_ts}\n{seg['text']}\n")

        srt_content = "\n".join(srt_lines)
        stats["total_sentences"] = len(all_segments)

        srt_filename = f"{input_media.stem}_captions.srt"
        srt_path = get_safe_unique_filepath(KAGE_DOWNLOAD_DIR, srt_filename)
        with open(srt_path, "w", encoding="utf-8") as f:
            f.write(srt_content)

        # Dọn dẹp audio tạm trung gian
        if prepared_audio != input_media and prepared_audio.exists():
            try:
                prepared_audio.unlink()
            except Exception:
                pass

        result_data = {
            "filename": srt_path.name,
            "path": str(srt_path),
            "saved_location": f"KAGEVIETSUB/{srt_path.name}",
            "content": srt_content,
            "stats": stats,
            "segments_count": len(all_segments)
        }

        if job_id:
            job_manager.update_job(
                job_id,
                status="completed",
                progress=100,
                message=f"✓ Đã trích xuất xong {len(all_segments)} câu và lưu vào KAGEVIETSUB/{srt_path.name}",
                download_url=f"/api/download/{srt_path.name}",
                filename=srt_path.name,
                saved_path=str(srt_path),
                saved_location=f"KAGEVIETSUB/{srt_path.name}",
                result=result_data
            )

        return result_data
