import os
import sys
from pathlib import Path

# Base Paths (determined dynamically from this file location)
TOOL_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = TOOL_DIR.parent
DATA_DIR = PROJECT_ROOT / "DATA"

# Runtime Subdirectories inside DATA
TEMP_DIR = DATA_DIR / "temp"
OUTPUT_DIR = DATA_DIR / "output"
UPLOADS_DIR = DATA_DIR / "uploads"
MODELS_DIR = DATA_DIR / "models"
LOGS_DIR = DATA_DIR / "logs"

# Web assets directory
WEB_DIR = TOOL_DIR / "web"

# Server configuration - BIND TO LOCALHOST ONLY (Private & Safe)
# Không expose ra LAN hoặc Internet. Chỉ truy cập qua 127.0.0.1 hoặc localhost.
_env_host = os.getenv("KAGE_HOST", os.getenv("DSUB_HOST", "127.0.0.1"))
HOST = "127.0.0.1" if _env_host in ["0.0.0.0", "", None] else _env_host
PORT = int(os.getenv("PORT", os.getenv("KAGE_PORT", os.getenv("DSUB_PORT", "8000"))))

# Xác định thư mục lưu trữ chính trên thiết bị (Android/Termux / PC)
def get_kagevietsub_download_dir() -> Path:
    """
    Xác định chính xác thư mục Download/KAGEVIETSUB trên thiết bị:
    - Android/Termux:
        1. /storage/emulated/0/Download/KAGEVIETSUB
        2. ~/storage/downloads/KAGEVIETSUB
        3. /sdcard/Download/KAGEVIETSUB
    - Windows / macOS / Linux:
        1. ~/Downloads/KAGEVIETSUB
    - Fallback an toàn:
        PROJECT_ROOT / "Download" / "KAGEVIETSUB"
    
    Tự động kiểm tra và tạo nếu chưa có; KHÔNG xóa dữ liệu cũ.
    """
    candidates = [
        Path("/storage/emulated/0/Download"),
        Path("/sdcard/Download"),
        Path.home() / "storage" / "downloads",
        Path.home() / "Downloads",
        PROJECT_ROOT / "Download"
    ]

    for base_dir in candidates:
        try:
            target = base_dir / "KAGEVIETSUB"
            target.mkdir(parents=True, exist_ok=True)
            # Kiểm tra quyền ghi an toàn
            test_file = target / ".write_test.tmp"
            try:
                test_file.touch()
                if test_file.exists():
                    test_file.unlink()
                return target
            except Exception:
                continue
        except Exception:
            continue

    fallback = PROJECT_ROOT / "Download" / "KAGEVIETSUB"
    fallback.mkdir(parents=True, exist_ok=True)
    return fallback

KAGE_DOWNLOAD_DIR = get_kagevietsub_download_dir()

def get_safe_unique_filepath(directory: Path, filename: str) -> Path:
    """
    Tạo đường dẫn file an toàn không bị ghi đè:
    video.mp4 -> video (1).mp4 -> video (2).mp4
    Chống path traversal (chỉ lấy filename sạch).
    """
    directory.mkdir(parents=True, exist_ok=True)
    safe_name = Path(filename).name.replace("/", "_").replace("\\", "_")
    p = Path(safe_name)
    stem = p.stem
    suffix = p.suffix

    candidate = directory / safe_name
    counter = 1
    while candidate.exists():
        candidate = directory / f"{stem} ({counter}){suffix}"
        counter += 1
    return candidate

def is_safe_path(target_path: Path) -> bool:
    """
    Kiểm tra bảo mật, chống ../ và path traversal ra ngoài các thư mục được phép.
    """
    try:
        resolved = target_path.resolve()
        allowed_roots = [
            DATA_DIR.resolve(),
            KAGE_DOWNLOAD_DIR.resolve(),
            PROJECT_ROOT.resolve()
        ]
        # Cho phép các thư mục lưu trữ hợp lệ trên Android nếu tồn tại
        android_storage = Path("/storage/emulated/0").resolve()
        if android_storage.exists():
            allowed_roots.append(android_storage)
        return any(str(resolved).startswith(str(root)) for root in allowed_roots)
    except Exception:
        return False

# Default settings
DEFAULT_WHISPER_MODEL = "large-v3-turbo"
DEFAULT_BEAM_SIZE = 5
DEFAULT_SPLIT_SENTENCE_MAX_WORDS = 20
DEFAULT_SPLIT_SENTENCE_MAX_DURATION = 6.0
DEFAULT_SILENCE_THRESHOLD = 0.3

def ensure_directories():
    """Tạo tất cả các thư mục cần thiết nếu chưa tồn tại. KHÔNG xóa dữ liệu cũ."""
    for d in [DATA_DIR, TEMP_DIR, OUTPUT_DIR, UPLOADS_DIR, MODELS_DIR, LOGS_DIR]:
        d.mkdir(parents=True, exist_ok=True)
    try:
        KAGE_DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass

# Auto-ensure on import
ensure_directories()
