/**
 * ==============================================================================
 * KAGEVIETSUB - LOCALHOST FRONTEND CONTROLLER (VANILLA JS • 100% PREVIEW PARITY)
 * ==============================================================================
 */

document.addEventListener("DOMContentLoaded", () => {
    // -------------------------------------------------------------
    // SVG ICONS TEMPLATES (Matching Lucide Icons in Preview)
    // -------------------------------------------------------------
    const ICONS = {
        check: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`,
        copy: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>`,
        loader: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="animate-spin"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>`,
        checkCircle: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/></svg>`,
        alertCircle: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/></svg>`,
        download: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>`,
        trash: `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/></svg>`,
        chevronDown: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m6 9 6 6 6-6"/></svg>`,
        chevronUp: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m18 15-6-6-6 6"/></svg>`
    };

    // -------------------------------------------------------------
    // NAVIGATION CONTROLLER (Mobile Drawer & Tab Switching)
    // -------------------------------------------------------------
    const mobileDrawer = document.getElementById("mobile-drawer");
    const mobileDrawerOverlay = document.getElementById("mobile-drawer-overlay");

    function openMobileDrawer() {
        if (mobileDrawer && mobileDrawerOverlay) {
            mobileDrawer.classList.add("open");
            mobileDrawerOverlay.classList.add("open");
            document.body.classList.add("drawer-open");
        }
    }

    function closeMobileDrawer() {
        if (mobileDrawer && mobileDrawerOverlay) {
            mobileDrawer.classList.remove("open");
            mobileDrawerOverlay.classList.remove("open");
            document.body.classList.remove("drawer-open");
        }
    }

    document.getElementById("btn-open-drawer")?.addEventListener("click", openMobileDrawer);
    document.getElementById("btn-close-drawer")?.addEventListener("click", closeMobileDrawer);
    mobileDrawerOverlay?.addEventListener("click", closeMobileDrawer);

    function switchMainTab(mainTabId, subTabId) {
        // Update main tab panes
        document.querySelectorAll(".tab-pane").forEach(pane => {
            pane.classList.toggle("active", pane.id === `main-tab-${mainTabId}`);
        });

        // Update nav buttons (both desktop and bottom nav)
        document.querySelectorAll("[data-main-tab]").forEach(btn => {
            btn.classList.toggle("active", btn.getAttribute("data-main-tab") === mainTabId);
        });

        // Update drawer nav items
        document.querySelectorAll("[data-drawer-tab]").forEach(btn => {
            btn.classList.toggle("active", btn.getAttribute("data-drawer-tab") === mainTabId);
        });

        // Close drawer if open
        closeMobileDrawer();

        // If specific sub-tab requested
        if (subTabId) {
            switchSubTab(subTabId);
        } else if (mainTabId === "audio") {
            if (typeof fetchWhisperModels === "function") {
                fetchWhisperModels(true);
            }
        }

        // Scroll to top
        window.scrollTo({ top: 0, behavior: "smooth" });
    }

    function switchSubTab(subTabId) {
        // Determine section container from subTabId prefix
        let prefix = "srt";
        if (subTabId.startsWith("audio")) prefix = "audio";
        else if (subTabId.startsWith("video")) prefix = "video";

        const section = document.getElementById(`main-tab-${prefix}`);
        if (!section) return;

        section.querySelectorAll(".sub-pane").forEach(p => {
            p.classList.toggle("active", p.id === `sub-pane-${subTabId}`);
        });

        section.querySelectorAll("[data-sub-tab]").forEach(btn => {
            btn.classList.toggle("active", btn.getAttribute("data-sub-tab") === subTabId);
        });

        if (subTabId === "audio-whisper") {
            if (typeof fetchWhisperModels === "function") {
                fetchWhisperModels(true);
            }
        }
    }

    // Attach click listeners for main navigation (desktop + bottom bar)
    document.querySelectorAll("[data-main-tab]").forEach(btn => {
        btn.addEventListener("click", () => {
            const tab = btn.getAttribute("data-main-tab");
            switchMainTab(tab);
        });
    });

    // Attach click listeners for mobile drawer items
    document.querySelectorAll("[data-drawer-tab]").forEach(btn => {
        btn.addEventListener("click", () => {
            const tab = btn.getAttribute("data-drawer-tab");
            switchMainTab(tab);
        });
    });

    // Attach click listeners for sub-tabs
    document.querySelectorAll("[data-sub-tab]").forEach(btn => {
        btn.addEventListener("click", () => {
            const subTab = btn.getAttribute("data-sub-tab");
            switchSubTab(subTab);
        });
    });

    // Logo click goes home
    document.getElementById("brand-logo")?.addEventListener("click", () => switchMainTab("home"));

    // Header settings button click
    document.getElementById("btn-header-settings")?.addEventListener("click", () => {
        switchMainTab("settings");
    });

    // Banner button goes to settings
    document.getElementById("btn-home-check-health")?.addEventListener("click", () => {
        switchMainTab("settings");
        checkHealth();
    });

    // Quick Action Cards on Home View (8 Actions)
    document.querySelectorAll(".action-card[data-action]").forEach(card => {
        card.addEventListener("click", () => {
            const action = card.getAttribute("data-action");
            switch (action) {
                case "srt":
                    switchMainTab("srt", "srt-editor");
                    break;
                case "tts":
                    if (ttsCurrentJobStatus !== "creating" && ttsCurrentJobStatus !== "merging") {
                        if (typeof resetTTSFormToIdle === "function") {
                            resetTTSFormToIdle();
                        }
                    }
                    switchMainTab("tts");
                    break;
                case "whisper":
                    switchMainTab("audio", "audio-whisper");
                    break;
                case "audio-merge":
                    switchMainTab("audio", "audio-merge");
                    break;
                case "video-cut":
                    switchMainTab("video", "video-cut");
                    break;
                case "video-merge":
                    switchMainTab("video", "video-merge");
                    break;
                case "video-compress":
                    switchMainTab("video", "video-compress");
                    break;
                case "srt-split":
                    switchMainTab("srt", "srt-split");
                    break;
                case "srt-upper":
                    switchMainTab("srt", "srt-upper");
                    break;
            }
        });
    });


    // -------------------------------------------------------------
    // JOB PROGRESS COMPONENT (Matching JobProgressCard.tsx)
    // -------------------------------------------------------------
    function renderJobCardHTML(job) {
        const status = job.status || "processing";
        const progress = job.progress !== undefined ? job.progress : 0;
        const isCompleted = status === "completed";
        const isFailed = status === "failed";
        const isProcessing = !isCompleted && !isFailed;

        let iconBoxClass = "processing";
        let iconSvg = ICONS.loader;
        let percentClass = "processing";
        let barClass = "processing";

        if (isCompleted) {
            iconBoxClass = "completed";
            iconSvg = ICONS.checkCircle;
            percentClass = "completed";
            barClass = "completed";
        } else if (isFailed) {
            iconBoxClass = "failed";
            iconSvg = ICONS.alertCircle;
            percentClass = "failed";
            barClass = "failed";
        }

        const typeLabels = {
            "tts": "Tạo Giọng Đọc TTS",
            "tts_create": "Tạo Giọng Đọc TTS",
            "tts_merge": "Ghép Audio TTS",
            "whisper_transcribe": "Trích xuất Whisper AI",
            "audio_merge": "Ghép File Audio",
            "video_cut": "Cắt Đoạn Video",
            "video_merge": "Ghép Video & Caption",
            "video_compress": "Nén Video"
        };
        const title = typeLabels[job.type] || (job.job_id && job.job_id.startsWith("tts_") ? "Tạo Giọng Đọc TTS" : (job.type || "Tác vụ hệ thống"));
        const filename = job.filename ? `File: ${job.filename}` : "";
        const shortId = job.job_id ? job.job_id.substring(0, 8) : "";

        return `
            <div class="job-progress-card" id="job-card-${job.job_id}" style="cursor:pointer;" onclick="window.handleGlobalJobCardClick && window.handleGlobalJobCardClick('${job.job_id}')" title="Nhấp để mở tác vụ này">
                <div class="job-card-header">
                    <div class="job-card-left">
                        <div class="job-icon-box ${iconBoxClass}">${iconSvg}</div>
                        <div>
                            <div class="job-title">${title}</div>
                            <div class="job-meta">ID: ${shortId} ${filename ? `• ${filename}` : ""}</div>
                        </div>
                    </div>
                    <span class="job-percent ${percentClass}">${progress}%</span>
                </div>

                <div class="progress-track">
                    <div class="progress-bar ${barClass}" style="width: ${progress}%"></div>
                </div>

                <div style="font-size: 11px; color: ${isFailed ? "#fb7185" : "#94a3b8"}; display: flex; align-items: center; justify-content: space-between;">
                    <span>${job.message || (isCompleted ? "Xử lý thành công!" : "Đang xử lý...")}</span>
                    <span style="text-transform: capitalize; font-weight: 600;">${status}</span>
                </div>

                ${isCompleted ? `
                    <div class="job-card-footer" style="display:flex; flex-wrap:wrap; align-items:center; justify-content:space-between; gap:8px;">
                        <div style="display:flex; align-items:center; gap:6px; font-size:12px; color:#34d399; font-weight:600;">
                            ${ICONS.checkCircle}
                            <span>✓ Đã xử lý xong</span>
                        </div>
                        <div style="display:flex; align-items:center; gap:6px; padding:4px 10px; background:#0e1322; border:1px solid rgba(16,185,129,0.25); border-radius:10px; font-size:11px; font-family:var(--font-mono); color:#cbd5e1;">
                            <span style="color:#64748b;">📁 Đã lưu vào:</span>
                            <strong style="color:#6ee7b7;">${job.saved_location || (job.filename ? `KAGEVIETSUB/${job.filename}` : "KAGEVIETSUB/")}</strong>
                        </div>
                    </div>
                ` : ""}

                ${isFailed && job.error ? `
                    <div style="padding: 8px 12px; background: rgba(244,63,94,0.1); border: 1px solid rgba(244,63,94,0.25); border-radius: 8px; font-size: 11px; color: #fb7185;">
                        <b>Lỗi:</b> ${job.error}
                    </div>
                ` : ""}
            </div>
        `;
    }

    async function pollJob(jobId, targetContainer, onComplete) {
        if (!targetContainer) return;
        targetContainer.style.display = "block";
        targetContainer.innerHTML = renderJobCardHTML({ job_id: jobId, status: "processing", progress: 5, message: "Khởi tạo tác vụ..." });

        const interval = setInterval(async () => {
            try {
                const res = await fetch(`/api/jobs/${jobId}`);
                if (!res.ok) throw new Error("Không thể kết nối tác vụ");
                const job = await res.json();

                targetContainer.innerHTML = renderJobCardHTML(job);
                updateGlobalActiveJobs();

                if (job.status === "completed") {
                    clearInterval(interval);
                    if (onComplete) onComplete(job);
                } else if (job.status === "failed") {
                    clearInterval(interval);
                }
            } catch (err) {
                targetContainer.innerHTML = `
                    <div class="status-toast error">
                        <span>Lỗi kiểm tra tiến trình: ${err.message}</span>
                    </div>
                `;
                clearInterval(interval);
            }
        }, 1000);
    }

    // Global Active Jobs Tracker
    async function updateGlobalActiveJobs() {
        try {
            const res = await fetch("/api/jobs");
            if (!res.ok) return;
            const data = await res.json();
            const jobs = data.jobs || [];
            const runningJobs = jobs.filter(j => j.status === "processing");

            // 1. Header Status Area
            const statusArea = document.getElementById("header-status-area");
            if (statusArea) {
                if (runningJobs.length > 0) {
                    statusArea.innerHTML = `
                        <div class="header-job-pill" onclick="document.querySelector('[data-main-tab=home]').click();">
                            ${ICONS.loader}
                            <span>${runningJobs.length} Tác vụ đang chạy</span>
                        </div>
                    `;
                } else {
                    statusArea.innerHTML = `
                        <div class="header-status-pill">
                            <span class="pulse-dot"></span>
                            <span>127.0.0.1:8000 Online</span>
                        </div>
                    `;
                }
            }

            // 2. Home View Jobs Widget
            const homeSection = document.getElementById("home-jobs-section");
            const homeList = document.getElementById("home-jobs-list");
            if (homeSection && homeList) {
                if (jobs.length > 0) {
                    homeSection.style.display = "block";
                    homeList.innerHTML = jobs.slice(0, 4).map(j => renderJobCardHTML(j)).join("");
                } else {
                    homeSection.style.display = "none";
                }
            }

            // 3. Settings View Jobs List
            const settingsList = document.getElementById("settings-jobs-list");
            if (settingsList) {
                if (jobs.length > 0) {
                    settingsList.innerHTML = jobs.slice(0, 6).map(j => renderJobCardHTML(j)).join("");
                } else {
                    settingsList.innerHTML = `<div style="font-size:12px; color:#64748b;">Chưa có tác vụ nào được thực thi.</div>`;
                }
            }
        } catch (e) {
            // silent fail on offline
        }
    }

    document.getElementById("btn-home-refresh-jobs")?.addEventListener("click", updateGlobalActiveJobs);
    setInterval(updateGlobalActiveJobs, 4000);
    updateGlobalActiveJobs();


    // -------------------------------------------------------------
    // 1. SRT STUDIO: EDITOR CONTROLLER
    // -------------------------------------------------------------
    const srtEditor = document.getElementById("srt-editor-textarea");
    const srtLineCount = document.getElementById("srt-line-count");
    const srtCharCount = document.getElementById("srt-char-count");
    const srtFileInput = document.getElementById("srt-file-input");
    const srtFilenameInput = document.getElementById("srt-filename-input");
    const srtStatusBanner = document.getElementById("srt-status-banner");
    const srtLogConsole = document.getElementById("srt-log-console");
    const btnRulesToggle = document.getElementById("btn-toggle-rules");
    const srtRulesAccordion = document.getElementById("srt-rules-accordion");
    const rulesChevron = document.getElementById("rules-chevron");
    const srtRulesInput = document.getElementById("srt-rules-input");

    // Initialize Default Content (Matching Preview initialContent)
    const SAMPLE_SRT = `1\n00:00:01,000 --> 00:00:03,500\n...Chào mừng bạn đến với KAGEVIETSUB.\n\n2\n00:00:03,500 --> 00:00:05,200\nỨng dụng chỉnh sửa phụ đề tự động trên điện thoại!\n\n3\n00:00:05,200 --> 00:00:07,000\nvi sao lai khong thu ngay?`;
    const DEFAULT_RULES = `... -> ,\n. -> ,\n! -> ,\nvi -> Vi\nxi -> Xi\n" -> `;

    if (srtEditor && !srtEditor.value.trim()) {
        srtEditor.value = SAMPLE_SRT;
    }
    if (srtRulesInput && !srtRulesInput.value.trim()) {
        srtRulesInput.value = DEFAULT_RULES;
    }

    function updateSrtStats() {
        if (!srtEditor) return;
        const val = srtEditor.value;
        const lines = val ? val.split("\n").length : 0;
        const chars = val.length;
        if (srtLineCount) srtLineCount.textContent = lines;
        if (srtCharCount) srtCharCount.textContent = chars;
    }
    srtEditor?.addEventListener("input", updateSrtStats);
    updateSrtStats();

    // Copy SRT Button
    const btnCopy = document.getElementById("btn-copy-srt");
    btnCopy?.addEventListener("click", () => {
        if (!srtEditor || !srtEditor.value) return;
        navigator.clipboard.writeText(srtEditor.value).then(() => {
            btnCopy.innerHTML = `${ICONS.check} <span>Đã sao chép!</span>`;
            setTimeout(() => {
                btnCopy.innerHTML = `${ICONS.copy} <span>Sao chép</span>`;
            }, 2000);
            logSrt("Đã sao chép nội dung SRT vào bộ nhớ tạm.", "success");
        });
    });

    // File Upload
    srtFileInput?.addEventListener("change", (e) => {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (evt) => {
            srtEditor.value = evt.target.result;
            updateSrtStats();
            if (srtFilenameInput) {
                srtFilenameInput.value = file.name;
            }
            logSrt(`Đã mở file: ${file.name} (${file.size} bytes)`, "success");
            setSrtStatus(`Đã tải file ${file.name}`, "success");
        };
        reader.readAsText(file, "utf-8");
    });

    // Save SRT directly to KAGEVIETSUB
    document.getElementById("btn-download-srt")?.addEventListener("click", async () => {
        const content = srtEditor.value;
        if (!content.trim()) {
            setSrtStatus("Nội dung SRT trống!", "warn");
            return;
        }
        let fname = srtFilenameInput.value.trim() || "edited_subtitles.srt";
        if (!fname.toLowerCase().endsWith(".srt")) fname += ".srt";

        setSrtStatus("Đang lưu file...", "info");
        try {
            const res = await fetch("/api/srt/save", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ content, filename: fname })
            });
            const data = await res.json();
            if (data.status === "saved") {
                const loc = data.saved_location || `KAGEVIETSUB/${fname}`;
                logSrt(`Đã lưu file thành công vào: ${loc}`, "success");
                setSrtStatus(`✓ Đã xử lý xong! Đã lưu vào ${loc}`, "success");
                const resContainer = document.getElementById("srt-save-result-container");
                if (resContainer) {
                    resContainer.style.display = "block";
                    resContainer.innerHTML = `
                        <div style="display:flex; flex-wrap:wrap; align-items:center; justify-content:space-between; gap:8px; padding:10px 14px; background:#0d1017; border:1px solid rgba(16,185,129,0.3); border-radius:12px; margin-top:8px;">
                            <div style="display:flex; align-items:center; gap:6px; font-size:12px; color:#34d399; font-weight:600;">
                                ${ICONS.checkCircle}
                                <span>✓ Đã xử lý xong</span>
                            </div>
                            <div style="display:flex; align-items:center; gap:6px; padding:4px 10px; background:#0e1322; border:1px solid rgba(16,185,129,0.25); border-radius:10px; font-size:11px; font-family:var(--font-mono); color:#cbd5e1;">
                                <span style="color:#64748b;">📁 Đã lưu vào:</span>
                                <strong style="color:#6ee7b7;">${loc}</strong>
                            </div>
                        </div>
                    `;
                }
            } else {
                setSrtStatus(data.detail || "Không thể lưu file.", "error");
            }
        } catch (err) {
            setSrtStatus(`Lỗi lưu file: ${err.message}`, "error");
        }
    });

    // Rules Accordion Toggle
    btnRulesToggle?.addEventListener("click", () => {
        if (!srtRulesAccordion) return;
        const isHidden = srtRulesAccordion.style.display === "none";
        srtRulesAccordion.style.display = isHidden ? "block" : "none";
        if (rulesChevron) {
            rulesChevron.innerHTML = isHidden ? `<path d="m18 15-6-6-6 6"/>` : `<path d="m6 9 6 6 6-6"/>`;
        }
    });

    function setSrtStatus(msg, type = "info") {
        if (!srtStatusBanner) return;
        srtStatusBanner.className = `status-toast ${type}`;
        srtStatusBanner.innerHTML = `<span>${msg}</span>`;
    }

    function logSrt(text, type = "info") {
        if (!srtLogConsole) return;
        const time = new Date().toLocaleTimeString("vi-VN", { hour12: false });
        const line = document.createElement("div");
        line.className = `log-line ${type}`;
        line.textContent = `[${time}] ${text}`;
        srtLogConsole.appendChild(line);
        srtLogConsole.scrollTop = srtLogConsole.scrollHeight;
    }

    // Generic SRT Action Caller
    async function handleSrtAction(endpoint, extraPayload = {}, successMsgFn) {
        const content = srtEditor.value;
        if (!content.trim()) {
            setSrtStatus("Vui lòng dán hoặc mở file SRT trước khi xử lý!", "warn");
            return;
        }

        setSrtStatus("Đang xử lý phụ đề...", "info");
        try {
            const res = await fetch(endpoint, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ content, ...extraPayload })
            });
            if (!res.ok) {
                const errData = await res.json().catch(() => ({}));
                throw new Error(errData.detail || `Lỗi máy chủ (${res.status})`);
            }
            const data = await res.json();
            if (data.content) {
                srtEditor.value = data.content;
                updateSrtStats();
            }
            const msg = successMsgFn ? successMsgFn(data) : "Xử lý thành công!";
            setSrtStatus(msg, "success");
            logSrt(msg, "success");
        } catch (err) {
            setSrtStatus(`Lỗi: ${err.message}`, "error");
            logSrt(`Lỗi: ${err.message}`, "error");
        }
    }

    // 2 Highlight Workflows
    document.getElementById("btn-purple-seq")?.addEventListener("click", () => {
        const rules = srtRulesInput.value;
        handleSrtAction(
            "/api/srt/purple-sequence",
            { rules },
            d => `Hoàn thành 3 Bước (Tím)! (Xóa ...: ${d.stats?.leading_ellipsis_removed || 0}, Dấu cuối: ${d.stats?.trailing_punctuation_removed || 0}, Thay thế: ${d.stats?.replacements_applied || 0})`
        );
    });

    document.getElementById("btn-all-seq")?.addEventListener("click", () => {
        const rules = srtRulesInput.value;
        handleSrtAction(
            "/api/srt/all-steps",
            { rules },
            d => `Hoàn thành tuần tự tất cả 7 bước chuẩn hoá SRT!`
        );
    });

    // 7 Individual Operations
    document.getElementById("btn-remove-punct")?.addEventListener("click", () => {
        handleSrtAction(
            "/api/srt/remove-trailing-punctuation",
            {},
            d => `Đã xóa dấu câu cuối cho ${d.changed_lines || 0} dòng (giữ lại dấu ?).`
        );
    });

    document.getElementById("btn-remove-ellipsis")?.addEventListener("click", () => {
        handleSrtAction(
            "/api/srt/remove-leading-ellipsis",
            {},
            d => `Đã xóa '...' ở đầu câu cho ${d.changed_lines || 0} dòng.`
        );
    });

    document.getElementById("btn-avoid-overlap")?.addEventListener("click", () => {
        handleSrtAction(
            "/api/srt/avoid-overlap",
            {},
            d => `Đã điều chỉnh mốc thời gian tránh đè chữ cho ${d.adjusted_sentences || 0} câu.`
        );
    });

    document.getElementById("btn-merge-short")?.addEventListener("click", () => {
        handleSrtAction(
            "/api/srt/merge-short",
            {},
            d => `Đã gộp ${d.total_merged || 0} câu phụ đề ngắn (<0.4s).`
        );
    });

    document.getElementById("btn-fix-repeat-23")?.addEventListener("click", () => {
        handleSrtAction(
            "/api/srt/fix-repeat-2-3",
            {},
            d => `Đã sửa và gộp lặp 2-3 từ (${d.merged_count || 0} vị trí).`
        );
    });

    document.getElementById("btn-fix-repeat-45")?.addEventListener("click", () => {
        handleSrtAction(
            "/api/srt/fix-repeat-4-5",
            {},
            d => `Đã sửa và gộp lặp 4-5 từ (${d.merged_count || 0} vị trí).`
        );
    });

    document.getElementById("btn-apply-replace")?.addEventListener("click", () => {
        const rules = srtRulesInput.value;
        handleSrtAction(
            "/api/srt/replace",
            { rules },
            d => `Đã áp dụng quy tắc thay thế cho ${d.total_replacements || 0} từ/dấu.`
        );
    });


    // -------------------------------------------------------------
    // 2. SRT SPLIT CONTROLLER
    // -------------------------------------------------------------
    let srtSplitFileObj = null;
    const srtSplitDrop = document.getElementById("srt-split-dropzone");
    const srtSplitInput = document.getElementById("srt-split-file");
    const srtSplitBadge = document.getElementById("srt-split-selected-file");

    srtSplitDrop?.addEventListener("click", () => srtSplitInput?.click());
    srtSplitInput?.addEventListener("change", (e) => {
        srtSplitFileObj = e.target.files[0];
        if (srtSplitFileObj && srtSplitBadge) {
            srtSplitBadge.style.display = "inline-flex";
            srtSplitBadge.textContent = `File đã chọn: ${srtSplitFileObj.name} (${(srtSplitFileObj.size / 1024).toFixed(1)} KB)`;
        }
    });

    document.getElementById("btn-run-srt-split")?.addEventListener("click", async () => {
        let content = srtEditor ? srtEditor.value : "";
        if (srtSplitFileObj) {
            content = await srtSplitFileObj.text();
        }
        if (!content.trim()) {
            alert("Vui lòng chọn file SRT hoặc nhập nội dung vào trình sửa!");
            return;
        }

        const count = parseInt(document.getElementById("srt-split-count")?.value || 10);
        const prefix = document.getElementById("srt-split-prefix")?.value || "split_srt";
        const resBox = document.getElementById("srt-split-result");
        if (resBox) {
            resBox.style.display = "block";
            resBox.innerHTML = `<div class="status-toast info">${ICONS.loader} <span>Đang chia nhỏ phụ đề...</span></div>`;
        }

        try {
            const res = await fetch("/api/srt/split", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ content, sentences_per_file: count, base_name: prefix })
            });
            const data = await res.json();
            if (resBox) {
                if (data.status === "success" && data.files) {
                    const filesListHtml = data.files.map(f => `
                        <div style="display:flex; justify-content:space-between; align-items:center; background:rgba(255,255,255,0.04); padding:6px 12px; border-radius:6px; margin-bottom:6px; font-size:12px; border:1px solid rgba(255,255,255,0.06);">
                            <span style="color:#67e8f9; font-family:monospace;">${f.filename}</span>
                            <span style="color:#94a3b8;">${f.sentences} câu</span>
                        </div>
                    `).join("");

                    resBox.innerHTML = `
                        <div class="status-toast success" style="margin-bottom:12px;">
                            <span>✓ Đã tách thành công ${data.files.length} file và lưu vào <strong>Download/KAGEVIETSUB/</strong></span>
                        </div>
                        <div style="max-height:180px; overflow-y:auto; padding-right:4px;">
                            ${filesListHtml}
                        </div>
                    `;
                } else {
                    resBox.innerHTML = `<div class="status-toast error"><span>Lỗi: ${data.detail || "Không thể tách file"}</span></div>`;
                }
            }
        } catch (err) {
            if (resBox) resBox.innerHTML = `<div class="status-toast error"><span>Lỗi kết nối: ${err.message}</span></div>`;
        }
    });


    // -------------------------------------------------------------
    // 3. SRT UPPERCASE CONTROLLER
    // -------------------------------------------------------------
    let srtUpperFileObj = null;
    const srtUpperDrop = document.getElementById("srt-upper-dropzone");
    const srtUpperInput = document.getElementById("srt-upper-file");
    const srtUpperBadge = document.getElementById("srt-upper-selected-file");

    srtUpperDrop?.addEventListener("click", () => srtUpperInput?.click());
    srtUpperInput?.addEventListener("change", (e) => {
        srtUpperFileObj = e.target.files[0];
        if (srtUpperFileObj && srtUpperBadge) {
            srtUpperBadge.style.display = "inline-flex";
            srtUpperBadge.textContent = `File đã chọn: ${srtUpperFileObj.name}`;
        }
    });

    document.getElementById("btn-run-srt-upper")?.addEventListener("click", async () => {
        let content = srtEditor ? srtEditor.value : "";
        let fname = "uppercase.srt";
        if (srtUpperFileObj) {
            content = await srtUpperFileObj.text();
            fname = srtUpperFileObj.name.replace(/\.srt$/i, "") + "_UPPER.srt";
        }
        if (!content.trim()) {
            alert("Vui lòng chọn file hoặc nhập phụ đề!");
            return;
        }

        const resBox = document.getElementById("srt-upper-result");
        if (resBox) {
            resBox.style.display = "block";
            resBox.innerHTML = `<div class="status-toast info">${ICONS.loader} <span>Đang chuyển sang chữ HOA...</span></div>`;
        }

        try {
            const res = await fetch("/api/srt/uppercase", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ content })
            });
            const data = await res.json();
            if (resBox && data.content) {
                const blob = new Blob([data.content], { type: "text/plain;charset=utf-8" });
                const url = URL.createObjectURL(blob);
                resBox.innerHTML = `
                    <div class="status-toast success">
                        <span>Chuyển đổi hoàn tất thành chữ in HOA!</span>
                    </div>
                    <div style="margin-top:10px;">
                        <a href="${url}" download="${fname}" class="btn btn-emerald" style="width:100%;">
                            ${ICONS.download}
                            <span>Tải file '${fname}'</span>
                        </a>
                    </div>
                `;
            }
        } catch (err) {
            if (resBox) resBox.innerHTML = `<div class="status-toast error"><span>Lỗi: ${err.message}</span></div>`;
        }
    });


    // -------------------------------------------------------------
    // 4. AUDIO STUDIO: WHISPER AI & MODEL MANAGEMENT
    // -------------------------------------------------------------
    let whisperFileObj = null;
    const whisperDrop = document.getElementById("whisper-dropzone");
    const whisperInput = document.getElementById("whisper-file");
    const whisperBadge = document.getElementById("whisper-selected");

    whisperDrop?.addEventListener("click", () => whisperInput?.click());
    whisperInput?.addEventListener("change", (e) => {
        whisperFileObj = e.target.files[0];
        if (whisperFileObj && whisperBadge) {
            whisperBadge.style.display = "inline-flex";
            whisperBadge.textContent = `File: ${whisperFileObj.name} (${(whisperFileObj.size / 1024 / 1024).toFixed(1)} MB)`;
        }
    });

    // --- WHISPER MODEL SCAN & MODAL STATE ---
    let currentWhisperModelsData = null;
    // PER-MODEL INDEPENDENT DOWNLOAD STATES
    // modelDownloadStates[modelId] = { status: 'NOT_DOWNLOADED'|'DOWNLOADING'|'DOWNLOADED'|'ERROR', progress: 0..100, message: '', error: '', jobId: '', pollInterval: null }
    const modelDownloadStates = {};

    const WHISPER_SUPPORTED_SPECS = [
        { id: "large-v3-turbo", name: "Large v3 Turbo (Chuẩn Studio)", size_mb: 1600, min_ram: "4GB RAM", speed: "Nhanh & Tối ưu", rec: true, desc: "Khuyên dùng cho PC / Laptop (Tối ưu tốc độ & chuẩn phòng thu)" },
        { id: "large-v3", name: "Large v3 (Chính xác tối đa)", size_mb: 3100, min_ram: "8GB RAM", speed: "Chậm", rec: false, desc: "Chính xác cao nhất cho thoại khó nhưng yêu cầu cấu hình mạnh" },
        { id: "medium", name: "Medium (Chính xác cao)", size_mb: 1500, min_ram: "4GB RAM", speed: "Trung bình", rec: false, desc: "Cân bằng tốc độ và độ chính xác, thích hợp máy trung bình" },
        { id: "small", name: "Small (Cân bằng & Nhanh)", size_mb: 461, min_ram: "2GB RAM", speed: "Nhanh", rec: true, desc: "Rất nhẹ, tối ưu cho Android (Termux) & máy tính phổ thông" },
        { id: "base", name: "Base (Nhẹ)", size_mb: 145, min_ram: "1GB RAM", speed: "Rất nhanh", rec: false, desc: "Siêu nhẹ, tải nhanh, phù hợp thiết bị cấu hình cơ bản" },
        { id: "tiny", name: "Tiny (Siêu nhẹ)", size_mb: 75, min_ram: "512MB RAM", speed: "Cực nhanh", rec: false, desc: "Nhẹ nhất nhưng độ chính xác tiếng Trung ở mức cơ bản" }
    ];

    // WHISPER READINESS HELPER (Section XXIII & XXIV)
    function requireWhisper() {
        if (!currentWhisperModelsData || !currentWhisperModelsData.available || !currentWhisperModelsData.models || currentWhisperModelsData.models.length === 0) {
            openWhisperModal("prompt");
            return false;
        }
        return true;
    }

    // MODAL VIEW SWITCHER
    function openWhisperModal(view = "prompt") {
        const modal = document.getElementById("whisper-model-modal");
        const viewPrompt = document.getElementById("whisper-modal-view-prompt");
        const viewDownloader = document.getElementById("whisper-modal-view-downloader");
        const titleEl = document.getElementById("whisper-modal-title");
        const readyCloseBtn = document.getElementById("btn-modal-ready-close");
        const promptCloseBtn = document.getElementById("btn-modal-prompt-close");

        if (!modal) return;
        modal.style.display = "flex";

        if (view === "prompt") {
            if (viewPrompt) viewPrompt.style.display = "block";
            if (viewDownloader) viewDownloader.style.display = "none";
            if (titleEl) titleEl.textContent = "Whisper AI chưa sẵn sàng";
            if (promptCloseBtn) {
                promptCloseBtn.style.display = "block";
            }
        } else {
            if (viewPrompt) viewPrompt.style.display = "none";
            if (viewDownloader) viewDownloader.style.display = "block";
            if (titleEl) titleEl.textContent = "Quản Lý & Tải Whisper AI Models";
            if (readyCloseBtn) {
                readyCloseBtn.style.display = "inline-flex";
            }
            renderWhisperSpecsList();
        }
    }

    function closeWhisperModal() {
        const modal = document.getElementById("whisper-model-modal");
        if (modal) modal.style.display = "none";
    }

    // RENDER STATUS BANNER & SELECT DROPDOWN
    function renderWhisperModelStatus(data) {
        const statusContainer = document.getElementById("whisper-model-status-container");
        const modelSelect = document.getElementById("whisper-model");
        const validNote = document.getElementById("whisper-model-valid-note");
        const modelCountEl = document.getElementById("whisper-model-count");
        const btnRun = document.getElementById("btn-run-whisper");
        const btnRunText = document.getElementById("btn-run-whisper-text");

        // Update modal directory text
        const dirEl = document.getElementById("whisper-modal-dir");
        const promptPathEl = document.getElementById("whisper-modal-prompt-path") || document.getElementById("modal-prompt-models-dir");
        const manualDirEl = document.getElementById("whisper-manual-dir-code");
        const dirPath = data.models_dir || "DATA/models/";
        if (dirEl) dirEl.textContent = dirPath;
        if (promptPathEl) promptPathEl.textContent = dirPath;
        if (manualDirEl) manualDirEl.textContent = dirPath;

        if (modelCountEl) modelCountEl.textContent = data.total_valid_count || 0;

        if (data.available && data.models && data.models.length > 0) {
            // ĐÃ CÓ MODEL HỢP LỆ TRONG DATA/models/
            const currentSelected = modelSelect?.value;
            let activeModel = data.models.find(m => m.id === currentSelected);
            if (!activeModel) {
                const defId = data.default_model || data.models[0].id;
                activeModel = data.models.find(m => m.id === defId) || data.models[0];
            }

            if (statusContainer) {
                statusContainer.innerHTML = `
                    <div class="status-badge-ready">
                        <div style="display:flex; align-items:center; gap:8px;">
                            <span class="pulse-dot" style="background:#10b981;"></span>
                            <strong style="color:#ffffff;">Whisper AI:</strong>
                            <span style="color:#34d399; font-weight:700;">● Sẵn sàng</span>
                            <span style="color:#64748b;">•</span>
                            <span style="color:#cbd5e1;">Model: <strong style="color:#c084fc;">${escapeHtml(activeModel.name)}</strong></span>
                        </div>
                        <div style="font-size:11px; color:#34d399; display:inline-flex; align-items:center; gap:4px; font-weight:600;">
                            <span>✓ Đã tải (${escapeHtml(activeModel.path)})</span>
                        </div>
                    </div>
                `;
            }

            // Populate SELECT with ONLY existing valid models
            if (modelSelect) {
                modelSelect.innerHTML = "";
                data.models.forEach(m => {
                    const opt = document.createElement("option");
                    opt.value = m.id;
                    opt.textContent = `✓ ${m.name} (~${m.size_mb} MB • ${m.min_ram} • ${m.speed})`;
                    if (m.id === activeModel.id) opt.selected = true;
                    modelSelect.appendChild(opt);
                });
            }

            if (validNote) {
                validNote.innerHTML = `<span style="color:#34d399; font-weight:600;">✓ Có ${data.total_valid_count} model hợp lệ</span>`;
            }

            if (btnRun) {
                btnRun.disabled = false;
                btnRun.style.opacity = "1";
                btnRun.style.cursor = "pointer";
            }
            if (btnRunText) {
                btnRunText.textContent = "🎙 Bắt Đầu Nhận Diện Phụ Đề Whisper";
            }

            // Close modal if it was open on prompt view
            const modal = document.getElementById("whisper-model-modal");
            const viewPrompt = document.getElementById("whisper-modal-view-prompt");
            if (modal && modal.style.display === "flex" && viewPrompt?.style.display === "block") {
                closeWhisperModal();
            }
        } else {
            // CHƯA CÓ MODEL NÀO HỢP LỆ TRONG DATA/models/
            if (statusContainer) {
                statusContainer.innerHTML = `
                    <div class="status-badge-locked">
                        <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:10px;">
                            <div>
                                <div style="font-weight:700; color:#fbbf24; font-size:13px; display:flex; align-items:center; gap:6px;">
                                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#fbbf24" stroke-width="2"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                                    <span>Whisper AI chưa sẵn sàng</span>
                                </div>
                                <div style="color:#cbd5e1; font-size:12px; margin-top:4px; line-height:1.4;">
                                    Chưa tìm thấy Whisper AI Model trong <code style="padding:2px 6px; background:#0b0e17; border-radius:4px; color:#c084fc; font-family:monospace; font-size:11px; border:1px solid rgba(168,85,247,0.2);">${escapeHtml(dirPath)}</code>. Chức năng Whisper đang bị tạm khóa.
                                </div>
                            </div>
                            <button class="btn btn-purple-gradient" id="btn-status-go-download" type="button" style="padding:6px 14px; font-size:12px;">
                                Đi đến tải Model
                            </button>
                        </div>
                    </div>
                `;
                document.getElementById("btn-status-go-download")?.addEventListener("click", () => {
                    openWhisperModal("downloader");
                });
            }

            if (modelSelect) {
                modelSelect.innerHTML = `<option value="" disabled selected>⚠ Chưa có model nào trong DATA/models/</option>`;
            }

            if (validNote) {
                validNote.innerHTML = `<span style="color:#fbbf24; font-weight:600;">⚠ Chưa có model hợp lệ</span>`;
            }

            if (btnRun) {
                btnRun.disabled = false;
                btnRun.style.opacity = "0.6";
                btnRun.style.cursor = "pointer";
            }
            if (btnRunText) {
                btnRunText.textContent = "⚠ Whisper AI chưa sẵn sàng (Bấm để mở popup)";
            }
        }
    }

    // RENDER SPECS LIST INSIDE DOWNLOADER MODAL (PER-MODEL INDEPENDENT UI)
    function renderWhisperSpecsList() {
        const listEl = document.getElementById("whisper-specs-list");
        const countTag = document.getElementById("modal-downloaded-count-badge") || document.getElementById("whisper-valid-count-tag");
        const unsupportedSec = document.getElementById("whisper-unsupported-section");

        if (!listEl) return;
        const validModels = currentWhisperModelsData?.models || [];
        const specs = (currentWhisperModelsData?.supported_specs && currentWhisperModelsData.supported_specs.length > 0)
            ? currentWhisperModelsData.supported_specs
            : WHISPER_SUPPORTED_SPECS;

        if (countTag) {
            countTag.textContent = `${validModels.length} / ${specs.length} model đã tải`;
        }

        listEl.innerHTML = "";
        specs.forEach(spec => {
            const id = spec.id;
            const state = modelDownloadStates[id] || { status: 'NOT_DOWNLOADED', progress: 0 };
            const card = document.createElement("div");

            let cardClass = "model-spec-card";
            if (state.status === "DOWNLOADED") cardClass += " downloaded";
            else if (state.status === "DOWNLOADING") cardClass += " downloading";
            else if (state.status === "ERROR") cardClass += " error";
            card.className = cardClass;
            card.id = `model-card-${id}`;

            let actionHtml = "";
            let progressHtml = "";
            let errorHtml = "";

            if (state.status === "DOWNLOADED") {
                // ĐÃ TẢI: Block trạng thái độc lập, KHÔNG render nút Tải xuống
                actionHtml = `
                    <div class="spec-badge-ready" id="badge-ready-${id}">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#34d399" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
                        <span>✓ ĐÃ TẢI</span>
                    </div>
                `;
            } else if (state.status === "DOWNLOADING") {
                // ĐANG TẢI: Button disabled + thanh tiến trình riêng của model này
                actionHtml = `
                    <button class="spec-btn-downloading" id="btn-dl-${id}" disabled>
                        <svg class="spin-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 2a10 10 0 0 1 10 10"/></svg>
                        <span>Đang tải...</span>
                    </button>
                `;
                progressHtml = `
                    <div class="model-spec-progress-box" id="prog-box-${id}">
                        <div class="model-spec-progress-header">
                            <span style="color:#c084fc; font-weight:600; font-size:11px;" id="prog-msg-${id}">${escapeHtml(state.message || 'Đang tải model...')}</span>
                            <span style="color:#ffffff; font-weight:700; font-size:11px;" id="prog-pct-${id}">${state.progress || 0}%</span>
                        </div>
                        <div class="model-spec-progress-bar-bg">
                            <div class="model-spec-progress-bar-fill" id="prog-bar-${id}" style="width: ${state.progress || 0}%;"></div>
                        </div>
                    </div>
                `;
            } else if (state.status === "ERROR") {
                // TẢI THẤT BẠI: Button THỬ LẠI (enabled) + box lỗi riêng
                actionHtml = `
                    <button class="spec-btn-retry" id="btn-dl-${id}" data-dl-model="${id}">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg>
                        <span>Thử lại (~${spec.size_mb} MB)</span>
                    </button>
                `;
                errorHtml = `
                    <div class="model-spec-error-box" id="err-box-${id}">
                        <div style="font-weight:700; color:#ef4444; display:flex; align-items:center; gap:4px;">
                            <span>⚠ TẢI THẤT BẠI:</span>
                        </div>
                        <div style="color:#fca5a5; margin-top:2px; font-size:11px; line-height:1.4;">
                            ${escapeHtml(state.error || 'Không thể tải model. Vui lòng thử lại.')}
                        </div>
                    </div>
                `;
            } else {
                // CHƯA TẢI: Button TẢI XUỐNG (enabled)
                actionHtml = `
                    <button class="spec-btn-download" id="btn-dl-${id}" data-dl-model="${id}">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>
                        <span>Tải (~${spec.size_mb} MB)</span>
                    </button>
                `;
            }

            card.innerHTML = `
                <div style="flex:1;">
                    <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
                        <span style="font-weight:700; font-size:13px; color:#ffffff;">${escapeHtml(spec.name || id)}</span>
                        ${spec.rec || spec.recommended ? `<span class="spec-badge-rec">KHUYÊN DÙNG</span>` : ""}
                    </div>
                    <div class="spec-meta">
                        <span>Dung lượng: <strong style="color:#cbd5e1;">~${spec.size_mb} MB</strong></span>
                        <span>•</span>
                        <span>Yêu cầu: <strong style="color:#cbd5e1;">${escapeHtml(spec.min_ram || '')}</strong></span>
                        <span>•</span>
                        <span>Tốc độ: <strong style="color:#cbd5e1;">${escapeHtml(spec.speed || '')}</strong></span>
                    </div>
                    <div style="font-size:11px; color:#94a3b8; margin-top:3px; line-height:1.4;">
                        ${escapeHtml(spec.description || spec.desc || "")}
                    </div>
                    ${progressHtml}
                    ${errorHtml}
                </div>
                <div style="display:flex; align-items:center;">
                    ${actionHtml}
                </div>
            `;
            listEl.appendChild(card);
        });

        // Gắn sự kiện click cho các nút Tải xuống / Thử lại
        listEl.querySelectorAll("[data-dl-model]").forEach(btn => {
            btn.addEventListener("click", () => {
                const modelId = btn.getAttribute("data-dl-model");
                startDownloadWhisperModel(modelId);
            });
        });

        // Hiển thị thông báo thư mục lạ nếu có
        if (unsupportedSec) {
            const unsupportedModels = currentWhisperModelsData?.unsupported_models || [];
            if (unsupportedModels.length > 0) {
                unsupportedSec.style.display = "block";
                unsupportedSec.innerHTML = `
                    <div style="font-weight:700; color:#94a3b8; font-size:12px; margin-bottom:4px;">
                        ℹ Thư mục lạ không thuộc Whisper (bị bỏ qua):
                    </div>
                    <div style="display:flex; flex-direction:column; gap:4px; font-size:11px; color:#94a3b8;">
                        ${unsupportedModels.map(u => `<div>• <strong>${escapeHtml(u.folder_name)}</strong>: ${escapeHtml(u.reason)}</div>`).join("")}
                    </div>
                `;
            } else {
                unsupportedSec.style.display = "none";
            }
        }
    }

    // FETCH / SCAN MODELS FROM BACKEND (SOURCE OF TRUTH)
    async function fetchWhisperModels(triggerPopupIfMissing = false, isScan = false) {
        try {
            const endpoint = isScan ? "/api/whisper/models/scan" : "/api/whisper/models";
            const res = await fetch(endpoint);
            const data = await res.json();
            currentWhisperModelsData = data;

            // Đồng bộ trạng thái từng model từ backend
            const validIds = new Set((data.models || []).map(m => m.id));
            const activeDl = data.active_downloads || {};
            const invalidMap = {};
            (data.invalid_models || []).forEach(inv => {
                if (inv.id) invalidMap[inv.id] = inv;
                if (inv.folder_name) invalidMap[inv.folder_name] = inv;
            });

            const specs = (data.supported_specs && data.supported_specs.length > 0)
                ? data.supported_specs
                : WHISPER_SUPPORTED_SPECS;

            specs.forEach(spec => {
                const id = spec.id;
                const curState = modelDownloadStates[id];

                if (validIds.has(id)) {
                    // Model đã tải thành công và hợp lệ
                    if (curState?.pollInterval) clearInterval(curState.pollInterval);
                    modelDownloadStates[id] = {
                        status: 'DOWNLOADED',
                        progress: 100,
                        message: 'Model đã sẵn sàng sử dụng',
                        error: null,
                        jobId: null,
                        pollInterval: null
                    };
                } else if (activeDl[id]) {
                    // Backend đang chạy tiến trình tải cho model này
                    const act = activeDl[id];
                    const existingJobId = curState?.jobId;
                    if (!curState || curState.status !== 'DOWNLOADING' || existingJobId !== act.job_id) {
                        modelDownloadStates[id] = {
                            status: 'DOWNLOADING',
                            progress: act.progress || 0,
                            message: act.message || 'Đang tải model...',
                            error: null,
                            jobId: act.job_id,
                            pollInterval: null
                        };
                        pollModelDownloadJob(id, act.job_id);
                    }
                } else if (curState?.status === 'DOWNLOADING') {
                    // Đang tải ở client, tiếp tục thăm dò
                } else if (curState?.status === 'ERROR') {
                    // Đang hiển thị lỗi ở client, giữ nguyên để thử lại
                } else if (invalidMap[id]) {
                    // Thư mục model bị hỏng/thiếu file
                    modelDownloadStates[id] = {
                        status: 'ERROR',
                        progress: 0,
                        message: null,
                        error: invalidMap[id].reason || 'Model bị lỗi hoặc thiếu file',
                        jobId: null,
                        pollInterval: null
                    };
                } else {
                    // Chưa tải
                    modelDownloadStates[id] = {
                        status: 'NOT_DOWNLOADED',
                        progress: 0,
                        message: null,
                        error: null,
                        jobId: null,
                        pollInterval: null
                    };
                }
            });

            renderWhisperModelStatus(data);

            if (!data.available) {
                // Chưa có model nào hợp lệ trong DATA/models/
                if (triggerPopupIfMissing) {
                    openWhisperModal("prompt");
                }
            } else {
                // Đã có ít nhất 1 model hợp lệ -> Cho phép đóng popup
                const readyCloseBtn = document.getElementById("btn-modal-ready-close");
                if (readyCloseBtn) readyCloseBtn.style.display = "inline-flex";
            }

            // Nếu view downloader đang mở thì render lại
            const viewDownloader = document.getElementById("whisper-modal-view-downloader");
            if (viewDownloader && viewDownloader.style.display === "block") {
                renderWhisperSpecsList();
            }
        } catch (err) {
            console.error("Lỗi quét Whisper models:", err);
        }
    }

    // DOWNLOAD MODEL HANDLER (PER-MODEL INDEPENDENT)
    async function startDownloadWhisperModel(modelId) {
        if (!modelId) return;

        // Nếu model này đang tải, từ chối tải trùng
        if (modelDownloadStates[modelId]?.status === 'DOWNLOADING') {
            return;
        }

        // Đặt trạng thái RIÊNG của model này thành DOWNLOADING
        modelDownloadStates[modelId] = {
            status: 'DOWNLOADING',
            progress: 2,
            message: `Bắt đầu kết nối tải model ${modelId}...`,
            error: null,
            jobId: null,
            pollInterval: null
        };

        // Render lại danh sách -> CHỈ modelId này chuyển sang Đang tải..., các model khác giữ nguyên
        renderWhisperSpecsList();

        try {
            const res = await fetch("/api/whisper/models/download", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ model_id: modelId })
            });
            const resData = await res.json();
            if (!res.ok) {
                throw new Error(resData.detail || "Không thể khởi tạo tiến trình tải.");
            }

            const jobId = resData.job_id;
            if (modelDownloadStates[modelId]) {
                modelDownloadStates[modelId].jobId = jobId;
                pollModelDownloadJob(modelId, jobId);
            }
        } catch (err) {
            if (modelDownloadStates[modelId]) {
                modelDownloadStates[modelId] = {
                    status: 'ERROR',
                    error: err.message || 'Lỗi khi gửi yêu cầu tải model',
                    progress: 0,
                    jobId: null,
                    pollInterval: null
                };
            }
            renderWhisperSpecsList();
        }
    }

    // THĂM DÒ TIẾN TRÌNH TẢI RIÊNG CHO TỪNG MODEL
    function pollModelDownloadJob(modelId, jobId) {
        if (!modelId || !jobId) return;

        if (modelDownloadStates[modelId]?.pollInterval) {
            clearInterval(modelDownloadStates[modelId].pollInterval);
        }

        const interval = setInterval(async () => {
            try {
                const jRes = await fetch(`/api/jobs/${jobId}`);
                if (!jRes.ok) return;
                const job = await jRes.json();

                if (job.status === "completed") {
                    clearInterval(interval);
                    if (modelDownloadStates[modelId]) {
                        modelDownloadStates[modelId] = {
                            status: 'DOWNLOADED',
                            progress: 100,
                            message: `✓ Đã tải xong model ${modelId}!`,
                            error: null,
                            jobId: null,
                            pollInterval: null
                        };
                    }
                    // Quét lại models từ backend và refresh UI
                    await fetchWhisperModels(false, true);
                    renderWhisperSpecsList();
                } else if (job.status === "failed") {
                    clearInterval(interval);
                    if (modelDownloadStates[modelId]) {
                        modelDownloadStates[modelId] = {
                            status: 'ERROR',
                            error: job.error || job.message || "Tải model thất bại.",
                            progress: job.progress || 0,
                            jobId: null,
                            pollInterval: null
                        };
                    }
                    renderWhisperSpecsList();
                } else {
                    // Đang tải (processing / queued)
                    const pct = job.progress || 0;
                    const msg = job.message || `Đang tải model ${modelId}...`;
                    if (modelDownloadStates[modelId]) {
                        modelDownloadStates[modelId].progress = pct;
                        modelDownloadStates[modelId].message = msg;
                    }

                    // Cập nhật mượt mà trực tiếp DOM của model này
                    const msgEl = document.getElementById(`prog-msg-${modelId}`);
                    const pctEl = document.getElementById(`prog-pct-${modelId}`);
                    const barEl = document.getElementById(`prog-bar-${modelId}`);
                    if (msgEl) msgEl.textContent = msg;
                    if (pctEl) pctEl.textContent = `${pct}%`;
                    if (barEl) barEl.style.width = `${pct}%`;
                }
            } catch (e) {
                console.error(`Lỗi thăm dò tiến trình download model ${modelId}:`, e);
            }
        }, 800);

        if (modelDownloadStates[modelId]) {
            modelDownloadStates[modelId].pollInterval = interval;
        }
    }

    // MODAL BUTTON LISTENERS
    document.getElementById("btn-open-whisper-modal")?.addEventListener("click", () => {
        openWhisperModal("downloader");
    });
    document.getElementById("btn-modal-close")?.addEventListener("click", closeWhisperModal);
    document.getElementById("btn-modal-prompt-close")?.addEventListener("click", closeWhisperModal);
    document.getElementById("btn-modal-ready-close")?.addEventListener("click", closeWhisperModal);
    document.getElementById("btn-modal-go-download")?.addEventListener("click", () => {
        openWhisperModal("downloader");
    });
    document.getElementById("btn-modal-switch-download")?.addEventListener("click", () => {
        openWhisperModal("downloader");
    });
    document.getElementById("btn-modal-back-to-prompt")?.addEventListener("click", () => {
        openWhisperModal("prompt");
    });
    document.getElementById("btn-modal-refresh-models")?.addEventListener("click", () => {
        fetchWhisperModels(false, true);
    });
    document.getElementById("btn-modal-refresh")?.addEventListener("click", () => {
        fetchWhisperModels(false, true);
    });

    // Close on backdrop click (Section XIX: Click outside closes popup)
    document.getElementById("whisper-model-modal")?.addEventListener("click", (e) => {
        if (e.target.id === "whisper-model-modal") {
            closeWhisperModal();
        }
    });

    // Close button (X) in header
    document.getElementById("btn-modal-close")?.addEventListener("click", closeWhisperModal);

    // RUN WHISPER TRANSCRIBE BUTTON
    document.getElementById("btn-run-whisper")?.addEventListener("click", async () => {
        if (!requireWhisper()) {
            return;
        }

        if (!whisperFileObj) {
            alert("Vui lòng chọn file âm thanh hoặc video!");
            return;
        }

        const selectedModel = document.getElementById("whisper-model").value;
        if (!selectedModel) {
            alert("Vui lòng chọn một model Whisper hợp lệ đã tải!");
            return;
        }

        const formData = new FormData();
        formData.append("file", whisperFileObj);
        formData.append("model_size", selectedModel);
        formData.append("max_words", document.getElementById("whisper-max-words").value);
        formData.append("max_duration", document.getElementById("whisper-max-dur").value);

        const progContainer = document.getElementById("whisper-progress");
        const resBox = document.getElementById("whisper-result-box");
        if (resBox) resBox.style.display = "none";

        try {
            const res = await fetch("/api/whisper/transcribe", { method: "POST", body: formData });
            const data = await res.json();
            if (!res.ok) {
                throw new Error(data.detail || "Không thể khởi tạo phiên nhận diện giọng nói.");
            }
            if (data.job_id) {
                pollJob(data.job_id, progContainer, (job) => {
                    if (resBox) resBox.style.display = "block";
                    const result = job.result || {};
                    const stats = result.stats || {};
                    const statsEl = document.getElementById("whisper-stats");
                    if (statsEl) {
                        statsEl.innerHTML = `
                            <span>${result.segments_count || 0} câu • Lọc Watermark: ${stats.watermark_filtered || 0} • Lọc Anh: ${stats.english_filtered || 0} • Lọc Thở/Cười: ${(stats.sigh_removed || 0) + (stats.laugh_removed || 0)}</span>
                        `;
                    }
                    const textEl = document.getElementById("whisper-preview-text");
                    if (textEl) textEl.textContent = result.content || "";

                    const btnDl = document.getElementById("btn-download-whisper-srt");
                    if (btnDl) {
                        btnDl.onclick = () => { window.location.href = job.download_url; };
                    }
                    const btnSend = document.getElementById("btn-send-whisper-to-editor");
                    if (btnSend) {
                        btnSend.onclick = () => {
                            if (srtEditor) {
                                srtEditor.value = result.content || "";
                                updateSrtStats();
                            }
                            switchMainTab("srt", "srt-editor");
                            logSrt("Đã nạp phụ đề từ Whisper vào Trình Sửa Phụ Đề.", "success");
                        };
                    }
                });
            }
        } catch (err) {
            alert(`Lỗi khởi tạo: ${err.message}`);
        }
    });

    // Run initial scan in background on load
    fetchWhisperModels(false);


    // -------------------------------------------------------------
    // 5. AUDIO STUDIO: AUDIO MERGE
    // -------------------------------------------------------------
    let audioFileList = [];
    const audioDrop = document.getElementById("audio-dropzone");
    const audioInput = document.getElementById("audio-files-input");
    const audioListEl = document.getElementById("audio-file-list");
    const audioCountEl = document.getElementById("audio-count");

    audioDrop?.addEventListener("click", () => audioInput.click());
    audioInput?.addEventListener("change", (e) => {
        for (const file of e.target.files) {
            audioFileList.push(file);
        }
        renderAudioList();
    });

    document.getElementById("btn-clear-audio-list")?.addEventListener("click", () => {
        audioFileList = [];
        renderAudioList();
    });

    function renderAudioList() {
        if (!audioListEl) return;
        audioListEl.innerHTML = "";
        if (audioCountEl) audioCountEl.textContent = audioFileList.length;
        audioFileList.forEach((f, idx) => {
            const item = document.createElement("div");
            item.className = "file-list-item";
            item.innerHTML = `
                <div style="display:flex; align-items:center; gap:8px;">
                    <span style="color:#64748b; font-family:var(--font-mono);">${idx + 1}.</span>
                    <span>${f.name}</span>
                </div>
                <div style="display:flex; align-items:center; gap:8px;">
                    <span style="color:#64748b; font-size:11px;">${(f.size / 1024 / 1024).toFixed(2)} MB</span>
                    <button class="file-list-remove" data-idx="${idx}">${ICONS.trash}</button>
                </div>
            `;
            item.querySelector(".file-list-remove")?.addEventListener("click", () => {
                audioFileList.splice(idx, 1);
                renderAudioList();
            });
            audioListEl.appendChild(item);
        });
    }

    document.getElementById("btn-run-audio-merge")?.addEventListener("click", async () => {
        if (audioFileList.length < 2) {
            alert("Vui lòng chọn ít nhất 2 file âm thanh!");
            return;
        }

        const formData = new FormData();
        audioFileList.forEach(f => formData.append("files", f));
        formData.append("output_filename", document.getElementById("audio-output-name").value || "combined.mp3");
        formData.append("sort_alphabetical", document.getElementById("audio-sort-alpha").checked);

        const prog = document.getElementById("audio-job-progress");
        try {
            const res = await fetch("/api/audio/merge", { method: "POST", body: formData });
            const data = await res.json();
            if (data.job_id) {
                pollJob(data.job_id, prog);
            }
        } catch (err) {
            alert(`Lỗi: ${err.message}`);
        }
    });


    // -------------------------------------------------------------
    // 6. VIDEO STUDIO: VIDEO CUT
    // -------------------------------------------------------------
    let videoCutFileObj = null;
    const videoCutDrop = document.getElementById("video-cut-dropzone");
    const videoCutInput = document.getElementById("video-cut-file");
    const videoCutBadge = document.getElementById("video-cut-selected");

    videoCutDrop?.addEventListener("click", () => videoCutInput.click());
    videoCutInput?.addEventListener("change", (e) => {
        videoCutFileObj = e.target.files[0];
        if (videoCutFileObj) {
            videoCutBadge.style.display = "inline-flex";
            videoCutBadge.textContent = `Video: ${videoCutFileObj.name} (${(videoCutFileObj.size / 1024 / 1024).toFixed(1)} MB)`;
        }
    });

    document.getElementById("btn-run-video-cut")?.addEventListener("click", async () => {
        if (!videoCutFileObj) {
            alert("Vui lòng chọn file video!");
            return;
        }

        const formData = new FormData();
        formData.append("file", videoCutFileObj);
        formData.append("segment_minutes", document.getElementById("video-cut-minutes").value || 5);
        formData.append("mode", document.getElementById("video-cut-mode").value || "copy");

        const prog = document.getElementById("video-cut-progress");
        try {
            const res = await fetch("/api/video/cut", { method: "POST", body: formData });
            const data = await res.json();
            if (data.job_id) {
                pollJob(data.job_id, prog);
            }
        } catch (err) {
            alert(`Lỗi: ${err.message}`);
        }
    });


    // -------------------------------------------------------------
    // 7. VIDEO STUDIO: VIDEO MERGE & CAPTION
    // -------------------------------------------------------------
    let videoMergeFiles = [];
    const videoMergeDrop = document.getElementById("video-merge-dropzone");
    const videoMergeInput = document.getElementById("video-merge-files");
    const videoMergeList = document.getElementById("video-merge-list");
    const captionCheckbox = document.getElementById("video-enable-caption");
    const captionBox = document.getElementById("caption-settings");

    videoMergeDrop?.addEventListener("click", () => videoMergeInput.click());
    videoMergeInput?.addEventListener("change", (e) => {
        for (const f of e.target.files) videoMergeFiles.push(f);
        renderVideoMergeList();
    });

    captionCheckbox?.addEventListener("change", (e) => {
        if (captionBox) captionBox.style.display = e.target.checked ? "block" : "none";
    });

    function renderVideoMergeList() {
        if (!videoMergeList) return;
        videoMergeList.innerHTML = "";
        videoMergeFiles.forEach((f, idx) => {
            const item = document.createElement("div");
            item.className = "file-list-item";
            item.innerHTML = `
                <div style="display:flex; align-items:center; gap:8px;">
                    <span style="color:#64748b; font-family:var(--font-mono);">${idx + 1}.</span>
                    <span>${f.name}</span>
                </div>
                <div style="display:flex; align-items:center; gap:8px;">
                    <span style="color:#64748b; font-size:11px;">${(f.size / 1024 / 1024).toFixed(1)} MB</span>
                    <button class="file-list-remove" data-idx="${idx}">${ICONS.trash}</button>
                </div>
            `;
            item.querySelector(".file-list-remove")?.addEventListener("click", () => {
                videoMergeFiles.splice(idx, 1);
                renderVideoMergeList();
            });
            videoMergeList.appendChild(item);
        });
    }

    document.getElementById("btn-run-video-merge")?.addEventListener("click", async () => {
        if (videoMergeFiles.length < 2) {
            alert("Vui lòng chọn ít nhất 2 video để ghép!");
            return;
        }

        const formData = new FormData();
        videoMergeFiles.forEach(f => formData.append("files", f));
        formData.append("output_filename", document.getElementById("video-merge-output").value || "merged_video.mp4");
        formData.append("mode", document.getElementById("video-merge-mode").value);

        if (captionCheckbox?.checked) {
            formData.append("caption", document.getElementById("video-caption-text").value);
            formData.append("font_size", document.getElementById("video-caption-size").value);
            formData.append("font_color", document.getElementById("video-caption-color").value);
            formData.append("caption_position", document.getElementById("video-caption-pos").value);
        }

        const prog = document.getElementById("video-merge-progress");
        try {
            const res = await fetch("/api/video/merge", { method: "POST", body: formData });
            const data = await res.json();
            if (data.job_id) {
                pollJob(data.job_id, prog);
            }
        } catch (err) {
            alert(`Lỗi: ${err.message}`);
        }
    });


    // -------------------------------------------------------------
    // 8. VIDEO STUDIO: VIDEO COMPRESS
    // -------------------------------------------------------------
    let videoCompressFile = null;
    const videoCompDrop = document.getElementById("video-compress-dropzone");
    const videoCompInput = document.getElementById("video-compress-file");
    const videoCompBadge = document.getElementById("video-compress-selected");

    videoCompDrop?.addEventListener("click", () => videoCompInput.click());
    videoCompInput?.addEventListener("change", (e) => {
        videoCompressFile = e.target.files[0];
        if (videoCompressFile) {
            videoCompBadge.style.display = "inline-flex";
            videoCompBadge.textContent = `Video: ${videoCompressFile.name} (${(videoCompressFile.size / 1024 / 1024).toFixed(1)} MB)`;
        }
    });

    document.getElementById("btn-run-video-compress")?.addEventListener("click", async () => {
        if (!videoCompressFile) {
            alert("Vui lòng chọn video cần nén!");
            return;
        }

        const formData = new FormData();
        formData.append("file", videoCompressFile);
        formData.append("crf", document.getElementById("video-compress-crf").value);
        formData.append("preset", document.getElementById("video-compress-preset").value);
        formData.append("codec", document.getElementById("video-compress-codec").value);

        const prog = document.getElementById("video-compress-progress");
        try {
            const res = await fetch("/api/video/compress", { method: "POST", body: formData });
            const data = await res.json();
            if (data.job_id) {
                pollJob(data.job_id, prog);
            }
        } catch (err) {
            alert(`Lỗi: ${err.message}`);
        }
    });


    // -------------------------------------------------------------
    // 9. SETTINGS & HEALTH CHECK & AUTO-UPDATE
    // -------------------------------------------------------------
    async function fetchAppVersion() {
        const verEl = document.getElementById("lbl-app-version");
        try {
            const res = await fetch("/api/version");
            if (!res.ok) return;
            const data = await res.json();
            if (data.version && verEl) {
                verEl.textContent = `v${data.version.replace(/^v/, "")}`;
            }
        } catch (e) {
            // Ignore offline/local failure
        }
    }

    async function checkAppUpdate() {
        const btn = document.getElementById("btn-check-update");
        const btnText = document.getElementById("btn-check-update-text");
        const box = document.getElementById("update-status-box");
        if (!btn || !box) return;

        btn.disabled = true;
        if (btnText) btnText.textContent = "Đang kiểm tra...";
        box.style.display = "block";
        box.style.background = "#141825";
        box.style.border = "1px solid #232b3f";
        box.style.color = "#94a3b8";
        box.innerHTML = `<div style="display:flex; align-items:center; gap:8px;">${ICONS.loader} <span>Đang kết nối GitHub và kiểm tra Update.txt...</span></div>`;

        try {
            const res = await fetch("/api/update/check");
            if (!res.ok) throw new Error("Không thể kết nối API cập nhật.");
            const data = await res.json();

            if (data.has_update) {
                box.style.background = "rgba(245, 158, 11, 0.08)";
                box.style.border = "1px solid rgba(245, 158, 11, 0.3)";
                box.style.color = "#fbbf24";
                box.innerHTML = `
                    <div style="font-weight:700; font-size:13px; margin-bottom:4px; display:flex; align-items:center; gap:6px;">
                        <span>🔔 Phát hiện phiên bản mới: v${data.latest_version.replace(/^v/, "")}</span>
                        <span style="font-size:11px; color:#94a3b8; font-weight:normal;">(Hiện tại: v${data.current_version.replace(/^v/, "")})</span>
                    </div>
                    <div style="color:#cbd5e1; margin-top:4px;">
                        Để cập nhật, vui lòng khởi động lại bằng lệnh <code>python START.py</code> (hoặc chạy file <code>START.bat</code>). KAGEVIETSUB sẽ tự động tải, xác thực SHA256, sao lưu và cập nhật an toàn.
                    </div>
                `;
            } else {
                box.style.background = "rgba(16, 185, 129, 0.08)";
                box.style.border = "1px solid rgba(16, 185, 129, 0.3)";
                box.style.color = "#34d399";
                box.innerHTML = `
                    <div style="font-weight:600; display:flex; align-items:center; gap:6px;">
                        ${ICONS.checkCircle}
                        <span>Bạn đang sử dụng phiên bản mới nhất (v${data.current_version.replace(/^v/, "")}).</span>
                    </div>
                `;
            }
        } catch (err) {
            box.style.background = "rgba(244, 63, 94, 0.08)";
            box.style.border = "1px solid rgba(244, 63, 94, 0.3)";
            box.style.color = "#fb7185";
            box.innerHTML = `
                <div style="display:flex; align-items:center; gap:6px;">
                    ${ICONS.alertCircle}
                    <span>Lỗi kiểm tra cập nhật: ${err.message}</span>
                </div>
            `;
        } finally {
            btn.disabled = false;
            if (btnText) btnText.textContent = "Kiểm tra cập nhật";
        }
    }

    document.getElementById("btn-check-update")?.addEventListener("click", checkAppUpdate);

    async function checkHealth() {
        const sysEl = document.getElementById("health-sys-info");
        const ffmpegEl = document.getElementById("health-ffmpeg-info");
        const dataEl = document.getElementById("health-data-info");

        if (sysEl) sysEl.innerHTML = `<div style="color:#94a3b8; font-size:11px;">Đang kiểm tra...</div>`;

        try {
            const res = await fetch("/api/health");
            if (!res.ok) throw new Error("Máy chủ phản hồi lỗi");
            const data = await res.json();

            if (sysEl) {
                sysEl.innerHTML = `
                    <div class="status-tile-row"><span class="status-tile-label">Hệ điều hành:</span> <span>${data.system?.platform || "Linux"}</span></div>
                    <div class="status-tile-row"><span class="status-tile-label">Python:</span> <span>${data.system?.python_version || "3.10"}</span></div>
                    <div class="status-tile-row"><span class="status-tile-label">Trạng thái:</span> <span style="color:#34d399; font-weight:600;">Sẵn sàng</span></div>
                `;
            }

            if (ffmpegEl) {
                ffmpegEl.innerHTML = `
                    <div class="status-tile-row"><span class="status-tile-label">FFmpeg:</span> <span style="color:#34d399;">${data.components?.ffmpeg?.status}</span></div>
                    <div class="status-tile-row"><span class="status-tile-label">FFprobe:</span> <span style="color:#34d399;">${data.components?.ffprobe?.status}</span></div>
                    <div class="status-tile-row"><span class="status-tile-label">GPU NVENC:</span> <span>${data.components?.nvenc_gpu?.status}</span></div>
                `;
            }

            if (dataEl) {
                dataEl.innerHTML = `
                    <div class="status-tile-row"><span class="status-tile-label">Thư mục DATA:</span> <span style="font-family:var(--font-mono); font-size:11px;">${data.directories?.DATA}</span></div>
                    <div class="status-tile-row"><span class="status-tile-label">File tạm (temp):</span> <span>${data.directories?.temp_files} files</span></div>
                    <div class="status-tile-row"><span class="status-tile-label">File xuất (out):</span> <span>${data.directories?.output_files} files</span></div>
                `;
            }
        } catch (err) {
            if (sysEl) sysEl.innerHTML = `<div style="color:#fb7185; font-size:11px;">Không kết nối được server Python: ${err.message}</div>`;
        }
    }

    document.getElementById("btn-refresh-health")?.addEventListener("click", checkHealth);

    document.getElementById("btn-cleanup-temp")?.addEventListener("click", async () => {
        try {
            const res = await fetch("/api/cleanup", { method: "POST" });
            const data = await res.json();
            alert(`Đã dọn dẹp ${data.cleaned_files || 0} file tạm thời (giải phóng ${data.freed_mb || 0} MB bộ nhớ).`);
            checkHealth();
        } catch (err) {
            alert(`Lỗi dọn dẹp: ${err.message}`);
        }
    });

    // ==============================================================================
    // TTS STUDIO [BETA] CONTROLLER (CapCut Engine • Real Multithreading • Timeline)
    // ==============================================================================
    let ttsCurrentJobId = null;
    let ttsCurrentJobStatus = "idle";
    let ttsPollTimer = null;
    let ttsSrtContent = "";
    let ttsSubtitlesList = [];
    let ttsFilterMode = "all"; // 'all' | 'error'
    let currentPreviewAudio = null;
    let isMergingActive = false;
    let ttsMergePopupShown = false;
    let ttsLastRevision = 0;

    function getSubStatusBadgeHTML(sub) {
        if (sub.status === "DONE" || sub.status === "READY_FOR_MERGE" || sub.status === "COMPLETED") {
            const durStr = sub.duration ? `${sub.duration.toFixed(1)}s` : "";
            return `<span class="tts-badge tts-badge-done">${ICONS.check} Đã tạo ${durStr}</span>`;
        } else if (sub.status === "TTS_PROCESSING") {
            return `<span class="tts-badge tts-badge-generating"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="animate-spin-slow"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg> Đang tạo TTS 1.0x...</span>`;
        } else if (sub.status === "TTS_COMPLETED") {
            return `<span class="tts-badge tts-badge-generating"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="animate-spin-slow"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg> Chờ tăng tốc...</span>`;
        } else if (sub.status === "SPEED_PROCESSING") {
            return `<span class="tts-badge tts-badge-generating"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="animate-spin-slow"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg> Đang tăng tốc...</span>`;
        } else if (sub.status === "RETRYING") {
            const passNum = sub.retry_count || 1;
            return `<span class="tts-badge" style="background:rgba(234,179,8,0.2); color:#facc15; border:1px solid rgba(234,179,8,0.4);"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="animate-spin-slow"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg> 🔄 Đang retry (${passNum}/3)...</span>`;
        } else if (sub.status === "GENERATING") {
            return `<span class="tts-badge tts-badge-generating"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="animate-spin-slow"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg> Đang tạo...</span>`;
        } else if (sub.status === "FAILED") {
            return `<span class="tts-badge" style="background:rgba(245,158,11,0.2); color:#fbbf24; border:1px solid rgba(245,158,11,0.4);" title="${escapeHtml(sub.error || 'Đang chờ retry sau khi hết lượt chính')}">⚠️ Chờ retry</span>`;
        } else if (sub.status === "FINAL_FAILED" || sub.status === "ERROR") {
            return `<span class="tts-badge tts-badge-error" title="${escapeHtml(sub.error || 'Lỗi không thể tạo audio sau 3 lần thử')}">❌ Lỗi (đã thử 3/3)</span>`;
        } else {
            return `<span class="tts-badge tts-badge-pending">⏳ Chờ tạo</span>`;
        }
    }

    function getSubActionButtonHTML(sub) {
        if (sub.status === "DONE" || sub.status === "READY_FOR_MERGE" || sub.status === "COMPLETED") {
            return `<button type="button" class="btn-tts-preview-sub" data-sub-idx="${sub.index}">▶ Nghe thử</button>`;
        } else if (sub.status === "ERROR" || sub.status === "FAILED" || sub.status === "FINAL_FAILED") {
            return `<button type="button" class="btn-tts-retry-sub" data-sub-idx="${sub.index}">Thử lại</button>`;
        }
        return "";
    }

    function renderSingleSubItemHTML(sub) {
        const itemClass = sub.status ? sub.status.toLowerCase() : "pending";
        const statusBadge = getSubStatusBadgeHTML(sub);
        const actionBtn = getSubActionButtonHTML(sub);

        return `
            <div id="tts-sub-item-${sub.index}" class="tts-sub-item ${itemClass}" data-sub-idx="${sub.index}" data-sub-status="${sub.status || 'PENDING'}">
                <div class="tts-sub-item-header">
                    <div style="display:flex; align-items:center; gap:6px;">
                        <span class="tts-sub-idx">#${String(sub.index).padStart(3, "0")}</span>
                        <span class="tts-sub-time">${sub.start}</span>
                    </div>
                    <div class="tts-sub-status" id="tts-sub-status-${sub.index}">${statusBadge}</div>
                </div>
                <div class="tts-sub-text">${escapeHtml(sub.text)}</div>
                <div class="tts-sub-actions-row" id="tts-sub-action-${sub.index}" style="${actionBtn ? '' : 'display:none;'}">
                    <span></span>${actionBtn}
                </div>
            </div>
        `;
    }

    let ttsLastRenderedCount = 0;
    let ttsLastFilterMode = "all";

    function renderTTSSubtitlesList(subs, forceFull = false) {
        const container = document.getElementById("tts-subtitle-items");
        if (!container) return;

        let filtered = subs;
        if (ttsFilterMode === "error") {
            filtered = subs.filter(s => s.status === "ERROR" || s.status === "FAILED" || s.status === "FINAL_FAILED" || s.status === "RETRYING");
        }

        if (filtered.length === 0) {
            container.innerHTML = `<div style="padding:16px; text-align:center; color:#64748b; font-size:12px;">Không có câu phụ đề nào để hiển thị.</div>`;
            ttsLastRenderedCount = 0;
            return;
        }

        container.innerHTML = filtered.map(sub => renderSingleSubItemHTML(sub)).join("");
        ttsLastRenderedCount = filtered.length;
        ttsLastFilterMode = ttsFilterMode;
    }

    // Cập nhật DOM siêu nhẹ, không tạo lại toàn bộ 1000 thẻ, giúp UI mượt mà 60fps
    function updateTTSSubtitlesDOM(subs) {
        const container = document.getElementById("tts-subtitle-items");
        if (!container) return;

        // Nếu chuyển đổi filter hoặc lần đầu render -> full render
        if (ttsLastFilterMode !== ttsFilterMode || ttsLastRenderedCount === 0) {
            renderTTSSubtitlesList(subs);
            return;
        }

        for (const sub of subs) {
            const el = document.getElementById(`tts-sub-item-${sub.index}`);
            if (!el) continue;

            const prevStatus = el.getAttribute("data-sub-status");
            if (prevStatus !== sub.status) {
                el.setAttribute("data-sub-status", sub.status || "PENDING");
                el.className = `tts-sub-item ${(sub.status || 'pending').toLowerCase()}`;

                const statusEl = document.getElementById(`tts-sub-status-${sub.index}`);
                if (statusEl) statusEl.innerHTML = getSubStatusBadgeHTML(sub);

                const actionEl = document.getElementById(`tts-sub-action-${sub.index}`);
                if (actionEl) {
                    const btnHtml = getSubActionButtonHTML(sub);
                    if (btnHtml) {
                        actionEl.style.display = "flex";
                        actionEl.innerHTML = `<span></span>${btnHtml}`;
                    } else {
                        actionEl.style.display = "none";
                        actionEl.innerHTML = "";
                    }
                }
            }
        }
    }

    let activePreviewButton = null;

    function playSubPreview(idx, btnElement = null) {
        if (!ttsCurrentJobId) return;

        if (currentPreviewAudio) {
            currentPreviewAudio.pause();
            currentPreviewAudio = null;
            if (activePreviewButton) {
                activePreviewButton.textContent = "▶ Nghe thử";
                activePreviewButton.disabled = false;
                activePreviewButton = null;
            }
        }

        const audioUrl = `/api/tts/preview/${ttsCurrentJobId}/${idx}?t=${Date.now()}`;
        if (btnElement) {
            activePreviewButton = btnElement;
            btnElement.textContent = "🔊 Đang phát...";
        }

        currentPreviewAudio = new Audio(audioUrl);
        currentPreviewAudio.onended = () => {
            if (activePreviewButton) {
                activePreviewButton.textContent = "▶ Nghe thử";
                activePreviewButton = null;
            }
        };
        currentPreviewAudio.onerror = (err) => {
            if (activePreviewButton) {
                activePreviewButton.textContent = "▶ Nghe thử";
                activePreviewButton = null;
            }
            alert(`Không thể nghe thử câu #${idx}. Hãy đảm bảo file đã được tạo.`);
        };
        currentPreviewAudio.play().catch(e => {
            if (activePreviewButton) {
                activePreviewButton.textContent = "▶ Nghe thử";
                activePreviewButton = null;
            }
        });
    }

    async function retrySingleTTSSubtitle(idx) {
        if (!ttsCurrentJobId) {
            alert("Chưa có job TTS đang chạy.");
            return;
        }

        const voice = document.getElementById("tts-voice-select")?.value || "BV421_vivn_streaming";
        const speed = parseFloat(document.getElementById("tts-speed-select")?.value || 1.0);

        try {
            const sub = ttsSubtitlesList.find(s => s.index === idx);
            if (sub) {
                sub.status = "GENERATING";
                renderTTSSubtitlesList(ttsSubtitlesList);
            }

            const res = await fetch("/api/tts/retry", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    job_id: ttsCurrentJobId,
                    subtitle_index: idx,
                    voice: voice,
                    speed: speed
                })
            });

            const data = await res.json();
            if (!res.ok) throw new Error(data.detail || "Thử lại thất bại");

            pollTTSJob(ttsCurrentJobId);
        } catch (err) {
            alert(`Lỗi khi thử lại câu ${idx}: ${err.message}`);
            pollTTSJob(ttsCurrentJobId);
        }
    }

    async function fetchTTSVoices() {
        const select = document.getElementById("tts-voice-select");
        if (!select) return;

        try {
            const res = await fetch("/api/tts/voices");
            if (!res.ok) throw new Error("Không thể tải danh sách giọng");
            const data = await res.json();
            const voices = data.voices || [];

            if (voices.length === 0) {
                select.innerHTML = `<option value="BV421_vivn_streaming">Giọng Nữ Việt Mặc Định (BV421_vivn_streaming)</option>`;
                return;
            }

            select.innerHTML = voices.map(v => {
                const isSelected = (v.voice_type === "BV421_vivn_streaming" || v.voice_type.includes("BV421")) ? "selected" : "";
                const tag = v.is_vip ? " [VIP]" : "";
                return `<option value="${escapeHtml(v.voice_type)}" data-resource-id="${escapeHtml(v.resource_id || '')}" ${isSelected}>
                    ${escapeHtml(v.name || v.voice_type)}${tag} (${escapeHtml(v.voice_type)})
                </option>`;
            }).join("");

        } catch (err) {
            console.error("Lỗi fetch giọng TTS:", err);
            select.innerHTML = `
                <option value="BV421_vivn_streaming" selected>Cô Gái Miền Bắc (BV421_vivn_streaming)</option>
                <option value="BV422_vivn_streaming">Chàng Trai Miền Bắc (BV422_vivn_streaming)</option>
                <option value="BV423_vivn_streaming">Cô Gái Sài Gòn (BV423_vivn_streaming)</option>
                <option value="BV424_vivn_streaming">Chàng Trai Sài Gòn (BV424_vivn_streaming)</option>
            `;
        }
    }

    async function parseAndLoadTTS_SRT(rawContent, filename = "phu_de.srt") {
        if (!rawContent || !rawContent.trim()) {
            alert("Nội dung SRT rỗng.");
            return;
        }

        const badge = document.getElementById("tts-selected-file-badge");
        if (badge) {
            badge.style.display = "flex";
            badge.innerHTML = `<span>⏳ Đang phân tích file <strong>${escapeHtml(filename)}</strong>...</span>`;
        }

        try {
            const res = await fetch("/api/tts/parse-srt", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ srt_content: rawContent })
            });

            const data = await res.json();
            if (!res.ok) throw new Error(data.detail || "Không thể phân tích file SRT");

            ttsSrtContent = rawContent;
            ttsSubtitlesList = data.subtitles || [];

            if (badge) {
                badge.innerHTML = `
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/></svg>
                    <span>Đã nạp <strong>${escapeHtml(filename)}</strong> (${data.total || ttsSubtitlesList.length} câu)</span>
                `;
            }

            // Hiển thị khung tiến trình và danh sách câu
            const progContainer = document.getElementById("tts-progress-container");
            if (progContainer) progContainer.style.display = "block";

            const statTotal = document.getElementById("tts-stat-total");
            if (statTotal) statTotal.textContent = data.total || ttsSubtitlesList.length;
            const statDone = document.getElementById("tts-stat-done");
            if (statDone) statDone.textContent = "0";
            const statFailed = document.getElementById("tts-stat-failed");
            if (statFailed) statFailed.textContent = "0";
            const statRem = document.getElementById("tts-stat-remaining");
            if (statRem) statRem.textContent = data.total || ttsSubtitlesList.length;
            const progPct = document.getElementById("tts-progress-percent");
            if (progPct) progPct.textContent = "0%";
            const progBar = document.getElementById("tts-progress-bar-fill");
            if (progBar) progBar.style.width = "0%";

            const banner = document.getElementById("tts-message-banner");
            if (banner) {
                banner.className = "status-toast info";
                banner.textContent = `Đã phân tích thành công ${data.total || ttsSubtitlesList.length} câu phụ đề. Sẵn sàng tạo giọng đọc.`;
            }

            renderTTSSubtitlesList(ttsSubtitlesList, true);

            // Tự động gợi ý tên file xuất theo tên SRT
            const nameInput = document.getElementById("tts-output-filename");
            if (nameInput && filename) {
                const base = filename.replace(/\.[^/.]+$/, "");
                nameInput.value = `${base}_tts.mp3`;
            }

            if (ttsCurrentJobStatus !== "creating" && ttsCurrentJobStatus !== "merging") {
                updateTTSButtonState("idle");
            }

        } catch (err) {
            if (badge) {
                badge.style.display = "flex";
                badge.innerHTML = `<span style="color:#f87171;">❌ Lỗi: ${escapeHtml(err.message)}</span>`;
            }
            alert(`Lỗi phân tích phụ đề SRT: ${err.message}`);
        }
    }

    let lastMergedJobData = null;

    function updateTTSButtonState(status, job = null) {
        const btn = document.getElementById("btn-start-tts");
        const btnText = document.getElementById("btn-start-tts-text");
        if (!btn) return;

        ttsCurrentJobStatus = status;

        switch (status) {
            case "idle":
                btn.disabled = false;
                btn.className = "btn btn-primary";
                btn.style.background = "";
                if (btnText) btnText.textContent = "Tạo TTS";
                break;
            case "creating":
                btn.disabled = false;
                btn.className = "btn btn-primary";
                btn.style.background = "";
                if (btnText) btnText.textContent = "Tạm dừng";
                break;
            case "paused":
                btn.disabled = false;
                btn.className = "btn btn-primary";
                btn.style.background = "";
                if (btnText) btnText.textContent = "Tiếp tục TTS";
                break;
            case "tts_completed":
                btn.disabled = false;
                btn.className = "btn btn-emerald";
                btn.style.background = "#10b981";
                if (btnText) btnText.textContent = "Ghép Audio";
                break;
            case "merging":
                btn.disabled = true;
                btn.className = "btn btn-emerald";
                btn.style.background = "#059669";
                if (btnText) btnText.textContent = "Đang ghép Audio...";
                break;
            case "merged":
                btn.disabled = true;
                btn.className = "btn btn-emerald";
                btn.style.background = "#059669";
                if (btnText) btnText.textContent = "Ghép Audio";
                break;
            case "error":
            case "failed":
                btn.disabled = false;
                btn.className = "btn btn-primary";
                btn.style.background = "";
                if (btnText) btnText.textContent = "Thử lại TTS";
                break;
            default:
                btn.disabled = false;
                btn.className = "btn btn-primary";
                btn.style.background = "";
                if (btnText) btnText.textContent = "Tạo TTS";
                break;
        }
    }

    function showTTSMergeSuccessPopup(data) {
        const popup = document.getElementById("tts-merge-success-popup");
        const nameEl = document.getElementById("tts-merge-success-filename");
        const pathEl = document.getElementById("tts-merge-success-path");

        const filename = data?.filename || (data?.saved_location ? data.saved_location.replace(/^.*[\/\\]/, "") : "tts_final_audio.mp3");
        if (nameEl) nameEl.textContent = filename;
        if (pathEl) pathEl.textContent = `Download/KAGEVIETSUB/${filename}`;
        if (popup) popup.style.display = "flex";
    }

    function resetTTSFormToIdle() {
        ttsCurrentJobId = null;
        sessionStorage.removeItem("kage_current_tts_job_id");
        ttsCurrentJobStatus = "idle";
        clearInterval(ttsPollTimer);
        updateTTSButtonState("idle");
        const banner = document.getElementById("tts-message-banner");
        if (banner) {
            banner.textContent = "Sẵn sàng tạo giọng đọc TTS.";
            banner.className = "status-toast info";
        }
    }
    window.resetTTSFormToIdle = resetTTSFormToIdle;

    async function pollTTSJob(jobId) {
        if (!jobId) return;

        try {
            let res = await fetch(`/api/tts/status/${jobId}?include_subtitles=true`);
            if (!res.ok) {
                res = await fetch(`/api/tts/job/${jobId}`);
            }
            if (!res.ok) return;
            const job = await res.json();

            // REVISION CHECK: Chống race condition & rollback UI
            if (job.revision !== undefined) {
                if (job.revision < ttsLastRevision) {
                    return; // Bỏ qua response cũ đến muộn hơn response mới
                }
                ttsLastRevision = job.revision;
            }

            const resData = job.result || job;
            const subs = job.subtitles || resData.subtitles || [];
            if (subs.length > 0) {
                ttsSubtitlesList = subs;
            }

            // STATE TỪ BACKEND LÀ NGUỒN SỰ THẬT DUY NHẤT (SOURCE OF TRUTH)
            const total = job.total !== undefined ? job.total : (resData.total || ttsSubtitlesList.length);
            const done = job.completed !== undefined ? job.completed : (resData.completed || 0);
            const failed = job.failed !== undefined ? job.failed : (resData.failed || 0);
            const processing = job.processing !== undefined ? job.processing : (resData.processing || 0);
            const finalizing = job.finalizing !== undefined ? job.finalizing : (resData.finalizing || 0);
            const remaining = job.pending !== undefined ? job.pending : (resData.pending !== undefined ? resData.pending : (total - done - failed));
            const threads = job.workers || resData.requested_workers || resData.threads || 5;
            const actW = job.actual_workers || resData.actual_workers || threads;
            const actRunning = job.active_workers !== undefined ? job.active_workers : (resData.active_workers !== undefined ? resData.active_workers : actW);
            const throughput = job.throughput_per_min !== undefined ? job.throughput_per_min : (resData.throughput_per_min || 0);
            const etaSec = job.eta_seconds !== undefined ? job.eta_seconds : null;
            const pct = job.progress !== undefined ? job.progress : Math.round((done + failed) / (total || 1) * 100);

            // Cập nhật UI chuẩn xác
            const statTotal = document.getElementById("tts-stat-total");
            if (statTotal) statTotal.textContent = total;
            const statDone = document.getElementById("tts-stat-done");
            if (statDone) statDone.textContent = done;
            const statFailed = document.getElementById("tts-stat-failed");
            if (statFailed) statFailed.textContent = failed;
            const statRetry = document.getElementById("tts-stat-retry");
            if (statRetry) {
                const curPass = job.retry_pass !== undefined ? job.retry_pass : (resData.retry_pass || 0);
                statRetry.textContent = `${curPass}/3`;
            }
            const statRem = document.getElementById("tts-stat-remaining");
            if (statRem) statRem.textContent = remaining;
            const statThr = document.getElementById("tts-stat-threads");
            if (statThr) {
                statThr.textContent = `${actRunning}/${actW} luồng`;
                statThr.title = `Yêu cầu: ${threads} luồng | Đã tạo thực tế: ${actW} luồng | Đang chạy: ${actRunning} luồng | Gối đầu: ${processing} xử lý API, ${finalizing} lưu audio`;
            }
            const statThroughput = document.getElementById("tts-stat-throughput");
            if (statThroughput) {
                statThroughput.textContent = `${throughput} câu/p`;
            }
            const statEta = document.getElementById("tts-stat-eta");
            if (statEta) {
                if (job.status === "tts_completed" || job.status === "completed" || job.status === "merged") {
                    statEta.textContent = "0s";
                } else if (etaSec !== null && etaSec !== undefined) {
                    statEta.textContent = etaSec > 60 ? `${Math.floor(etaSec / 60)}p ${etaSec % 60}s` : `${etaSec}s`;
                } else {
                    statEta.textContent = "--:--";
                }
            }
            const progPct = document.getElementById("tts-progress-percent");
            if (progPct) progPct.textContent = `${pct}%`;
            const progBar = document.getElementById("tts-progress-bar-fill");
            if (progBar) progBar.style.width = `${pct}%`;
            const errCnt = document.getElementById("tts-err-filter-count");
            if (errCnt) errCnt.textContent = failed;

            const banner = document.getElementById("tts-message-banner");
            if (banner) {
                banner.textContent = job.message || "Đang xử lý...";
                if (job.status === "tts_completed" || job.status === "completed" || job.status === "merged") banner.className = "status-toast success";
                else if (job.status === "failed" || job.status === "error") banner.className = "status-toast error";
                else if (job.status === "completed_with_errors") banner.className = "status-toast warn";
                else banner.className = "status-toast info";
            }

            // Cập nhật DOM hiệu năng cao (chỉ đổi những dòng có trạng thái thay đổi)
            updateTTSSubtitlesDOM(ttsSubtitlesList);

            // NGUỒN SỰ THẬT DUY NHẤT TỪ BACKEND
            const rawStatus = (job.status || "idle").toLowerCase();
            let effectiveStatus = rawStatus;
            if (rawStatus === "completed" && job.saved_location) {
                effectiveStatus = "merged";
            } else if (rawStatus === "completed" && !job.saved_location) {
                effectiveStatus = "tts_completed";
            } else if (rawStatus === "completed_with_errors") {
                effectiveStatus = "tts_completed";
            } else if (rawStatus === "processing" || rawStatus === "generating") {
                effectiveStatus = "creating";
            }

            ttsCurrentJobStatus = effectiveStatus;
            updateTTSButtonState(effectiveStatus, job);

            const retryAllBtn = document.getElementById("btn-tts-retry-all-failed");
            if (retryAllBtn) {
                retryAllBtn.style.display = (failed > 0 && effectiveStatus === "tts_completed") ? "inline-flex" : "none";
            }

            // Xử lý khi job ở trạng thái MERGED (đã ghép audio thành công)
            if (effectiveStatus === "merged" || (job.saved_location && isMergingActive)) {
                isMergingActive = false;
                clearInterval(ttsPollTimer);

                const filename = job.filename || (job.saved_location ? job.saved_location.replace(/^.*[\/\\]/, "") : "tts_final_audio.mp3");
                lastMergedJobData = {
                    filename: filename,
                    saved_location: job.saved_location || `Download/KAGEVIETSUB/${filename}`
                };

                // Hiển thị popup tự động duy nhất 1 lần khi merge xong
                if (!ttsMergePopupShown) {
                    ttsMergePopupShown = true;
                    showTTSMergeSuccessPopup(lastMergedJobData);
                }
            } else if (effectiveStatus === "tts_completed") {
                // Đã xong tạo TTS nhưng chưa nhấn Ghép audio -> dừng polling
                clearInterval(ttsPollTimer);
            } else if (effectiveStatus === "failed" || effectiveStatus === "error" || effectiveStatus === "stopped") {
                clearInterval(ttsPollTimer);
            }

        } catch (e) {
            console.error("Lỗi polling TTS job:", e);
        }
    }

    async function pauseCurrentTTSJob() {
        if (!ttsCurrentJobId) return;
        const btn = document.getElementById("btn-start-tts");
        const btnText = document.getElementById("btn-start-tts-text");
        if (btnText) btnText.textContent = "⏳ Đang tạm dừng...";
        if (btn) btn.disabled = true;

        try {
            const res = await fetch(`/api/tts/${ttsCurrentJobId}/pause`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ job_id: ttsCurrentJobId })
            });
            if (!res.ok) throw new Error("Không thể tạm dừng job");
            await pollTTSJob(ttsCurrentJobId);
        } catch (e) {
            alert(`Lỗi tạm dừng: ${e.message}`);
            await pollTTSJob(ttsCurrentJobId);
        }
    }

    async function resumeCurrentTTSJob() {
        if (!ttsCurrentJobId) return;
        const btn = document.getElementById("btn-start-tts");
        const btnText = document.getElementById("btn-start-tts-text");
        if (btnText) btnText.textContent = "⏳ Đang tiếp tục...";
        if (btn) btn.disabled = true;

        try {
            const res = await fetch(`/api/tts/${ttsCurrentJobId}/resume`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ job_id: ttsCurrentJobId })
            });
            if (!res.ok) throw new Error("Không thể tiếp tục job");

            clearInterval(ttsPollTimer);
            ttsPollTimer = setInterval(() => pollTTSJob(ttsCurrentJobId), 800);
            await pollTTSJob(ttsCurrentJobId);
        } catch (e) {
            alert(`Lỗi tiếp tục: ${e.message}`);
            await pollTTSJob(ttsCurrentJobId);
        }
    }

    async function mergeCurrentTTSJob() {
        if (!ttsCurrentJobId) {
            alert("Chưa có tiến trình TTS hoàn thành để ghép audio.");
            return;
        }

        isMergingActive = true;
        ttsMergePopupShown = false;
        updateTTSButtonState("merging");

        const outFilename = document.getElementById("tts-output-filename")?.value || "tts_final_audio.mp3";

        try {
            const res = await fetch(`/api/tts/${ttsCurrentJobId}/merge`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    job_id: ttsCurrentJobId,
                    output_filename: outFilename
                })
            });

            const data = await res.json();
            if (!res.ok) throw new Error(data.detail || "Lỗi ghép audio");

            clearInterval(ttsPollTimer);
            ttsPollTimer = setInterval(() => pollTTSJob(ttsCurrentJobId), 800);
            await pollTTSJob(ttsCurrentJobId);

        } catch (err) {
            isMergingActive = false;
            updateTTSButtonState("tts_completed");
            alert(`Lỗi ghép audio: ${err.message}`);
        }
    }

    async function startNewTTSJob() {
        isMergingActive = false;
        ttsMergePopupShown = false;

        if (!ttsSrtContent || ttsSubtitlesList.length === 0) {
            alert("Vui lòng chọn hoặc kéo thả file .SRT vào trước khi bắt đầu.");
            return;
        }

        const voice = document.getElementById("tts-voice-select")?.value || "BV421_vivn_streaming";
        const speed = parseFloat(document.getElementById("tts-speed-select")?.value || 1.0);
        let threads = parseInt(document.getElementById("tts-threads-input")?.value || 5);
        threads = Math.max(1, Math.min(30, threads));
        const outFilename = document.getElementById("tts-output-filename")?.value || "tts_final_audio.mp3";

        const btn = document.getElementById("btn-start-tts");
        if (btn) btn.disabled = true;
        const btnText = document.getElementById("btn-start-tts-text");
        if (btnText) btnText.textContent = "⏳ Đang khởi chạy...";

        const progressContainer = document.getElementById("tts-progress-container");
        if (progressContainer) progressContainer.style.display = "block";

        try {
            const res = await fetch("/api/tts/create-job", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    srt_content: ttsSrtContent,
                    voice: voice,
                    speed: speed,
                    threads: threads,
                    output_filename: outFilename
                })
            });

            const data = await res.json();
            if (!res.ok) throw new Error(data.detail || "Không thể tạo job TTS");

            ttsCurrentJobId = data.job_id;
            sessionStorage.setItem("kage_current_tts_job_id", ttsCurrentJobId);
            ttsLastRevision = 0;

            clearInterval(ttsPollTimer);
            ttsPollTimer = setInterval(() => pollTTSJob(ttsCurrentJobId), 800);
            await pollTTSJob(ttsCurrentJobId);

        } catch (err) {
            updateTTSButtonState("idle");
            alert(`Lỗi khởi chạy TTS: ${err.message}`);
        }
    }

    async function loadTTSJob(jobId) {
        if (!jobId) return;
        ttsCurrentJobId = jobId;
        sessionStorage.setItem("kage_current_tts_job_id", jobId);

        const progressContainer = document.getElementById("tts-progress-container");
        if (progressContainer) progressContainer.style.display = "block";

        await pollTTSJob(jobId);

        clearInterval(ttsPollTimer);
        if (ttsCurrentJobStatus === "creating" || ttsCurrentJobStatus === "merging") {
            ttsPollTimer = setInterval(() => pollTTSJob(jobId), 800);
        }
    }
    window.loadTTSJob = loadTTSJob;

    window.handleGlobalJobCardClick = function(jobId) {
        if (!jobId) return;
        if (jobId.startsWith("tts_") || jobId.startsWith("tts-")) {
            switchMainTab("tts");
            loadTTSJob(jobId);
        } else if (jobId.startsWith("whisper_") || jobId.startsWith("wh_")) {
            switchMainTab("audio", "audio-whisper");
        } else if (jobId.startsWith("audio_merge_")) {
            switchMainTab("audio", "audio-merge");
        } else if (jobId.startsWith("video_cut_")) {
            switchMainTab("video", "video-cut");
        } else if (jobId.startsWith("video_merge_")) {
            switchMainTab("video", "video-merge");
        } else if (jobId.startsWith("video_compress_")) {
            switchMainTab("video", "video-compress");
        }
    };

    function initTTSController() {
        fetchTTSVoices();

        const threadInput = document.getElementById("tts-threads-input");
        const threadLabel = document.getElementById("tts-threads-label");

        if (threadInput && threadLabel) {
            threadInput.addEventListener("input", () => {
                let v = parseInt(threadInput.value);
                if (isNaN(v)) v = 5;
                if (v < 1) v = 1;
                if (v > 30) v = 30;
                threadLabel.textContent = `${v} luồng`;
            });
        }

        const dropzone = document.getElementById("tts-dropzone");
        const fileInput = document.getElementById("tts-file-input");

        if (dropzone && fileInput) {
            dropzone.addEventListener("click", () => fileInput.click());
            dropzone.addEventListener("dragover", (e) => {
                e.preventDefault();
                dropzone.classList.add("dragover");
            });
            dropzone.addEventListener("dragleave", () => dropzone.classList.remove("dragover"));
            dropzone.addEventListener("drop", (e) => {
                e.preventDefault();
                dropzone.classList.remove("dragover");
                if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                    const f = e.dataTransfer.files[0];
                    const reader = new FileReader();
                    reader.onload = (evt) => parseAndLoadTTS_SRT(evt.target.result, f.name);
                    reader.readAsText(f, "utf-8");
                }
            });

            fileInput.addEventListener("change", (e) => {
                if (fileInput.files && fileInput.files.length > 0) {
                    const f = fileInput.files[0];
                    const reader = new FileReader();
                    reader.onload = (evt) => parseAndLoadTTS_SRT(evt.target.result, f.name);
                    reader.readAsText(f, "utf-8");
                }
            });
        }

        document.getElementById("btn-tts-use-editor-srt")?.addEventListener("click", () => {
            const editorText = document.getElementById("srt-editor-textarea")?.value || "";
            if (!editorText.trim()) {
                alert("Trình Sửa Phụ Đề hiện tại đang rỗng. Hãy dán nội dung SRT hoặc tải file lên trước.");
                return;
            }
            parseAndLoadTTS_SRT(editorText, "Trình_Sửa_Phụ_Đề.srt");
        });

        // Click wrapper khi nút bị disabled ở trạng thái 'merged' để mở lại popup thành công
        const startBtnWrapper = document.getElementById("btn-start-tts-wrapper");
        if (startBtnWrapper) {
            startBtnWrapper.addEventListener("click", () => {
                const btn = document.getElementById("btn-start-tts");
                if (btn && btn.disabled && ttsCurrentJobStatus === "merged") {
                    showTTSMergeSuccessPopup(lastMergedJobData);
                }
            });
        }

        // DUY NHẤT 1 NÚT #btn-start-tts ĐIỀU KHIỂN TOÀN BỘ VÒNG ĐỜI TTS
        document.getElementById("btn-start-tts")?.addEventListener("click", async () => {
            if (ttsCurrentJobStatus === "creating") {
                await pauseCurrentTTSJob();
                return;
            }
            if (ttsCurrentJobStatus === "paused") {
                await resumeCurrentTTSJob();
                return;
            }
            if (ttsCurrentJobStatus === "tts_completed") {
                await mergeCurrentTTSJob();
                return;
            }
            if (ttsCurrentJobStatus === "merging" || ttsCurrentJobStatus === "merged") {
                return;
            }

            // Trạng thái IDLE hoặc error/failed:
            // Kiểm tra xem có job nào đang chạy không
            if (ttsCurrentJobId && (ttsCurrentJobStatus === "creating" || ttsCurrentJobStatus === "merging")) {
                const runningModal = document.getElementById("tts-job-running-popup");
                if (runningModal) runningModal.style.display = "flex";
                return;
            }

            await startNewTTSJob();
        });

        // Modal cảnh báo khi có job đang chạy
        document.getElementById("btn-running-popup-home")?.addEventListener("click", () => {
            const popup = document.getElementById("tts-job-running-popup");
            if (popup) popup.style.display = "none";
            switchMainTab("home");
        });
        document.getElementById("btn-running-popup-close")?.addEventListener("click", () => {
            const popup = document.getElementById("tts-job-running-popup");
            if (popup) popup.style.display = "none";
        });
        document.getElementById("tts-job-running-popup")?.addEventListener("click", (e) => {
            if (e.target.id === "tts-job-running-popup") {
                const popup = document.getElementById("tts-job-running-popup");
                if (popup) popup.style.display = "none";
            }
        });

        // Modal thông báo Ghép Audio thành công
        document.getElementById("btn-close-tts-merge-popup")?.addEventListener("click", () => {
            const popup = document.getElementById("tts-merge-success-popup");
            if (popup) popup.style.display = "none";
        });

        document.getElementById("tts-merge-success-popup")?.addEventListener("click", (e) => {
            if (e.target.id === "tts-merge-success-popup") {
                const popup = document.getElementById("tts-merge-success-popup");
                if (popup) popup.style.display = "none";
            }
        });

        document.getElementById("btn-tts-retry-all-failed")?.addEventListener("click", async () => {
            if (!ttsCurrentJobId) return;
            const failedSubs = ttsSubtitlesList.filter(s => s.status === "ERROR" || s.status === "FAILED" || s.status === "FINAL_FAILED");
            if (failedSubs.length === 0) {
                alert("Không có câu nào bị lỗi.");
                return;
            }

            const voice = document.getElementById("tts-voice-select")?.value || "BV421_vivn_streaming";
            const speed = parseFloat(document.getElementById("tts-speed-select")?.value || 1.0);

            for (const sub of failedSubs) {
                sub.status = "GENERATING";
            }
            renderTTSSubtitlesList(ttsSubtitlesList);

            for (const sub of failedSubs) {
                try {
                    await fetch("/api/tts/retry", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({
                            job_id: ttsCurrentJobId,
                            subtitle_index: sub.index,
                            voice: voice,
                            speed: speed
                        })
                    });
                } catch (e) {}
            }

            clearInterval(ttsPollTimer);
            ttsPollTimer = setInterval(() => pollTTSJob(ttsCurrentJobId), 800);
            await pollTTSJob(ttsCurrentJobId);
        });

        document.getElementById("btn-tts-filter-all")?.addEventListener("click", () => {
            ttsFilterMode = "all";
            document.getElementById("btn-tts-filter-all").classList.add("active");
            document.getElementById("btn-tts-filter-err").classList.remove("active");
            renderTTSSubtitlesList(ttsSubtitlesList);
        });

        document.getElementById("btn-tts-filter-err")?.addEventListener("click", () => {
            ttsFilterMode = "error";
            document.getElementById("btn-tts-filter-err").classList.add("active");
            document.getElementById("btn-tts-filter-all").classList.remove("active");
            renderTTSSubtitlesList(ttsSubtitlesList);
        });

        // Event Delegation cho danh sách phụ đề TTS (xử lý Nghe thử & Thử lại tức thì mà không cần gắn lại handler)
        const subContainer = document.getElementById("tts-subtitle-items");
        if (subContainer) {
            subContainer.addEventListener("click", async (e) => {
                const retryBtn = e.target.closest(".btn-tts-retry-sub");
                if (retryBtn) {
                    e.stopPropagation();
                    const idx = parseInt(retryBtn.getAttribute("data-sub-idx"));
                    if (!isNaN(idx)) await retrySingleTTSSubtitle(idx);
                    return;
                }

                const previewBtn = e.target.closest(".btn-tts-preview-sub");
                if (previewBtn) {
                    e.stopPropagation();
                    const idx = parseInt(previewBtn.getAttribute("data-sub-idx"));
                    if (!isNaN(idx)) playSubPreview(idx, previewBtn);
                    return;
                }
            });
        }

        // Phục hồi job trước đó nếu có trong session, ngược lại khởi tạo IDLE
        const savedJobId = sessionStorage.getItem("kage_current_tts_job_id");
        if (savedJobId) {
            loadTTSJob(savedJobId);
        } else {
            updateTTSButtonState("idle");
        }
    }

    // Helper escape html
    function escapeHtml(text) {
        if (!text) return "";
        return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
    }

    // Initial Health Check, Version Fetch & TTS Init
    fetchAppVersion();
    checkHealth();
    initTTSController();
});
