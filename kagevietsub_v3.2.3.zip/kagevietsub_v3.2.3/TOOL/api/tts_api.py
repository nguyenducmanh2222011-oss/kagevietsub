#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB - TTS API ROUTER (TƯƠNG THÍCH PYTHON 3.14 + ANDROID/PC)
==============================================================================
API tạo giọng đọc TTS CapCut cho phụ đề SRT:
- Lấy danh mục giọng đọc (GET /api/tts/voices)
- Phân tích & kiểm tra tính hợp lệ của file SRT (POST /api/tts/parse-srt)
- Khởi tạo tiến trình tạo TTS đa luồng (POST /api/tts/create-job)
- Thử lại từng câu phụ đề bị lỗi (POST /api/tts/retry)
- Ghép nối audio hoàn chỉnh theo mốc thời gian SRT (POST /api/tts/merge)
- Truy vấn trạng thái job (GET /api/tts/job/{job_id})
==============================================================================
"""

from typing import Optional, Dict, Any, List
from pathlib import Path
from TOOL.engines.tts_engine import TTSEngine
from TOOL.engines.srt_engine import SrtEngine
from TOOL.services.task_service import job_manager

try:
    from pydantic import BaseModel
except ImportError:
    class BaseModel:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

try:
    from fastapi import APIRouter, HTTPException, Body
    router = APIRouter(prefix="/api/tts", tags=["CapCut TTS Operations"])
    HAS_FASTAPI = True
except ImportError:
    router = None
    HAS_FASTAPI = False


class TTSCreateJobRequest(BaseModel):
    srt_content: str
    voice: str = "BV421_vivn_streaming"
    speed: float = 1.0
    threads: int = 5
    output_filename: Optional[str] = None


class TTSRetryRequest(BaseModel):
    job_id: str
    subtitle_index: int
    voice: Optional[str] = None
    speed: Optional[float] = None


class TTSMergeRequest(BaseModel):
    job_id: str
    output_filename: Optional[str] = "tts_final_audio.mp3"


def handle_tts_voices() -> Dict[str, Any]:
    """Trả về danh sách giọng đọc tiếng Việt khả dụng."""
    voices = TTSEngine.get_voices()
    return {
        "status": "ok",
        "voices": voices,
        "total": len(voices)
    }


def handle_tts_parse_srt(srt_content: str) -> Dict[str, Any]:
    """
    Phân tích nội dung SRT, kiểm tra tính hợp lệ của timestamp và block:
    - Kiểm tra số thứ tự
    - Kiểm tra mốc thời gian start / end
    - Kiểm tra block rỗng
    """
    if not srt_content or not srt_content.strip():
        raise ValueError("Nội dung file SRT rỗng.")

    blocks = SrtEngine.parse_srt(srt_content)
    if not blocks:
        raise ValueError("Không tìm thấy khối phụ đề SRT hợp lệ. Vui lòng kiểm tra định dạng file .srt.")

    subtitles = []
    for idx, b in enumerate(blocks, 1):
        s_ms = SrtEngine.time_to_ms(b["start"])
        e_ms = SrtEngine.time_to_ms(b["end"])
        if e_ms <= s_ms:
            # Tự động sửa nhẹ nếu end_ms <= start_ms (thêm 1 giây)
            e_ms = s_ms + 1000
            b["end"] = SrtEngine.ms_to_time(e_ms)

        subtitles.append({
            "index": idx,
            "id": f"{idx:04d}",
            "start": b["start"],
            "end": b["end"],
            "start_ms": s_ms,
            "end_ms": e_ms,
            "text": b["text"].strip(),
            "status": "PENDING"
        })

    return {
        "status": "ok",
        "total": len(subtitles),
        "subtitles": subtitles
    }


def handle_tts_create_job(
    srt_content: str,
    voice: str = "BV421_vivn_streaming",
    speed: float = 1.0,
    threads: int = 5,
    output_filename: Optional[str] = None
) -> Dict[str, Any]:
    """Khởi tạo job tạo TTS với đa luồng thực tế."""
    # 1. Parse SRT
    parse_res = handle_tts_parse_srt(srt_content)
    subtitles = parse_res["subtitles"]
    if not subtitles:
        raise ValueError("Không có câu phụ đề nào để tạo giọng đọc.")

    # 2. Validate params
    threads = max(1, min(30, int(threads)))
    speed = max(0.25, min(4.0, float(speed)))
    voice_info = TTSEngine.validate_vietnamese_voice(voice)
    if not voice_info:
        default_voices = TTSEngine.get_voices()
        voice = default_voices[0]["voice_type"] if default_voices else "BV421_vivn_streaming"
    else:
        voice = voice_info["voice_type"]

    # 3. Tạo Job
    job_id = job_manager.create_job("tts_generation", {
        "voice": voice,
        "speed": speed,
        "threads": threads,
        "total_subtitles": len(subtitles),
        "output_filename": output_filename or "tts_final_audio.mp3"
    })

    # 4. Kích hoạt Worker trong Background
    def _task(jid):
        TTSEngine.process_tts_job(
            job_id=jid,
            subtitles=subtitles,
            voice=voice,
            speed=speed,
            threads=threads
        )

    job_manager.run_in_background(job_id, _task)

    return {
        "status": "ok",
        "job_id": job_id,
        "message": f"Đã khởi tạo tiến trình tạo TTS cho {len(subtitles)} câu phụ đề ({threads} luồng).",
        "total": len(subtitles),
        "threads": threads,
        "voice": voice,
        "speed": speed
    }


def handle_tts_retry(
    job_id: str,
    subtitle_index: int,
    voice: Optional[str] = None,
    speed: Optional[float] = None
) -> Dict[str, Any]:
    """Thử lại tạo TTS cho 1 câu phụ đề cụ thể."""
    return TTSEngine.retry_subtitle(job_id, subtitle_index, voice, speed)


def handle_tts_merge(
    job_id: str,
    output_filename: Optional[str] = "tts_final_audio.mp3"
) -> Dict[str, Any]:
    """Ghép nối audio theo mốc thời gian SRT trong background."""
    out_name = output_filename or "tts_final_audio.mp3"
    job_manager.update_job(job_id, status="processing", progress=10, message="Bắt đầu ghép nối audio theo SRT...")

    def _merge_task(jid):
        TTSEngine.merge_tts_audio_by_srt(jid, out_name)

    job_manager.run_in_background(job_id, _merge_task)
    return {
        "status": "ok",
        "job_id": job_id,
        "message": "Đã bắt đầu ghép nối audio theo mốc thời gian SRT."
    }


def handle_tts_get_status(job_id: str, include_subtitles: bool = False) -> Dict[str, Any]:
    """
    Trả về metadata trạng thái chuẩn cho polling hiệu năng cao:
    - Source of truth duy nhất từ Backend
    - Monotonic revision chống rollback dữ liệu
    - Trả về các chỉ số phân biệt rõ ràng: completed, processing, finalizing, pending, failed, retrying, final_failed
    - Thông số Throughput/phút và ETA dự kiến
    - Hạn chế payload: không trả danh sách subtitles nếu include_subtitles=False
    - Tự động khôi phục từ Checkpoint và Reconcile thực tế đĩa cứng (Crash Recovery) nếu server vừa khởi động lại
    """
    job = job_manager.get_job(job_id)
    if not job:
        job = TTSEngine.recover_job_from_disk(job_id)
        if not job:
            raise ValueError(f"Không tìm thấy job '{job_id}'.")

    res = job.get("result") or {}
    total = res.get("total") or job.get("metadata", {}).get("total_subtitles", 0)
    completed = res.get("completed", 0)
    failed = res.get("failed", 0)
    processing = res.get("processing", 0)
    finalizing = res.get("finalizing", 0)
    retrying = res.get("retrying", 0)
    final_failed = res.get("final_failed", 0)
    pending = res.get("pending", max(0, total - (completed + failed + processing + finalizing + retrying)))
    progress = job.get("progress", res.get("progress", 0))
    revision = res.get("revision", 1)
    throughput = res.get("throughput_per_min", 0.0)

    eta_sec = None
    remaining = max(0, total - completed - failed)
    if throughput > 0 and remaining > 0:
        eta_sec = int((remaining / throughput) * 60)

    raw_status = str(job.get("status", "unknown")).lower()
    merge_status = job.get("merge_status")
    if not merge_status:
        if job.get("saved_location"):
            merge_status = "completed"
        elif raw_status == "merging":
            merge_status = "merging"
        else:
            merge_status = "idle"

    if raw_status in ["merged"] or (raw_status == "completed" and job.get("saved_location")):
        norm_status = "merged"
    elif raw_status in ["tts_completed", "completed_with_errors"] or (raw_status == "completed" and not job.get("saved_location")):
        norm_status = "tts_completed"
    elif raw_status in ["merging"]:
        norm_status = "merging"
    elif raw_status in ["paused"]:
        norm_status = "paused"
    elif raw_status in ["processing", "generating", "creating"]:
        norm_status = "creating"
    elif raw_status in ["failed", "error"]:
        norm_status = "error"
    elif raw_status in ["idle"]:
        norm_status = "idle"
    else:
        norm_status = raw_status

    status_data: Dict[str, Any] = {
        "job_id": job_id,
        "type": "tts",
        "status": norm_status,
        "raw_status": raw_status,
        "merge_status": merge_status,
        "output_file": job.get("filename") or job.get("saved_location"),
        "updated_at": job.get("updated_at", time.time()),
        "revision": revision,
        "total": total,
        "completed": completed,
        "processing": processing,
        "finalizing": finalizing,
        "pending": pending,
        "failed": failed,
        "retrying": retrying,
        "final_failed": final_failed,
        "progress": progress,
        "throughput_per_min": throughput,
        "eta_seconds": eta_sec,
        "workers": res.get("requested_workers", job.get("metadata", {}).get("threads", 5)),
        "actual_workers": res.get("actual_workers", job.get("metadata", {}).get("threads", 5)),
        "active_workers": res.get("active_workers", 0),
        "speed": res.get("speed", job.get("metadata", {}).get("speed", 1.0)),
        "voice": res.get("voice", job.get("metadata", {}).get("voice", "")),
        "retry_pass": res.get("retry_pass", 0),
        "failed_indices": res.get("failed_indices", []),
        "message": job.get("message", ""),
        "saved_location": job.get("saved_location", None),
        "download_url": job.get("download_url", None)
    }

    if include_subtitles:
        status_data["subtitles"] = res.get("subtitles", [])

    return status_data


def handle_tts_get_job(job_id: str) -> Dict[str, Any]:
    """Lấy trạng thái chi tiết của job TTS (kèm Crash Recovery nếu cần)."""
    job = job_manager.get_job(job_id)
    if not job:
        job = TTSEngine.recover_job_from_disk(job_id)
        if not job:
            raise ValueError(f"Không tìm thấy job '{job_id}'.")
    return job


def handle_tts_pause(job_id: str) -> Dict[str, Any]:
    """Tạm dừng job TTS."""
    return TTSEngine.pause_job(job_id)


def handle_tts_resume(job_id: str) -> Dict[str, Any]:
    """Tiếp tục job TTS."""
    return TTSEngine.resume_job(job_id)


def handle_tts_stop(job_id: str) -> Dict[str, Any]:
    """Dừng hẳn job TTS."""
    return TTSEngine.stop_job(job_id)


def handle_tts_preview(job_id: str, subtitle_index: int) -> Path:
    """Lấy đường dẫn file audio của 1 câu phụ đề cụ thể để phát nghe thử."""
    from TOOL.config import TEMP_DIR
    job_dir = TEMP_DIR / "tts" / f"job_{job_id}"
    audio_file = job_dir / f"{subtitle_index:04d}.mp3"
    if not audio_file.exists():
        raise FileNotFoundError(f"Chưa có file audio nghe thử cho câu số {subtitle_index}.")
    return audio_file


# ==============================================================================
# FASTAPI ROUTER DEFINITIONS
# ==============================================================================
if HAS_FASTAPI and router is not None:
    from fastapi.responses import FileResponse

    @router.get("/voices")
    def api_tts_voices():
        return handle_tts_voices()

    @router.post("/parse-srt")
    def api_tts_parse(payload: Dict[str, Any] = Body(...)):
        content = payload.get("srt_content") or payload.get("content") or ""
        try:
            return handle_tts_parse_srt(content)
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    @router.post("/create-job")
    def api_tts_create(req: TTSCreateJobRequest):
        try:
            return handle_tts_create_job(
                srt_content=req.srt_content,
                voice=req.voice,
                speed=req.speed,
                threads=req.threads,
                output_filename=req.output_filename
            )
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    @router.post("/retry")
    def api_tts_retry(req: TTSRetryRequest):
        try:
            return handle_tts_retry(req.job_id, req.subtitle_index, req.voice, req.speed)
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    @router.post("/merge")
    def api_tts_merge(req: TTSMergeRequest):
        try:
            return handle_tts_merge(req.job_id, req.output_filename)
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    @router.post("/pause")
    def api_tts_pause(payload: Dict[str, Any] = Body(...)):
        job_id = payload.get("job_id", "")
        try:
            return handle_tts_pause(job_id)
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    @router.post("/{job_id}/pause")
    def api_tts_pause_by_id(job_id: str):
        try:
            return handle_tts_pause(job_id)
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    @router.post("/resume")
    def api_tts_resume(payload: Dict[str, Any] = Body(...)):
        job_id = payload.get("job_id", "")
        try:
            return handle_tts_resume(job_id)
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    @router.post("/{job_id}/resume")
    def api_tts_resume_by_id(job_id: str):
        try:
            return handle_tts_resume(job_id)
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    @router.post("/{job_id}/merge")
    def api_tts_merge_by_id(job_id: str, payload: Optional[Dict[str, Any]] = Body(None)):
        output_filename = (payload or {}).get("output_filename", "tts_final_audio.mp3") if payload else "tts_final_audio.mp3"
        try:
            return handle_tts_merge(job_id, output_filename)
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    @router.post("/stop")
    def api_tts_stop(payload: Dict[str, Any] = Body(...)):
        job_id = payload.get("job_id", "")
        try:
            return handle_tts_stop(job_id)
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    @router.get("/job/{job_id}")
    def api_tts_job_detail(job_id: str):
        try:
            return handle_tts_get_job(job_id)
        except Exception as e:
            raise HTTPException(status_code=404, detail=str(e))

    @router.get("/status/{job_id}")
    def api_tts_status(job_id: str, include_subtitles: bool = False):
        try:
            return handle_tts_get_status(job_id, include_subtitles=include_subtitles)
        except Exception as e:
            raise HTTPException(status_code=404, detail=str(e))

    @router.get("/preview/{job_id}/{subtitle_index}")
    def api_tts_preview(job_id: str, subtitle_index: int):
        try:
            audio_path = handle_tts_preview(job_id, subtitle_index)
            return FileResponse(
                path=str(audio_path),
                media_type="audio/mpeg",
                filename=audio_path.name
            )
        except Exception as e:
            raise HTTPException(status_code=404, detail=str(e))
