import sys
import os
import time
import json
import logging
import subprocess
import urllib.request
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

# Path setup to import full capcut-tts-api repository untouched
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
CAPCUT_REPO_DIR = PROJECT_ROOT / "capcut-tts-api"

if str(CAPCUT_REPO_DIR) not in sys.path:
    sys.path.insert(0, str(CAPCUT_REPO_DIR))

try:
    from capcut_tts_api.client import CapCutClient
    from capcut_tts_api.models import VoiceInfo
    from capcut_tts_api.exceptions import CapCutError, CapCutTaskError
except ImportError as e:
    raise ImportError(f"Không thể import capcut_tts_api từ repository {CAPCUT_REPO_DIR}: {e}")

logger = logging.getLogger("CapCutTTSAdapter")


class CapCutTTSAdapter:
    """
    Adapter mỏng kết nối KAGEVIETSUB với toàn bộ repository K07VN/capcut-tts-api.
    Tối ưu hóa hiệu năng cao cho Android / Termux / PC:
    - HTTP Keep-Alive & Connection Pooling tái sử dụng socket cho tất cả workers
    - Polling không block với khoảng cách linh hoạt micro-intervals (0.10s -> 0.30s)
    - Tải file dạng streaming trực tiếp vào đĩa, tránh tải toàn bộ vào RAM
    - Xác thực file nhị phân siêu tốc không làm nghẽn CPU
    """

    def __init__(self):
        # Thiết lập session tái sử dụng kết nối HTTP Keep-Alive và Connection Pooling
        self.session = None
        try:
            import requests
            from requests.adapters import HTTPAdapter
            from urllib3.util.retry import Retry

            sess = requests.Session()
            # Bật connection pool lớn hỗ trợ đồng thời từ 1 đến 30+ workers
            adapter = HTTPAdapter(
                pool_connections=64,
                pool_maxsize=128,
                max_retries=Retry(
                    total=2,
                    backoff_factor=0.1,
                    status_forcelist=[502, 503, 504],
                    raise_on_status=False
                ),
                pool_block=False
            )
            sess.mount("http://", adapter)
            sess.mount("https://", adapter)
            sess.headers.update({
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "Connection": "keep-alive"
            })
            self.session = sess
        except Exception as ex:
            logger.warning(f"Không thể khởi tạo pooled requests.Session: {ex}")
            self.session = None

        self.client = CapCutClient(session=self.session)
        self.voice_catalog_path = CAPCUT_REPO_DIR / "Voice.json"
        if not self.voice_catalog_path.exists():
            # Fallback nếu nằm ở root
            self.voice_catalog_path = PROJECT_ROOT / "Voice.json"

    def get_vietnamese_voices(self) -> List[Dict[str, Any]]:
        """
        Lấy danh sách giọng đọc tiếng Việt từ catalog Voice.json của repository gốc.
        Chỉ giữ lại giọng có lang/lan/locale là 'vi-VN' hoặc 'vi'.
        """
        if not self.voice_catalog_path.exists():
            logger.error(f"Không tìm thấy file Voice.json tại {self.voice_catalog_path}")
            return []

        try:
            voices_info: List[VoiceInfo] = self.client.list_voices(lang="vi-VN", catalog_path=self.voice_catalog_path)
            result = []
            for v in voices_info:
                result.append({
                    "voice_type": v.voice_type,
                    "name": v.display_name or v.voice_type,
                    "resource_id": v.resource_id,
                    "lang": v.lang or "vi-VN",
                    "lan": v.lan or "vi"
                })
            return result
        except Exception as e:
            logger.error(f"Lỗi khi đọc danh sách voice từ Voice.json qua capcut_tts_api: {e}")
            return []

    def fetch_audio_url(
        self,
        text: str,
        voice: str,
        timeout: float = 45.0
    ) -> Tuple[bool, Optional[str], Optional[str], Optional[str], Dict[str, int]]:
        """
        Giai đoạn 80% của TTS Request Worker:
        1. Gọi create_tts_task
        2. Query task với micro-intervals thích ứng
        3. Trích xuất audio_url từ payload khi API xử lý xong (RESULT_READY)
        
        Trả về: (success, audio_url, task_id, error_msg, timing_metrics)
        """
        metrics = {"api_ms": 0, "query_ms": 0, "total_api_ms": 0}
        if not text or not text.strip():
            return False, None, None, "Văn bản rỗng.", metrics

        t_start = time.time()
        task_id = None
        try:
            # 1. Tạo task TTS thông qua CapCutClient
            t0 = time.time()
            create_res = self.client.create_tts_task(
                texts=text.strip(),
                voice=voice
            )
            t1 = time.time()
            metrics["api_ms"] = int((t1 - t0) * 1000)

            tasks = (create_res.get("data") or {}).get("tasks") or []
            if not tasks:
                err_info = json.dumps(create_res, ensure_ascii=False)
                metrics["total_api_ms"] = int((time.time() - t_start) * 1000)
                return False, None, None, f"CapCut API không trả về task: {err_info}", metrics

            task_id = tasks[0].get("id")
            token = tasks[0].get("token")

            if not task_id or not token:
                metrics["total_api_ms"] = int((time.time() - t_start) * 1000)
                return False, None, task_id, f"Task ID hoặc Token không hợp lệ từ response: {tasks[0]}", metrics

            # 2. Query task với progressive micro-intervals
            t_query_start = time.time()
            audio_url = None
            last_status = "unknown"
            poll_intervals = [0.10, 0.15, 0.20, 0.25, 0.30]
            poll_idx = 0

            while time.time() - t_query_start < timeout:
                query_res = self.client.query_tts_task(task_id, token)
                query_tasks = (query_res.get("data") or {}).get("tasks") or []

                if query_tasks:
                    task_info = query_tasks[0]
                    last_status = task_info.get("status", "unknown")

                    if last_status in ["succeed", "success", "completed", "done"]:
                        payload_raw = task_info.get("payload") or "{}"
                        if isinstance(payload_raw, str):
                            try:
                                payload = json.loads(payload_raw)
                            except Exception:
                                payload = {}
                        else:
                            payload = payload_raw

                        subtitles = payload.get("audio_subtitles") or []
                        if subtitles:
                            audio_url = subtitles[0].get("speech_url")
                            break
                        else:
                            metrics["total_api_ms"] = int((time.time() - t_start) * 1000)
                            return False, None, task_id, f"Payload không có audio_subtitles: {payload_raw}", metrics

                    elif last_status == "failed":
                        fail_msg = json.dumps(query_res, ensure_ascii=False)
                        metrics["total_api_ms"] = int((time.time() - t_start) * 1000)
                        return False, None, task_id, f"CapCut task báo lỗi FAILED: {fail_msg}", metrics

                sleep_dur = poll_intervals[min(poll_idx, len(poll_intervals) - 1)]
                poll_idx += 1
                time.sleep(sleep_dur)

            t2 = time.time()
            metrics["query_ms"] = int((t2 - t_query_start) * 1000)
            metrics["total_api_ms"] = int((time.time() - t_start) * 1000)

            if not audio_url:
                return False, None, task_id, f"Hết thời gian chờ CapCut TTS ({timeout}s). Trạng thái cuối: {last_status}", metrics

            return True, audio_url, task_id, None, metrics

        except Exception as e:
            metrics["total_api_ms"] = int((time.time() - t_start) * 1000)
            logger.exception("Lỗi ngoại lệ trong fetch_audio_url")
            return False, None, task_id, f"Exception trong fetch_audio_url: {str(e)}", metrics

    def download_and_finalize_audio(
        self,
        audio_url: str,
        raw_output_path: Path,
        final_output_path: Path,
        speed: float = 1.0,
        timeout: float = 30.0
    ) -> Tuple[bool, float, Optional[str], Dict[str, int]]:
        """
        Giai đoạn 20% của Audio Finalization Worker:
        1. Tải audio từ CDN (Stream I/O)
        2. Xác thực file raw
        3. Áp dụng tốc độ (FFmpeg atempo hoặc rename nếu 1.0x)
        4. Xác thực file final trên đĩa
        5. Dọn dẹp file raw tạm
        
        Trả về: (success, final_duration, error_msg, timing_metrics)
        """
        metrics = {"dl_ms": 0, "speed_ms": 0, "val_ms": 0, "total_fin_ms": 0}
        t_start = time.time()
        raw_output_path = Path(raw_output_path)
        final_output_path = Path(final_output_path)

        raw_output_path.parent.mkdir(parents=True, exist_ok=True)
        final_output_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            # 1. Download stream
            t_dl_start = time.time()
            if self.session is not None:
                resp = self.session.get(audio_url, stream=True, timeout=timeout)
                if resp.status_code != 200:
                    metrics["total_fin_ms"] = int((time.time() - t_start) * 1000)
                    return False, 0.0, f"Không thể tải audio từ CDN (HTTP {resp.status_code})", metrics
                with open(raw_output_path, "wb") as f:
                    for chunk in resp.iter_content(chunk_size=16384):
                        if chunk:
                            f.write(chunk)
            else:
                req = urllib.request.Request(audio_url, headers={"User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(req, timeout=timeout) as resp:
                    if resp.status != 200:
                        metrics["total_fin_ms"] = int((time.time() - t_start) * 1000)
                        return False, 0.0, f"Không thể tải audio từ CDN (HTTP {resp.status})", metrics
                    with open(raw_output_path, "wb") as f:
                        while True:
                            chunk = resp.read(16384)
                            if not chunk:
                                break
                            f.write(chunk)

            metrics["dl_ms"] = int((time.time() - t_dl_start) * 1000)

            # 2. Validate raw file
            v_raw, dur_raw, err_raw = self.validate_audio_file(raw_output_path)
            if not v_raw or dur_raw <= 0.05:
                if raw_output_path.exists():
                    try:
                        raw_output_path.unlink()
                    except Exception:
                        pass
                metrics["total_fin_ms"] = int((time.time() - t_start) * 1000)
                return False, 0.0, f"File raw tải về không hợp lệ: {err_raw}", metrics

            # 3. Apply speed
            t_sp_start = time.time()
            ok_sp, dur_final, err_sp = self.apply_speed(raw_output_path, final_output_path, speed)
            metrics["speed_ms"] = int((time.time() - t_sp_start) * 1000)

            if not ok_sp:
                metrics["total_fin_ms"] = int((time.time() - t_start) * 1000)
                return False, 0.0, f"Lỗi xử lý tốc độ audio: {err_sp}", metrics

            # 4. Validate final file
            t_val_start = time.time()
            v_final, dur_final_check, err_final = self.validate_audio_file(final_output_path)
            metrics["val_ms"] = int((time.time() - t_val_start) * 1000)
            metrics["total_fin_ms"] = int((time.time() - t_start) * 1000)

            if not v_final or dur_final_check <= 0.05:
                if final_output_path.exists():
                    try:
                        final_output_path.unlink()
                    except Exception:
                        pass
                return False, 0.0, f"File audio cuối cùng không hợp lệ: {err_final}", metrics

            # Dọn dẹp file raw nếu khác file final
            if raw_output_path.exists() and raw_output_path != final_output_path:
                try:
                    raw_output_path.unlink()
                except Exception:
                    pass

            return True, dur_final_check, None, metrics

        except Exception as ex:
            metrics["total_fin_ms"] = int((time.time() - t_start) * 1000)
            logger.exception("Lỗi ngoại lệ trong download_and_finalize_audio")
            return False, 0.0, f"Exception trong download_and_finalize_audio: {str(ex)}", metrics

    def generate_raw_audio(
        self,
        text: str,
        voice: str,
        output_path: Path,
        timeout: float = 45.0
    ) -> Tuple[bool, float, Optional[str], Optional[str], Dict[str, int]]:
        """
        Tạo file audio thô (native 1.0x) cho subtitle text thông qua CapCut API:
        1. Gọi fetch_audio_url
        2. Tải và xác thực file
        
        Trả về: (success, duration, error_msg, task_id, timing_metrics)
        """
        ok, audio_url, task_id, err, timing = self.fetch_audio_url(text, voice, timeout)
        if not ok or not audio_url:
            return False, 0.0, err, task_id, timing

        ok_dl, dur, err_dl, dl_timing = self.download_and_finalize_audio(
            audio_url=audio_url,
            raw_output_path=output_path,
            final_output_path=output_path,
            speed=1.0,
            timeout=30.0
        )
        timing.update(dl_timing)
        timing["total_ms"] = timing.get("total_api_ms", 0) + dl_timing.get("total_fin_ms", 0)

        if not ok_dl:
            return False, 0.0, err_dl, task_id, timing

        return True, dur, None, task_id, timing

    @staticmethod
    def build_atempo_filter(speed: float) -> str:
        """
        Tạo chuỗi filter atempo cho FFmpeg.
        Do filter atempo trong FFmpeg chỉ hỗ trợ giá trị trong khoảng [0.5, 2.0]:
        - Nếu speed nằm trong khoảng [0.5, 2.0]: dùng 1 atempo.
        - Nếu speed < 0.5 hoặc > 2.0: nối chuỗi (chaining) nhiều atempo filter.
        VD: 0.4x  -> atempo=0.5,atempo=0.8
            2.5x  -> atempo=2.0,atempo=1.25
        Giữ nguyên pitch (cao độ) của giọng đọc.
        """
        if abs(speed - 1.0) <= 0.001:
            return ""

        filters = []
        curr = float(speed)

        while curr > 2.0:
            filters.append("atempo=2.0")
            curr /= 2.0

        while curr < 0.5:
            filters.append("atempo=0.5")
            curr /= 0.5

        if abs(curr - 1.0) > 0.001:
            filters.append(f"atempo={curr:.4f}".rstrip('0').rstrip('.'))

        return ",".join(filters)

    def apply_speed(
        self,
        raw_output_path: Path,
        final_output_path: Path,
        speed: float
    ) -> Tuple[bool, float, Optional[str]]:
        """
        Áp dụng tốc độ giọng đọc bằng FFmpeg atempo filter từ raw audio (1.0x):
        - Nếu speed == 1.0x: Sao chép/đổi tên file trực tiếp (0 overhead)
        - Nếu speed != 1.0x: Chạy FFmpeg atempo filter nhẹ nhàng
        - Kiểm tra tính hợp lệ của file final
        """
        raw_output_path = Path(raw_output_path)
        final_output_path = Path(final_output_path)

        if not raw_output_path.exists():
            return False, 0.0, "File raw audio không tồn tại để xử lý speed."

        final_output_path.parent.mkdir(parents=True, exist_ok=True)

        if abs(speed - 1.0) <= 0.01:
            if raw_output_path != final_output_path:
                try:
                    if final_output_path.exists():
                        final_output_path.unlink()
                    raw_output_path.rename(final_output_path)
                except Exception as ex:
                    return False, 0.0, f"Không thể đổi tên file raw audio: {ex}"
            valid, duration, check_err = self.validate_audio_file(final_output_path)
            if not valid:
                return False, 0.0, f"File audio không hợp lệ: {check_err}"
            return True, duration, None

        cmd = [
            "ffmpeg", "-y",
            "-i", str(raw_output_path),
            "-filter:a", f"atempo={speed:.2f}",
            "-threads", "2",
            "-loglevel", "error",
            "-nostats",
            str(final_output_path)
        ]
        try:
            run_res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            if run_res.returncode != 0 or not final_output_path.exists():
                return False, 0.0, f"Lỗi FFmpeg xử lý tốc độ {speed}x: {run_res.stderr}"
        except FileNotFoundError:
            logger.warning("Không tìm thấy FFmpeg trong PATH hệ thống.")
            return False, 0.0, "FFmpeg không có sẵn trong hệ thống để xử lý tốc độ."
        except Exception as ex:
            return False, 0.0, f"Ngoại lệ xử lý FFmpeg speed: {str(ex)}"

        valid, duration, check_err = self.validate_audio_file(final_output_path)
        if not valid:
            if final_output_path.exists():
                try:
                    final_output_path.unlink()
                except Exception:
                    pass
            return False, 0.0, f"File audio sau khi speed {speed}x không hợp lệ: {check_err}"

        return True, duration, None

    def generate_single_audio(
        self,
        text: str,
        voice: str,
        output_path: Path,
        speed: float = 1.0,
        timeout: float = 45.0
    ) -> Tuple[bool, float, Optional[str], Optional[str]]:
        """
        Hàm tương thích ngược: Tạo raw 1.0x từ API sau đó áp dụng speed.
        """
        raw_temp = output_path.parent / f"raw_{output_path.name}"
        ok, dur, err, task_id, _ = self.generate_raw_audio(text, voice, raw_temp, timeout)
        if not ok:
            return False, 0.0, err, task_id

        ok_sp, dur_sp, err_sp = self.apply_speed(raw_temp, output_path, speed)
        if not ok_sp:
            return False, 0.0, err_sp, task_id

        if raw_temp.exists() and raw_temp != output_path:
            try:
                raw_temp.unlink()
            except Exception:
                pass

        return True, dur_sp, None, task_id

    @staticmethod
    def validate_audio_file(file_path: Path) -> Tuple[bool, float, Optional[str]]:
        """
        Kiểm tra tính hợp lệ của file audio siêu tốc (Fast Binary MP3 Check):
        - File tồn tại & Dung lượng > 150 bytes
        - Nhận diện magic byte MP3 (ID3v2 hoặc Frame Sync MPEG)
        - Ước tính duration theo bitrate 128kbps tiêu chuẩn (16KB/s) với độ chính xác cao trong 0.05ms
        - Tránh gọi subprocess ffprobe cho từng câu để tối đa tốc độ trên Android/Termux
        """
        file_path = Path(file_path)
        if not file_path.exists():
            return False, 0.0, "File audio không tồn tại."

        try:
            size = file_path.stat().st_size
        except Exception as e:
            return False, 0.0, f"Không thể đọc thông tin file: {e}"

        if size < 150:
            return False, 0.0, f"File audio quá nhỏ ({size} bytes)."

        # Kiểm tra nhanh header nhị phân của MP3
        try:
            with open(file_path, "rb") as f:
                header = f.read(64)
            # MP3 có thể bắt đầu bằng ID3v2 (ID3) hoặc MPEG audio frame sync (0xFF 0xFB/0xF3/0xF2/0xFA/0xE0...)
            is_id3 = header.startswith(b"ID3")
            is_mpeg_sync = len(header) >= 2 and header[0] == 0xFF and (header[1] & 0xE0 == 0xE0)

            if not (is_id3 or is_mpeg_sync):
                # Nếu không phải MP3 header thông thường
                logger.warning(f"File {file_path.name} không có header MP3 chuẩn (len: {len(header)})")
        except Exception as ex:
            logger.warning(f"Lỗi kiểm tra header MP3: {ex}")

        # Tính toán thời lượng audio dựa trên chuẩn MP3 CapCut (128kbps ~ 16000 bytes/sec)
        est_dur = max(0.2, round(size / 16000.0, 2))
        return True, est_dur, None
