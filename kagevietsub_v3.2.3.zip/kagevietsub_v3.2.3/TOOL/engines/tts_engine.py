#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==================================================
KAGEVIETSUB - CAPCUT TTS ENGINE
==================================================
Tích hợp trực tiếp qua CapCutTTSAdapter kết nối tới
repository K07VN/capcut-tts-api hoàn chỉnh:
- Tự động lấy danh sách giọng Việt từ Voice.json gốc
- Tự động kiểm tra file đã tồn tại và hợp lệ (Resume)
- Tự động thử lại từng câu bị lỗi (Retry up to 3) với Error Log chi tiết
- Quản lý đa luồng worker (1 - 30 luồng)
- Điều chỉnh tốc độ giọng đọc (0.75x - 2.0x) bằng FFmpeg atempo
- Ghép nối audio chuẩn timeline SRT và lưu trực tiếp vào Download/KAGEVIETSUB
==================================================
"""

import os
import time
import json
import threading
import logging
import subprocess
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional

from TOOL.config import TEMP_DIR, OUTPUT_DIR, KAGE_DOWNLOAD_DIR, get_safe_unique_filepath
from TOOL.services.ffmpeg_service import FFmpegService
from TOOL.services.task_service import job_manager, HardwareOptimizer
from TOOL.engines.srt_engine import SrtEngine
from TOOL.engines.timeline_merger import TimelineAudioMerger
from TOOL.integrations.capcut_tts_adapter import CapCutTTSAdapter

logger = logging.getLogger("TTSEngine")

# Khởi tạo adapter mỏng duy nhất
tts_adapter = CapCutTTSAdapter()


class WorkerTracker:
    """
    Quản lý theo dõi trạng thái hoạt động thực tế của từng Worker trong TTS Engine.
    - Phân biệt rõ ràng: requested_workers vs actual_workers vs active_workers
    - Cho phép chạy toàn bộ 1..30 worker đồng thời trên network I/O
    - Không áp đặt clamp cứng 5..6 luồng, không dùng semaphore chặn luồng
    """
    def __init__(self, requested_workers: int):
        self.requested_workers = max(1, min(30, int(requested_workers)))
        self.actual_workers = self.requested_workers
        self.lock = threading.Lock()
        self.worker_states: Dict[str, str] = {}
        self.worker_latencies: List[float] = []

    def set_actual(self, count: int):
        with self.lock:
            self.actual_workers = count

    def set_worker_state(self, worker_name: str, state: str):
        with self.lock:
            self.worker_states[worker_name] = state

    def record_latency(self, latency_ms: float):
        with self.lock:
            self.worker_latencies.append(latency_ms)
            if len(self.worker_latencies) > 50:
                self.worker_latencies.pop(0)

    def get_active_count(self) -> int:
        with self.lock:
            return sum(1 for s in self.worker_states.values() if s not in ["STOPPED", "COMPLETED", "IDLE"])

    def get_summary(self) -> Dict[str, Any]:
        with self.lock:
            active_cnt = sum(1 for s in self.worker_states.values() if s not in ["STOPPED", "COMPLETED", "IDLE"])
            avg_lat = sum(self.worker_latencies) / max(1, len(self.worker_latencies)) if self.worker_latencies else 0.0
            return {
                "requested_workers": self.requested_workers,
                "actual_workers": self.actual_workers,
                "active_workers": active_cnt,
                "avg_latency_ms": round(avg_lat, 1),
                "worker_states": dict(self.worker_states)
            }


class JobStateTracker:
    """
    Source of Truth duy nhất cho trạng thái của TTS Job:
    - Quản lý versioning / revision tăng đơn điệu (monotonic integer revision)
    - Cập nhật nguyên tử (atomic updates) có Lock bảo vệ
    - Tính toán chính xác các chỉ số: completed, processing, finalizing, pending, failed, throughput/min
    - Hỗ trợ lưu Checkpoint an toàn và Reconcile trạng thái theo thực tế đĩa cứng
    """
    def __init__(self, job_id: str, sub_states: List[Dict[str, Any]], job_dir: Path, requested_workers: int, voice: str, speed: float):
        self.job_id = job_id
        self.sub_states = sub_states
        self.sub_map = {s["index"]: s for s in sub_states}
        self.job_dir = Path(job_dir)
        self.requested_workers = requested_workers
        self.actual_workers = requested_workers
        self.voice = voice
        self.speed = speed
        self.total = len(sub_states)
        self.revision = 1
        self.lock = threading.RLock()
        self.start_time = time.time()
        self.last_sync_time = 0.0

    def update_sub_stage(
        self,
        index: int,
        stage: str,
        duration: float = 0.0,
        task_id: Optional[str] = None,
        error: Optional[str] = None,
        retry_count: Optional[int] = None
    ) -> int:
        """Cập nhật trạng thái của một subtitle item và tăng revision."""
        with self.lock:
            sub = self.sub_map.get(index)
            if not sub:
                return self.revision
            sub["status"] = stage
            if duration > 0:
                sub["duration"] = duration
            if task_id:
                sub["task_id"] = task_id
            if error is not None:
                sub["error"] = error
            if retry_count is not None:
                sub["retry_count"] = retry_count
            self.revision += 1
            return self.revision

    def get_snapshot(self, include_subtitles: bool = True, worker_tracker: Optional[WorkerTracker] = None, current_retry_pass: int = 0) -> Dict[str, Any]:
        """Lấy snapshot toàn vẹn của Job với tính toán metric throughput thời gian thực."""
        with self.lock:
            ready_cnt = sum(1 for s in self.sub_states if s["status"] in ["READY_FOR_MERGE", "DONE", "COMPLETED"])
            proc_cnt = sum(1 for s in self.sub_states if s["status"] in ["API_PROCESSING", "PROCESSING", "TTS_PROCESSING"])
            fin_cnt = sum(1 for s in self.sub_states if s["status"] in ["RESULT_READY", "FINALIZING", "DOWNLOADING", "SPEED_PROCESSING", "TTS_COMPLETED"])
            retrying_cnt = sum(1 for s in self.sub_states if s["status"] == "RETRYING")
            failed_subs = [s for s in self.sub_states if s["status"] in ["FAILED", "ERROR", "FINAL_FAILED"]]
            failed_cnt = len(failed_subs)
            final_failed_cnt = sum(1 for s in self.sub_states if s["status"] == "FINAL_FAILED")
            pending_cnt = max(0, self.total - (ready_cnt + proc_cnt + fin_cnt + retrying_cnt + failed_cnt))
            failed_indices = [s["index"] for s in failed_subs]

            elapsed_sec = max(1.0, time.time() - self.start_time)
            throughput = round((ready_cnt / (elapsed_sec / 60.0)), 1)
            pct = int(ready_cnt / self.total * 100) if self.total > 0 else 100

            active_workers = worker_tracker.get_active_count() if worker_tracker else 0
            actual_workers = worker_tracker.actual_workers if worker_tracker else self.actual_workers

            snapshot = {
                "job_id": self.job_id,
                "revision": self.revision,
                "total": self.total,
                "completed": ready_cnt,
                "processing": proc_cnt,
                "finalizing": fin_cnt,
                "pending": pending_cnt,
                "failed": failed_cnt,
                "retrying": retrying_cnt,
                "final_failed": final_failed_cnt,
                "progress": pct,
                "throughput_per_min": throughput,
                "failed_indices": failed_indices,
                "retry_pass": current_retry_pass,
                "max_retries": 3,
                "threads": self.requested_workers,
                "requested_workers": self.requested_workers,
                "actual_workers": actual_workers,
                "active_workers": active_workers,
                "active_threads": f"{active_workers}/{actual_workers}",
                "voice": self.voice,
                "speed": self.speed,
                "job_dir": str(self.job_dir)
            }
            if include_subtitles:
                snapshot["subtitles"] = list(self.sub_states)
            return snapshot

    def save_checkpoint(self):
        """Lưu file checkpoint.json nguyên tử vào thư mục job."""
        try:
            with self.lock:
                snapshot = self.get_snapshot(include_subtitles=True)
            chk_path = self.job_dir / "checkpoint.json"
            tmp_path = self.job_dir / "checkpoint.tmp"
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(snapshot, f, ensure_ascii=False, indent=2)
            tmp_path.replace(chk_path)
        except Exception as ex:
            logger.warning(f"Lỗi khi lưu checkpoint: {ex}")

    def reconcile_from_disk(self) -> int:
        """
        Quét đĩa cứng để đối chiếu và căn chỉnh trạng thái thực tế của các file audio:
        - Nếu file tồn tại và vượt qua kiểm tra duration/hợp lệ -> READY_FOR_MERGE
        - Ngược lại -> giữ nguyên trạng thái lỗi hoặc PENDING
        """
        with self.lock:
            for s in self.sub_states:
                final_p = self.job_dir / s["audio_filename"]
                if final_p.exists():
                    valid, dur, _ = CapCutTTSAdapter.validate_audio_file(final_p)
                    if valid and dur > 0.05:
                        s["status"] = "READY_FOR_MERGE"
                        s["duration"] = dur
                        s["error"] = None
                    else:
                        if s["status"] in ["READY_FOR_MERGE", "DONE", "COMPLETED"]:
                            s["status"] = "FAILED"
                            s["error"] = "File audio trên đĩa không hợp lệ sau kiểm tra."
                else:
                    if s["status"] in ["READY_FOR_MERGE", "DONE", "COMPLETED"]:
                        s["status"] = "FAILED"
                        s["error"] = "Không tìm thấy file audio trên đĩa."
            self.revision += 1
            self.save_checkpoint()
            return self.revision


class TTSEngine:
    @classmethod
    def get_vietnamese_voices(cls) -> List[Dict[str, Any]]:
        """Lấy danh sách giọng đọc tiếng Việt chuẩn từ Voice.json qua CapCutTTSAdapter."""
        return tts_adapter.get_vietnamese_voices()

    @classmethod
    def get_voices(cls) -> List[Dict[str, Any]]:
        """Trả về danh sách giọng đọc tiếng Việt hợp lệ."""
        return cls.get_vietnamese_voices()

    @classmethod
    def validate_vietnamese_voice(cls, voice_input: str) -> Optional[Dict[str, Any]]:
        """Kiểm tra giọng đọc xem có nằm trong danh sách tiếng Việt hay không."""
        if not voice_input:
            return None
        v_str = str(voice_input).strip()
        for v in cls.get_vietnamese_voices():
            if v_str in (v["voice_type"], v["resource_id"], v.get("name", "")):
                return v
        return None

    @staticmethod
    def generate_single_audio(
        text: str,
        voice: str,
        output_file: Path,
        speed: float = 1.0,
        max_retries: int = 3
    ) -> Tuple[bool, float, str, Optional[str]]:
        """
        Tạo 1 file audio cho 1 câu phụ đề với cơ chế Resume & Retry:
        - Nếu file đã tồn tại và hợp lệ -> Skip (Resume)
        - Thử lại tối đa max_retries lần nếu gặp lỗi API
        - Ghi Error Log chi tiết chuẩn
        """
        output_file = Path(output_file)

        # 1. BƯỚC RESUME: Kiểm tra file đã tồn tại và hợp lệ chưa
        if output_file.exists():
            valid, dur, check_err = CapCutTTSAdapter.validate_audio_file(output_file)
            if valid and dur > 0.05:
                logger.info(f"[RESUME] File {output_file.name} đã tồn tại và hợp lệ ({dur:.2f}s). Bỏ qua tạo lại.")
                return True, dur, "", "RESUMED"

        # 2. BƯỚC RETRY LOOPS
        last_err = "Không xác định"
        last_task_id = None

        for attempt in range(1, max_retries + 1):
            ok, dur, err_msg, task_id = tts_adapter.generate_single_audio(
                text=text,
                voice=voice,
                output_path=output_file,
                speed=speed,
                timeout=45.0
            )

            if ok:
                return True, dur, "", task_id

            last_err = err_msg or "Lỗi gọi API CapCut"
            last_task_id = task_id

            err_log_formatted = (
                f"\n[TTS] Subtitle Output: {output_file.name}\n"
                f"[TEXT] '{text}'\n"
                f"[VOICE] {voice}\n"
                f"[TASK] {task_id or 'N/A'}\n"
                f"[STATUS] FAILED\n"
                f"[ERROR] {last_err}\n"
                f"[RETRY] {attempt}/{max_retries}\n"
            )
            logger.warning(err_log_formatted)
            print(err_log_formatted, flush=True)

            if attempt < max_retries:
                time.sleep(0.5 * attempt)

        full_failure_msg = f"[TASK: {last_task_id or 'N/A'}] [RETRY: {max_retries}/{max_retries}] FAILED: {last_err}"
        return False, 0.0, full_failure_msg, last_task_id

    @staticmethod
    def process_tts_job(
        job_id: str,
        subtitles: List[Dict[str, Any]],
        voice: str = "BV421_vivn_streaming",
        speed: float = 1.0,
        threads: int = 5
    ) -> Dict[str, Any]:
        """
        Xử lý pipeline TTS với mô hình gối đầu 80/20 (Conveyor Pipeline) & State API chuẩn:
        - Tách biệt 2 giai đoạn:
          1. Giai đoạn 80% (TTS Request Workers 1..30): Gọi API tạo + query task.
             Ngay khi nhận được audio_url (RESULT_READY), lập tức đẩy vào finalization_queue
             và lấy câu tiếp theo NGAY LẬP TỨC (chạy gối đầu, không chờ I/O).
          2. Giai đoạn 20% (Audio Finalization Workers): Tải audio stream, áp dụng tốc độ,
             xác thực file trên đĩa và cập nhật trạng thái COMPLETED/READY_FOR_MERGE.
        - Source of Truth duy nhất qua JobStateTracker với revision tăng đơn điệu.
        - Không bao giờ đánh dấu COMPLETED ảo; chỉ hoàn thành khi file đã tồn tại và hợp lệ trên đĩa.
        - Cơ chế bỏ qua lỗi thông minh & 3 đợt retry gối đầu tự động.
        """
        import queue
        import threading

        job_dir = TEMP_DIR / "tts" / f"job_{job_id}"
        job_dir.mkdir(parents=True, exist_ok=True)

        hw_profile = HardwareOptimizer.get_hardware_profile()
        requested_threads = max(1, min(30, int(threads)))
        total = len(subtitles)

        # Số lượng worker cho Finalization (I/O, FFmpeg speed, Disk write)
        num_finalization_workers = max(4, min(8, hw_profile["cpu_cores"] + 2))

        worker_tracker = WorkerTracker(requested_workers=requested_threads)
        ctx = job_manager.get_control_context(job_id)

        if not job_manager.get_job(job_id):
            with job_manager._lock:
                job_manager._jobs[job_id] = {
                    "job_id": job_id,
                    "type": "tts_generation",
                    "status": "queued",
                    "progress": 0,
                    "message": "Task queued...",
                    "created_at": time.time(),
                    "error": None,
                    "result": None,
                    "metadata": {}
                }

        # Chuẩn bị danh sách subtitle state với khóa duy nhất
        sub_states: List[Dict[str, Any]] = []
        for idx, sub in enumerate(subtitles, 1):
            sub_states.append({
                "index": idx,
                "id": sub.get("id") or f"{idx:04d}",
                "task_key": f"{job_id}:{idx:04d}",
                "start": sub.get("start", "00:00:00,000"),
                "end": sub.get("end", "00:00:00,000"),
                "start_ms": SrtEngine.time_to_ms(sub.get("start", "00:00:00,000")),
                "end_ms": SrtEngine.time_to_ms(sub.get("end", "00:00:00,000")),
                "text": (sub.get("text") or "").strip(),
                "status": "PENDING",  # PENDING | API_PROCESSING | RESULT_READY | FINALIZING | READY_FOR_MERGE | FAILED | RETRYING | FINAL_FAILED
                "duration": 0.0,
                "task_id": None,
                "error": None,
                "retry_count": 0,
                "audio_filename": f"{idx:04d}.mp3",
                "raw_filename": f"raw_{idx:04d}.mp3"
            })

        state_tracker = JobStateTracker(
            job_id=job_id,
            sub_states=sub_states,
            job_dir=job_dir,
            requested_workers=requested_threads,
            voice=voice,
            speed=speed
        )

        job_manager.update_job(
            job_id,
            status="processing",
            progress=0,
            message=f"Đang tạo TTS: 0/{total} (Thành công: 0, Chờ xử lý: {total}) - Retry: 0/3",
            result=state_tracker.get_snapshot(include_subtitles=True, worker_tracker=worker_tracker, current_retry_pass=0)
        )

        finalization_queue = queue.Queue()
        sync_lock = threading.Lock()
        last_sync_time = 0.0

        def _sync_job_progress(force: bool = False, current_retry_pass: int = 0, stage_msg: Optional[str] = None):
            nonlocal last_sync_time
            now = time.time()
            if not force and (now - last_sync_time) < 0.15:
                return

            with sync_lock:
                last_sync_time = time.time()
                snapshot = state_tracker.get_snapshot(
                    include_subtitles=True,
                    worker_tracker=worker_tracker,
                    current_retry_pass=current_retry_pass
                )
                ready_cnt = snapshot["completed"]
                failed_cnt = snapshot["failed"]
                retrying_cnt = snapshot["retrying"]
                proc_cnt = snapshot["processing"]
                fin_cnt = snapshot["finalizing"]
                processed_total = ready_cnt + failed_cnt + retrying_cnt + proc_cnt + fin_cnt

                if stage_msg:
                    msg = stage_msg
                elif current_retry_pass == 0:
                    msg = f"Đang tạo: {ready_cnt}/{total} xong (Gối đầu: {proc_cnt + fin_cnt}, Lỗi: {failed_cnt}) - {snapshot['throughput_per_min']} câu/phút"
                else:
                    msg = f"Đang retry lần {current_retry_pass}/3 (Còn {failed_cnt + retrying_cnt} câu lỗi)..."

                job_manager.update_job(
                    job_id,
                    progress=snapshot["progress"],
                    message=msg,
                    result=snapshot
                )

        # ======================================================================
        # GIAI ĐOẠN 20%: AUDIO FINALIZATION WORKERS (Background I/O & Speed)
        # ======================================================================
        def _finalization_worker_loop():
            while True:
                try:
                    task = finalization_queue.get(timeout=0.25)
                except queue.Empty:
                    if ctx.is_stopped() or job_manager.shutdown_requested:
                        break
                    continue

                if task is None:
                    finalization_queue.task_done()
                    break

                sub_item = task["sub"]
                audio_url = task.get("audio_url")
                raw_p = task["raw_path"]
                final_p = task["final_path"]
                tgt_sp = task["speed"]
                pass_num = task.get("retry_pass", 0)

                if ctx.is_stopped() or job_manager.shutdown_requested:
                    state_tracker.update_sub_stage(sub_item["index"], "FAILED", error="Tiến trình đã bị dừng.")
                    _sync_job_progress(force=True, current_retry_pass=pass_num)
                    finalization_queue.task_done()
                    continue

                state_tracker.update_sub_stage(sub_item["index"], "FINALIZING")
                _sync_job_progress(current_retry_pass=pass_num)

                ok, dur, err_msg, timing = tts_adapter.download_and_finalize_audio(
                    audio_url=audio_url,
                    raw_output_path=raw_p,
                    final_output_path=final_p,
                    speed=tgt_sp,
                    timeout=30.0
                )

                if ok and dur > 0.05:
                    state_tracker.update_sub_stage(
                        sub_item["index"],
                        "READY_FOR_MERGE",
                        duration=dur,
                        error=None
                    )
                else:
                    state_tracker.update_sub_stage(
                        sub_item["index"],
                        "FAILED",
                        error=err_msg or "Lỗi tải hoặc xác thực file audio cuối cùng",
                        retry_count=pass_num
                    )

                _sync_job_progress(current_retry_pass=pass_num)
                finalization_queue.task_done()

        # Khởi động background finalization workers
        fin_threads = []
        for _ in range(num_finalization_workers):
            t = threading.Thread(target=_finalization_worker_loop, daemon=True)
            t.start()
            fin_threads.append(t)

        # ======================================================================
        # GIAI ĐOẠN 80%: TTS REQUEST EXECUTION (Gọi API & Cấp task gối đầu)
        # ======================================================================
        def _execute_request_stage(sub_item: Dict[str, Any], worker_name: str = "TTS Worker", current_retry_pass: int = 0):
            final_p = job_dir / sub_item["audio_filename"]
            raw_p = job_dir / sub_item["raw_filename"]
            item_text = sub_item["text"]

            # 1. Kiểm tra Resume file final
            if final_p.exists():
                v, dur_f, _ = CapCutTTSAdapter.validate_audio_file(final_p)
                if v and dur_f > 0.05:
                    state_tracker.update_sub_stage(sub_item["index"], "READY_FOR_MERGE", duration=dur_f, error=None)
                    _sync_job_progress(current_retry_pass=current_retry_pass)
                    return

            # 2. Kiểm tra Stop / Pause
            if ctx.is_stopped() or job_manager.shutdown_requested:
                state_tracker.update_sub_stage(sub_item["index"], "FAILED", error="Tiến trình đã bị dừng bởi người dùng.")
                _sync_job_progress(current_retry_pass=current_retry_pass)
                return

            if not ctx.wait_if_paused(timeout=None):
                return

            if ctx.is_stopped() or job_manager.shutdown_requested:
                return

            if not item_text:
                silence_ok = _create_silence_audio(0.5, final_p)
                if silence_ok:
                    state_tracker.update_sub_stage(sub_item["index"], "READY_FOR_MERGE", duration=0.5, error=None)
                else:
                    state_tracker.update_sub_stage(sub_item["index"], "FAILED", error="Dòng phụ đề rỗng.")
                _sync_job_progress(current_retry_pass=current_retry_pass)
                return

            state_tracker.update_sub_stage(sub_item["index"], "API_PROCESSING")
            _sync_job_progress(current_retry_pass=current_retry_pass)

            # Gọi CapCut API (giai đoạn 80%) lấy audio_url
            ok_url, audio_url, task_id, err_api, timing = tts_adapter.fetch_audio_url(
                text=item_text,
                voice=voice,
                timeout=45.0
            )
            worker_tracker.record_latency(timing.get("total_api_ms", 500))

            if not ok_url or not audio_url:
                logger.info(f"[{worker_name}] Sub #{sub_item['index']:03d} | API FAILED: {err_api}")
                state_tracker.update_sub_stage(
                    sub_item["index"],
                    "FAILED",
                    task_id=task_id,
                    error=err_api or "Lỗi gọi API CapCut",
                    retry_count=current_retry_pass
                )
                _sync_job_progress(current_retry_pass=current_retry_pass)
                return

            logger.info(f"[{worker_name}] Sub #{sub_item['index']:03d} | API: {timing.get('api_ms', 0)}ms | Query: {timing.get('query_ms', 0)}ms | RESULT_READY -> Enqueue Finalization")

            # 80/20 Pipeline Overlap: Đẩy vào finalization_queue, giải phóng ngay TTS worker
            state_tracker.update_sub_stage(
                sub_item["index"],
                "FINALIZING",
                task_id=task_id
            )
            finalization_queue.put({
                "sub": sub_item,
                "audio_url": audio_url,
                "task_id": task_id,
                "raw_path": raw_p,
                "final_path": final_p,
                "speed": speed,
                "retry_pass": current_retry_pass
            })
            _sync_job_progress(current_retry_pass=current_retry_pass)

        # ======================================================================
        # GIAI ĐOẠN 1: LƯỢT TẠO CHÍNH (MAIN PASS) - TOÀN BỘ WORKER (1..30)
        # ======================================================================
        main_task_queue = queue.Queue()
        for s in sub_states:
            main_task_queue.put(s)

        def _main_worker_loop(worker_name: str, worker_id: int):
            logger.info(f"[{worker_name}] Started")
            print(f"[{worker_name}] Started", flush=True)
            worker_tracker.set_worker_state(worker_name, "RUNNING")

            while not main_task_queue.empty():
                if ctx.is_stopped() or job_manager.shutdown_requested:
                    worker_tracker.set_worker_state(worker_name, "STOPPED")
                    break
                if not ctx.wait_if_paused(timeout=0.2):
                    continue
                if ctx.is_stopped() or job_manager.shutdown_requested:
                    worker_tracker.set_worker_state(worker_name, "STOPPED")
                    break

                try:
                    item = main_task_queue.get_nowait()
                except queue.Empty:
                    break

                worker_tracker.set_worker_state(worker_name, f"SUB_{item['index']:03d}")
                try:
                    _execute_request_stage(item, worker_name=worker_name, current_retry_pass=0)
                except Exception as ex:
                    state_tracker.update_sub_stage(item["index"], "FAILED", error=str(ex))
                    logger.error(f"[{worker_name}] Lỗi Sub #{item['index']:03d}: {ex}")
                    _sync_job_progress(current_retry_pass=0)
                finally:
                    main_task_queue.task_done()
                    worker_tracker.set_worker_state(worker_name, "IDLE")

            worker_tracker.set_worker_state(worker_name, "COMPLETED")

        logger.info(f"[TTS] Requested workers: {requested_threads}")
        logger.info(f"[TTS] Finalization workers: {num_finalization_workers}")
        logger.info(f"[TTS] Creating workers...")

        tts_threads = []
        for i in range(1, requested_threads + 1):
            worker_name = f"TTS Worker {i:02d}"
            try:
                t = threading.Thread(
                    target=_main_worker_loop,
                    args=(worker_name, i),
                    name=worker_name,
                    daemon=True
                )
                t.start()
                tts_threads.append(t)
                worker_tracker.set_worker_state(worker_name, "STARTED")
            except Exception as ex:
                logger.error(f"[TTS] Lỗi không thể tạo thread {worker_name}: {ex}")

        actual_workers = len(tts_threads)
        worker_tracker.set_actual(actual_workers)
        state_tracker.actual_workers = actual_workers

        for t in tts_threads:
            t.join()

        # Đợi các tác vụ download & finalization của main pass hoàn thành
        finalization_queue.join()
        state_tracker.reconcile_from_disk()
        _sync_job_progress(force=True, current_retry_pass=0)

        # ======================================================================
        # GIAI ĐOẠN 2: LƯỢT RETRY THEO ĐỢT (RETRY PASS 1 -> 2 -> 3)
        # ======================================================================
        if not (ctx.is_stopped() or job_manager.shutdown_requested):
            failed_subs = [
                s for s in sub_states 
                if s["status"] not in ["READY_FOR_MERGE", "DONE", "COMPLETED"] 
                or not (job_dir / s["audio_filename"]).exists()
            ]

            if failed_subs:
                _sync_job_progress(
                    force=True, 
                    current_retry_pass=0, 
                    stage_msg="Đã tạo xong lượt chính. Đang kiểm tra các câu lỗi..."
                )

                for retry_pass in range(1, 4):
                    if ctx.is_stopped() or job_manager.shutdown_requested:
                        break

                    current_failed = [
                        s for s in sub_states 
                        if s["status"] not in ["READY_FOR_MERGE", "DONE", "COMPLETED"]
                        or not (job_dir / s["audio_filename"]).exists()
                    ]

                    if not current_failed:
                        logger.info(f"Tất cả câu đã thành công trước Retry {retry_pass}.")
                        break

                    logger.info(f"Bắt đầu RETRY lần {retry_pass}/3 cho {len(current_failed)} câu bị lỗi...")
                    for s in current_failed:
                        state_tracker.update_sub_stage(s["index"], "RETRYING", retry_count=retry_pass)

                    _sync_job_progress(
                        force=True, 
                        current_retry_pass=retry_pass, 
                        stage_msg=f"Đang retry lần {retry_pass}/3 (còn {len(current_failed)} câu lỗi)..."
                    )

                    retry_queue = queue.Queue()
                    for s in current_failed:
                        retry_queue.put(s)

                    def _retry_worker_loop(worker_name: str, pass_num: int):
                        logger.info(f"[{worker_name}] Started (Retry Pass {pass_num})")

                        while not retry_queue.empty():
                            if ctx.is_stopped() or job_manager.shutdown_requested:
                                break
                            if not ctx.wait_if_paused(timeout=0.2):
                                continue
                            if ctx.is_stopped() or job_manager.shutdown_requested:
                                break

                            try:
                                item = retry_queue.get_nowait()
                            except queue.Empty:
                                break

                            try:
                                _execute_request_stage(item, worker_name=worker_name, current_retry_pass=pass_num)
                            except Exception as ex:
                                state_tracker.update_sub_stage(item["index"], "FAILED", error=str(ex))
                                _sync_job_progress(current_retry_pass=pass_num)
                            finally:
                                retry_queue.task_done()

                    r_threads = []
                    retry_worker_count = min(requested_threads, len(current_failed))
                    for i in range(1, retry_worker_count + 1):
                        r_name = f"Retry Worker {i:02d}"
                        rt = threading.Thread(
                            target=_retry_worker_loop,
                            args=(r_name, retry_pass),
                            name=r_name,
                            daemon=True
                        )
                        rt.start()
                        r_threads.append(rt)

                    for rt in r_threads:
                        rt.join()

                    # Đợi finalization queue hoàn thành cho đợt retry này
                    finalization_queue.join()
                    state_tracker.reconcile_from_disk()

                    still_failed = [
                        s for s in sub_states 
                        if s["status"] not in ["READY_FOR_MERGE", "DONE", "COMPLETED"]
                        or not (job_dir / s["audio_filename"]).exists()
                    ]

                    if retry_pass == 3:
                        for s in still_failed:
                            state_tracker.update_sub_stage(s["index"], "FINAL_FAILED", retry_count=3)

                    _sync_job_progress(
                        force=True, 
                        current_retry_pass=retry_pass, 
                        stage_msg=f"Retry {retry_pass}/3: Còn lỗi {len(still_failed)} câu" if still_failed else "✓ Tất cả câu lỗi đã được sửa thành công"
                    )

                    if not still_failed:
                        break

        # Dừng background finalization workers
        for _ in range(num_finalization_workers):
            finalization_queue.put(None)

        for t in fin_threads:
            t.join()

        # ======================================================================
        # GIAI ĐOẠN 3: ĐỐI CHIẾU THỰC TẾ & HOÀN TẤT TIẾN TRÌNH
        # ======================================================================
        state_tracker.reconcile_from_disk()
        snapshot = state_tracker.get_snapshot(include_subtitles=True, worker_tracker=worker_tracker)

        final_ready = snapshot["completed"]
        final_err = snapshot["failed"]
        failed_indices = snapshot["failed_indices"]
        is_stopped = ctx.is_stopped() or job_manager.shutdown_requested

        if is_stopped:
            final_status = "stopped"
            final_msg = "⏹ Tiến trình TTS đã dừng."
        elif final_err == 0:
            final_status = "completed"
            final_msg = "✓ Tất cả TTS đã tạo thành công. Sẵn sàng ghép audio."
        else:
            final_status = "completed_with_errors"
            idx_list_str = ", ".join(str(i) for i in failed_indices[:15])
            if len(failed_indices) > 15:
                idx_list_str += f"... (+{len(failed_indices) - 15} câu nữa)"
            final_msg = f"⚠ Hoàn tất nhưng còn {final_err} câu không thể tạo TTS (Đã thử tối đa 3 lần). Câu lỗi: {idx_list_str}"

        job_manager.update_job(
            job_id,
            status=final_status,
            progress=100 if not is_stopped else snapshot["progress"],
            message=final_msg,
            result=snapshot
        )

        state_tracker.save_checkpoint()
        return job_manager.get_job(job_id) or {}

    @staticmethod
    def retry_subtitle(
        job_id: str,
        subtitle_index: int,
        voice: Optional[str] = None,
        speed: Optional[float] = None
    ) -> Dict[str, Any]:
        """Thử lại tạo duy nhất 1 câu phụ đề bị lỗi."""
        job = job_manager.get_job(job_id)
        if not job or not job.get("result"):
            raise ValueError(f"Không tìm thấy dữ liệu job '{job_id}'.")

        res = job["result"]
        sub_states: List[Dict[str, Any]] = res.get("subtitles", [])
        job_dir = Path(res.get("job_dir", str(TEMP_DIR / "tts" / f"job_{job_id}")))
        use_voice = voice or res.get("voice", "BV421_vivn_streaming")
        use_speed = speed if speed is not None else float(res.get("speed", 1.0))

        target_sub = next((s for s in sub_states if s["index"] == subtitle_index), None)
        if not target_sub:
            raise ValueError(f"Không tìm thấy câu phụ đề số {subtitle_index} trong job.")

        target_sub["status"] = "TTS_PROCESSING"
        target_sub["error"] = None

        job_manager.update_job(
            job_id,
            message=f"Đang thử lại câu số {subtitle_index}...",
            result=res
        )

        final_path = job_dir / target_sub["audio_filename"]
        raw_path = job_dir / target_sub.get("raw_filename", f"raw_{target_sub['audio_filename']}")

        if final_path.exists():
            final_path.unlink()
        if raw_path.exists():
            raw_path.unlink()

        ok_raw, dur_raw, err_raw, task_id, timing = tts_adapter.generate_raw_audio(
            text=target_sub["text"],
            voice=use_voice,
            output_path=raw_path,
            timeout=45.0
        )

        if ok_raw:
            target_sub["task_id"] = task_id
            if abs(use_speed - 1.0) <= 0.01:
                try:
                    if final_path.exists():
                        final_path.unlink()
                    raw_path.rename(final_path)
                except Exception:
                    pass
                
                v_ok, dur_ok, err_v = CapCutTTSAdapter.validate_audio_file(final_path)
                if v_ok and dur_ok > 0.05:
                    target_sub["status"] = "READY_FOR_MERGE"
                    target_sub["duration"] = dur_ok
                    target_sub["error"] = None
                else:
                    target_sub["status"] = "FINAL_FAILED"
                    target_sub["error"] = f"File audio không hợp lệ: {err_v}"
            else:
                target_sub["status"] = "SPEED_PROCESSING"
                ok_sp, dur_sp, err_sp = tts_adapter.apply_speed(raw_path, final_path, use_speed)
                if ok_sp:
                    target_sub["status"] = "READY_FOR_MERGE"
                    target_sub["duration"] = dur_sp
                    target_sub["error"] = None
                    try:
                        if raw_path.exists() and raw_path != final_path:
                            raw_path.unlink()
                    except Exception:
                        pass
                else:
                    target_sub["status"] = "FINAL_FAILED"
                    target_sub["error"] = f"Lỗi FFmpeg speed: {err_sp}"
        else:
            target_sub["status"] = "FINAL_FAILED"
            target_sub["task_id"] = task_id
            target_sub["error"] = err_raw

        c_ready = sum(1 for s in sub_states if s["status"] in ["READY_FOR_MERGE", "DONE", "COMPLETED"])
        c_err = sum(1 for s in sub_states if s["status"] in ["FAILED", "ERROR", "FINAL_FAILED"])
        failed_indices = [s["index"] for s in sub_states if s["status"] in ["FAILED", "ERROR", "FINAL_FAILED"]]
        res["completed"] = c_ready
        res["failed"] = c_err
        res["failed_indices"] = failed_indices

        final_status = "tts_completed" if c_err == 0 else "completed_with_errors"
        if c_err == 0:
            final_msg = "✓ Tất cả TTS đã tạo thành công. Sẵn sàng ghép audio."
        else:
            idx_list_str = ", ".join(str(i) for i in failed_indices[:15])
            if len(failed_indices) > 15:
                idx_list_str += f"... (+{len(failed_indices) - 15} câu nữa)"
            final_msg = f"⚠ Hoàn tất nhưng còn {c_err} câu không thể tạo TTS. Câu lỗi: {idx_list_str}"

        job_manager.update_job(
            job_id,
            status=final_status,
            merge_status="idle",
            message=final_msg,
            result=res
        )

        return job_manager.get_job(job_id) or {}

    @staticmethod
    def pause_job(job_id: str) -> Dict[str, Any]:
        """Tạm dừng job TTS đang chạy."""
        job = job_manager.get_job(job_id)
        if not job:
            raise ValueError(f"Không tìm thấy job '{job_id}'.")
        job_manager.update_job(job_id, status="paused", message="⏸ Tiến trình TTS đã được tạm dừng.")
        return job_manager.get_job(job_id) or {}

    @staticmethod
    def resume_job(job_id: str) -> Dict[str, Any]:
        """Tiếp tục job TTS đang bị tạm dừng."""
        job = job_manager.get_job(job_id)
        if not job:
            raise ValueError(f"Không tìm thấy job '{job_id}'.")
        if job.get("status") == "paused":
            job_manager.update_job(job_id, status="processing", message="▶ Đang tiếp tục tiến trình TTS...")
        return job_manager.get_job(job_id) or {}

    @staticmethod
    def stop_job(job_id: str) -> Dict[str, Any]:
        """Dừng hẳn job TTS đang chạy."""
        job = job_manager.get_job(job_id)
        if not job:
            raise ValueError(f"Không tìm thấy job '{job_id}'.")
        job_manager.update_job(job_id, status="stopped", message="⏹ Tiến trình TTS đã bị dừng bởi người dùng.")
        return job_manager.get_job(job_id) or {}

    @classmethod
    def recover_job_from_disk(cls, job_id: str) -> Optional[Dict[str, Any]]:
        """
        Khôi phục Job sau khi server crash hoặc restart (Crash Recovery):
        1. Đọc checkpoint.json từ thư mục temp/tts/job_{job_id}/
        2. Quét toàn bộ file audio thực tế trên đĩa cứng
        3. Đối chiếu và xác thực audio từng câu
        4. Đồng bộ lại các biến đếm (completed, failed, pending) theo đúng thực tế đĩa cứng
        5. Đăng ký lại vào job_manager để tiếp tục theo dõi
        """
        chk_path = TEMP_DIR / "tts" / f"job_{job_id}" / "checkpoint.json"
        if not chk_path.exists():
            return None

        try:
            with open(chk_path, "r", encoding="utf-8") as f:
                checkpoint = json.load(f)

            job_dir = Path(checkpoint.get("job_dir", str(TEMP_DIR / "tts" / f"job_{job_id}")))
            sub_states = checkpoint.get("subtitles", [])
            total = len(sub_states)

            # Khởi tạo tracker và đối chiếu thực tế đĩa cứng
            tracker = JobStateTracker(
                job_id=job_id,
                sub_states=sub_states,
                job_dir=job_dir,
                requested_workers=checkpoint.get("requested_workers", 5),
                voice=checkpoint.get("voice", "BV421_vivn_streaming"),
                speed=checkpoint.get("speed", 1.0)
            )
            tracker.reconcile_from_disk()
            snapshot = tracker.get_snapshot(include_subtitles=True)

            status = "completed" if snapshot["completed"] == total and total > 0 else (
                "completed_with_errors" if snapshot["failed"] > 0 and (snapshot["completed"] + snapshot["failed"]) == total else "paused"
            )

            job_dict = {
                "job_id": job_id,
                "type": "tts_generation",
                "status": status,
                "progress": snapshot["progress"],
                "message": f"Đã khôi phục từ checkpoint: {snapshot['completed']}/{total} câu audio hợp lệ trên đĩa.",
                "download_url": None,
                "filename": None,
                "saved_path": None,
                "saved_location": None,
                "created_at": time.time(),
                "completed_at": time.time() if status in ["completed", "completed_with_errors"] else None,
                "error": None,
                "result": snapshot,
                "metadata": {
                    "threads": snapshot["requested_workers"],
                    "voice": snapshot["voice"],
                    "speed": snapshot["speed"],
                    "total_subtitles": total
                }
            }

            with job_manager._lock:
                job_manager._jobs[job_id] = job_dict

            return job_dict
        except Exception as ex:
            logger.warning(f"Lỗi khi khôi phục checkpoint cho job '{job_id}': {ex}")
            return None

    @staticmethod
    def merge_tts_audio_by_srt(
        job_id: str,
        output_filename: str = "tts_final_audio.mp3"
    ) -> Tuple[bool, str, Path]:
        """
        Ghép các file audio của từng subtitle theo mốc thời gian SRT:
        - Đặt audio đúng start timestamp của từng câu (Source of Truth)
        - Hỗ trợ AUDIO OVERLAP (trộn amix các audio chồng lên nhau tại cùng mốc thời gian)
        - Tự động chèn khoảng lặng (silence) ở các khoảng trống
        - Chia timeline thành các Chunk 5 phút (300,000ms) để tối ưu hiệu năng
        - Kiểm tra tính hợp lệ của file xuất
        - Quản lý Checkpoint & Resume (PENDING, PROCESSING, COMPLETED, FAILED)
        - TỰ ĐỘNG XÓA FILE TẠM CỦA JOB CHỈ KHI VALIDATE THÀNH CÔNG
        - Lưu trực tiếp vào Download/KAGEVIETSUB/
        """
        job = job_manager.get_job(job_id)
        if not job or not job.get("result"):
            raise ValueError(f"Không tìm thấy job '{job_id}'.")

        res = job["result"]
        sub_states: List[Dict[str, Any]] = res.get("subtitles", [])
        job_dir = Path(res.get("job_dir", str(TEMP_DIR / "tts" / f"job_{job_id}")))

        if not sub_states:
            raise ValueError("Danh sách phụ đề rỗng.")

        missing_subs = [s["index"] for s in sub_states if s.get("status") not in ["READY_FOR_MERGE", "DONE", "COMPLETED"]]
        if missing_subs:
            missing_str = ", ".join(str(i) for i in missing_subs[:8])
            if len(missing_subs) > 8:
                missing_str += f"... (+{len(missing_subs)-8} câu nữa)"
            raise ValueError(f"Còn {len(missing_subs)} câu phụ đề chưa hoàn thành hoặc bị lỗi ({missing_str}). Vui lòng tạo đủ trước khi ghép.")

        def _report_progress(pct: int, msg: str):
            job_manager.update_job(
                job_id,
                status="merging",
                merge_status="merging",
                progress=pct,
                message=msg
            )

        ok, msg, out_path = TimelineAudioMerger.merge(
            job_id=job_id,
            sub_states=sub_states,
            job_dir=job_dir,
            output_filename=output_filename,
            progress_callback=_report_progress
        )

        if ok:
            size_mb = round(os.path.getsize(out_path) / (1024 * 1024), 2)
            saved_loc = f"Download/KAGEVIETSUB/{out_path.name}"
            success_msg = f"✓ Đã ghép audio thành công ({size_mb} MB). File đã lưu vào: {saved_loc}"

            job_manager.update_job(
                job_id,
                status="merged",
                merge_status="completed",
                progress=100,
                message=success_msg,
                filename=out_path.name,
                saved_path=str(out_path),
                saved_location=saved_loc,
                download_url=f"/api/download/{urllib.parse.quote(out_path.name)}"
            )

            return True, success_msg, out_path
        else:
            job_manager.update_job(
                job_id,
                status="tts_completed",
                merge_status="failed",
                error=msg,
                message=f"Lỗi ghép audio: {msg}"
            )
            return False, msg, out_path


def _create_silence_audio(duration_sec: float, out_file: Path) -> bool:
    """Tạo một đoạn audio silence chuẩn 44100Hz Stereo qua FFmpeg lavfi."""
    dur = max(0.05, float(duration_sec))
    cmd = [
        "ffmpeg", "-y", "-f", "lavfi",
        "-i", "anullsrc=r=44100:cl=stereo",
        "-t", f"{dur:.3f}",
        "-vn", "-ar", "44100", "-ac", "2", "-b:a", "192k",
        str(out_file), "-loglevel", "error"
    ]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True)
        return r.returncode == 0 and out_file.exists()
    except Exception:
        return False

