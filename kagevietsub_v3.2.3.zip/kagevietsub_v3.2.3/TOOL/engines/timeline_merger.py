#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB - TIMELINE AUDIO MERGER ENGINE
==============================================================================
Kiến trúc Audio Merge Engine tối ưu cho Android / Termux / Server:
SRT → Timeline Builder → Chunk Planner → Merge Checkpoint Manager → Chunk Mixer → Finalizer

Đặc điểm:
- Ghép audio chuẩn timeline SRT (START TIME làm Source of Truth)
- Hỗ trợ AUDIO OVERLAP (trộn bằng amix không cắt/lùi/chờ/dịch câu)
- Tự động chèn SILENCE khoảng trống
- Chia timeline thành các Chunk 5 phút (300,000ms)
- Quản lý trạng thái Checkpoint & Resume (PENDING, PROCESSING, COMPLETED, FAILED)
- Sub-batching tối đa 50 câu/lần mix để tiết kiệm RAM & tránh quá tải File Descriptor trên Android
- Dọn dẹp tài nguyên temp CHỈ KHI VALIDATE THÀNH CÔNG
==============================================================================
"""

import os
import gc
import json
import logging
import subprocess
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional, Callable

from TOOL.config import TEMP_DIR, KAGE_DOWNLOAD_DIR, get_safe_unique_filepath
from TOOL.services.ffmpeg_service import FFmpegService
from TOOL.integrations.capcut_tts_adapter import CapCutTTSAdapter

logger = logging.getLogger("TimelineAudioMerger")


class TimelineBuilder:
    @staticmethod
    def build_timeline(sub_states: List[Dict[str, Any]], job_dir: Path) -> Tuple[List[Dict[str, Any]], int]:
        """
        Xây dựng timeline từ danh sách câu phụ đề SRT và file audio tương ứng.
        Mốc START TIME của SRT là Source of Truth.
        """
        items = []
        for sub in sub_states:
            audio_filename = sub.get("audio_filename") or f"{sub['index']:04d}.mp3"
            audio_file = job_dir / audio_filename
            if not audio_file.exists():
                raise FileNotFoundError(f"Không tìm thấy file audio cho câu số {sub['index']}: {audio_file.name}")

            s_ms = int(sub["start_ms"])
            d_sec = float(sub.get("duration", 0.0))
            if d_sec <= 0:
                info = FFmpegService.get_media_info(audio_file)
                d_sec = float(info.get("duration", 1.0))
            d_ms = max(100, int(d_sec * 1000))

            items.append({
                "index": sub["index"],
                "file": audio_file,
                "start_ms": s_ms,
                "end_ms": s_ms + d_ms,
                "duration_ms": d_ms,
                "text": sub.get("text", "")
            })

        items.sort(key=lambda x: x["start_ms"])
        max_timeline_ms = max((it["end_ms"] for it in items), default=1000)
        return items, max_timeline_ms


class ChunkPlanner:
    @staticmethod
    def plan_chunks(
        items: List[Dict[str, Any]],
        max_timeline_ms: int,
        chunk_size_ms: int = 300000
    ) -> List[Dict[str, Any]]:
        """
        Phân chia timeline thành các Chunk 5 phút (300,000ms).
        Lọc danh sách các câu phụ đề có mốc thời gian giao thoa với khoảng chunk [c_start, c_end).
        """
        num_chunks = max(1, (max_timeline_ms + chunk_size_ms - 1) // chunk_size_ms)
        chunks = []

        for k in range(num_chunks):
            c_start = k * chunk_size_ms
            c_end = (k + 1) * chunk_size_ms if k < num_chunks - 1 else max(c_start + 1000, max_timeline_ms)
            c_dur_sec = max(0.1, (c_end - c_start) / 1000.0)

            chunk_items = [
                it for it in items
                if it["start_ms"] < c_end and it["end_ms"] > c_start
            ]

            chunks.append({
                "index": k,
                "c_start": c_start,
                "c_end": c_end,
                "duration_sec": c_dur_sec,
                "chunk_items": chunk_items,
                "filename": f"chunk_{k:04d}.mp3"
            })

        return chunks


class MergeCheckpointManager:
    def __init__(self, job_dir: Path):
        self.job_dir = job_dir
        self.ckpt_file = job_dir / "merge_checkpoint.json"

    def load_checkpoint(self) -> Optional[Dict[str, Any]]:
        if self.ckpt_file.exists():
            try:
                with open(self.ckpt_file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                return None
        return None

    def save_checkpoint(self, checkpoint_data: Dict[str, Any]):
        try:
            with open(self.ckpt_file, "w", encoding="utf-8") as f:
                json.dump(checkpoint_data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.warning(f"Lỗi lưu merge checkpoint: {e}")

    def init_checkpoint(self, total_chunks: int, chunk_plans: List[Dict[str, Any]]) -> Dict[str, Any]:
        existing = self.load_checkpoint()
        if existing and existing.get("total_chunks") == total_chunks:
            # Re-verify completed chunk files
            for chunk_data in existing.get("chunks", []):
                idx = chunk_data["index"]
                c_file = self.job_dir / f"chunk_{idx:04d}.mp3"
                if chunk_data["status"] == "COMPLETED":
                    if not c_file.exists() or c_file.stat().st_size == 0:
                        chunk_data["status"] = "PENDING"
                        chunk_data["error"] = "File chunk không tồn tại trên đĩa."
            self.save_checkpoint(existing)
            return existing

        new_data = {
            "job_id": self.job_dir.name,
            "total_chunks": total_chunks,
            "chunk_size_ms": 300000,
            "chunks": [
                {
                    "index": p["index"],
                    "status": "PENDING", # PENDING, PROCESSING, COMPLETED, FAILED
                    "file": p["filename"],
                    "error": None
                }
                for p in chunk_plans
            ]
        }
        self.save_checkpoint(new_data)
        return new_data

    def update_chunk_status(self, index: int, status: str, error: Optional[str] = None):
        data = self.load_checkpoint()
        if not data:
            return
        for c in data.get("chunks", []):
            if c["index"] == index:
                c["status"] = status
                c["error"] = error
                break
        self.save_checkpoint(data)

    def is_chunk_completed(self, index: int) -> bool:
        data = self.load_checkpoint()
        if not data:
            return False
        for c in data.get("chunks", []):
            if c["index"] == index and c["status"] == "COMPLETED":
                c_file = self.job_dir / f"chunk_{index:04d}.mp3"
                if c_file.exists() and c_file.stat().st_size > 0:
                    valid, dur, _ = CapCutTTSAdapter.validate_audio_file(c_file)
                    if valid and dur > 0.05:
                        return True
        return False


class ChunkMixer:
    SUB_BATCH_SIZE = 50

    @classmethod
    def mix_chunk(cls, plan: Dict[str, Any], job_dir: Path) -> Tuple[bool, str, Path]:
        chunk_out = job_dir / plan["filename"]
        c_start = plan["c_start"]
        c_dur_sec = plan["duration_sec"]
        chunk_items = plan["chunk_items"]

        if chunk_out.exists():
            chunk_out.unlink()

        if not chunk_items:
            ok = cls._create_silence_audio(c_dur_sec, chunk_out)
            if not ok:
                return False, "Lỗi tạo audio silence cho chunk rỗng.", chunk_out
            return True, "", chunk_out

        if len(chunk_items) <= cls.SUB_BATCH_SIZE:
            ok, err = cls._mix_batch(chunk_items, c_start, c_dur_sec, chunk_out)
            if not ok:
                cls._create_silence_audio(c_dur_sec, chunk_out)
                return False, f"Lỗi FFmpeg mix chunk: {err}", chunk_out
        else:
            sub_chunk_files = []
            num_batches = (len(chunk_items) + cls.SUB_BATCH_SIZE - 1) // cls.SUB_BATCH_SIZE
            batch_err = None

            for b_idx in range(num_batches):
                b_items = chunk_items[b_idx * cls.SUB_BATCH_SIZE : (b_idx + 1) * cls.SUB_BATCH_SIZE]
                sub_out = job_dir / f"sub_{plan['filename']}_{b_idx}.mp3"
                if sub_out.exists():
                    sub_out.unlink()

                ok_sub, err_sub = cls._mix_batch(b_items, c_start, c_dur_sec, sub_out)
                if not ok_sub:
                    batch_err = err_sub
                    break
                sub_chunk_files.append(sub_out)

            if batch_err or not sub_chunk_files:
                for sf in sub_chunk_files:
                    if sf.exists():
                        sf.unlink()
                cls._create_silence_audio(c_dur_sec, chunk_out)
                return False, f"Lỗi sub-batch mix: {batch_err}", chunk_out

            ok_final, err_final = cls._mix_sub_chunks(sub_chunk_files, c_dur_sec, chunk_out)
            for sf in sub_chunk_files:
                try:
                    if sf.exists():
                        sf.unlink()
                except Exception:
                    pass

            if not ok_final:
                cls._create_silence_audio(c_dur_sec, chunk_out)
                return False, f"Lỗi amix sub-chunks: {err_final}", chunk_out

        valid, dur, check_err = CapCutTTSAdapter.validate_audio_file(chunk_out)
        if not valid or dur < 0.05:
            cls._create_silence_audio(c_dur_sec, chunk_out)
            return False, f"Chunk audio không hợp lệ: {check_err}", chunk_out

        gc.collect()
        return True, "", chunk_out

    @staticmethod
    def _mix_batch(
        batch_items: List[Dict[str, Any]],
        c_start: int,
        c_dur_sec: float,
        out_file: Path
    ) -> Tuple[bool, str]:
        cmd = ["ffmpeg", "-y"]
        filter_parts = []
        input_count = len(batch_items)

        for idx_m, it in enumerate(batch_items):
            start_ms = it["start_ms"]
            if start_ms >= c_start:
                ss = 0.0
                delay_ms = start_ms - c_start
            else:
                ss = (c_start - start_ms) / 1000.0
                delay_ms = 0

            if ss > 0.001:
                cmd.extend(["-ss", f"{ss:.3f}", "-i", str(it["file"])])
            else:
                cmd.extend(["-i", str(it["file"])])

            filter_parts.append(f"[{idx_m}:a]adelay={delay_ms}|{delay_ms}[a{idx_m}];")

        cmd.extend(["-f", "lavfi", "-i", f"anullsrc=r=44100:cl=stereo:d={c_dur_sec:.3f}"])
        canvas_idx = input_count
        filter_parts.append(f"[{canvas_idx}:a]adelay=0|0[canvas];")

        inputs_str = "".join(f"[a{m}]" for m in range(input_count)) + "[canvas]"
        filter_parts.append(f"{inputs_str}amix=inputs={input_count + 1}:dropout_transition=0:normalize=0,atrim=0:{c_dur_sec:.3f}[out]")

        filter_complex_str = "".join(filter_parts)
        cmd.extend([
            "-filter_complex", filter_complex_str,
            "-map", "[out]",
            "-vn", "-ar", "44100", "-ac", "2", "-b:a", "192k",
            str(out_file), "-loglevel", "error"
        ])

        try:
            r = subprocess.run(cmd, capture_output=True, text=True)
            return (r.returncode == 0 and out_file.exists() and out_file.stat().st_size > 0), r.stderr or ""
        except Exception as e:
            return False, str(e)

    @staticmethod
    def _mix_sub_chunks(
        sub_chunk_files: List[Path],
        c_dur_sec: float,
        out_file: Path
    ) -> Tuple[bool, str]:
        cmd = ["ffmpeg", "-y"]
        for sf in sub_chunk_files:
            cmd.extend(["-i", str(sf)])

        n = len(sub_chunk_files)
        inputs_str = "".join(f"[{m}:a]" for m in range(n))
        filter_str = f"{inputs_str}amix=inputs={n}:dropout_transition=0:normalize=0,atrim=0:{c_dur_sec:.3f}[out]"

        cmd.extend([
            "-filter_complex", filter_str,
            "-map", "[out]",
            "-vn", "-ar", "44100", "-ac", "2", "-b:a", "192k",
            str(out_file), "-loglevel", "error"
        ])

        try:
            r = subprocess.run(cmd, capture_output=True, text=True)
            return (r.returncode == 0 and out_file.exists() and out_file.stat().st_size > 0), r.stderr or ""
        except Exception as e:
            return False, str(e)

    @staticmethod
    def _create_silence_audio(duration_sec: float, out_file: Path) -> bool:
        dur = max(0.05, float(duration_sec))
        cmd = [
            "ffmpeg", "-y", "-f", "lavfi",
            "-i", "anullsrc=r=44100:cl=stereo",
            "-t", f"{dur:.3f}",
            "-vn", "-ar", "44100", "-ac", "2", "-b:a", "192k",
            str(out_file), "-loglevel", "error"
        ]
        try:
            r = subprocess.run(cmd, capture_output=True, text=True)
            return r.returncode == 0 and out_file.exists()
        except Exception:
            return False


class Finalizer:
    @staticmethod
    def finalize(
        job_id: str,
        chunk_files: List[Path],
        output_path: Path,
        job_dir: Path
    ) -> Tuple[bool, str, Path]:
        concat_txt = job_dir / "concat_chunks.txt"
        with open(concat_txt, "w", encoding="utf-8") as f:
            for cf in chunk_files:
                safe_p = str(cf.resolve()).replace("\\", "/")
                f.write(f"file '{safe_p}'\n")

        concat_cmd = [
            "ffmpeg", "-y", "-f", "concat", "-safe", "0",
            "-i", str(concat_txt),
            "-vn", "-ar", "44100", "-ac", "2", "-b:a", "192k",
            str(output_path), "-loglevel", "error"
        ]

        try:
            res_p = subprocess.run(concat_cmd, capture_output=True, text=True)
            if res_p.returncode != 0 or not output_path.exists() or output_path.stat().st_size == 0:
                err_details = res_p.stderr or "Lỗi kết xuất file MP3 từ FFmpeg."
                return False, err_details, output_path
        except FileNotFoundError:
            err_details = "Không tìm thấy công cụ FFmpeg trong PATH hệ thống."
            return False, err_details, output_path

        valid_final, dur_final, val_err = CapCutTTSAdapter.validate_audio_file(output_path)
        if not valid_final or dur_final < 0.1:
            err_details = f"File MP3 kết xuất không hợp lệ hoặc rỗng: {val_err or ''}"
            return False, err_details, output_path

        # TỰ ĐỘNG XÓA FILE TẠM CHỈ KHI VALIDATE THÀNH CÔNG
        try:
            from TOOL.services.cleanup_service import CleanupService
            CleanupService.cleanup_job_temp(job_id)
        except Exception as e:
            logger.warning(f"Bỏ qua lỗi xóa temp job {job_id}: {e}")

        return True, "✓ Ghép audio hoàn tất thành công.", output_path


class TimelineAudioMerger:
    CHUNK_SIZE_MS = 300000  # 5 phút

    @classmethod
    def merge(
        cls,
        job_id: str,
        sub_states: List[Dict[str, Any]],
        job_dir: Path,
        output_filename: str = "tts_final_audio.mp3",
        progress_callback: Optional[Callable[[int, str], None]] = None
    ) -> Tuple[bool, str, Path]:
        """
        Thực thi toàn bộ luồng ghép audio theo kiến trúc:
        SRT -> TimelineBuilder -> ChunkPlanner -> MergeCheckpointManager -> ChunkMixer -> Finalizer
        """
        def _report(pct: int, msg: str):
            if progress_callback:
                progress_callback(pct, msg)

        _report(10, "Đang kiểm tra dữ liệu và khởi tạo mixer timeline...")

        # 1. Timeline Builder
        items, max_timeline_ms = TimelineBuilder.build_timeline(sub_states, job_dir)

        # 2. Chunk Planner
        chunk_plans = ChunkPlanner.plan_chunks(items, max_timeline_ms, cls.CHUNK_SIZE_MS)
        num_chunks = len(chunk_plans)

        # 3. Merge Checkpoint Manager
        ckpt_mgr = MergeCheckpointManager(job_dir)
        ckpt_mgr.init_checkpoint(num_chunks, chunk_plans)

        _report(20, f"Đang xử lý timeline ({num_chunks} chunk 5 phút)...")

        # 4. Chunk Mixer
        completed_chunk_files = []
        for k, plan in enumerate(chunk_plans):
            chunk_file = job_dir / plan["filename"]
            pct = 20 + int((k / num_chunks) * 60)

            # Check if chunk already COMPLETED (Resume merge support)
            if ckpt_mgr.is_chunk_completed(k):
                _report(pct, f"[Resume] Chunk {k+1}/{num_chunks} đã hoàn thành, bỏ qua.")
                completed_chunk_files.append(chunk_file)
                continue

            _report(pct, f"Đang trộn audio timeline chunk {k+1}/{num_chunks} ({len(plan['chunk_items'])} câu)...")
            ckpt_mgr.update_chunk_status(k, "PROCESSING")

            ok_mix, err_mix, out_c = ChunkMixer.mix_chunk(plan, job_dir)
            if not ok_mix:
                ckpt_mgr.update_chunk_status(k, "FAILED", err_mix)
                return False, f"Lỗi trộn chunk {k+1}/{num_chunks}: {err_mix}", out_c

            ckpt_mgr.update_chunk_status(k, "COMPLETED")
            completed_chunk_files.append(out_c)

        # 5. Finalizer
        _report(85, "Đang kết xuất file MP3 hoàn chỉnh vào Download/KAGEVIETSUB...")

        if not output_filename.lower().endswith(".mp3"):
            output_filename += ".mp3"
        output_path = get_safe_unique_filepath(KAGE_DOWNLOAD_DIR, output_filename)

        ok_fin, msg_fin, final_path = Finalizer.finalize(
            job_id=job_id,
            chunk_files=completed_chunk_files,
            output_path=output_path,
            job_dir=job_dir
        )

        return ok_fin, msg_fin, final_path
