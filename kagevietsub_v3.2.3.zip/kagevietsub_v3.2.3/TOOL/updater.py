#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB - AUTO UPDATER ENGINE (WINDOWS CMD/POWERSHELL + ANDROID TERMUX)
==============================================================================
- Nguồn kiểm tra duy nhất: file Update.txt trên GitHub repository:
  nguyenducmanh2222011-oss/Update-tool (nhánh main)
- Đọc VERSION, URL và SHA256 từ Update.txt
- So sánh phiên bản local từ version.json (Semantic Versioning: MAJOR.MINOR.PATCH)
- Hỏi xác nhận người dùng [Y/N]
- Chặn cập nhật nếu hệ thống đang có tác vụ xử lý
- Tải ZIP vào DATA/temp/updater/kagevietsub_update_vX.X.X.zip (KHÔNG lưu vào Download/KAGEVIETSUB/)
- Kiểm tra mã SHA256 của file ZIP vừa tải nếu Update.txt có cung cấp
- Giải nén vào DATA/temp/updater/extracted/ và kiểm tra version.json trong gói
- Sao lưu CODE hiện tại vào DATA/temp/updater/backup/ (loại trừ DATA/models, uploads, output...)
- Thay thế CODE, bảo toàn tuyệt đối: DATA/models, DATA/uploads, DATA/temp, DATA/output, Download/KAGEVIETSUB/
- Sau khi thành công: cập nhật version.json, dọn dẹp file ZIP tạm và thoát để người dùng chạy lại START.py
- Nếu lỗi: giữ nguyên/khôi phục code cũ, bảo toàn dữ liệu và báo lỗi chi tiết
- Không hot-reload, không tự động nâng cấp pip, offline-safe không gây treo START.py
==============================================================================
"""

import os
import sys
import json
import shutil
import zipfile
import hashlib
import urllib.request
import urllib.error
import re
from pathlib import Path
from typing import Dict, Any, Optional, Tuple, List

# Xác định đường dẫn gốc
TOOL_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = TOOL_DIR.parent
DATA_DIR = PROJECT_ROOT / "DATA"
VERSION_FILE = PROJECT_ROOT / "version.json"

# Cấu hình tập trung nguồn kiểm tra Update
UPDATE_INFO_URL = os.getenv(
    "KAGE_UPDATE_URL",
    "https://raw.githubusercontent.com/nguyenducmanh2222011-oss/Update-tool/main/Update.txt"
)
UPDATE_TIMEOUT = 6  # seconds (Offline-safe timeout)

# Danh mục thư mục & file bảo vệ tuyệt đối (KHÔNG ĐƯỢC XÓA, GHI ĐÈ HAY ĐÓNG GÓI VÀO UPDATE)
PROTECTED_PATHS = [
    "DATA/models",
    "DATA/uploads",
    "DATA/temp",
    "DATA/output",
    "DATA/logs",
    "Download",
    "Download/KAGEVIETSUB",
    ".env",
    ".env.local"
]

def parse_version_tuple(v_str: str) -> Tuple[int, ...]:
    """
    Chuyển chuỗi version 'v1.2.0', '1.10.0' thành tuple (1, 10, 0)
    để so sánh số học chính xác theo Semantic Versioning.
    """
    clean = re.sub(r'^[^\d]*', '', str(v_str).strip())
    parts = re.findall(r'\d+', clean)
    if not parts:
        return (0, 0, 0)
    return tuple(int(p) for p in parts[:4])

def get_local_version() -> str:
    """Đọc phiên bản hiện tại từ version.json ở thư mục gốc."""
    if VERSION_FILE.exists():
        try:
            with open(VERSION_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                return str(data.get("version", "1.0.0")).strip()
        except Exception:
            pass
    return "1.0.0"

def set_local_version(version: str):
    """Ghi phiên bản mới vào version.json (chỉ lưu version, không lưu URL/lịch sử)."""
    try:
        data = {"version": version.lstrip("v").strip()}
        with open(VERSION_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
            f.write("\n")
    except Exception:
        pass

def parse_update_txt(raw_text: str) -> Dict[str, str]:
    """
    Phân tích nội dung Update.txt linh hoạt và tương thích ngược:
    Hỗ trợ format tiêu chuẩn:
      VERSION=1.2.0
      URL=https://.../update.zip
      SHA256=...
    và các biến thể key: value hoặc JSON.
    """
    info: Dict[str, str] = {
        "version": "",
        "url": "",
        "sha256": "",
        "notes": ""
    }

    raw_text = raw_text.strip()
    if not raw_text:
        return info

    # Trường hợp 1: Nếu là JSON
    if raw_text.startswith("{") and raw_text.endswith("}"):
        try:
            data = json.loads(raw_text)
            info["version"] = str(data.get("version", data.get("VERSION", ""))).strip().lstrip("v")
            info["url"] = str(data.get("url", data.get("URL", data.get("download_url", "")))).strip()
            info["sha256"] = str(data.get("sha256", data.get("SHA256", ""))).strip()
            info["notes"] = str(data.get("notes", data.get("changelog", ""))).strip()
            return info
        except Exception:
            pass

    # Trường hợp 2: Format KEY=VALUE hoặc KEY: VALUE theo dòng
    notes_lines = []
    in_notes = False

    for line in raw_text.splitlines():
        line_s = line.strip()
        if not line_s or line_s.startswith("#"):
            continue

        if "=" in line_s:
            k, _, v = line_s.partition("=")
            key = k.strip().upper()
            val = v.strip().strip('"').strip("'")
            if key in ["VERSION", "VER", "TAG"]:
                info["version"] = val.lstrip("v")
            elif key in ["URL", "DOWNLOAD_URL", "LINK", "ZIP_URL"]:
                info["url"] = val
            elif key in ["SHA256", "HASH", "CHECKSUM"]:
                info["sha256"] = val
            elif key in ["NOTES", "CHANGELOG", "DESC"]:
                info["notes"] = val
        elif ":" in line_s:
            k, _, v = line_s.partition(":")
            key = k.strip().upper()
            val = v.strip().strip('"').strip("'")
            if key in ["VERSION", "VER"]:
                info["version"] = val.lstrip("v")
            elif key in ["URL", "DOWNLOAD_URL", "LINK"]:
                info["url"] = val
            elif key in ["SHA256", "HASH"]:
                info["sha256"] = val

    return info

def check_for_update(update_url: str = UPDATE_INFO_URL, timeout: int = UPDATE_TIMEOUT) -> Tuple[bool, str, Dict[str, str]]:
    """
    Kiểm tra phiên bản mới từ file Update.txt trên GitHub.
    Trả về: (has_update: bool, latest_version_str: str, update_info: dict)
    Offline-safe: timeout nhanh, không gây crash hoặc treo START.py nếu mất mạng.
    """
    local_ver = get_local_version()
    local_tuple = parse_version_tuple(local_ver)

    req = urllib.request.Request(
        update_url,
        headers={
            "User-Agent": "KAGEVIETSUB-Updater/1.0",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache"
        }
    )

    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            if response.status == 200:
                content = response.read().decode("utf-8", errors="ignore")
                info = parse_update_txt(content)
                remote_ver = info.get("version", "").strip()

                if not remote_ver:
                    return False, local_ver, {}

                remote_tuple = parse_version_tuple(remote_ver)
                if remote_tuple > local_tuple:
                    return True, remote_ver, info
                else:
                    return False, remote_ver, info
    except Exception:
        # Không có mạng, DNS lỗi, GitHub chặn hoặc timeout -> tiếp tục khởi động bình thường
        return False, local_ver, {}

    return False, local_ver, {}

def is_system_busy() -> bool:
    """Kiểm tra xem hệ thống có đang bận xử lý tác vụ hay không."""
    try:
        from TOOL.services.task_service import job_manager
        return job_manager.has_active_jobs()
    except Exception:
        return False

def calculate_sha256(file_path: Path) -> str:
    """Tính mã SHA256 của file."""
    sha256_hash = hashlib.sha256()
    with open(file_path, "rb") as f:
        for byte_block in iter(lambda: f.read(65536), b""):
            sha256_hash.update(byte_block)
    return sha256_hash.hexdigest().lower()

def download_update_zip(url: str, destination: Path, expected_sha256: str = "", timeout: int = 60) -> Tuple[bool, str]:
    """
    Tải file ZIP update từ URL vào thư mục tạm chuyên dụng.
    Tiến hành kiểm tra mã SHA256 nếu có.
    KHÔNG xóa file ZIP ngay nếu có lỗi.
    """
    try:
        destination.parent.mkdir(parents=True, exist_ok=True)
        req = urllib.request.Request(
            url,
            headers={
                "User-Agent": "KAGEVIETSUB-Updater/1.0",
                "Accept": "*/*"
            }
        )

        with urllib.request.urlopen(req, timeout=timeout) as response, open(destination, "wb") as out_file:
            total_size = int(response.headers.get("Content-Length", 0))
            block_size = 32768
            downloaded = 0

            while True:
                buffer = response.read(block_size)
                if not buffer:
                    break
                downloaded += len(buffer)
                out_file.write(buffer)
                if total_size > 0:
                    try:
                        from TOOL.cli_ui import print_progress_bar
                        print_progress_bar(downloaded, total_size, prefix="Đang tải gói cập nhật...")
                    except Exception:
                        pass

            if total_size > 0:
                sys.stdout.write("\n")
                sys.stdout.flush()

        if not destination.exists() or destination.stat().st_size == 0:
            return False, "File tải về rỗng hoặc không thể lưu."

        # Kiểm tra tính hợp lệ của ZIP
        if not zipfile.is_zipfile(destination):
            return False, "File tải về không phải là file ZIP hợp lệ."

        # Kiểm tra SHA256 nếu có
        if expected_sha256:
            calc_hash = calculate_sha256(destination)
            if calc_hash != expected_sha256.strip().lower():
                return False, f"Mã SHA256 không khớp! (Kỳ vọng: {expected_sha256}, Thực tế: {calc_hash})"

        return True, "Tải file thành công."

    except Exception as e:
        return False, f"Lỗi tải gói cập nhật: {str(e)}"

def is_path_protected(rel_path_str: str) -> bool:
    """Kiểm tra xem đường dẫn có nằm trong vùng bảo vệ dữ liệu người dùng hay không."""
    norm = rel_path_str.replace("\\", "/").strip("/")
    for p in PROTECTED_PATHS:
        p_norm = p.strip("/")
        if norm == p_norm or norm.startswith(p_norm + "/"):
            return True
    return False

def create_code_backup(backup_dir: Path) -> bool:
    """
    Sao lưu code hiện tại sang DATA/temp/updater/backup/ phục vụ rollback nếu update lỗi.
    Tuyệt đối KHÔNG sao lưu dữ liệu người dùng (DATA/models, uploads, temp, output, Download).
    """
    if backup_dir.exists():
        shutil.rmtree(backup_dir, ignore_errors=True)
    backup_dir.mkdir(parents=True, exist_ok=True)

    try:
        for item in PROJECT_ROOT.iterdir():
            if item.name == "DATA" or item.name == "Download" or item.name.startswith("."):
                continue
            if item.name in ["node_modules", "dist", "__pycache__"]:
                continue
            if item.is_file():
                shutil.copy2(item, backup_dir / item.name)
            elif item.is_dir():
                shutil.copytree(
                    item,
                    backup_dir / item.name,
                    ignore=shutil.ignore_patterns("*.pyc", "__pycache__", "node_modules")
                )
        return True
    except Exception:
        return False

def restore_code_backup(backup_dir: Path) -> bool:
    """Khôi phục code từ bản sao lưu nếu quá trình cập nhật gặp sự cố."""
    if not backup_dir.exists():
        return False
    try:
        for item in backup_dir.iterdir():
            if item.name == "DATA" or item.name == "Download":
                continue
            dest = PROJECT_ROOT / item.name
            if item.is_file():
                shutil.copy2(item, dest)
            elif item.is_dir():
                if dest.exists():
                    shutil.rmtree(dest, ignore_errors=True)
                shutil.copytree(item, dest)
        return True
    except Exception:
        return False

def apply_update_process(zip_path: Path, expected_version: str) -> Tuple[bool, str]:
    """
    Toàn bộ quy trình giải nén, kiểm tra version, backup, thay thế code và dọn dẹp:
    1. Kiểm tra zip integrity
    2. Giải nén vào DATA/temp/updater/extracted/
    3. Tìm version.json trong gói và so sánh với expected_version
    4. Backup code cũ
    5. Thay thế code
    6. Kiểm tra code mới
    7. Cập nhật version.json
    8. Chỉ xóa ZIP và temp khi toàn bộ thành công
    """
    updater_temp = DATA_DIR / "temp" / "updater"
    backup_dir = updater_temp / "backup"
    extract_dir = updater_temp / "extracted"

    if extract_dir.exists():
        shutil.rmtree(extract_dir, ignore_errors=True)
    extract_dir.mkdir(parents=True, exist_ok=True)

    # 1. Kiểm tra tính toàn vẹn ZIP
    try:
        with zipfile.ZipFile(zip_path, "r") as zip_ref:
            if zip_ref.testzip() is not None:
                return False, "File ZIP cập nhật bị hỏng hoặc lỗi CRC."
            zip_ref.extractall(extract_dir)
    except Exception as e:
        return False, f"Lỗi giải nén ZIP: {str(e)}"

    # 2. Tìm thư mục gốc chứa code bên trong zip
    source_root = extract_dir
    extracted_entries = [e for e in extract_dir.iterdir() if e.is_dir()]
    # Nếu zip đóng gói trong 1 thư mục con duy nhất (như KAGEVIETSUB-1.2.0/)
    if len(extracted_entries) == 1 and not (extract_dir / "START.py").exists() and not (extract_dir / "TOOL").exists():
        source_root = extracted_entries[0]

    # 3. Kiểm tra version.json trong package giải nén nếu có
    pkg_version_file = source_root / "version.json"
    if pkg_version_file.exists():
        try:
            with open(pkg_version_file, "r", encoding="utf-8") as f:
                pkg_data = json.load(f)
                pkg_ver = str(pkg_data.get("version", "")).strip().lstrip("v")
                exp_ver = expected_version.strip().lstrip("v")
                if pkg_ver and exp_ver and parse_version_tuple(pkg_ver) != parse_version_tuple(exp_ver):
                    return False, f"Phiên bản trong gói ({pkg_ver}) không khớp với Update.txt ({exp_ver})."
        except Exception:
            pass

    # 4. Sao lưu CODE cũ
    if not create_code_backup(backup_dir):
        return False, "Không thể tạo bản sao lưu an toàn cho code hiện tại."

    try:
        # 5. Thay thế CODE (bảo vệ 100% dữ liệu người dùng)
        for root, dirs, files in os.walk(source_root):
            rel_dir = Path(root).relative_to(source_root)
            rel_dir_str = str(rel_dir).replace("\\", "/")

            if is_path_protected(rel_dir_str):
                continue

            target_dir = PROJECT_ROOT / rel_dir
            target_dir.mkdir(parents=True, exist_ok=True)

            for file_name in files:
                rel_file_path = rel_dir / file_name
                rel_file_str = str(rel_file_path).replace("\\", "/")

                if is_path_protected(rel_file_str):
                    continue

                src_file = Path(root) / file_name
                dst_file = PROJECT_ROOT / rel_file_path
                shutil.copy2(src_file, dst_file)

        # 6. Cập nhật version.json
        set_local_version(expected_version)

        # 7. Kiểm tra tính toàn vẹn code mới
        if not (PROJECT_ROOT / "START.py").exists() or not (PROJECT_ROOT / "TOOL").exists():
            raise RuntimeError("Thiếu các file thành phần cốt lõi sau khi thay thế code.")

        # 8. CẬP NHẬT THÀNH CÔNG -> XÓA FILE ZIP TẠM & DỌN DẸP
        if zip_path.exists():
            try:
                zip_path.unlink()
            except Exception:
                pass
        shutil.rmtree(extract_dir, ignore_errors=True)
        shutil.rmtree(backup_dir, ignore_errors=True)

        return True, "Cập nhật hoàn tất thành công."

    except Exception as e:
        # Rollback tự động
        restore_code_backup(backup_dir)
        return False, f"Lỗi trong quá trình thay thế code: {str(e)}. Đã khôi phục phiên bản trước."

def print_update_available_banner(current_ver: str, new_ver: str):
    """Hiển thị thông báo có bản cập nhật theo đúng format yêu cầu."""
    from TOOL.cli_ui import Colors, Icons
    C = Colors

    print()
    print(f"{C.CYAN}╔══════════════════════════════════════════╗{C.RESET}")
    print(f"{C.CYAN}║{C.BRIGHT_YELLOW}{C.BOLD}       KAGEVIETSUB UPDATE AVAILABLE       {C.RESET}{C.CYAN}║{C.RESET}")
    print(f"{C.CYAN}╚══════════════════════════════════════════╝{C.RESET}")
    print()
    print(f" {C.WHITE}Phiên bản hiện tại : {C.BRIGHT_CYAN}v{current_ver.lstrip('v')}{C.RESET}")
    print(f" {C.WHITE}Phiên bản mới      : {C.BRIGHT_GREEN}v{new_ver.lstrip('v')}{C.RESET}")
    print()

def print_update_success_banner(old_ver: str, new_ver: str):
    """Hiển thị thông báo cập nhật thành công theo đúng format yêu cầu."""
    from TOOL.cli_ui import Colors, Icons
    C = Colors

    print()
    print(f"{C.GREEN}╔══════════════════════════════════════════╗{C.RESET}")
    print(f"{C.GREEN}║{C.BRIGHT_GREEN}{C.BOLD}       KAGEVIETSUB UPDATE SUCCESS         {C.RESET}{C.GREEN}║{C.RESET}")
    print(f"{C.GREEN}╚══════════════════════════════════════════╝{C.RESET}")
    print()
    print(f" {C.GREEN}✓{C.RESET} {C.WHITE}Phiên bản cũ: {C.GRAY}v{old_ver.lstrip('v')}{C.RESET}")
    print(f" {C.GREEN}✓{C.RESET} {C.WHITE}Phiên bản mới: {C.BRIGHT_GREEN}v{new_ver.lstrip('v')}{C.RESET}")
    print(f" {C.GREEN}✓{C.RESET} {C.WHITE}Code đã được cập nhật{C.RESET}")
    print(f" {C.GREEN}✓{C.RESET} {C.WHITE}Dữ liệu người dùng được giữ nguyên{C.RESET}")
    print()
    print(f" {C.BRIGHT_YELLOW}Hãy chạy lại KAGEVIETSUB để sử dụng phiên bản mới.{C.RESET}")
    print(f" {C.GRAY}Lệnh khởi chạy: {C.CYAN}python START.py{C.RESET}")
    print()

def run_cli_update_flow(prompt_user: bool = True) -> bool:
    """
    Quy trình kiểm tra và cập nhật hoàn chỉnh khi START.py khởi động:
    1. Kiểm tra Update.txt trên GitHub
    2. Có bản mới -> Hiển thị banner update và hỏi [Y/N]
    3. Nếu N -> bỏ qua và tiếp tục chạy KAGEVIETSUB
    4. Nếu Y -> kiểm tra job đang chạy -> tải zip -> verify SHA256 -> extract -> backup -> replace -> exit
    """
    from TOOL.cli_ui import Colors, Icons, print_warning, print_error, print_info

    has_update, remote_ver, update_info = check_for_update()

    if not has_update or not update_info:
        return False

    current_ver = get_local_version()
    new_ver = remote_ver

    # 1. Hiển thị banner update
    print_update_available_banner(current_ver, new_ver)

    # 2. Hỏi người dùng [Y/N]
    if prompt_user:
        try:
            prompt_msg = f" {Colors.BRIGHT_WHITE}Bạn có muốn cập nhật không? [Y/N]: {Colors.RESET}"
            choice = input(prompt_msg).strip().lower()
        except (KeyboardInterrupt, EOFError):
            print()
            return False

        if choice not in ["y", "yes", "có", "c"]:
            print(f" {Colors.GRAY}Bỏ qua cập nhật. KAGEVIETSUB tiếp tục khởi động...{Colors.RESET}\n")
            return False

    # 3. Kiểm tra tác vụ đang xử lý
    if is_system_busy():
        print()
        print(f" {Colors.YELLOW}{Icons.WARN} Không thể cập nhật lúc này.{Colors.RESET}")
        print(f"   {Colors.WHITE}KAGEVIETSUB đang có tác vụ đang chạy.{Colors.RESET}")
        print(f"   {Colors.GRAY}Hãy chờ tác vụ hoàn tất rồi cập nhật.{Colors.RESET}")
        print()
        return False

    # 4. Lấy URL tải ZIP
    download_url = update_info.get("url", "").strip()
    if not download_url:
        print_error("Không tìm thấy link tải ZIP trong Update.txt.")
        return False

    expected_sha256 = update_info.get("sha256", "").strip()
    updater_dir = DATA_DIR / "temp" / "updater"
    updater_dir.mkdir(parents=True, exist_ok=True)
    temp_zip = updater_dir / f"kagevietsub_update_v{new_ver.lstrip('v')}.zip"

    print_info(f"Đang chuẩn bị tải gói cập nhật v{new_ver.lstrip('v')}...")

    # 5. Tải ZIP
    success_dl, dl_msg = download_update_zip(download_url, temp_zip, expected_sha256=expected_sha256)
    if not success_dl:
        print_error("Tải bản cập nhật thất bại", reason=dl_msg)
        return False

    # 6. Tiến hành sao lưu và thay thế code
    print_info("Đang kiểm tra gói cập nhật và áp dụng code mới...")
    success_apply, apply_msg = apply_update_process(temp_zip, new_ver)

    if not success_apply:
        print_error("Cập nhật thất bại", reason=apply_msg)
        return False

    # 7. Thành công -> Hiển thị banner và thoát hoàn toàn
    print_update_success_banner(current_ver, new_ver)
    sys.exit(0)

if __name__ == "__main__":
    # Chạy độc lập: python updater.py
    run_cli_update_flow(prompt_user=True)

