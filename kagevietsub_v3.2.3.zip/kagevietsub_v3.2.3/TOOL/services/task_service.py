import os
import sys
import threading
import uuid
import time
import logging
from typing import Dict, Any, Optional, Callable, List

logger = logging.getLogger("kagevietsub.task_service")


class HardwareOptimizer:
    """Tự động phát hiện phần cứng (CPU, RAM, Nền tảng) để điều chỉnh mức Concurrency tối ưu."""
    
    @staticmethod
    def is_android() -> bool:
        return (
            os.path.exists("/data/data/com.termux")
            or "ANDROID_ROOT" in os.environ
            or "com.termux" in os.environ.get("PREFIX", "")
        )

    @classmethod
    def get_hardware_profile(cls) -> Dict[str, Any]:
        cpu_cores = os.cpu_count() or 4
        android = cls.is_android()

        # Cho phép cấu hình tối đa lên tới 30 workers theo yêu cầu người dùng,
        # và điều phối thông minh qua Adaptive Concurrency Controller
        max_tts_workers = 30
        default_tts_workers = 5
        max_speed_workers = min(4, max(2, cpu_cores // 2))
        ffmpeg_threads = 2 if android else 4
        merge_batch_size = 30 if android else 50

        return {
            "is_android": android,
            "cpu_cores": cpu_cores,
            "max_tts_workers": max_tts_workers,
            "default_tts_workers": default_tts_workers,
            "max_speed_workers": max_speed_workers,
            "ffmpeg_threads": ffmpeg_threads,
            "merge_batch_size": merge_batch_size
        }


class JobControlContext:
    """Quản lý điều khiển luồng (Pause / Resume / Stop / Cancel) bằng Event không khóa CPU."""
    
    def __init__(self, job_id: str):
        self.job_id = job_id
        self._pause_event = threading.Event()
        self._pause_event.set()  # Mặc định đang chạy (không pause)
        self._stop_event = threading.Event()
        self.cancel_requested = False
        self.pause_requested = False

    def pause(self):
        self.pause_requested = True
        self._pause_event.clear()

    def resume(self):
        self.pause_requested = False
        self._pause_event.set()

    def stop(self):
        self.cancel_requested = True
        self._stop_event.set()
        self._pause_event.set()  # Đánh thức worker nếu đang sleep pause

    def is_paused(self) -> bool:
        return not self._pause_event.is_set()

    def is_stopped(self) -> bool:
        return self._stop_event.is_set() or self.cancel_requested

    def wait_if_paused(self, timeout: Optional[float] = None) -> bool:
        """Nếu đang pause, worker sẽ chờ tại đây bằng Event mà không tốn CPU."""
        if not self._pause_event.is_set():
            return self._pause_event.wait(timeout=timeout)
        return True


class TaskService:
    def __init__(self):
        self._jobs: Dict[str, Dict[str, Any]] = {}
        self._contexts: Dict[str, JobControlContext] = {}
        self._lock = threading.RLock()
        self.shutdown_requested = False
        self._active_threads: List[threading.Thread] = []

    def can_accept_new_jobs(self) -> bool:
        return not self.shutdown_requested

    def get_control_context(self, job_id: str) -> JobControlContext:
        with self._lock:
            if job_id not in self._contexts:
                self._contexts[job_id] = JobControlContext(job_id)
            return self._contexts[job_id]

    def create_job(self, task_type: str, metadata: Optional[Dict[str, Any]] = None) -> str:
        if self.shutdown_requested:
            raise RuntimeError("Máy chủ đang trong quá trình dừng, không nhận thêm tác vụ mới.")

        job_id = uuid.uuid4().hex[:12]
        with self._lock:
            self._jobs[job_id] = {
                "job_id": job_id,
                "type": task_type,
                "status": "queued",
                "progress": 0,
                "message": "Task queued...",
                "download_url": None,
                "filename": None,
                "saved_path": None,
                "saved_location": None,
                "created_at": time.time(),
                "completed_at": None,
                "error": None,
                "result": None,
                "metadata": metadata or {}
            }
            self._contexts[job_id] = JobControlContext(job_id)
        return job_id

    def update_job(
        self,
        job_id: str,
        status: Optional[str] = None,
        progress: Optional[int] = None,
        message: Optional[str] = None,
        download_url: Optional[str] = None,
        filename: Optional[str] = None,
        saved_path: Optional[str] = None,
        saved_location: Optional[str] = None,
        error: Optional[str] = None,
        result: Optional[Any] = None
    ):
        with self._lock:
            if job_id not in self._jobs:
                return
            job = self._jobs[job_id]
            if status is not None:
                job["status"] = status
                if status == "paused":
                    self.get_control_context(job_id).pause()
                elif status in ["processing", "generating", "merging"]:
                    self.get_control_context(job_id).resume()
                elif status in ["stopped", "failed", "cancelled"]:
                    self.get_control_context(job_id).stop()

            if progress is not None:
                job["progress"] = max(0, min(100, int(progress)))
            if message is not None:
                job["message"] = message
            if download_url is not None:
                job["download_url"] = download_url
            if filename is not None:
                job["filename"] = filename
            if saved_path is not None:
                job["saved_path"] = saved_path
            if saved_location is not None:
                job["saved_location"] = saved_location
            if error is not None:
                job["error"] = error
            if result is not None:
                job["result"] = result
            if status in ["completed", "failed", "stopped"]:
                job["completed_at"] = time.time()

        # Tự động dọn dẹp file temp của job khi xong hoặc lỗi (không xóa file download chính)
        if status in ["completed", "failed"]:
            try:
                from TOOL.services.cleanup_service import CleanupService
                up_files = []
                meta = self._jobs.get(job_id, {}).get("metadata", {})
                if "upload_paths" in meta:
                    up_files = meta["upload_paths"]
                elif "upload_path" in meta:
                    up_files = [meta["upload_path"]]
                CleanupService.cleanup_job_temp(job_id, uploaded_files=up_files)
            except Exception:
                pass

    def get_job(self, job_id: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            job = self._jobs.get(job_id)
            return dict(job) if job else None

    def list_jobs(self, limit: int = 20) -> list:
        with self._lock:
            items = list(self._jobs.values())
            items.sort(key=lambda x: x["created_at"], reverse=True)
            return [dict(j) for j in items[:limit]]

    def get_active_jobs(self) -> list:
        with self._lock:
            return [dict(j) for j in self._jobs.values() if j.get("status") in ["processing", "queued", "paused", "merging"]]

    def has_active_jobs(self) -> bool:
        with self._lock:
            return any(j.get("status") in ["processing", "queued", "paused", "merging"] for j in self._jobs.values())

    def pause_job(self, job_id: str) -> Dict[str, Any]:
        """Tạm dừng job tức thì không chờ đợi."""
        ctx = self.get_control_context(job_id)
        ctx.pause()
        self.update_job(job_id, status="paused", message="⏸ Tiến trình đã được tạm dừng.")
        return self.get_job(job_id) or {"job_id": job_id, "status": "paused"}

    def resume_job(self, job_id: str) -> Dict[str, Any]:
        """Tiếp tục job tức thì."""
        ctx = self.get_control_context(job_id)
        ctx.resume()
        self.update_job(job_id, status="processing", message="▶ Đang tiếp tục tiến trình...")
        return self.get_job(job_id) or {"job_id": job_id, "status": "processing"}

    def stop_job(self, job_id: str) -> Dict[str, Any]:
        """Dừng job tức thì không chờ đợi."""
        ctx = self.get_control_context(job_id)
        ctx.stop()
        self.update_job(job_id, status="stopped", message="⏹ Tiến trình đã dừng bởi người dùng.")
        return self.get_job(job_id) or {"job_id": job_id, "status": "stopped"}

    def request_shutdown(self, timeout_sec: float = 3.0):
        """Kích hoạt quá trình Graceful Shutdown."""
        self.shutdown_requested = True
        logger.info("[SHUTDOWN] Đã kích hoạt cờ shutdown_requested = True. Dừng nhận job mới.")
        
        # Dừng tất cả các job đang chạy
        with self._lock:
            for job_id, ctx in self._contexts.items():
                ctx.stop()
            for job_id, job in self._jobs.items():
                if job.get("status") in ["processing", "queued", "paused", "merging"]:
                    job["status"] = "stopped"
                    job["message"] = "Server shutting down."

    def run_in_background(self, job_id: str, target: Callable[..., Any], *args, **kwargs):
        def _wrapper():
            self.update_job(job_id, status="processing", progress=5, message="Processing started...")
            try:
                result = target(job_id, *args, **kwargs)
                current_job = self.get_job(job_id)
                if current_job and current_job.get("status") not in ["failed", "completed", "stopped"]:
                    self.update_job(job_id, status="completed", progress=100, message="Task completed successfully!", result=result)
            except Exception as e:
                logger.exception(f"Lỗi background job {job_id}: {e}")
                self.update_job(job_id, status="failed", error=str(e), message=f"Lỗi: {str(e)}")

        thread = threading.Thread(target=_wrapper, daemon=True)
        with self._lock:
            self._active_threads.append(thread)
        thread.start()


# Global singleton
job_manager = TaskService()

