#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
DSUB LOCAL - HIGH-PERFORMANCE SERVER (PYTHON 3.14 + TERMUX ANDROID & PC)
==============================================================================
Hỗ trợ 2 chế độ hoạt động:
1. FastAPI + Uvicorn (Nếu môi trường có sẵn)
2. Standalone Threading HTTP Server (Thuần Python 3.14, 0 dependencies bên ngoài)
Đảm bảo 100% không bao giờ crash do lỗi pydantic-core trên Termux Android.
==============================================================================
"""

import os
import sys
import json
import shutil
import zipfile
import platform
import logging
import urllib.parse
import threading
from pathlib import Path
from http.server import HTTPServer, SimpleHTTPRequestHandler
from socketserver import ThreadingMixIn
from typing import Dict, Any, Optional

# Đảm bảo đường dẫn TOOL và PROJECT_ROOT trong sys.path
TOOL_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = TOOL_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
if str(TOOL_DIR) not in sys.path:
    sys.path.insert(0, str(TOOL_DIR))

from TOOL.config import (
    HOST, PORT, DATA_DIR, TEMP_DIR, OUTPUT_DIR, UPLOADS_DIR,
    MODELS_DIR, LOGS_DIR, WEB_DIR, KAGE_DOWNLOAD_DIR, ensure_directories, is_safe_path
)
from TOOL.system_check import is_android, get_full_system_info
from TOOL.services.ffmpeg_service import FFmpegService
from TOOL.services.task_service import job_manager
from TOOL.services.cleanup_service import CleanupService
from TOOL.services.file_service import FileService
from TOOL.updater import get_local_version, check_for_update, is_system_busy

# Import API dispatchers
from TOOL.api.srt_api import (
    handle_parse_srt, handle_remove_trailing_punct, handle_remove_leading_ellipsis,
    handle_replace_rules, handle_avoid_overlap, handle_purple_sequence,
    handle_fix_repeat_2_3, handle_fix_repeat_4_5, handle_merge_short,
    handle_all_steps, handle_uppercase, handle_split_srt, handle_save_srt
)
from TOOL.api.audio_api import handle_audio_merge
from TOOL.api.video_api import handle_video_cut, handle_video_merge, handle_video_compress
from TOOL.api.whisper_api import handle_whisper_models, handle_whisper_transcribe, handle_download_whisper_model
from TOOL.api.tts_api import (
    handle_tts_voices, handle_tts_parse_srt, handle_tts_create_job,
    handle_tts_retry, handle_tts_merge, handle_tts_get_job, handle_tts_preview
)

# Setup logging
log_file = LOGS_DIR / "kage_server.log"
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.FileHandler(str(log_file), encoding="utf-8"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("kagevietsub_server")

def get_health_data() -> Dict[str, Any]:
    """Tạo dữ liệu phản hồi cho /api/health theo chuẩn yêu cầu."""
    sys_info = get_full_system_info()
    return {
        "status": "ok",
        "app_name": "KAGEVIETSUB",
        "platform": "android" if is_android() else platform.system().lower(),
        "python": platform.python_version(),
        "architecture": platform.machine() or "ARM64",
        "system": {
            "python_version": platform.python_version(),
            "os": platform.system(),
            "platform": sys_info["platform_display"],
            "processor": platform.processor() or platform.machine()
        },
        "components": sys_info["components"],
        "directories": {
            "DATA": str(DATA_DIR),
            "temp_files": len(list(TEMP_DIR.glob("*"))) if TEMP_DIR.exists() else 0,
            "output_files": len(list(OUTPUT_DIR.glob("*"))) if OUTPUT_DIR.exists() else 0
        }
    }

def create_export_zip() -> Path:
    """Tạo gói KAGEVIETSUB.zip xuất toàn bộ project độc lập."""
    export_zip_path = OUTPUT_DIR / "KAGEVIETSUB.zip"
    with zipfile.ZipFile(export_zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(PROJECT_ROOT):
            if "node_modules" in root or ".git" in root or "__pycache__" in root or "dist" in root:
                continue
            for file in files:
                full_path = Path(root) / file
                rel_path = full_path.relative_to(PROJECT_ROOT)
                if file.endswith(".zip"):
                    continue
                zipf.write(full_path, arcname=str(Path("KAGEVIETSUB") / rel_path))
    return export_zip_path

# ==============================================================================
# FASTAPI APP (NẾU CÓ CÀI ĐẶT FASTAPI & UVICORN)
# ==============================================================================
try:
    from fastapi import FastAPI, HTTPException, Request, UploadFile, File, Form
    from fastapi.staticfiles import StaticFiles
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import FileResponse, JSONResponse
    import uvicorn

    from TOOL.api.srt_api import router as srt_router
    from TOOL.api.audio_api import router as audio_router
    from TOOL.api.video_api import router as video_router
    from TOOL.api.whisper_api import router as whisper_router
    from TOOL.api.tts_api import router as tts_router

    fastapi_app = FastAPI(
        title="KAGEVIETSUB",
        description="Studio xử lý phụ đề SRT, Video, Audio và Whisper trên Android & PC",
        version="1.0.0"
    )

    fastapi_app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    fastapi_app.include_router(srt_router)
    fastapi_app.include_router(audio_router)
    fastapi_app.include_router(video_router)
    fastapi_app.include_router(whisper_router)
    fastapi_app.include_router(tts_router)

    @fastapi_app.get("/api/health")
    def api_health():
        return get_health_data()

    @fastapi_app.get("/api/system/info")
    def api_system_info():
        return get_full_system_info()

    @fastapi_app.get("/api/jobs/{job_id}")
    def api_get_job(job_id: str):
        job = job_manager.get_job(job_id)
        if not job:
            raise HTTPException(status_code=404, detail=f"Không tìm thấy tác vụ với ID '{job_id}'")
        return job

    @fastapi_app.get("/api/jobs")
    def api_list_jobs():
        return {"jobs": job_manager.list_jobs()}

    @fastapi_app.get("/api/download/{filename}")
    def api_download(filename: str):
        safe_name = Path(filename).name
        file_path = OUTPUT_DIR / safe_name
        if not file_path.exists() or not file_path.is_file():
            temp_path = TEMP_DIR / safe_name
            if temp_path.exists() and temp_path.is_file():
                file_path = temp_path
            else:
                raise HTTPException(status_code=404, detail=f"File '{filename}' không tồn tại.")

        return FileResponse(
            path=str(file_path),
            filename=safe_name,
            media_type="application/octet-stream"
        )

    @fastapi_app.post("/api/cleanup")
    def api_cleanup():
        return CleanupService.clear_temp_folder()

    @fastapi_app.get("/api/version")
    def api_version():
        return {
            "version": get_local_version(),
            "app_name": "KAGEVIETSUB"
        }

    @fastapi_app.get("/api/update/check")
    def api_update_check():
        has_update, latest_ver, update_info = check_for_update()
        return {
            "has_update": has_update,
            "current_version": get_local_version(),
            "latest_version": latest_ver,
            "is_busy": is_system_busy(),
            "download_url": update_info.get("url", ""),
            "sha256": update_info.get("sha256", ""),
            "release_notes": update_info.get("notes", "")
        }

    @fastapi_app.get("/api/export-project")
    def api_export_zip():
        zip_path = create_export_zip()
        return FileResponse(
            path=str(zip_path),
            filename="KAGEVIETSUB.zip",
            media_type="application/zip"
        )

    if WEB_DIR.exists():
        if (WEB_DIR / "assets").exists():
            fastapi_app.mount("/assets", StaticFiles(directory=str(WEB_DIR / "assets")), name="assets")
        
        @fastapi_app.get("/{full_path:path}")
        async def serve_spa(full_path: str):
            if full_path.startswith("api/"):
                raise HTTPException(status_code=404, detail="API route not found")
            file_path = WEB_DIR / full_path
            if file_path.exists() and file_path.is_file():
                return FileResponse(file_path)
            index_file = WEB_DIR / "index.html"
            if index_file.exists():
                return FileResponse(index_file)
            raise HTTPException(status_code=404, detail="File not found")

    HAS_FASTAPI_SERVER = True
except Exception as e:
    logger.info(f"FastAPI / Uvicorn không khả dụng ({e}). Sử dụng Standalone Multi-threaded Engine.")
    HAS_FASTAPI_SERVER = False
    fastapi_app = None

# ==============================================================================
# STANDALONE MULTI-THREADED HTTP SERVER (ZERO-DEPENDENCY PURE PYTHON 3.14)
# ==============================================================================
class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True

class DSubRequestHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(WEB_DIR) if WEB_DIR.exists() else str(PROJECT_ROOT), **kwargs)

    def _send_cors_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, DELETE")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With")

    def _send_json(self, data: Any, status_code: int = 200):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self._send_cors_headers()
        self.end_headers()
        self.wfile.write(body)

    def _send_file_download(self, file_path: Path, filename: str, mime_type: str = "application/octet-stream"):
        if not file_path.exists():
            self._send_json({"error": f"File '{filename}' không tồn tại."}, 404)
            return
        file_size = file_path.stat().st_size
        self.send_response(200)
        self.send_header("Content-Type", mime_type)
        self.send_header("Content-Length", str(file_size))
        self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self._send_cors_headers()
        self.end_headers()
        with open(file_path, "rb") as f:
            shutil.copyfileobj(f, self.wfile)

    def do_OPTIONS(self):
        self.send_response(204)
        self._send_cors_headers()
        self.end_headers()

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path == "/api/health":
            return self._send_json(get_health_data())

        if path == "/api/system/info":
            return self._send_json(get_full_system_info())

        if path == "/api/jobs":
            return self._send_json({"jobs": job_manager.list_jobs()})

        if path.startswith("/api/jobs/"):
            job_id = path[len("/api/jobs/"):]
            job = job_manager.get_job(job_id)
            if not job:
                return self._send_json({"detail": f"Không tìm thấy job '{job_id}'"}, 404)
            return self._send_json(job)

        if path.startswith("/api/download/"):
            raw_filename = urllib.parse.unquote(path[len("/api/download/"):])
            # Chặn triệt để Path Traversal
            if ".." in raw_filename or "/" in raw_filename or "\\" in raw_filename:
                return self._send_json({"detail": "Yêu cầu đường dẫn không an toàn."}, 400)
            safe_name = Path(raw_filename).name
            target = KAGE_DOWNLOAD_DIR / safe_name
            if not target.exists():
                target = OUTPUT_DIR / safe_name
            if not target.exists():
                target = TEMP_DIR / safe_name
            return self._send_file_download(target, safe_name)

        if path == "/api/export-project":
            zip_p = create_export_zip()
            return self._send_file_download(zip_p, "KAGEVIETSUB.zip", "application/zip")

        if path == "/api/whisper/models":
            return self._send_json(handle_whisper_models())

        if path == "/api/tts/voices":
            return self._send_json(handle_tts_voices())

        if path.startswith("/api/tts/job/"):
            tts_jid = path[len("/api/tts/job/"):]
            try:
                return self._send_json(handle_tts_get_job(tts_jid))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 404)

        if path.startswith("/api/tts/preview/"):
            parts = path[len("/api/tts/preview/"):].split("?")[0].split("/")
            if len(parts) >= 2:
                jid, idx_str = parts[0], parts[1]
                try:
                    idx = int(idx_str)
                    preview_p = handle_tts_preview(jid, idx)
                    if not preview_p.exists():
                        return self._send_json({"detail": "File preview không tồn tại."}, 404)
                    file_size = preview_p.stat().st_size
                    self.send_response(200)
                    self.send_header("Content-Type", "audio/mpeg")
                    self.send_header("Content-Length", str(file_size))
                    self.send_header("Accept-Ranges", "bytes")
                    self.send_header("Cache-Control", "public, max-age=3600")
                    self._send_cors_headers()
                    self.end_headers()
                    with open(preview_p, "rb") as f:
                        shutil.copyfileobj(f, self.wfile)
                    return
                except Exception as e:
                    return self._send_json({"detail": str(e)}, 404)

        if path == "/api/version":
            return self._send_json({
                "version": get_local_version(),
                "app_name": "KAGEVIETSUB"
            })

        if path == "/api/update/check":
            has_update, latest_ver, update_info = check_for_update()
            return self._send_json({
                "has_update": has_update,
                "current_version": get_local_version(),
                "latest_version": latest_ver,
                "is_busy": is_system_busy(),
                "download_url": update_info.get("url", ""),
                "sha256": update_info.get("sha256", ""),
                "release_notes": update_info.get("notes", "")
            })

        # Fallback to static files or SPA index.html
        target = WEB_DIR / path.lstrip("/")
        if target.exists() and target.is_file():
            return super().do_GET()
        index_file = WEB_DIR / "index.html"
        if index_file.exists():
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(index_file.stat().st_size))
            self._send_cors_headers()
            self.end_headers()
            with open(index_file, "rb") as f:
                shutil.copyfileobj(f, self.wfile)
            return
        return super().do_GET()

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        content_type = self.headers.get("Content-Type", "")
        content_length = int(self.headers.get("Content-Length", 0))

        # 1. Xử lý Multipart Form Data (File Uploads)
        if "multipart/form-data" in content_type:
            raw_body = self.rfile.read(content_length)
            boundary = content_type.split("boundary=")[1].encode("utf-8")
            parts = raw_body.split(b"--" + boundary)

            form_fields = {}
            uploaded_files = []

            for p in parts:
                if not p or p == b"--\r\n" or p == b"--":
                    continue
                header_part, _, body_part = p.partition(b"\r\n\r\n")
                body_part = body_part.rstrip(b"\r\n")
                header_str = header_part.decode("utf-8", errors="ignore")

                if 'filename="' in header_str:
                    fn_match = re_filename(header_str)
                    if fn_match and body_part:
                        saved_p = FileService.save_upload(body_part, fn_match)
                        uploaded_files.append((fn_match, saved_p))
                elif 'name="' in header_str:
                    field_name = re_name(header_str)
                    if field_name:
                        form_fields[field_name] = body_part.decode("utf-8", errors="ignore")

            # Route Multipart Endpoints
            if path == "/api/audio/merge":
                paths = [p for _, p in uploaded_files]
                out_name = form_fields.get("output_filename", "combined.mp3")
                sort_alpha = form_fields.get("sort_alphabetical", "true").lower() == "true"
                try:
                    res = handle_audio_merge(paths, out_name, sort_alpha)
                    return self._send_json(res)
                except Exception as e:
                    return self._send_json({"detail": str(e)}, 400)

            if path == "/api/video/cut":
                if not uploaded_files:
                    return self._send_json({"detail": "Chưa chọn file video"}, 400)
                fn, p = uploaded_files[0]
                mins = int(form_fields.get("segment_minutes", 5))
                mode = form_fields.get("mode", "copy")
                res = handle_video_cut(p, fn, mins, mode)
                return self._send_json(res)

            if path == "/api/video/merge":
                paths = [p for _, p in uploaded_files]
                out_name = form_fields.get("output_filename", "merged_video.mp4")
                mode = form_fields.get("mode", "lossless")
                caption = form_fields.get("caption") or None
                font_sz = int(form_fields.get("font_size", 24))
                font_col = form_fields.get("font_color", "white")
                pos = form_fields.get("caption_position", "bottom")
                try:
                    res = handle_video_merge(paths, out_name, mode, caption, font_sz, font_col, pos)
                    return self._send_json(res)
                except Exception as e:
                    return self._send_json({"detail": str(e)}, 400)

            if path == "/api/video/compress":
                if not uploaded_files:
                    return self._send_json({"detail": "Chưa chọn file video"}, 400)
                fn, p = uploaded_files[0]
                crf = int(form_fields.get("crf", 18))
                preset = form_fields.get("preset", "slow")
                codec = form_fields.get("codec", "libx264")
                res = handle_video_compress(p, fn, crf, preset, codec)
                return self._send_json(res)

            if path == "/api/whisper/transcribe":
                if not uploaded_files:
                    return self._send_json({"detail": "Chưa chọn file âm thanh/video"}, 400)
                fn, p = uploaded_files[0]
                model_sz = form_fields.get("model_size", "large-v3-turbo")
                beam = int(form_fields.get("beam_size", 5))
                lang = form_fields.get("language", "zh")
                mw = int(form_fields.get("max_words", 20))
                md = float(form_fields.get("max_duration", 6.0))
                st = float(form_fields.get("silence_threshold", 0.3))
                res = handle_whisper_transcribe(p, fn, model_sz, beam, lang, mw, md, st)
                return self._send_json(res)

            if path == "/api/video/info":
                if not uploaded_files:
                    return self._send_json({"detail": "Chưa chọn file"}, 400)
                fn, p = uploaded_files[0]
                info = FFmpegService.get_media_info(p)
                return self._send_json({"filename": fn, "info": info})

        # 2. Xử lý JSON Body
        raw_body = self.rfile.read(content_length).decode("utf-8") if content_length > 0 else "{}"
        try:
            payload = json.loads(raw_body) if raw_body else {}
        except Exception:
            payload = {}

        if path == "/api/cleanup":
            return self._send_json(CleanupService.clear_temp_folder())

        if path == "/api/whisper/models/download":
            model_id = payload.get("model_id", "")
            try:
                return self._send_json(handle_download_whisper_model(model_id))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/whisper/models/scan":
            return self._send_json(handle_whisper_models())

        # TTS Endpoints
        if path == "/api/tts/parse-srt":
            srt_cnt = payload.get("srt_content") or payload.get("content") or ""
            try:
                return self._send_json(handle_tts_parse_srt(srt_cnt))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/tts/create-job":
            srt_cnt = payload.get("srt_content") or payload.get("content") or ""
            vc = payload.get("voice", "BV421_vivn_streaming")
            spd = float(payload.get("speed", 1.0))
            thrd = int(payload.get("threads", 5))
            out_fn = payload.get("output_filename")
            try:
                return self._send_json(handle_tts_create_job(srt_cnt, vc, spd, thrd, out_fn))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/tts/retry":
            jid = payload.get("job_id", "")
            idx = int(payload.get("subtitle_index", 1))
            vc = payload.get("voice")
            spd = float(payload.get("speed")) if payload.get("speed") is not None else None
            try:
                return self._send_json(handle_tts_retry(jid, idx, vc, spd))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/tts/pause":
            jid = payload.get("job_id", "")
            try:
                return self._send_json(handle_tts_pause(jid))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/tts/resume":
            jid = payload.get("job_id", "")
            try:
                return self._send_json(handle_tts_resume(jid))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/tts/stop":
            jid = payload.get("job_id", "")
            try:
                return self._send_json(handle_tts_stop(jid))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/shutdown":
            try:
                threading.Thread(target=perform_graceful_shutdown, daemon=True).start()
                return self._send_json({"status": "ok", "message": "Máy chủ đang tiến hành dừng an toàn..."})
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        if path == "/api/tts/merge":
            jid = payload.get("job_id", "")
            out_fn = payload.get("output_filename", "tts_final_audio.mp3")
            try:
                return self._send_json(handle_tts_merge(jid, out_fn))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        # SRT Endpoints
        content = payload.get("content", "")
        rules = payload.get("rules")

        if path == "/api/srt/parse":
            return self._send_json(handle_parse_srt(content))
        if path == "/api/srt/remove-trailing-punctuation":
            return self._send_json(handle_remove_trailing_punct(content))
        if path == "/api/srt/remove-leading-ellipsis":
            return self._send_json(handle_remove_leading_ellipsis(content))
        if path == "/api/srt/replace":
            return self._send_json(handle_replace_rules(content, rules))
        if path == "/api/srt/avoid-overlap":
            return self._send_json(handle_avoid_overlap(content))
        if path == "/api/srt/purple-sequence":
            return self._send_json(handle_purple_sequence(content, rules))
        if path == "/api/srt/fix-repeat-2-3":
            return self._send_json(handle_fix_repeat_2_3(content))
        if path == "/api/srt/fix-repeat-4-5":
            return self._send_json(handle_fix_repeat_4_5(content))
        if path == "/api/srt/merge-short":
            return self._send_json(handle_merge_short(content))
        if path == "/api/srt/all-steps":
            return self._send_json(handle_all_steps(content, rules))
        if path == "/api/srt/uppercase":
            return self._send_json(handle_uppercase(content))
        if path == "/api/srt/save":
            filename = payload.get("filename", "edited.srt")
            try:
                return self._send_json(handle_save_srt(content, filename))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)
        if path == "/api/srt/split":
            s_per = int(payload.get("sentences_per_file", 10))
            base_n = payload.get("base_name", "subtitle")
            try:
                return self._send_json(handle_split_srt(content, s_per, base_n))
            except Exception as e:
                return self._send_json({"detail": str(e)}, 400)

        return self._send_json({"detail": f"Endpoint POST '{path}' không tồn tại."}, 404)

def re_filename(headers: str) -> Optional[str]:
    import re
    m = re.search(r'filename="([^"]+)"', headers)
    return m.group(1) if m else None

def re_name(headers: str) -> Optional[str]:
    import re
    m = re.search(r'name="([^"]+)"', headers)
    return m.group(1) if m else None

# ==============================================================================
# GRACEFUL SHUTDOWN & ENTRY POINT
# ==============================================================================
_shutdown_in_progress = False

def perform_graceful_shutdown():
    """Thực hiện quy trình dừng server an toàn 3 bước."""
    global _shutdown_in_progress
    if _shutdown_in_progress:
        return
    _shutdown_in_progress = True

    print("\n==================================================")
    print("KAGEVIETSUB")
    print("Đang dừng server...\n")
    print("[1/3] Dừng nhận job mới...")
    job_manager.request_shutdown(timeout_sec=2.0)
    time.sleep(0.5)

    print("[2/3] Dọn file tạm...")
    CleanupService.run_shutdown_cleanup()
    print("✓ Đã dọn file tạm")

    print("[3/3] Đóng server...")
    time.sleep(0.3)
    print("✓ Server đã dừng")
    print("==================================================\n")


def run_server(host: str = HOST, port: int = PORT):
    ensure_directories()
    CleanupService.cleanup_orphaned_temp()

    if HAS_FASTAPI_SERVER and fastapi_app is not None:
        try:
            logger.info(f"Khởi chạy FastAPI + Uvicorn tại http://{host}:{port}")
            print(f"\n[✓] KAGEVIETSUB SERVER ONLINE: http://{host}:{port}")
            uvicorn.run(fastapi_app, host=host, port=port, log_level="warning")
            perform_graceful_shutdown()
            return
        except KeyboardInterrupt:
            perform_graceful_shutdown()
            return
        except Exception as e:
            logger.warning(f"Uvicorn gặp lỗi ({e}). Tự động chuyển sang Standalone Server.")

    logger.info(f"Khởi chạy Standalone Multi-Threaded Engine tại http://{host}:{port}")
    server = ThreadedHTTPServer((host, port), DSubRequestHandler)
    print(f"\n[✓] KAGEVIETSUB SERVER ONLINE: http://{host}:{port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.server_close()
        perform_graceful_shutdown()

if __name__ == "__main__":
    run_server()
