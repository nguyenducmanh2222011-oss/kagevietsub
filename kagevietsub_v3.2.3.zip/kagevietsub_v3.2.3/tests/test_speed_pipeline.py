#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB - SPEED TTS PIPELINE TEST & BENCHMARK SUITE
==============================================================================
Kiểm thử toàn diện Pipeline TTS + Speed Engine:
1. Fast path 1.0x
2. Filter atempo & chaining cho các mức tốc độ (0.4x, 0.8x, 1.25x, 1.5x, 2.5x)
3. Chạy song song TTS Worker & Speed Worker
4. Chuyển đổi trạng thái PENDING -> TTS_PROCESSING -> TTS_COMPLETED -> SPEED_PROCESSING -> READY_FOR_MERGE
5. Khả năng Resume khi ứng dụng bị ngắt
6. Kiểm tra tính hợp lệ (Validation)
==============================================================================
"""

import os
import sys
import time
import shutil
import resource
import threading
import subprocess
from pathlib import Path
from typing import List, Dict, Any

# Setup import path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from TOOL.config import TEMP_DIR, KAGE_DOWNLOAD_DIR
from TOOL.engines.tts_engine import TTSEngine
from TOOL.integrations.capcut_tts_adapter import CapCutTTSAdapter
from TOOL.services.task_service import job_manager


def test_atempo_filter_chaining():
    print("\n[TEST 1] Kiểm tra tạo filter atempo & chaining cho FFmpeg...")
    adapter = CapCutTTSAdapter()

    f_1_0 = adapter.build_atempo_filter(1.0)
    assert f_1_0 == "", f"Expected empty for 1.0x, got '{f_1_0}'"

    f_0_8 = adapter.build_atempo_filter(0.8)
    assert f_0_8 == "atempo=0.8", f"Expected 'atempo=0.8', got '{f_0_8}'"

    f_1_25 = adapter.build_atempo_filter(1.25)
    assert f_1_25 == "atempo=1.25", f"Expected 'atempo=1.25', got '{f_1_25}'"

    f_2_5 = adapter.build_atempo_filter(2.5)
    assert f_2_5 == "atempo=2.0,atempo=1.25", f"Expected 'atempo=2.0,atempo=1.25', got '{f_2_5}'"

    f_0_4 = adapter.build_atempo_filter(0.4)
    assert f_0_4 == "atempo=0.5,atempo=0.8", f"Expected 'atempo=0.5,atempo=0.8', got '{f_0_4}'"

    print(" -> atempo 1.0x : Fast path (empty filter)")
    print(f" -> atempo 0.8x : {f_0_8}")
    print(f" -> atempo 1.25x: {f_1_25}")
    print(f" -> atempo 2.5x : {f_2_5} (Chained)")
    print(f" -> atempo 0.4x : {f_0_4} (Chained)")
    print(" [✓] TEST 1 PASS")


def test_1_0x_fast_path():
    print("\n[TEST 2] Kiểm tra 1.0x Fast Path (không qua FFmpeg speed)...")
    adapter = CapCutTTSAdapter()
    sample_dir = TEMP_DIR / "tts_test_fastpath"
    sample_dir.mkdir(parents=True, exist_ok=True)

    raw_file = sample_dir / "raw_0001.mp3"
    final_file = sample_dir / "0001.mp3"

    cmd = [
        "ffmpeg", "-y", "-f", "lavfi",
        "-i", "sine=frequency=440:sample_rate=44100",
        "-t", "2.0",
        "-vn", "-ar", "44100", "-ac", "2", "-b:a", "192k",
        str(raw_file), "-loglevel", "error"
    ]
    subprocess.run(cmd, check=True)

    t0 = time.time()
    ok, dur, err = adapter.apply_speed(raw_file, final_file, speed=1.0)
    elapsed = time.time() - t0

    assert ok, f"Fast path failed: {err}"
    assert final_file.exists()
    assert elapsed < 1.0, f"Fast path should be sub-second, took {elapsed:.4f}s"
    print(f" -> Fast path completed in {elapsed*1000:.2f} ms (duration={dur:.2f}s)")

    shutil.rmtree(sample_dir, ignore_errors=True)
    print(" [✓] TEST 2 PASS")


def test_speed_pipeline_end_to_end():
    print("\n[TEST 3] Kiểm tra Pipeline TTS + Speed Workers end-to-end...")
    job_id = f"test_pipeline_{int(time.time())}"
    
    subs = [
        {"id": "0001", "start": "00:00:01,000", "end": "00:00:03,000", "text": "Câu phụ đề số 1."},
        {"id": "0002", "start": "00:00:04,000", "end": "00:00:06,000", "text": "Câu phụ đề số 2."},
        {"id": "0003", "start": "00:00:07,000", "end": "00:00:09,000", "text": "Câu phụ đề số 3."},
    ]

    job = TTSEngine.process_tts_job(
        job_id=job_id,
        subtitles=subs,
        voice="BV421_vivn_streaming",
        speed=1.25,
        threads=2
    )

    res = job["result"]
    assert res["completed"] == 3, f"Expected 3 completed, got {res['completed']}"
    assert res["failed"] == 0, f"Expected 0 failed, got {res['failed']}"

    for sub in res["subtitles"]:
        assert sub["status"] == "READY_FOR_MERGE", f"Sub {sub['index']} status is {sub['status']}"
        assert sub["duration"] > 0, "Duration must be positive"

    print(" -> Tình trạng 3 câu phụ đề đều là READY_FOR_MERGE với speed 1.25x.")
    print(" [✓] TEST 3 PASS")


def test_resume_capability():
    print("\n[TEST 4] Kiểm tra tính năng Resume khi RAW AUDIO hoặc FINAL AUDIO đã tồn tại...")
    job_id = f"test_resume_{int(time.time())}"
    job_dir = TEMP_DIR / "tts" / f"job_{job_id}"
    job_dir.mkdir(parents=True, exist_ok=True)

    final_1 = job_dir / "0001.mp3"
    cmd = [
        "ffmpeg", "-y", "-f", "lavfi",
        "-i", "sine=frequency=440:sample_rate=44100",
        "-t", "1.5",
        "-vn", "-ar", "44100", "-ac", "2", "-b:a", "192k",
        str(final_1), "-loglevel", "error"
    ]
    subprocess.run(cmd, check=True)

    subs = [
        {"id": "0001", "start": "00:00:01,000", "end": "00:00:03,000", "text": "Câu 1 đã có final."},
        {"id": "0002", "start": "00:00:04,000", "end": "00:00:06,000", "text": "Câu 2 cần tạo mới."}
    ]

    job = TTSEngine.process_tts_job(
        job_id=job_id,
        subtitles=subs,
        voice="BV421_vivn_streaming",
        speed=1.5,
        threads=2
    )

    res = job["result"]
    assert res["completed"] == 2
    sub1 = res["subtitles"][0]
    assert sub1["status"] == "READY_FOR_MERGE"
    assert abs(sub1["duration"] - 1.5) < 0.2, f"Resumed final duration should be ~1.5s, got {sub1['duration']}"

    print(" -> Tự động phát hiện file đã hoàn thành và Resume thành công.")
    print(" [✓] TEST 4 PASS")


def run_all_tests():
    print("=" * 70)
    print("KAGEVIETSUB - CHECKING SPEED TTS PIPELINE")
    print("=" * 70)

    test_atempo_filter_chaining()
    test_1_0x_fast_path()
    test_speed_pipeline_end_to_end()
    test_resume_capability()

    print("\n" + "=" * 70)
    print("TẤT CẢ CÁC BÀI TEST CHỨC NĂNG SPEED PIPELINE ĐÃ ĐẠT 100%!")
    print("=" * 70)


if __name__ == "__main__":
    run_all_tests()
