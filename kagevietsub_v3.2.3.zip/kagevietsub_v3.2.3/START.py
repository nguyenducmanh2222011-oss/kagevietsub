#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB - SINGLE LAUNCHER (PYTHON 3.14 + TERMUX ANDROID & PC)
==============================================================================
Khởi chạy duy nhất:
    python START.py  (trên Android Termux, Linux, Windows, macOS)
Tùy chọn CLI:
    python START.py --check       (Kiểm tra toàn bộ hệ thống)
    python START.py --debug       (Bật chế độ debug chi tiết)
    python START.py --no-browser  (Không tự động mở trình duyệt)
    python START.py --port 8000   (Tùy chỉnh cổng máy chủ)
==============================================================================
"""

import os
import sys
import socket
import shutil
import subprocess
import platform
import threading
import time
import argparse
import webbrowser
from pathlib import Path

# 1. Xác định đường dẫn gốc và thêm vào sys.path
ROOT_DIR = Path(__file__).resolve().parent
TOOL_DIR = ROOT_DIR / "TOOL"
DATA_DIR = ROOT_DIR / "DATA"
LOGS_DIR = DATA_DIR / "logs"

if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))
if str(TOOL_DIR) not in sys.path:
    sys.path.insert(0, str(TOOL_DIR))

# Import CLI UI toolkit
from TOOL.cli_ui import (
    Colors, Icons, print_banner, print_step, print_server_card,
    print_info, print_success, print_warning, print_error,
    set_terminal_title, clear_screen
)
from TOOL.system_check import (
    is_android, check_python_version, check_ffmpeg,
    print_system_check_report, get_full_system_info
)

def ensure_data_folders():
    """Tự động tạo các thư mục runtime trong DATA/."""
    for sub in ["temp", "output", "uploads", "models", "logs"]:
        (DATA_DIR / sub).mkdir(parents=True, exist_ok=True)

def get_lan_ip() -> str:
    """Tự động phát hiện địa chỉ IP trong mạng nội bộ (LAN)."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"

def open_browser(url: str, delay: float = 0.8):
    """Mở trình duyệt sau khi máy chủ bắt đầu chạy."""
    def _open():
        time.sleep(delay)
        try:
            if is_android() and shutil.which("termux-open-url"):
                import subprocess
                subprocess.run(["termux-open-url", url], capture_output=True)
            else:
                webbrowser.open_new_tab(url)
        except Exception:
            pass
    t = threading.Thread(target=_open, daemon=True)
    t.start()

def parse_arguments():
    """Phân tích tham số dòng lệnh."""
    parser = argparse.ArgumentParser(
        description="KAGEVIETSUB - Bộ công cụ Video, SRT, Audio & TTS",
        add_help=True
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="Kiểm tra tương thích hệ thống và thoát"
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Kích hoạt chế độ debug hiển thị chi tiết lỗi"
    )
    parser.add_argument(
        "--no-browser",
        action="store_true",
        help="Không tự động mở trình duyệt web khi khởi chạy"
    )
    parser.add_argument(
        "--no-update-check",
        action="store_true",
        help="Bỏ qua kiểm tra cập nhật từ GitHub khi khởi động"
    )
    parser.add_argument(
        "--port",
        type=int,
        default=int(os.getenv("PORT", os.getenv("KAGE_PORT", os.getenv("DSUB_PORT", "8000")))),
        help="Cổng kết nối máy chủ (mặc định 8000)"
    )
    return parser.parse_args()

def main():
    args = parse_arguments()
    set_terminal_title("KAGEVIETSUB")
    ensure_data_folders()

    # Nếu chọn --check, in chẩn đoán hệ thống và thoát
    if args.check:
        clear_screen()
        print_banner()
        print_system_check_report()
        sys.exit(0)

    # Chế độ khởi động tiêu chuẩn
    clear_screen()
    print_banner()

    # Kiểm tra cập nhật tự động từ GitHub Releases (Offline-safe, timeout nhanh)
    if not args.no_update_check:
        try:
            from TOOL.updater import run_cli_update_flow
            run_cli_update_flow(prompt_user=True)
        except Exception:
            pass

    port = args.port
    host = "127.0.0.1"  # Bắt buộc Localhost Only: an toàn, không expose ra LAN/Internet
    debug_mode = args.debug

    # BƯỚC 1: Checking Python
    py_info = check_python_version()
    if py_info["is_supported"]:
        py_title = f"Checking Python {py_info['version']}"
        print_step(1, 7, py_title, status="ok")
    else:
        print_step(1, 7, f"Checking Python {py_info['version']}", status="fail", reason="Yêu cầu Python >= 3.8")
        if not debug_mode:
            sys.exit(1)

    # BƯỚC 2: Checking FFmpeg
    ff_info = check_ffmpeg()
    if ff_info["ffmpeg_installed"]:
        print_step(2, 7, "Checking FFmpeg", status="ok")
    else:
        print_step(2, 7, "Checking FFmpeg", status="warn")
        if is_android():
            print(f"        {Colors.GRAY}Gợi ý: Cài đặt FFmpeg trên Termux bằng lệnh: {Colors.CYAN}pkg install ffmpeg -y{Colors.RESET}")
        else:
            print(f"        {Colors.GRAY}Gợi ý: Thêm FFmpeg vào PATH hệ thống để kích hoạt đầy đủ Video/Audio Engine{Colors.RESET}")

    # BƯỚC 3: Checking configuration
    try:
        from TOOL import config
        print_step(3, 7, "Checking configuration", status="ok")
    except Exception as e:
        print_step(3, 7, "Checking configuration", status="fail", reason=str(e))
        if debug_mode:
            raise

    # BƯỚC 4: Checking SRT Engine
    try:
        from TOOL.engines import srt_engine
        print_step(4, 7, "Checking SRT Engine", status="ok")
    except Exception as e:
        print_step(4, 7, "Checking SRT Engine", status="fail", reason=str(e))
        if debug_mode:
            raise

    # BƯỚC 5: Checking Audio Engine
    try:
        from TOOL.engines import audio_engine
        print_step(5, 7, "Checking Audio Engine", status="ok")
    except Exception as e:
        print_step(5, 7, "Checking Audio Engine", status="fail", reason=str(e))
        if debug_mode:
            raise

    # BƯỚC 6: Checking Video Engine
    try:
        from TOOL.engines import video_engine
        print_step(6, 7, "Checking Video Engine", status="ok")
    except Exception as e:
        print_step(6, 7, "Checking Video Engine", status="fail", reason=str(e))
        if debug_mode:
            raise

    # BƯỚC 7: Starting server & Crash recovery
    try:
        from TOOL.services.cleanup_service import CleanupService
        CleanupService.cleanup_orphaned_temp()
    except Exception:
        pass

    print_step(7, 7, "Starting server (Localhost Only)", status="ok")

    local_url = f"http://127.0.0.1:{port}"

    # Hiển thị Card máy chủ Localhost
    print_server_card(local_url=local_url, port=port)

    # Tự động mở trình duyệt (nếu không dùng cờ --no-browser)
    if not args.no_browser:
        open_browser(local_url)

    # Chạy Server
    try:
        from TOOL.server import run_server
        run_server(host=host, port=port)
    except KeyboardInterrupt:
        print(f"\n {Colors.CYAN}{Icons.INFO}{Colors.RESET} {Colors.BRIGHT_WHITE}KAGEVIETSUB đã dừng an toàn. Hẹn gặp lại!{Colors.RESET}\n")
        sys.exit(0)
    except Exception as e:
        print_error("Lỗi khi khởi chạy máy chủ", reason=str(e))
        log_file = LOGS_DIR / "startup.log"
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(f"Server Fatal Error: {str(e)}\n")
        if debug_mode:
            import traceback
            traceback.print_exc()

if __name__ == "__main__":
    main()
