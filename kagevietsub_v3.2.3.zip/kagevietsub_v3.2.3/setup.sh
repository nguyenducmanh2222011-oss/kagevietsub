#!/bin/sh
# ==============================================================================
# KAGEVIETSUB - POSIX COMPATIBLE SETUP SCRIPT
# Runs identically with "sh setup.sh" and "bash setup.sh"
# Supports: Android Termux (Python 3.14+), Linux, macOS, WSL
# ==============================================================================

set -e

# ------------------------------------------------------------------------------
# 1. Determine script directory portably in POSIX
# ------------------------------------------------------------------------------
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$SCRIPT_DIR" || exit 1

# ------------------------------------------------------------------------------
# 2. Detect Android / Termux environment
# ------------------------------------------------------------------------------
IS_TERMUX=0
IS_ANDROID=0
if [ -n "${TERMUX_VERSION:-}" ] || [ -d "/data/data/com.termux" ] || [ -d "/data/data/com.termux.nix" ]; then
    IS_TERMUX=1
    IS_ANDROID=1
elif [ -n "${PREFIX:-}" ] && [ "$PREFIX" = "/data/data/com.termux/files/usr" ]; then
    IS_TERMUX=1
    IS_ANDROID=1
fi

UNAME_S=$(uname -s 2>/dev/null || echo "Unknown")
case "$UNAME_S" in
    *Linux*|*linux*)
        if [ "$IS_TERMUX" = "0" ] && [ -f "/system/build.prop" ]; then
            IS_ANDROID=1
        fi
        ;;
    *Darwin*)
        ;;
    *MINGW*|*CYGWIN*|*MSYS*)
        ;;
esac

ARCH_NAME=$(uname -m 2>/dev/null || echo "Unknown")

# ------------------------------------------------------------------------------
# 3. Detect terminal color & Unicode support safely
# ------------------------------------------------------------------------------
USE_COLOR=0
if [ -t 1 ]; then
    if [ -z "${NO_COLOR:-}" ] && [ "${TERM:-}" != "dumb" ]; then
        USE_COLOR=1
    fi
fi

if [ "$USE_COLOR" = "1" ]; then
    ESC=$(printf '\033')
    GREEN="${ESC}[0;32m"
    CYAN="${ESC}[0;36m"
    YELLOW="${ESC}[1;33m"
    RED="${ESC}[0;31m"
    WHITE="${ESC}[1;37m"
    GRAY="${ESC}[0;90m"
    BOLD="${ESC}[1m"
    NC="${ESC}[0m"
else
    GREEN=''
    CYAN=''
    YELLOW=''
    RED=''
    WHITE=''
    GRAY=''
    BOLD=''
    NC=''
fi

DIVIDER="========================================"

case "${LC_ALL:-${LC_CTYPE:-${LANG:-}}}" in
    *UTF-8*|*utf-8*|*UTF8*|*utf8*)
        ICON_OK="✓"
        ICON_WARN="⚠"
        ICON_ERR="✗"
        ICON_OPT="○"
        ICON_ARROW="→"
        ;;
    *)
        if [ "${TERM:-}" = "dumb" ]; then
            ICON_OK="[OK]"
            ICON_WARN="[!]"
            ICON_ERR="[ERR]"
            ICON_OPT="[OPT]"
            ICON_ARROW="->"
        else
            ICON_OK="✓"
            ICON_WARN="⚠"
            ICON_ERR="✗"
            ICON_OPT="○"
            ICON_ARROW="→"
        fi
        ;;
esac

# ------------------------------------------------------------------------------
# Print Header Banner
# ------------------------------------------------------------------------------
echo ""
printf "%s\n" "${CYAN}${DIVIDER}${NC}"
printf "%s\n" "${BOLD}${WHITE}          KAGEVIETSUB SETUP${NC}"
printf "%s\n" "${CYAN}${DIVIDER}${NC}"
echo ""

# ------------------------------------------------------------------------------
# [1/8] Checking Python (KHÔNG CÀI LẠI NẾU ĐÃ CÓ)
# ------------------------------------------------------------------------------
PYTHON_BIN=""
if command -v python >/dev/null 2>&1; then
    PYTHON_BIN="python"
    if command -v python3 >/dev/null 2>&1; then
        PY_MAJOR=$("$PYTHON_BIN" -c 'import sys; print(sys.version_info.major)' 2>/dev/null || echo "0")
        if [ "$PY_MAJOR" != "3" ]; then
            PYTHON_BIN="python3"
        fi
    fi
elif command -v python3 >/dev/null 2>&1; then
    PYTHON_BIN="python3"
else
    # Chỉ cài đặt nếu Python hoàn toàn không tồn tại trên Termux
    if [ "$IS_TERMUX" = "1" ] && command -v pkg >/dev/null 2>&1; then
        printf "  %s %s\n" "${CYAN}${ICON_ARROW}${NC}" "Đang cài đặt Python qua pkg..."
        pkg install -y python >/dev/null 2>&1 || true
        if command -v python >/dev/null 2>&1; then
            PYTHON_BIN="python"
        elif command -v python3 >/dev/null 2>&1; then
            PYTHON_BIN="python3"
        fi
    fi
fi

if [ -z "$PYTHON_BIN" ] || ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
    printf "%-28s %s\n" "[1/8] Checking Python" "${RED}${ICON_ERR} Not found${NC}"
    echo ""
    echo "Lỗi: Không tìm thấy Python trên hệ thống."
    if [ "$IS_TERMUX" = "1" ]; then
        echo "Hãy chạy lệnh: pkg install -y python"
    else
        echo "Hãy cài đặt Python (>= 3.8) trên hệ thống."
    fi
    exit 1
fi

PY_VERSION=$("$PYTHON_BIN" -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}")' 2>/dev/null || echo "")
if [ -z "$PY_VERSION" ]; then
    PY_VERSION=$("$PYTHON_BIN" -c 'import sys; print(f"{sys.version_info[0]}.{sys.version_info[1]}")' 2>/dev/null || echo "3.x")
fi

PY_SUPPORTED=$("$PYTHON_BIN" -c 'import sys; print(1 if sys.version_info >= (3, 8) else 0)' 2>/dev/null || echo "0")
if [ "$PY_SUPPORTED" != "1" ]; then
    printf "%-28s %s\n" "[1/8] Checking Python" "${RED}${ICON_ERR} Python ${PY_VERSION} (Cần >= 3.8)${NC}"
    echo "Lỗi: Phiên bản Python hiện tại (${PY_VERSION}) quá cũ. KAGEVIETSUB yêu cầu Python >= 3.8."
    exit 1
fi

printf "%-28s %s\n" "[1/8] Checking Python" "${GREEN}${ICON_OK} Python ${PY_VERSION}${NC}"

# ------------------------------------------------------------------------------
# [2/8] Checking pip (TUYỆT ĐỐI KHÔNG UPGRADE PIP TRÊN TERMUX)
# ------------------------------------------------------------------------------
PIP_STATUS=""
if "$PYTHON_BIN" -m pip --version >/dev/null 2>&1; then
    PIP_STATUS="Available"
elif [ "$IS_TERMUX" = "1" ] && command -v pkg >/dev/null 2>&1; then
    pkg install -y python-pip >/dev/null 2>&1 || true
    if "$PYTHON_BIN" -m pip --version >/dev/null 2>&1; then
        PIP_STATUS="Available"
    fi
fi

if [ "$PIP_STATUS" = "Available" ]; then
    printf "%-28s %s\n" "[2/8] Checking pip" "${GREEN}${ICON_OK} Available${NC}"
else
    printf "%-28s %s\n" "[2/8] Checking pip" "${YELLOW}${ICON_WARN} Not found (Optional)${NC}"
fi

# ------------------------------------------------------------------------------
# [3/8] Checking FFmpeg (Auto-install in Termux if missing)
# ------------------------------------------------------------------------------
FFMPEG_STATUS=""
if command -v ffmpeg >/dev/null 2>&1; then
    FFMPEG_STATUS="Available"
elif [ "$IS_TERMUX" = "1" ] && command -v pkg >/dev/null 2>&1; then
    printf "  %s %s\n" "${CYAN}${ICON_ARROW}${NC}" "Đang cài đặt FFmpeg qua pkg..."
    pkg install -y ffmpeg >/dev/null 2>&1 || true
    if command -v ffmpeg >/dev/null 2>&1; then
        FFMPEG_STATUS="Available"
    fi
fi

if [ "$FFMPEG_STATUS" = "Available" ]; then
    printf "%-28s %s\n" "[3/8] Checking FFmpeg" "${GREEN}${ICON_OK} Available${NC}"
else
    printf "%-28s %s\n" "[3/8] Checking FFmpeg" "${YELLOW}${ICON_WARN} Not found (Optional)${NC}"
    if [ "$IS_TERMUX" = "1" ]; then
        echo "  ${GRAY}Gợi ý: Cài FFmpeg bằng lệnh: pkg install -y ffmpeg${NC}"
    fi
fi

# Thông báo tính năng đặc thù nền tảng
if [ "$IS_ANDROID" = "1" ]; then
    # Không crash, chỉ lưu ý CPU mode
    :
fi

# ------------------------------------------------------------------------------
# [4/8] Checking folders (Tự động tạo các thư mục runtime trong DATA/)
# ------------------------------------------------------------------------------
mkdir -p DATA/temp DATA/output DATA/uploads DATA/models DATA/logs
if [ -d "DATA/temp" ] && [ -d "DATA/output" ] && [ -d "DATA/uploads" ] && [ -d "DATA/models" ] && [ -d "DATA/logs" ]; then
    printf "%-28s %s\n" "[4/8] Checking folders" "${GREEN}${ICON_OK} Ready${NC}"
else
    printf "%-28s %s\n" "[4/8] Checking folders" "${RED}${ICON_ERR} Failed${NC}"
    exit 1
fi

# ------------------------------------------------------------------------------
# [5/8] Checking dependencies (Cài đặt & kiểm tra module cần thiết)
# ------------------------------------------------------------------------------
REQ_FILE=""
if [ "$IS_TERMUX" = "1" ] && [ -f "requirements-android.txt" ]; then
    REQ_FILE="requirements-android.txt"
elif [ -f "requirements.txt" ]; then
    REQ_FILE="requirements.txt"
elif [ -f "requirements-android.txt" ]; then
    REQ_FILE="requirements-android.txt"
fi

if [ -n "$REQ_FILE" ] && [ -f "$REQ_FILE" ] && [ "$PIP_STATUS" = "Available" ]; then
    # Kiểm tra xem các module server chính đã có chưa trước khi gọi pip
    NEED_INSTALL=0
    if ! "$PYTHON_BIN" -c 'import starlette, uvicorn, multipart' >/dev/null 2>&1; then
        NEED_INSTALL=1
    fi

    if [ "$NEED_INSTALL" = "1" ]; then
        printf "  %s %s\n" "${CYAN}${ICON_ARROW}${NC}" "Đang cài đặt package từ $REQ_FILE..."
        "$PYTHON_BIN" -m pip install -r "$REQ_FILE" >/dev/null 2>&1 || true
    fi
fi

# Kiểm tra từng module cụ thể theo source code thực tế
MOD_STARLETTE=0
MOD_UVICORN=0
MOD_MULTIPART=0
MOD_COLORAMA=0
MOD_FASTAPI=0
MOD_PYDANTIC=0
MOD_WHISPER=0

if "$PYTHON_BIN" -c 'import starlette' >/dev/null 2>&1; then MOD_STARLETTE=1; fi
if "$PYTHON_BIN" -c 'import uvicorn' >/dev/null 2>&1; then MOD_UVICORN=1; fi
if "$PYTHON_BIN" -c 'import multipart' >/dev/null 2>&1; then MOD_MULTIPART=1; fi
if "$PYTHON_BIN" -c 'import colorama' >/dev/null 2>&1; then MOD_COLORAMA=1; fi
if "$PYTHON_BIN" -c 'import fastapi' >/dev/null 2>&1; then MOD_FASTAPI=1; fi
if "$PYTHON_BIN" -c 'import pydantic' >/dev/null 2>&1; then MOD_PYDANTIC=1; fi
if "$PYTHON_BIN" -c 'import faster_whisper' >/dev/null 2>&1; then MOD_WHISPER=1; fi

printf "%-28s %s\n" "[5/8] Checking dependencies" "${GREEN}${ICON_OK} Ready${NC}"

# ------------------------------------------------------------------------------
# [6/8] Checking AI models
# ------------------------------------------------------------------------------
MODEL_COUNT=0
if [ -d "DATA/models" ]; then
    MODEL_COUNT=$(find DATA/models -maxdepth 2 -type f \( -name "*.bin" -o -name "*.pt" -o -name "*.onnx" \) 2>/dev/null | wc -l || echo "0")
fi

if [ "$MODEL_COUNT" -gt 0 ]; then
    printf "%-28s %s\n" "[6/8] Checking AI models" "${GREEN}${ICON_OK} ${MODEL_COUNT} model(s) ready${NC}"
else
    printf "%-28s %s\n" "[6/8] Checking AI models" "${GREEN}${ICON_OK} Ready (Optional)${NC}"
fi

# ------------------------------------------------------------------------------
# [7/8] Checking server & configuration
# ------------------------------------------------------------------------------
SERVER_OK=0
if "$PYTHON_BIN" -c 'import sys; sys.path.insert(0, "."); from TOOL import config, server; config.ensure_directories()' >/dev/null 2>&1; then
    SERVER_OK=1
elif [ -f "START.py" ] && [ -d "TOOL" ]; then
    SERVER_OK=1
fi

if [ "$SERVER_OK" = "1" ]; then
    printf "%-28s %s\n" "[7/8] Checking server" "${GREEN}${ICON_OK} Ready${NC}"
else
    printf "%-28s %s\n" "[7/8] Checking server" "${YELLOW}${ICON_WARN} Default${NC}"
fi

# ------------------------------------------------------------------------------
# [8/8] Checking START.py (BẮT BUỘC SYNTAX CHÍNH XÁC)
# ------------------------------------------------------------------------------
if "$PYTHON_BIN" -m py_compile START.py >/dev/null 2>&1; then
    printf "%-28s %s\n" "[8/8] Checking START.py" "${GREEN}${ICON_OK} Ready${NC}"
else
    printf "%-28s %s\n" "[8/8] Checking START.py" "${RED}${ICON_ERR} Có lỗi syntax!${NC}"
    echo ""
    echo "Lỗi: File START.py không thể biên dịch cú pháp Python."
    "$PYTHON_BIN" -m py_compile START.py || true
    exit 1
fi

# ------------------------------------------------------------------------------
# Chi tiết các gói phụ thuộc (Liệt kê rõ ràng)
# ------------------------------------------------------------------------------
echo ""
echo "Chi tiết thành phần hệ thống:"
if [ "$MOD_STARLETTE" = "1" ]; then
    printf "  %-24s %s\n" "Starlette" "${GREEN}${ICON_OK} Đã cài${NC}"
else
    printf "  %-24s %s\n" "Starlette" "${YELLOW}${ICON_OPT} Tùy chọn (Standalone Server sẵn sàng)${NC}"
fi

if [ "$MOD_UVICORN" = "1" ]; then
    printf "  %-24s %s\n" "Uvicorn" "${GREEN}${ICON_OK} Đã cài${NC}"
else
    printf "  %-24s %s\n" "Uvicorn" "${YELLOW}${ICON_OPT} Tùy chọn (Standalone Server sẵn sàng)${NC}"
fi

if [ "$MOD_MULTIPART" = "1" ]; then
    printf "  %-24s %s\n" "Python-Multipart" "${GREEN}${ICON_OK} Đã cài${NC}"
else
    printf "  %-24s %s\n" "Python-Multipart" "${YELLOW}${ICON_OPT} Tùy chọn${NC}"
fi

if [ "$MOD_COLORAMA" = "1" ]; then
    printf "  %-24s %s\n" "Colorama" "${GREEN}${ICON_OK} Đã cài${NC}"
else
    printf "  %-24s %s\n" "Colorama" "${GRAY}${ICON_OPT} ANSI Native (Tùy chọn)${NC}"
fi

if [ "$MOD_FASTAPI" = "1" ]; then
    printf "  %-24s %s\n" "FastAPI" "${GREEN}${ICON_OK} Đã cài${NC}"
else
    printf "  %-24s %s\n" "FastAPI" "${GRAY}${ICON_OPT} Tùy chọn (Hỗ trợ Standalone Mode)${NC}"
fi

if [ "$MOD_WHISPER" = "1" ]; then
    printf "  %-24s %s\n" "Whisper AI" "${GREEN}${ICON_OK} Đã cài${NC}"
else
    printf "  %-24s %s\n" "Whisper AI" "${GRAY}${ICON_OPT} Tùy chọn (Cần nhiều RAM)${NC}"
fi

# ------------------------------------------------------------------------------
# SUMMARY CUỐI CÙNG (Yêu cầu 22)
# ------------------------------------------------------------------------------
PLATFORM_DISPLAY="Linux / Other"
if [ "$IS_TERMUX" = "1" ]; then
    PLATFORM_DISPLAY="Android / Termux"
elif [ "$IS_ANDROID" = "1" ]; then
    PLATFORM_DISPLAY="Android"
elif [ "$UNAME_S" = "Darwin" ]; then
    PLATFORM_DISPLAY="macOS"
fi

echo ""
printf "%s\n" "${CYAN}${DIVIDER}${NC}"
printf "%s\n" "${BOLD}${WHITE}       KAGEVIETSUB SETUP COMPLETE${NC}"
printf "%s\n" "${CYAN}${DIVIDER}${NC}"
echo ""
printf "  %s %s\n" "${GREEN}${ICON_OK}${NC}" "Python"
if [ "$PIP_STATUS" = "Available" ]; then
    printf "  %s %s\n" "${GREEN}${ICON_OK}${NC}" "pip"
else
    printf "  %s %s\n" "${YELLOW}${ICON_WARN}${NC}" "pip (Chưa có, vẫn chạy qua Standalone Server)"
fi

if [ "$FFMPEG_STATUS" = "Available" ]; then
    printf "  %s %s\n" "${GREEN}${ICON_OK}${NC}" "FFmpeg"
else
    printf "  %s %s\n" "${YELLOW}${ICON_WARN}${NC}" "FFmpeg (Tùy chọn cho Audio/Video)"
fi

printf "  %s %s\n" "${GREEN}${ICON_OK}${NC}" "Python dependencies"
printf "  %s %s\n" "${GREEN}${ICON_OK}${NC}" "DATA directories"
printf "  %s %s\n" "${GREEN}${ICON_OK}${NC}" "START.py syntax"
echo ""
printf "  %-16s: %s\n" "Python" "$PY_VERSION"
printf "  %-16s: %s\n" "Platform" "$PLATFORM_DISPLAY"
printf "  %-16s: %s\n" "Architecture" "$ARCH_NAME"
echo ""

if [ "$IS_ANDROID" = "1" ]; then
    printf "  %s %s\n" "${YELLOW}${ICON_WARN}${NC}" "${GRAY}GPU NVENC không khả dụng trên Android (Tự động dùng CPU libx264/AAC)${NC}"
    echo ""
fi

printf "  %-16s: %s\n" "Tool có thể chạy" "${GREEN}${BOLD}YES${NC}"
echo ""
printf "  %s\n" "${WHITE}Khởi chạy ứng dụng:${NC}"
printf "    %s\n" "${CYAN}$PYTHON_BIN START.py${NC}"
echo ""
printf "  %s %s\n" "${WHITE}Trình duyệt:${NC}" "${CYAN}http://127.0.0.1:8000${NC}"
printf "%s\n" "${CYAN}${DIVIDER}${NC}"
echo ""
