#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB - UPDATER ENTRY POINT
==============================================================================
Chạy độc lập để kiểm tra và cập nhật KAGEVIETSUB lên bản mới nhất:
    python updater.py
==============================================================================
"""

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent
TOOL_DIR = ROOT_DIR / "TOOL"
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))
if str(TOOL_DIR) not in sys.path:
    sys.path.insert(0, str(TOOL_DIR))

from TOOL.updater import run_cli_update_flow, get_local_version, check_for_update
from TOOL.cli_ui import print_banner, set_terminal_title, print_info, print_success, Colors

def main():
    set_terminal_title("KAGEVIETSUB - Updater")
    print_banner()
    local_ver = get_local_version()
    print_info(f"Phiên bản hiện tại: {Colors.BRIGHT_CYAN}v{local_ver}{Colors.RESET}")
    print_info("Đang kiểm tra bản cập nhật mới từ Update.txt...")

    updated = run_cli_update_flow(prompt_user=True)
    if not updated:
        has_update, latest_ver, _ = check_for_update()
        if not has_update:
            print_success(f"Bạn đang sử dụng phiên bản KAGEVIETSUB mới nhất (v{local_ver}).")

if __name__ == "__main__":
    main()
