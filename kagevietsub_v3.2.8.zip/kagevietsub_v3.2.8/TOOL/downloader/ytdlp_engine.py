#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB DOWNLOADER - YT-DLP ENGINE WRAPPER
==============================================================================
- Quản lý và tìm kiếm binary yt-dlp an toàn
- Trích xuất metadata (Tiêu đề, Thumbnail, Độ dài, Danh sách độ phân giải)
- Xây dựng lệnh thực thi subprocess an toàn (không dùng shell=True)
- Phân tích realtime stdout stream để cập nhật tiến độ, tốc độ, ETA
- TUYỆT ĐỐI KHÔNG GIỚI HẠN BĂNG THÔNG
==============================================================================
"""

import os
import re
import sys
import json
import shutil
import subprocess
import logging
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple, Callable

logger = logging.getLogger("downloader.ytdlp")

TOOL_DIR = Path(__file__).resolve().parent.parent

def find_ytdlp_executable() -> Optional[List[str]]:
    """
    Tìm binary hoặc module thực thi yt-dlp theo thứ tự ưu tiên:
    1. Binary trong hệ thống (PATH): yt-dlp
    2. Binary đóng gói trong TOOL/bin/yt-dlp
    3. Python module: [sys.executable, "-m", "yt_dlp"]
    """
    sys_bin = shutil.which("yt-dlp")
    if sys_bin:
        return [sys_bin]

    local_bin = TOOL_DIR / "bin" / "yt-dlp"
    if local_bin.exists() and os.access(local_bin, os.X_OK):
        return [str(local_bin)]

    local_bin_exe = TOOL_DIR / "bin" / "yt-dlp.exe"
    if local_bin_exe.exists():
        return [str(local_bin_exe)]

    try:
        res = subprocess.run([sys.executable, "-m", "yt_dlp", "--version"], capture_output=True, text=True, timeout=5)
        if res.returncode == 0:
            return [sys.executable, "-m", "yt_dlp"]
    except Exception:
        pass

    return None

def is_ytdlp_ready() -> Tuple[bool, str]:
    """Kiểm tra yt-dlp đã sẵn sàng hay chưa."""
    cmd = find_ytdlp_executable()
    if not cmd:
        return False, "Chưa cài đặt hoặc không tìm thấy yt-dlp."
    try:
        res = subprocess.run(cmd + ["--version"], capture_output=True, text=True, timeout=5)
        if res.returncode == 0:
            return True, res.stdout.strip()
        return False, f"Lỗi chạy yt-dlp: {res.stderr}"
    except Exception as e:
        return False, str(e)

def extract_metadata(url: str, cookies_file: Optional[str] = None) -> Tuple[bool, Dict[str, Any], str]:
    """
    Trích xuất metadata của video mà KHÔNG tải video:
    - Tiêu đề, thumbnail, tác giả, thời lượng
    - Danh sách độ phân giải khả dụng (1080p, 720p, 480p, 360p...)
    - Kiểm tra nếu URL là playlist / channel để cảnh báo
    """
    ytdlp_cmd = find_ytdlp_executable()
    if not ytdlp_cmd:
        return False, {}, "❌ Không tìm thấy công cụ yt-dlp trên hệ thống."

    cmd = list(ytdlp_cmd) + [
        "--dump-single-json",
        "--no-download",
        "--no-playlist",
        "--no-warnings",
        "--socket-timeout", "15"
    ]

    if cookies_file and Path(cookies_file).exists():
        cmd += ["--cookies", str(cookies_file)]

    url_lower = url.lower()
    if "bilibili.com" in url_lower or "b23.tv" in url_lower:
        cmd += [
            "--referer", "https://www.bilibili.com",
            "--user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        ]
    elif "douyin.com" in url_lower:
        cmd += [
            "--referer", "https://www.douyin.com",
            "--user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        ]
    elif "tiktok.com" in url_lower:
        cmd += [
            "--referer", "https://www.tiktok.com",
            "--user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        ]
    elif "youtube.com" in url_lower or "youtu.be" in url_lower:
        node_bin = shutil.which("node") or "/usr/local/bin/node" or "/usr/bin/node"
        if node_bin and Path(node_bin).exists():
            cmd += ["--js-runtimes", f"node:{node_bin}"]

    cmd.append(url)

    try:
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if res.returncode != 0:
            raw_err = (res.stderr or res.stdout or "").strip()
                                              
            filtered_err_lines = [
                line.strip() for line in raw_err.splitlines()
                if line.strip() and not line.strip().startswith("Deprecated Feature:")
            ]
            err_msg = " ".join(filtered_err_lines) or "Không thể lấy thông tin video từ liên kết."

            if "Sign in to confirm you’re not a bot" in err_msg or "Sign in to confirm" in err_msg:
                err_msg = "YouTube yêu cầu xác thực người dùng hoặc cookies để tải video này."
            elif "Unsupported URL" in err_msg:
                err_msg = "Trang web này chưa được hỗ trợ hoặc link không đúng định dạng."
            elif "Video unavailable" in err_msg or "Private video" in err_msg:
                err_msg = "Video không khả dụng hoặc ở chế độ riêng tư."
            elif "404" in err_msg:
                err_msg = "Không tìm thấy video (Lỗi 404)."
            elif "HTTP Error 403" in err_msg:
                err_msg = "Bị máy chủ video từ chối truy cập (HTTP 403 Forbidden)."
            return False, {}, err_msg

        data = json.loads(res.stdout)

        if "_type" in data and data["_type"] in ["playlist", "multi_video"]:
            entries = data.get("entries", [])
            if len(entries) > 1:
                return False, {}, "⚠ URL chứa nhiều video (danh sách phát). Vui lòng dán link từng video đơn lẻ."
            elif len(entries) == 1 and entries[0]:
                data = entries[0]

        formats = data.get("formats", [])
        heights = set()
        for f in formats:
            h = f.get("height")
            if h and isinstance(h, int) and h > 0:
                heights.add(h)

        sorted_heights = sorted(list(heights), reverse=True)
        available_resolutions = ["Auto"]
        for h in sorted_heights:
            if h >= 2160:
                res_label = "2160p (4K)"
            elif h >= 1440:
                res_label = "1440p (2K)"
            elif h >= 1080:
                res_label = "1080p (Full HD)"
            elif h >= 720:
                res_label = "720p (HD)"
            elif h >= 480:
                res_label = "480p"
            elif h >= 360:
                res_label = "360p"
            else:
                res_label = f"{h}p"

            if res_label not in available_resolutions:
                available_resolutions.append(res_label)

        duration = data.get("duration", 0) or 0
        dur_str = format_duration(int(duration))

        title = data.get("title", "Video").strip()
        thumbnail = data.get("thumbnail") or ""
        uploader = data.get("uploader") or data.get("creator") or data.get("channel") or ""

        parsed_meta = {
            "title": title,
            "thumbnail": thumbnail,
            "duration": duration,
            "duration_formatted": dur_str,
            "uploader": uploader,
            "available_resolutions": available_resolutions,
            "raw_formats_count": len(formats),
            "webpage_url": data.get("webpage_url", url),
            "extractor": data.get("extractor", "")
        }

        return True, parsed_meta, ""
    except subprocess.TimeoutExpired:
        return False, {}, "Quá thời gian kết nối (timeout) khi lấy thông tin video."
    except json.JSONDecodeError:
        return False, {}, "Không thể phân tích dữ liệu JSON từ dịch vụ tải."
    except Exception as e:
        return False, {}, f"Lỗi không xác định: {str(e)}"

def format_duration(seconds: int) -> str:
    """Định dạng giây thành mm:ss hoặc hh:mm:ss."""
    if not seconds or seconds < 0:
        return "00:00"
    m, s = divmod(seconds, 60)
    h, m = divmod(m, 60)
    if h > 0:
        return f"{h:02d}:{m:02d}:{s:02d}"
    return f"{m:02d}:{s:02d}"

def parse_ytdlp_progress_line(line: str) -> Optional[Dict[str, Any]]:
    """
    Phân tích dòng output tiến độ từ yt-dlp:
    Hỗ trợ mẫu:
    [download]  45.2% of ~  12.30MiB at    5.12MiB/s ETA 00:03
    hoặc
    [download] 100% of 10.50MiB in 00:02
    hoặc custom template:
    45.2%;5.12MiB/s;00:03;12.30MiB;5.50MiB
    """
    line = line.strip()
    if not line:
        return None

    if ";" in line and ("%" in line or "MiB" in line or "k" in line):
        parts = line.split(";")
        if len(parts) >= 3:
            pct_raw = parts[0].replace("%", "").strip()
            try:
                pct = float(pct_raw)
            except ValueError:
                pct = 0.0
            return {
                "progress": min(100.0, max(0.0, pct)),
                "speed": parts[1].strip() if len(parts) > 1 else "",
                "eta": parts[2].strip() if len(parts) > 2 else "",
                "total": parts[3].strip() if len(parts) > 3 else "",
                "downloaded": parts[4].strip() if len(parts) > 4 else ""
            }

    m = re.search(r'\[download\]\s+([\d\.]+)%\s+of\s+~?([\w\.\s]+)\s+at\s+([\w\.\s/]+)\s+ETA\s+([\w\:]+)', line)
    if m:
        try:
            pct = float(m.group(1))
        except ValueError:
            pct = 0.0
        return {
            "progress": min(100.0, max(0.0, pct)),
            "total": m.group(2).strip(),
            "speed": m.group(3).strip(),
            "eta": m.group(4).strip()
        }

    m_simple = re.search(r'\[download\]\s+([\d\.]+)%', line)
    if m_simple:
        try:
            pct = float(m_simple.group(1))
            return {"progress": min(100.0, max(0.0, pct))}
        except ValueError:
            pass

    return None
