#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB DOWNLOADER - FILE VERIFIER (FFPROBE)
==============================================================================
Kiểm tra tính toàn vẹn và hợp lệ tuyệt đối của file media sau khi tải / ghép:
- Kiểm tra file tồn tại
- Kiểm tra kích thước file > 0 (bắt lỗi file 0 KB)
- Kiểm tra luồng video & luồng audio qua FFprobe
- Kiểm tra thời lượng (duration > 0)
==============================================================================
"""

import json
import shutil
import subprocess
from pathlib import Path
from typing import Tuple, Dict, Any

def run_ffprobe(file_path: Path) -> Tuple[bool, Dict[str, Any], str]:
    """
    Thực thi ffprobe phân tích sâu cấu trúc container và streams.
    """
    if not file_path.exists():
        return False, {}, f"File không tồn tại: {file_path.name}"

    file_size = file_path.stat().st_size
    if file_size <= 0:
        return False, {}, f"❌ File tải về có dung lượng 0 KB: {file_path.name}"

    ffprobe_bin = shutil.which("ffprobe")
    if not ffprobe_bin:
                                                                    
        if file_size > 1024:
            return True, {"format": {"size": file_size, "duration": 0}}, "Cảnh báo: Không có FFprobe, xác thực qua file size."
        return False, {}, "Thiếu công cụ FFprobe để xác thực cấu trúc file."

    cmd = [
        ffprobe_bin,
        "-v", "quiet",
        "-print_format", "json",
        "-show_format",
        "-show_streams",
        str(file_path)
    ]

    try:
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
        if res.returncode != 0:
            return False, {}, f"FFprobe không thể đọc file (file có thể bị hỏng): {res.stderr}"

        info = json.loads(res.stdout)
        return True, info, ""
    except subprocess.TimeoutExpired:
        return False, {}, "FFprobe quá thời gian chờ (timeout) khi đọc file."
    except Exception as e:
        return False, {}, f"Lỗi khi chạy FFprobe: {str(e)}"

def verify_mp4(file_path: Path, expect_audio: bool = True) -> Tuple[bool, str, Dict[str, Any]]:
    """
    Xác thực nghiêm ngặt file MP4:
    1. File tồn tại
    2. File size > 0
    3. Có ít nhất 1 video stream hợp lệ
    4. Có audio stream (nếu video nguồn có audio)
    5. Duration > 0
    """
    success, info, err = run_ffprobe(file_path)
    if not success:
        return False, err, {}

    streams = info.get("streams", [])
    format_info = info.get("format", {})

    has_video = any(s.get("codec_type") == "video" for s in streams)
    has_audio = any(s.get("codec_type") == "audio" for s in streams)

    try:
        duration = float(format_info.get("duration", 0))
    except (ValueError, TypeError):
        duration = 0.0

    if not has_video:
        return False, "❌ File MP4 không chứa luồng hình ảnh (video stream) hợp lệ.", info

    if expect_audio and not has_audio:
                                                               
        pass

    details = {
        "duration": duration,
        "size": format_info.get("size", file_path.stat().st_size),
        "video_codec": next((s.get("codec_name") for s in streams if s.get("codec_type") == "video"), "unknown"),
        "audio_codec": next((s.get("codec_name") for s in streams if s.get("codec_type") == "audio"), None),
        "width": next((s.get("width") for s in streams if s.get("codec_type") == "video"), 0),
        "height": next((s.get("height") for s in streams if s.get("codec_type") == "video"), 0),
    }

    return True, "File MP4 hợp lệ.", details

def verify_mp3(file_path: Path) -> Tuple[bool, str, Dict[str, Any]]:
    """
    Xác thực nghiêm ngặt file MP3 / Audio:
    1. File tồn tại
    2. File size > 0
    3. Có ít nhất 1 audio stream
    4. Duration > 0
    """
    success, info, err = run_ffprobe(file_path)
    if not success:
        return False, err, {}

    streams = info.get("streams", [])
    format_info = info.get("format", {})

    has_audio = any(s.get("codec_type") == "audio" for s in streams)

    try:
        duration = float(format_info.get("duration", 0))
    except (ValueError, TypeError):
        duration = 0.0

    if not has_audio:
        return False, "❌ File Audio không chứa luồng âm thanh (audio stream) hợp lệ.", info

    details = {
        "duration": duration,
        "size": format_info.get("size", file_path.stat().st_size),
        "audio_codec": next((s.get("codec_name") for s in streams if s.get("codec_type") == "audio"), "mp3"),
        "channels": next((s.get("channels") for s in streams if s.get("codec_type") == "audio"), 2),
        "sample_rate": next((s.get("sample_rate") for s in streams if s.get("codec_type") == "audio"), 44100)
    }

    return True, "File MP3 hợp lệ.", details

def verify_thumbnail(file_path: Path) -> Tuple[bool, str]:
    """Kiểm tra file thumbnail tồn tại và size > 0."""
    if not file_path.exists():
        return False, "File thumbnail không tồn tại."
    if file_path.stat().st_size <= 0:
        return False, "File thumbnail dung lượng 0 KB."
    return True, "Thumbnail hợp lệ."

def verify_media_file(file_path: Path, format_type: str = "MP4") -> Tuple[bool, str, Dict[str, Any]]:
    """Xác thực định dạng media theo loại MP4 hoặc MP3."""
    if str(format_type).upper() == "MP3":
        return verify_mp3(file_path)
    return verify_mp4(file_path)
