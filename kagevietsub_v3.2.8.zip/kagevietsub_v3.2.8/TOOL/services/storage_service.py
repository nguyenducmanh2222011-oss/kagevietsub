import os
import sys
import platform
from pathlib import Path
from typing import Dict, Any, List

TOOL_DIR = Path(__file__).resolve().parent.parent
PROJECT_ROOT = TOOL_DIR.parent
DATA_DIR = PROJECT_ROOT / "DATA"

class StorageService:
    """
    Service quản lý lưu trữ trừu tượng hóa (Storage Abstraction).
    Tự động tương thích với Android/Termux, Windows và Linux Desktop.
    KHÔNG hardcode đường dẫn thiết bị trực tiếp trong các module khác.
    """

    @staticmethod
    def is_android() -> bool:
        if os.environ.get("TERMUX_VERSION") or os.environ.get("PREFIX", "").startswith("/data/data/com.termux"):
            return True
        if Path("/data/data/com.termux").exists():
            return True
        system_str = platform.system().lower()
        if "android" in system_str or "android" in platform.platform().lower():
            return True
        try:
            if hasattr(os, "uname") and "android" in os.uname().release.lower():
                return True
        except Exception:
            pass
        return False

    @staticmethod
    def is_windows() -> bool:
        return os.name == "nt" or sys.platform == "win32"

    @classmethod
    def get_platform(cls) -> str:
        if cls.is_android():
            return "android"
        if cls.is_windows():
            return "windows"
        return "linux"

    @classmethod
    def get_root(cls) -> Path:
        return PROJECT_ROOT

    @classmethod
    def get_data_dir(cls) -> Path:
        d = DATA_DIR
        d.mkdir(parents=True, exist_ok=True)
        return d

    @classmethod
    def get_upload_dir(cls) -> Path:
        d = DATA_DIR / "uploads"
        d.mkdir(parents=True, exist_ok=True)
        return d

    @classmethod
    def get_temp_dir(cls) -> Path:
        d = DATA_DIR / "temp"
        d.mkdir(parents=True, exist_ok=True)
        return d

    @classmethod
    def get_output_dir(cls) -> Path:
        """
        Xác định chính xác thư mục xuất file kết quả theo hệ điều hành:
        - ANDROID: /storage/emulated/0/Download/KAGEVIETSUB hoặc ~/storage/downloads/KAGEVIETSUB
        - WINDOWS: %USERPROFILE%\\Downloads\\KAGEVIETSUB (~/Downloads/KAGEVIETSUB)
        - LINUX: ~/Downloads/KAGEVIETSUB
        """
        plat = cls.get_platform()

        if plat == "android":
            candidates = [
                Path("/storage/emulated/0/Download"),
                Path.home() / "storage" / "downloads",
                Path("/sdcard/Download")
            ]
            for base_dir in candidates:
                try:
                    if not base_dir.exists():
                        try:
                            base_dir.mkdir(parents=True, exist_ok=True)
                        except Exception:
                            continue
                    target = base_dir / "KAGEVIETSUB"
                    target.mkdir(parents=True, exist_ok=True)
                                                              
                    test_file = target / ".write_test.tmp"
                    try:
                        test_file.touch()
                        if test_file.exists():
                            test_file.unlink()
                        return target.resolve()
                    except Exception:
                        continue
                except Exception:
                    continue

            fallback = PROJECT_ROOT / "Download" / "KAGEVIETSUB"
            fallback.mkdir(parents=True, exist_ok=True)
            return fallback.resolve()

        elif plat == "windows":
            try:
                win_downloads = Path.home() / "Downloads" / "KAGEVIETSUB"
                win_downloads.mkdir(parents=True, exist_ok=True)
                return win_downloads.resolve()
            except Exception:
                pass

        elif plat == "linux":
            try:
                linux_downloads = Path.home() / "Downloads" / "KAGEVIETSUB"
                linux_downloads.mkdir(parents=True, exist_ok=True)
                return linux_downloads.resolve()
            except Exception:
                pass

        out = DATA_DIR / "output"
        out.mkdir(parents=True, exist_ok=True)
        return out.resolve()

    @classmethod
    def get_models_dir(cls) -> Path:
        d = DATA_DIR / "models"
        d.mkdir(parents=True, exist_ok=True)
        return d

    @classmethod
    def get_job_temp_dir(cls, job_id: str) -> Path:
        d = cls.get_temp_dir() / f"job_{job_id}"
        d.mkdir(parents=True, exist_ok=True)
        return d

    @classmethod
    def ensure_all_directories(cls):
        """Tự tạo tất cả các thư mục dữ liệu nếu chưa tồn tại."""
        dirs = [
            cls.get_data_dir(),
            cls.get_upload_dir(),
            cls.get_temp_dir(),
            cls.get_output_dir(),
            cls.get_models_dir(),
            DATA_DIR / "logs",
            DATA_DIR / "logs" / "daily",
            DATA_DIR / "logs" / "system",
        ]
        for d in dirs:
            d.mkdir(parents=True, exist_ok=True)
