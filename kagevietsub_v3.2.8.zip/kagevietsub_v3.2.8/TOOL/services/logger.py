import os
import sys
import time
import datetime
import threading
import re
import traceback
from pathlib import Path
from typing import Optional, Any, Dict, List, Tuple

from TOOL.config import LOGS_DIR

DAILY_LOGS_DIR = LOGS_DIR / "daily"
SYSTEM_LOGS_DIR = LOGS_DIR / "system"
MACHINE_INFO_LOG = SYSTEM_LOGS_DIR / "machine-info.log"

PROTECTED_LOG_PATHS = [
    MACHINE_INFO_LOG.resolve(),
    SYSTEM_LOGS_DIR.resolve()
]

DAILY_LOG_RETENTION_DAYS = int(os.getenv("DAILY_LOG_RETENTION_DAYS", "30"))
MAX_LOG_FILE_SIZE_BYTES = int(os.getenv("MAX_LOG_FILE_SIZE_BYTES", str(50 * 1024 * 1024)))

SECRET_PATTERNS = [
    re.compile(r'(?i)(api[_-]?key\s*[:=]\s*["\']?)([^"\'\s&,;]{6,})', re.IGNORECASE),
    re.compile(r'(?i)(token\s*[:=]\s*["\']?)([^"\'\s&,;]{6,})', re.IGNORECASE),
    re.compile(r'(?i)(authorization\s*[:=]\s*["\']?Bearer\s+)([^"\'\s&,;]{6,})', re.IGNORECASE),
    re.compile(r'(?i)(cookie\s*[:=]\s*["\']?)([^"\'\s\r\n]{6,})', re.IGNORECASE),
    re.compile(r'(?i)(password\s*[:=]\s*["\']?)([^"\'\s&,;]{3,})', re.IGNORECASE),
    re.compile(r'(?i)(secret\s*[:=]\s*["\']?)([^"\'\s&,;]{6,})', re.IGNORECASE),
    re.compile(r'(?i)(access[_-]?token\s*[:=]\s*["\']?)([^"\'\s&,;]{6,})', re.IGNORECASE),
    re.compile(r'(?i)(ds2_token\s*[:=]\s*["\']?)([^"\'\s&,;]{6,})', re.IGNORECASE),
    re.compile(r'(?i)(bearer\s+)([a-zA-Z0-9_\-\.]{10,})', re.IGNORECASE),
    re.compile(r'(?i)(AIzaSy[a-zA-Z0-9_\-]{33})', re.IGNORECASE),
    re.compile(r'(?i)(sk-[a-zA-Z0-9]{20,})', re.IGNORECASE),
]

def redact_secrets(text: str) -> str:
    if not text:
        return ""
    sanitized = str(text)
    for pattern in SECRET_PATTERNS:
        if pattern.groups == 2:
            sanitized = pattern.sub(r'\1[REDACTED]', sanitized)
        elif pattern.groups == 1:
            sanitized = pattern.sub('[REDACTED]', sanitized)
        else:
            sanitized = pattern.sub('[REDACTED]', sanitized)
    return sanitized

class CentralLogger:
    _instance = None
    _lock = threading.RLock()

    def __new__(cls, *args, **kwargs):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super(CentralLogger, cls).__new__(cls)
                cls._instance._initialized = False
            return cls._instance

    def __init__(self):
        if getattr(self, "_initialized", False):
            return
        with self._lock:
            self.daily_logs_dir = DAILY_LOGS_DIR
            self.system_logs_dir = SYSTEM_LOGS_DIR
            self.machine_info_log = MACHINE_INFO_LOG
            
            self.daily_logs_dir.mkdir(parents=True, exist_ok=True)
            self.system_logs_dir.mkdir(parents=True, exist_ok=True)
            
            self.max_file_size = MAX_LOG_FILE_SIZE_BYTES
            self.retention_days = DAILY_LOG_RETENTION_DAYS
            self._write_lock = threading.RLock()
            self._initialized = True

    def _get_active_log_file(self) -> Path:
        now = datetime.datetime.now()
        date_str = now.strftime("%Y-%m-%d")
        
        base_file = self.daily_logs_dir / f"{date_str}.log"
        if not base_file.exists():
            return base_file
        
        try:
            size = base_file.stat().st_size
            if size < self.max_file_size:
                return base_file
        except Exception:
            return base_file

        idx = 1
        while True:
            rot_file = self.daily_logs_dir / f"{date_str}.{idx}.log"
            if not rot_file.exists():
                return rot_file
            try:
                if rot_file.stat().st_size < self.max_file_size:
                    return rot_file
            except Exception:
                return rot_file
            idx += 1

    def _format_timestamp(self) -> str:
        now = datetime.datetime.now()
        return now.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

    def is_path_protected(self, path: Path) -> bool:
        try:
            resolved = path.resolve()
            for p in PROTECTED_LOG_PATHS:
                if resolved == p or str(resolved).startswith(str(SYSTEM_LOGS_DIR.resolve())):
                    return True
            return False
        except Exception:
            return True

    def write_machine_info(self, sys_info: Dict[str, Any], host: str = "127.0.0.1", port: int = 8000):
        with self._write_lock:
            try:
                self.system_logs_dir.mkdir(parents=True, exist_ok=True)
                timestamp = self._format_timestamp()
                pid = os.getpid()
                
                and_info = sys_info.get("android", {})
                cpu_info = sys_info.get("cpu", {})
                mem_info = sys_info.get("memory", {})
                st_info = sys_info.get("storage", {})
                paths = sys_info.get("paths", {})
                deps = sys_info.get("dependencies", {})

                content = (
                    f"==================================================\n"
                    f"KAGEVIETSUB SYSTEM ENVIRONMENT LOG\n"
                    f"Timestamp: {timestamp}\n"
                    f"PID: {pid}\n"
                    f"Version: {sys_info.get('version', 'unknown')}\n"
                    f"Platform: {sys_info.get('platform_display', sys_info.get('platform', 'unknown'))}\n"
                    f"Architecture: {sys_info.get('architecture', 'unknown')}\n"
                    f"Python: {deps.get('python', {}).get('version', sys.version.split()[0])}\n"
                    f"CPU: {cpu_info.get('model', 'unknown')} ({cpu_info.get('logical_cores', 1)} cores)\n"
                    f"RAM: Total {mem_info.get('total_mb', 0)}MB | Avail {mem_info.get('available_mb', 0)}MB\n"
                    f"Storage Free: DATA {st_info.get('data_storage', {}).get('free_gb', 0)}GB | Output {st_info.get('output_storage', {}).get('free_gb', 0)}GB\n"
                    f"Android/Termux: is_android={and_info.get('is_android')} is_termux={and_info.get('is_termux')} termux_ver={and_info.get('termux_version')}\n"
                    f"FFmpeg: {deps.get('ffmpeg', {}).get('installed')} (Path: {deps.get('ffmpeg', {}).get('path')})\n"
                    f"FFprobe: {deps.get('ffprobe', {}).get('installed')} (Path: {deps.get('ffprobe', {}).get('path')})\n"
                    f"Server Binding: {host}:{port}\n"
                    f"Project Root: {paths.get('project_root')}\n"
                    f"Download Output: {paths.get('download_output')}\n"
                    f"==================================================\n\n"
                )
                safe_content = redact_secrets(content)
                with open(self.machine_info_log, "a", encoding="utf-8", buffering=1) as f:
                    f.write(safe_content)
                    f.flush()
            except Exception as e:
                try:
                    sys.stderr.write(f"[LOGGER ERROR] Failed to write machine info: {e}\n")
                except Exception:
                    pass

    def cleanup_old_logs(self, retention_days: Optional[int] = None) -> int:
        if retention_days is None:
            retention_days = self.retention_days

        with self._write_lock:
            removed_count = 0
            try:
                if not self.daily_logs_dir.exists():
                    return 0

                today = datetime.date.today()
                date_file_pattern = re.compile(r"^(\d{4}-\d{2}-\d{2})(?:\.\d+)?\.log$")

                active_file = self._get_active_log_file().resolve()

                for entry in os.scandir(self.daily_logs_dir):
                    if not entry.is_file():
                        continue

                    entry_path = Path(entry.path)
                    
                    if self.is_path_protected(entry_path):
                        continue

                    if entry_path.resolve() == active_file:
                        continue

                    match = date_file_pattern.match(entry.name)
                    if not match:
                        continue

                    date_str = match.group(1)
                    try:
                        file_date = datetime.datetime.strptime(date_str, "%Y-%m-%d").date()
                    except ValueError:
                        continue

                    age_days = (today - file_date).days
                    if age_days > retention_days:
                        try:
                            entry_path.unlink()
                            removed_count += 1
                            self.info("LOGGER", "CLEANUP", f"Removed old log: {entry.name}")
                        except Exception as del_err:
                            self.error("LOGGER", "CLEANUP_FILE_ERROR", f"Failed to delete {entry.name}", exc=del_err)

                if removed_count > 0:
                    self.info("LOGGER", "CLEANUP", f"Cleanup completed. Removed {removed_count} old daily logs.")
            except Exception as e:
                self.error("LOGGER", "CLEANUP_ERROR", "Log cleanup exception occurred", exc=e)
            
            return removed_count

    def _resolve_log_args(self, default_level: str, *args, **kwargs) -> Tuple[str, str, str]:
        """
        Phân giải linh hoạt đối số log:
        - 1 đối số: logger.info("message") -> ("APP", default_level, "message")
        - 2 đối số: logger.info("EVENT", "message") -> ("APP", "EVENT", "message")
        - 3+ đối số: logger.info("MODULE", "EVENT", "message") -> ("MODULE", "EVENT", "message")
        """
        if len(args) == 0:
            return "APP", default_level, str(kwargs.get("message", ""))
        elif len(args) == 1:
            return "APP", default_level, str(args[0])
        elif len(args) == 2:
            return "APP", str(args[0]), str(args[1])
        else:
            module = str(args[0])
            event = str(args[1])
            msg = str(args[2])
            if len(args) > 3:
                extra = " ".join(str(a) for a in args[3:])
                msg = f"{msg} {extra}"
            return module, event, msg

    def log(
        self,
        level: str,
        module: str = "SYSTEM",
        event: str = "EVENT",
        message: str = "",
        job_id: Optional[str] = None,
        request_id: Optional[str] = None,
        exc: Optional[Exception] = None,
        **kwargs: Any
    ):
        try:
            timestamp = self._format_timestamp()
            lvl = (level or "INFO").upper()
            mod = (module or "SYSTEM").upper()
            evt = (event or "EVENT").upper()

            tags = []
            if request_id:
                tags.append(f"[request_id={request_id}]")
            if job_id:
                tags.append(f"[job_id={job_id}]")

            tag_str = " ".join(tags)

            parts = []
            if message:
                parts.append(str(message).strip())
            for k, v in kwargs.items():
                if v is not None:
                    parts.append(f"{k}={v}")

            if exc is not None:
                parts.append(f"exc_type={type(exc).__name__}")
                parts.append(f"exc_msg={str(exc)}")
                tb_str = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__)).strip()
                if tb_str:
                    parts.append(f"traceback=\n{tb_str}")

            raw_content = " ".join(parts)
            safe_content = redact_secrets(raw_content)

            if tag_str:
                log_line = f"[{timestamp}] [{lvl}] [{mod}] [{evt}] {tag_str} {safe_content}\n"
            else:
                log_line = f"[{timestamp}] [{lvl}] [{mod}] [{evt}] {safe_content}\n"

            with self._write_lock:
                try:
                    target_file = self._get_active_log_file()
                    with open(target_file, "a", encoding="utf-8", buffering=1) as f:
                        f.write(log_line)
                        f.flush()
                except Exception as write_err:
                    try:
                        sys.stderr.write(f"[LOGGER ERROR] Failed to write log: {write_err}\n")
                    except Exception:
                        pass
        except Exception as outer_err:
            try:
                sys.stderr.write(f"[LOGGER CRITICAL ERROR] Fail-safe caught log exception: {outer_err}\n")
            except Exception:
                pass

    def debug(self, *args, **kwargs):
        try:
            mod, evt, msg = self._resolve_log_args("DEBUG", *args, **kwargs)
            self.log("DEBUG", mod, evt, msg, **kwargs)
        except Exception:
            pass

    def info(self, *args, **kwargs):
        try:
            mod, evt, msg = self._resolve_log_args("INFO", *args, **kwargs)
            self.log("INFO", mod, evt, msg, **kwargs)
        except Exception:
            pass

    def warning(self, *args, **kwargs):
        try:
            mod, evt, msg = self._resolve_log_args("WARNING", *args, **kwargs)
            self.log("WARNING", mod, evt, msg, **kwargs)
        except Exception:
            pass

    def error(self, *args, **kwargs):
        try:
            exc = kwargs.pop("exc", None) or kwargs.pop("exc_info", None)
            if exc is True:
                exc = sys.exc_info()[1]
            mod, evt, msg = self._resolve_log_args("ERROR", *args, **kwargs)
            self.log("ERROR", mod, evt, msg, exc=exc, **kwargs)
        except Exception:
            pass

    def critical(self, *args, **kwargs):
        try:
            exc = kwargs.pop("exc", None) or kwargs.pop("exc_info", None)
            if exc is True:
                exc = sys.exc_info()[1]
            mod, evt, msg = self._resolve_log_args("CRITICAL", *args, **kwargs)
            self.log("CRITICAL", mod, evt, msg, exc=exc, **kwargs)
        except Exception:
            pass

    def exception(self, *args, **kwargs):
        try:
            exc = kwargs.pop("exc", None) or kwargs.pop("exc_info", None)
            if exc is None or exc is True:
                exc = sys.exc_info()[1]
            mod, evt, msg = self._resolve_log_args("EXCEPTION", *args, **kwargs)
            self.log("ERROR", mod, evt, msg, exc=exc, **kwargs)
        except Exception:
            pass

    def get_module_logger(self, module_name: str) -> "ModuleLoggerAdapter":
        return ModuleLoggerAdapter(self, module_name)

class ModuleLoggerAdapter:
    def __init__(self, central_logger: CentralLogger, module_name: str):
        self._logger = central_logger
        self.module_name = module_name

    def debug(self, msg: str, *args, **kwargs):
        formatted = msg % args if args else msg
        self._logger.debug(self.module_name, "DEBUG", formatted, **kwargs)

    def info(self, msg: str, *args, **kwargs):
        formatted = msg % args if args else msg
        self._logger.info(self.module_name, "INFO", formatted, **kwargs)

    def warning(self, msg: str, *args, **kwargs):
        formatted = msg % args if args else msg
        self._logger.warning(self.module_name, "WARNING", formatted, **kwargs)

    def error(self, msg: str, *args, **kwargs):
        formatted = msg % args if args else msg
        exc = kwargs.pop("exc", None) or kwargs.pop("exc_info", None)
        if exc is True:
            exc = sys.exc_info()[1]
        self._logger.error(self.module_name, "ERROR", formatted, exc=exc, **kwargs)

    def critical(self, msg: str, *args, **kwargs):
        formatted = msg % args if args else msg
        exc = kwargs.pop("exc", None) or kwargs.pop("exc_info", None)
        if exc is True:
            exc = sys.exc_info()[1]
        self._logger.critical(self.module_name, "CRITICAL", formatted, exc=exc, **kwargs)

    def exception(self, msg: str, *args, **kwargs):
        formatted = msg % args if args else msg
        exc = kwargs.pop("exc", None) or sys.exc_info()[1]
        self._logger.exception(self.module_name, "EXCEPTION", formatted, exc=exc, **kwargs)

logger = CentralLogger()
