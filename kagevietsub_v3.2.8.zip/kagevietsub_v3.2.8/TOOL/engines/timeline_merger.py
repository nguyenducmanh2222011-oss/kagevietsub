#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB - ULTRA-FAST TIMELINE AUDIO MERGER ENGINE
==============================================================================
Kiến trúc tối ưu hóa hiệu năng cao cho Android / Termux / Linux / PC:
1. AudioAnalyzer: Tự động phân tích codec, sample_rate, channels, bitrate.
2. Fast Path / Stream Copy / Remux: Ưu tiên xử lý tuyến tính, không encode lặp lại.
3. TimelineSegmenter: Phân cụm các câu trùng lặp (Overlap) cục bộ để mix riêng biệt,
   giữ nguyên vẹn mốc thời gian SRT (Start Time là Source of Truth).
4. Silence Optimization: Tái sử dụng nguồn silence chuẩn, không tạo hàng nghìn file rác.
5. Adaptive Chunking & Concurrency: Tự động điều chỉnh kích thước chunk theo CPU và RAM,
   hỗ trợ Checkpoint & Resume tức thì.
6. Atomic Output & Verification: Ghi ra file temp, kiểm tra ffprobe toàn vẹn,
   sau đó di chuyển nguyên tử sang Download/KAGEVIETSUB/ mà không xóa dữ liệu người dùng.
7. Non-blocking & Stop/Cancellation: Hỗ trợ ngắt tiến trình FFmpeg an toàn, không treo server.
==============================================================================
"""

import os
import gc
import re
import json
import time
import shutil
import logging
import threading
import subprocess
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional, Callable

from TOOL.config import TEMP_DIR, KAGE_DOWNLOAD_DIR, get_safe_unique_filepath
from TOOL.services.ffmpeg_service import FFmpegService
from TOOL.services.task_service import job_manager, HardwareOptimizer
from TOOL.integrations.capcut_tts_adapter import CapCutTTSAdapter

logger = logging.getLogger("TimelineAudioMerger")

class AudioAnalyzer:
    """Tự động phân tích đặc tính âm thanh của các file đầu vào."""

    @staticmethod
    def inspect_audio_file(file_path: Path) -> Dict[str, Any]:
        """Lấy codec, sample_rate, channels, bitrate, duration của file audio."""
        info = FFmpegService.get_media_info(file_path)
                                                 
        cmd = [
            "ffprobe", "-v", "quiet", "-print_format", "json",
            "-show_streams", "-show_format", str(file_path)
        ]
        try:
            res = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
            if res.returncode == 0:
                data = json.loads(res.stdout)
                streams = data.get("streams", [])
                a_stream = next((s for s in streams if s.get("codec_type") == "audio"), {})
                fmt = data.get("format", {})
                return {
                    "codec": a_stream.get("codec_name", "mp3"),
                    "sample_rate": int(a_stream.get("sample_rate", 44100)),
                    "channels": int(a_stream.get("channels", 2)),
                    "bitrate": int(fmt.get("bit_rate", 128000)),
                    "duration": float(fmt.get("duration", info.get("duration", 1.0))),
                    "format_name": fmt.get("format_name", "mp3")
                }
        except Exception as ex:
            logger.warning(f"Lỗi ffprobe {file_path.name}: {ex}")

        return {
            "codec": info.get("audio_codec", "mp3"),
            "sample_rate": 44100,
            "channels": 2,
            "bitrate": 128000,
            "duration": float(info.get("duration", 1.0)),
            "format_name": "mp3"
        }

    @classmethod
    def analyze_audio_compatibility(cls, sample_files: List[Path]) -> Dict[str, Any]:
        """
        Kiểm tra tính tương thích giữa các file audio trong danh sách.
        Nếu cùng codec, sample_rate, channels -> Cho phép FAST PATH.
        """
        if not sample_files:
            return {
                "is_compatible": True,
                "can_stream_copy": True,
                "sample_rate": 44100,
                "channels": 2,
                "codec": "mp3",
                "bitrate": "192k"
            }

        first_info = cls.inspect_audio_file(sample_files[0])
        codec = first_info["codec"]
        sr = first_info["sample_rate"]
        ch = first_info["channels"]

        test_samples = sample_files[:min(5, len(sample_files))]
        is_compat = True
        for sf in test_samples:
            inf = cls.inspect_audio_file(sf)
            if inf["codec"] != codec or inf["sample_rate"] != sr or inf["channels"] != ch:
                is_compat = False
                break

        return {
            "is_compatible": is_compat,
            "can_stream_copy": is_compat and (codec in ["mp3", "aac"] or codec.startswith("pcm")),
            "sample_rate": sr,
            "channels": ch,
            "codec": codec,
            "bitrate": "192k"
        }

class DeviceOptimizer:
    """Tự động tối ưu tài nguyên theo phần cứng thực tế và công thức thích ứng."""

    @staticmethod
    def get_merge_concurrency_profile(total_items: int = 100, total_duration_ms: int = 600000, active_tts: int = 0) -> Dict[str, Any]:
        from TOOL.services.system_info import SystemInfoDetector, calculate_merge_workers
        sys_info = SystemInfoDetector.get_full_system_info()
        job_info = {
            "audio_count": total_items,
            "total_duration_ms": total_duration_ms,
            "active_tts_workers": active_tts
        }
        return calculate_merge_workers(sys_info, job_info)

    @staticmethod
    def get_optimal_threads() -> int:
        prof = DeviceOptimizer.get_merge_concurrency_profile()
        return prof.get("ffmpeg_threads_per_worker", 2)

    @staticmethod
    def get_chunk_size_ms(total_items: int, total_duration_ms: int) -> int:
        """Kích thước chunk động dựa trên số câu, phần cứng và tổng thời lượng."""
        from TOOL.services.system_info import SystemInfoDetector
        is_android = SystemInfoDetector.is_android()
        if total_items <= 50:
            return max(600000, total_duration_ms + 10000)                                    
        elif is_android:
            return 180000                                                      
        elif total_items <= 500:
            return 300000                          
        else:
            return 240000                                  

class TimelineBuilder:
    @staticmethod
    def build_timeline(sub_states: List[Dict[str, Any]], job_dir: Path) -> Tuple[List[Dict[str, Any]], int]:
        """
        Xây dựng timeline từ danh sách câu phụ đề SRT và file audio tương ứng.
        Mốc START TIME của SRT là Source of Truth.
        """
        items = []
        for sub in sub_states:
            audio_filename = sub.get("audio_filename")
            if not audio_filename:
                cand_wav = job_dir / f"{sub['index']:04d}.wav"
                cand_mp3 = job_dir / f"{sub['index']:04d}.mp3"
                if cand_wav.exists():
                    audio_filename = f"{sub['index']:04d}.wav"
                else:
                    audio_filename = f"{sub['index']:04d}.mp3"
            audio_file = job_dir / audio_filename
            if not audio_file.exists():
                raise FileNotFoundError(f"Không tìm thấy file audio cho câu số {sub['index']}: {audio_file.name}")

            s_ms = int(sub["start_ms"])
            d_sec = float(sub.get("duration", 0.0))
            if d_sec <= 0:
                                              
                _, est_dur, _ = CapCutTTSAdapter.validate_audio_file(audio_file)
                d_sec = est_dur if est_dur > 0 else 1.0
            d_ms = max(50, int(d_sec * 1000))

            items.append({
                "index": sub["index"],
                "file": audio_file,
                "start_ms": s_ms,
                "end_ms": s_ms + d_ms,
                "duration_ms": d_ms,
                "duration_sec": d_sec,
                "text": sub.get("text", "")
            })

        items.sort(key=lambda x: x["start_ms"])
        max_timeline_ms = max((it["end_ms"] for it in items), default=1000)
        return items, max_timeline_ms

class TimelineSegmenter:
    """Phân nhóm các câu phụ đề thành các Cụm (Clusters / Segments) để xử lý Overlap cục bộ."""

    @staticmethod
    def group_into_clusters(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        if not items:
            return []

        clusters = []
        curr_cluster = [items[0]]
        curr_start = items[0]["start_ms"]
        curr_end = items[0]["end_ms"]

        for item in items[1:]:
            s_start = item["start_ms"]
            s_end = item["end_ms"]
                                                                                  
            if s_start < curr_end:
                curr_cluster.append(item)
                curr_end = max(curr_end, s_end)
            else:
                clusters.append({
                    "start_ms": curr_start,
                    "end_ms": curr_end,
                    "items": curr_cluster
                })
                curr_cluster = [item]
                curr_start = s_start
                curr_end = s_end

        if curr_cluster:
            clusters.append({
                "start_ms": curr_start,
                "end_ms": curr_end,
                "items": curr_cluster
            })

        return clusters

class ChunkPlanner:
    @staticmethod
    def plan_chunks(
        items: List[Dict[str, Any]],
        max_timeline_ms: int,
        chunk_size_ms: int = 300000,
        audio_format: str = "mp3"
    ) -> List[Dict[str, Any]]:
        """
        Phân chia timeline thành các Chunk an toàn theo mốc thời gian.
        """
        num_chunks = max(1, (max_timeline_ms + chunk_size_ms - 1) // chunk_size_ms)
        chunks = []
        ext = "wav" if str(audio_format).lower() == "wav" else "mp3"

        for k in range(num_chunks):
            c_start = k * chunk_size_ms
            c_end = (k + 1) * chunk_size_ms if k < num_chunks - 1 else max(c_start + 1000, max_timeline_ms)
            c_dur_sec = max(0.1, (c_end - c_start) / 1000.0)

            chunk_items = [
                it for it in items
                if it["start_ms"] < c_end and it["end_ms"] > c_start
            ]

            chunks.append({
                "index": k,
                "c_start": c_start,
                "c_end": c_end,
                "duration_sec": c_dur_sec,
                "chunk_items": chunk_items,
                "filename": f"chunk_{k:04d}.{ext}"
            })

        return chunks

class MergeCheckpointManager:
    """Quản lý lưu và khôi phục trạng thái Checkpoint cho tiến trình ghép audio (Thread-safe)."""

    def __init__(self, job_dir: Path):
        self.job_dir = job_dir
        self.ckpt_file = job_dir / "merge_checkpoint.json"
        self._lock = threading.RLock()

    def load_checkpoint(self) -> Optional[Dict[str, Any]]:
        with self._lock:
            if self.ckpt_file.exists():
                try:
                    with open(self.ckpt_file, "r", encoding="utf-8") as f:
                        return json.load(f)
                except Exception:
                    return None
            return None

    def save_checkpoint(self, checkpoint_data: Dict[str, Any]):
        with self._lock:
            try:
                with open(self.ckpt_file, "w", encoding="utf-8") as f:
                    json.dump(checkpoint_data, f, indent=2, ensure_ascii=False)
            except Exception as e:
                logger.warning(f"Lỗi lưu merge checkpoint: {e}")

    def init_checkpoint(self, total_chunks: int, chunk_plans: List[Dict[str, Any]]) -> Dict[str, Any]:
        with self._lock:
            existing = self.load_checkpoint()
            if existing and existing.get("total_chunks") == total_chunks:
                for chunk_data in existing.get("chunks", []):
                    idx = chunk_data["index"]
                    fname = chunk_data.get("file") or f"chunk_{idx:04d}.mp3"
                    c_file = self.job_dir / fname
                    if chunk_data["status"] == "COMPLETED":
                        if not c_file.exists() or c_file.stat().st_size == 0:
                            chunk_data["status"] = "PENDING"
                            chunk_data["error"] = "File chunk không tồn tại trên đĩa."
                self.save_checkpoint(existing)
                return existing

            new_data = {
                "job_id": self.job_dir.name,
                "total_chunks": total_chunks,
                "chunks": [
                    {
                        "index": p["index"],
                        "status": "PENDING",
                        "file": p["filename"],
                        "error": None
                    }
                    for p in chunk_plans
                ]
            }
            self.save_checkpoint(new_data)
            return new_data

    def update_chunk_status(self, index: int, status: str, error: Optional[str] = None):
        with self._lock:
            data = self.load_checkpoint()
            if not data:
                return
            for c in data.get("chunks", []):
                if c["index"] == index:
                    c["status"] = status
                    c["error"] = error
                    break
            self.save_checkpoint(data)

    def is_chunk_completed(self, index: int) -> bool:
        with self._lock:
            data = self.load_checkpoint()
            if not data:
                return False
            for c in data.get("chunks", []):
                if c["index"] == index and c["status"] == "COMPLETED":
                    fname = c.get("file") or f"chunk_{index:04d}.mp3"
                    c_file = self.job_dir / fname
                    if c_file.exists() and c_file.stat().st_size > 0:
                        valid, dur, _ = CapCutTTSAdapter.validate_audio_file(c_file)
                        if valid and dur > 0.05:
                            return True
            return False

class ChunkMixer:
    """Trộn các phần tử audio trong từng Chunk với tốc độ cao."""

    @classmethod
    def mix_chunk_fast(
        cls,
        plan: Dict[str, Any],
        job_dir: Path,
        audio_profile: Dict[str, Any],
        audio_format: str = "mp3",
        cancel_check: Optional[Callable[[], bool]] = None
    ) -> Tuple[bool, str, Path]:
        """
        Trộn chunk với thuật toán cụm Overlap + Tuyến tính hóa Concat:
        1. Phân nhóm các câu thành Cụm (Clusters).
        2. Nếu cụm đơn lẻ (1 câu): Dùng trực tiếp file gốc, KHÔNG encode lại.
        3. Nếu cụm trùng lặp (>= 2 câu): Mix cục bộ cụm đó (chỉ vài giây, cực nhanh).
        4. Nối các cụm cùng khoảng silence chính xác qua FFmpeg concat demuxer.
        """
        chunk_out = job_dir / plan["filename"]
        c_start = plan["c_start"]
        c_end = plan["c_end"]
        c_dur_sec = plan["duration_sec"]
        chunk_items = plan["chunk_items"]
        ext = "wav" if str(audio_format).lower() == "wav" else "mp3"

        if chunk_out.exists():
            try:
                chunk_out.unlink()
            except Exception:
                pass

        if not chunk_items:
            ok = cls._create_silence_audio(c_dur_sec, chunk_out, audio_profile)
            if not ok:
                return False, "Lỗi tạo audio silence cho chunk rỗng.", chunk_out
            return True, "", chunk_out

        if cancel_check and cancel_check():
            return False, "Tiến trình bị dừng bởi người dùng.", chunk_out

        clusters = TimelineSegmenter.group_into_clusters(chunk_items)
        cluster_render_list = []
        threads = DeviceOptimizer.get_optimal_threads()
        sr = audio_profile.get("sample_rate", 44100)
        ch = audio_profile.get("channels", 2)

        for c_idx, cluster in enumerate(clusters):
            if cancel_check and cancel_check():
                return False, "Tiến trình bị dừng bởi người dùng.", chunk_out

            c_items = cluster["items"]
            cluster_start = cluster["start_ms"]
            cluster_end = cluster["end_ms"]

            if len(c_items) == 1:
                item = c_items[0]
                cluster_render_list.append((cluster_start, item["file"], cluster_end - cluster_start))
            else:
                cluster_file = job_dir / f"mix_cl_{plan['index']}_{c_idx}.{ext}"
                c_dur = max(0.1, (cluster_end - cluster_start) / 1000.0)

                cmd_m = ["ffmpeg", "-y"]
                filter_parts = []
                for m_i, it in enumerate(c_items):
                    delay_ms = max(0, it["start_ms"] - cluster_start)
                    cmd_m.extend(["-i", str(it["file"])])
                    filter_parts.append(f"[{m_i}:a]adelay={delay_ms}|{delay_ms}[a{m_i}];")

                inputs_s = "".join(f"[a{m}]" for m in range(len(c_items)))
                filter_parts.append(f"{inputs_s}amix=inputs={len(c_items)}:dropout_transition=0:normalize=0,atrim=0:{c_dur:.3f}[out]")

                mix_encode_args = ["-c:a", "pcm_s16le"] if ext == "wav" else ["-b:a", "192k"]
                cmd_m.extend([
                    "-filter_complex", "".join(filter_parts),
                    "-map", "[out]",
                    "-vn", "-ar", str(sr), "-ac", str(ch),
                    *mix_encode_args,
                    "-threads", str(threads),
                    str(cluster_file), "-loglevel", "error"
                ])

                try:
                    r = subprocess.run(cmd_m, capture_output=True, text=True, timeout=30)
                    if r.returncode != 0 or not cluster_file.exists():
                        cluster_render_list.append((cluster_start, c_items[0]["file"], cluster_end - cluster_start))
                    else:
                        cluster_render_list.append((cluster_start, cluster_file, cluster_end - cluster_start))
                except Exception as ex:
                    logger.warning(f"Lỗi mix cluster {c_idx}: {ex}")
                    cluster_render_list.append((cluster_start, c_items[0]["file"], cluster_end - cluster_start))

        max_silence_dur = 0.0
        t_cur = c_start
        for c_st, _, c_dur_ms in cluster_render_list:
            if c_st > t_cur:
                gap = (c_st - t_cur) / 1000.0
                if gap > max_silence_dur:
                    max_silence_dur = gap
            t_cur = c_st + int(c_dur_ms)
        if c_end > t_cur:
            gap_tail = (c_end - t_cur) / 1000.0
            if gap_tail > max_silence_dur:
                max_silence_dur = gap_tail

        silence_master = job_dir / f"silence_master_{plan['index']}.{ext}"
        master_dur = max(2.0, max_silence_dur + 1.0)
        cls._create_silence_audio(master_dur, silence_master, audio_profile)

        concat_txt = job_dir / f"concat_chunk_{plan['index']}.txt"
        with open(concat_txt, "w", encoding="utf-8") as f:
            t_cursor = c_start
            for c_st, c_fp, c_dur_ms in cluster_render_list:
                if c_st > t_cursor:
                    gap_sec = (c_st - t_cursor) / 1000.0
                    if gap_sec >= 0.01 and silence_master.exists():
                        safe_silence = str(silence_master.resolve()).replace("'", "'\\''")
                        f.write(f"file '{safe_silence}'\ninpoint 0.0\noutpoint {gap_sec:.3f}\n")
                safe_fp = str(c_fp.resolve()).replace("'", "'\\''")
                f.write(f"file '{safe_fp}'\n")
                t_cursor = c_st + int(c_dur_ms)

            if c_end > t_cursor:
                gap_end = (c_end - t_cursor) / 1000.0
                if gap_end >= 0.01 and silence_master.exists():
                    safe_silence = str(silence_master.resolve()).replace("'", "'\\''")
                    f.write(f"file '{safe_silence}'\ninpoint 0.0\noutpoint {gap_end:.3f}\n")

        concat_encode_args = ["-c:a", "pcm_s16le"] if ext == "wav" else ["-c:a", "libmp3lame", "-b:a", "192k"]
        concat_cmd = [
            "ffmpeg", "-y", "-f", "concat", "-safe", "0",
            "-i", str(concat_txt),
            *concat_encode_args,
            "-ar", str(sr), "-ac", str(ch),
            "-threads", str(threads),
            str(chunk_out), "-loglevel", "error"
        ]

        try:
            res_p = subprocess.run(concat_cmd, capture_output=True, text=True, timeout=120)
            if res_p.returncode != 0 or not chunk_out.exists() or chunk_out.stat().st_size == 0:
                return False, f"FFmpeg concat error: {res_p.stderr}", chunk_out
        except Exception as e:
            return False, f"Lỗi thực thi concat: {e}", chunk_out

        try:
            if concat_txt.exists():
                concat_txt.unlink()
            if silence_master.exists():
                silence_master.unlink()
            for p in job_dir.glob(f"mix_cl_{plan['index']}_*.*"):
                try:
                    p.unlink()
                except Exception:
                    pass
        except Exception:
            pass

        valid, dur, check_err = CapCutTTSAdapter.validate_audio_file(chunk_out)
        if not valid or dur < 0.05:
            return False, f"Chunk audio không hợp lệ: {check_err}", chunk_out

        gc.collect()
        return True, "", chunk_out

    @staticmethod
    def _create_silence_audio(duration_sec: float, out_file: Path, audio_profile: Optional[Dict[str, Any]] = None) -> bool:
        dur = max(0.05, float(duration_sec))
        sr = audio_profile.get("sample_rate", 44100) if audio_profile else 44100
        ch = audio_profile.get("channels", 2) if audio_profile else 2
        cl_layout = "stereo" if ch == 2 else "mono"
        ext = out_file.suffix.lower()
        encode_args = ["-c:a", "pcm_s16le"] if ext == ".wav" else ["-b:a", "192k"]
        cmd = [
            "ffmpeg", "-y", "-f", "lavfi",
            "-i", f"anullsrc=r={sr}:cl={cl_layout}",
            "-t", f"{dur:.3f}",
            "-vn", "-ar", str(sr), "-ac", str(ch),
            *encode_args,
            str(out_file), "-loglevel", "error"
        ]
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
            return r.returncode == 0 and out_file.exists()
        except Exception:
            return False

class Finalizer:
    @staticmethod
    def finalize(
        job_id: str,
        chunk_files: List[Path],
        output_path: Path,
        job_dir: Path,
        audio_profile: Dict[str, Any],
        audio_format: str = "mp3",
        keep_source: bool = False
    ) -> Tuple[bool, str, Path]:
        """
        Ghép các file Chunk lại thành file kết quả duy nhất:
        1. Ghi ra file tạm final.tmp trước.
        2. Xác thực ffprobe nghiêm ngặt (size > 0, duration > 0, có audio stream).
        3. Di chuyển nguyên tử sang Download/KAGEVIETSUB/.
        4. Tuyệt đối KHÔNG xóa Download/KAGEVIETSUB/ (dữ liệu người dùng).
        5. Xóa thư mục temp của job sau khi xác thực thành công (nếu keep_source=False).
        """
        ext = "wav" if str(audio_format).lower() == "wav" else "mp3"
        temp_final = output_path.parent / f".{output_path.name}.tmp.{ext}"
        if temp_final.exists():
            try:
                temp_final.unlink()
            except Exception:
                pass

        if len(chunk_files) == 1:
            logger.info(f"[MERGE] Copying single chunk to temp final: {temp_final.resolve()}")
            shutil.copyfile(chunk_files[0], temp_final)
        else:
            concat_txt = job_dir / "concat_chunks.txt"
            with open(concat_txt, "w", encoding="utf-8") as f:
                for cf in chunk_files:
                    safe_p = str(cf.resolve()).replace("'", "'\\''")
                    f.write(f"file '{safe_p}'\n")

            threads = DeviceOptimizer.get_optimal_threads()
            concat_cmd = [
                "ffmpeg", "-y", "-f", "concat", "-safe", "0",
                "-i", str(concat_txt),
                "-c", "copy",
                "-threads", str(threads),
                "-f", ext,
                str(temp_final), "-loglevel", "error"
            ]

            logger.info(f"[MERGE] FFmpeg command started: {' '.join(concat_cmd)}")
            try:
                res_p = subprocess.run(concat_cmd, capture_output=True, text=True, timeout=120)
                logger.info(f"[MERGE] FFmpeg exit code: {res_p.returncode}")
                if res_p.returncode != 0 or not temp_final.exists() or temp_final.stat().st_size == 0:
                    sr = audio_profile.get("sample_rate", 44100)
                    ch = audio_profile.get("channels", 2)
                    encode_args = ["-c:a", "pcm_s16le"] if ext == "wav" else ["-c:a", "libmp3lame", "-b:a", "192k"]
                    concat_cmd_fallback = [
                        "ffmpeg", "-y", "-f", "concat", "-safe", "0",
                        "-i", str(concat_txt),
                        *encode_args,
                        "-ar", str(sr), "-ac", str(ch),
                        "-threads", str(threads),
                        "-f", ext,
                        str(temp_final), "-loglevel", "error"
                    ]
                    logger.info(f"[MERGE] FFmpeg fallback command started: {' '.join(concat_cmd_fallback)}")
                    res_fb = subprocess.run(concat_cmd_fallback, capture_output=True, text=True, timeout=180)
                    logger.info(f"[MERGE] FFmpeg exit code: {res_fb.returncode}")
                    if res_fb.returncode != 0 or not temp_final.exists() or temp_final.stat().st_size == 0:
                        if temp_final.exists():
                            try:
                                temp_final.unlink()
                            except Exception:
                                pass
                        return False, f"Lỗi kết xuất file {ext.upper()} (exit code {res_fb.returncode}): {res_fb.stderr}", output_path
            except FileNotFoundError:
                return False, "Không tìm thấy công cụ FFmpeg trong PATH hệ thống.", output_path
            except Exception as ex:
                return False, f"Lỗi FFmpeg: {ex}", output_path

        exists = temp_final.exists()
        file_size = temp_final.stat().st_size if exists else 0
        logger.info(f"[MERGE] Output exists: {exists}")
        logger.info(f"[MERGE] Output size: {file_size} bytes")

        if not exists or file_size == 0:
            return False, f"File {ext.upper()} kết xuất có kích thước 0 bytes.", output_path

        media_info = FFmpegService.get_media_info(temp_final)
        dur = float(media_info.get("duration", 0.0))
        has_audio = media_info.get("has_audio", False)
        logger.info(f"[MERGE] FFprobe verification: duration={dur:.2f}s, has_audio={has_audio}")

        if dur < 0.1 or not has_audio:
            if temp_final.exists():
                try:
                    temp_final.unlink()
                except Exception:
                    pass
            return False, f"File {ext.upper()} kết xuất không hợp lệ qua FFprobe (dur={dur}s, has_audio={has_audio}).", output_path

        output_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            if output_path.exists():
                output_path.unlink()
            shutil.move(str(temp_final), str(output_path))
        except Exception:
            try:
                shutil.copyfile(str(temp_final), str(output_path))
                if temp_final.exists():
                    temp_final.unlink()
            except Exception as move_ex:
                return False, f"Lỗi di chuyển file kết quả vào {output_path}: {move_ex}", output_path

        final_exists = output_path.exists()
        final_size = output_path.stat().st_size if final_exists else 0
        if not final_exists or final_size == 0:
            return False, f"Lỗi di chuyển file kết quả vào thư mục {output_path.parent}.", output_path

        logger.info(f"[MERGE] Final output verified: {output_path.resolve()}")
        logger.info(f"[MERGE] Job completed")

        if not keep_source:
            try:
                from TOOL.services.cleanup_service import CleanupService
                CleanupService.cleanup_job_temp(job_id)
            except Exception as e:
                logger.warning(f"Bỏ qua lỗi xóa temp job {job_id}: {e}")
        else:
            try:
                for chunk_p in chunk_files:
                    if chunk_p.exists():
                        try:
                            chunk_p.unlink()
                        except Exception:
                            pass
                for txt_p in job_dir.glob("concat_*.txt"):
                    try:
                        txt_p.unlink()
                    except Exception:
                        pass
                ckpt_p = job_dir / "merge_checkpoint.json"
                if ckpt_p.exists():
                    try:
                        ckpt_p.unlink()
                    except Exception:
                        pass
            except Exception as ex:
                logger.warning(f"Bỏ qua dọn dẹp merge artifacts: {ex}")

        return True, f"✓ Ghép audio {ext.upper()} hoàn tất thành công.", output_path

class TimelineAudioMerger:
    """Engine ghép nối Audio Timeline cao cấp của KAGEVIETSUB."""

    CHUNK_SIZE_MS = 300000                   

    @classmethod
    def merge(
        cls,
        job_id: str,
        sub_states: List[Dict[str, Any]],
        job_dir: Path,
        output_filename: str = "tts_final_audio.mp3",
        audio_format: str = "mp3",
        progress_callback: Optional[Callable[[int, str], None]] = None,
        keep_source: bool = False
    ) -> Tuple[bool, str, Path]:
        """
        Thực thi toàn bộ pipeline ghép audio:
        SRT -> AudioAnalyzer -> TimelineBuilder -> Dynamic Profiler -> ChunkPlanner -> MergeCheckpointManager -> Parallel ChunkMixer -> Finalizer
        """
        def _report(pct: int, msg: str):
            if progress_callback:
                progress_callback(pct, msg)

        audio_format = str(audio_format).lower().strip() if audio_format else "mp3"
        if audio_format not in ["mp3", "wav"]:
            audio_format = "mp3"

        if not output_filename:
            output_filename = f"tts_final_audio.{audio_format}"
        else:
            if audio_format == "wav":
                if not output_filename.lower().endswith(".wav"):
                    if output_filename.lower().endswith(".mp3"):
                        output_filename = output_filename[:-4] + ".wav"
                    else:
                        output_filename += ".wav"
            else:
                if not output_filename.lower().endswith(".mp3"):
                    if output_filename.lower().endswith(".wav"):
                        output_filename = output_filename[:-4] + ".mp3"
                    else:
                        output_filename += ".mp3"

        ctrl_ctx = job_manager.get_control_context(job_id)
        if ctrl_ctx.is_stopped():
            return False, "Tiến trình đã bị dừng trước khi bắt đầu.", job_dir / output_filename

        t_start = time.perf_counter()
        _report(5, "Đang phân tích cấu trúc timeline và định dạng audio...")

        items, max_timeline_ms = TimelineBuilder.build_timeline(sub_states, job_dir)
        total_items = len(items)

        sample_paths = [it["file"] for it in items[:10]]
        audio_profile = AudioAnalyzer.analyze_audio_compatibility(sample_paths)

        calc_profile = DeviceOptimizer.get_merge_concurrency_profile(total_items, max_timeline_ms)
        recommended_workers = calc_profile.get("recommended_workers", 2)
        max_safe_workers = calc_profile.get("max_safe_workers", 4)
        active_workers = recommended_workers
        is_android = calc_profile.get("is_android", False)
        cpu_cores = calc_profile.get("logical_cores", os.cpu_count() or 4)
        ram_avail = calc_profile.get("available_ram_mb", 2048)

        logger.info(
            f"[MERGE]\n"
            f"Device: {'Android' if is_android else platform.system() + ' PC'}\n"
            f"CPU: {cpu_cores} cores\n"
            f"RAM available: {ram_avail} MB\n"
            f"Audio count: {total_items}\n"
            f"Audio format: {audio_format.upper()}\n"
            f"Recommended workers: {recommended_workers}\n"
            f"Max safe workers: {max_safe_workers}\n"
            f"Active workers: {active_workers}"
        )

        adaptive_chunk_ms = DeviceOptimizer.get_chunk_size_ms(total_items, max_timeline_ms)
        chunk_plans = ChunkPlanner.plan_chunks(items, max_timeline_ms, adaptive_chunk_ms, audio_format=audio_format)
        num_chunks = len(chunk_plans)

        ckpt_mgr = MergeCheckpointManager(job_dir)
        ckpt_mgr.init_checkpoint(num_chunks, chunk_plans)

        _report(15, f"Bắt đầu xử lý {total_items} câu ({num_chunks} chunk {audio_format.upper()}, {active_workers} luồng tự động)...")

        completed_chunk_files = [None] * num_chunks
        chunks_done_count = 0
        merge_lock = threading.Lock()
        mix_error = None

        def _process_chunk_task(plan_tuple: Tuple[int, Dict[str, Any]]) -> Tuple[bool, str, Optional[Path]]:
            nonlocal chunks_done_count, mix_error
            k, plan = plan_tuple
            if ctrl_ctx.is_stopped() or mix_error:
                return False, "Tiến trình đã dừng.", None

            chunk_file = job_dir / plan["filename"]

            if ckpt_mgr.is_chunk_completed(k):
                with merge_lock:
                    chunks_done_count += 1
                    completed_chunk_files[k] = chunk_file
                    pct = 15 + int((chunks_done_count / num_chunks) * 70)
                _report(pct, f"[Resume] Chunk {k+1}/{num_chunks} đã có sẵn, bỏ qua.")
                return True, "", chunk_file

            ckpt_mgr.update_chunk_status(k, "PROCESSING")

            with merge_lock:
                pct = 15 + int((chunks_done_count / num_chunks) * 70)
            _report(pct, f"Đang ghép audio chunk {k+1}/{num_chunks} ({len(plan['chunk_items'])} câu, {active_workers} luồng)...")

            ok_mix, err_mix, out_c = ChunkMixer.mix_chunk_fast(
                plan=plan,
                job_dir=job_dir,
                audio_profile=audio_profile,
                audio_format=audio_format,
                cancel_check=lambda: ctrl_ctx.is_stopped() or (mix_error is not None)
            )

            if not ok_mix:
                if ctrl_ctx.is_stopped():
                    ckpt_mgr.update_chunk_status(k, "FAILED", "Stopped by user")
                    return False, "Tiến trình bị dừng bởi người dùng.", out_c
                ckpt_mgr.update_chunk_status(k, "FAILED", err_mix)
                with merge_lock:
                    if not mix_error:
                        mix_error = f"Lỗi trộn chunk {k+1}/{num_chunks}: {err_mix}"
                return False, err_mix, out_c

            ckpt_mgr.update_chunk_status(k, "COMPLETED")
            with merge_lock:
                chunks_done_count += 1
                completed_chunk_files[k] = out_c
                pct = 15 + int((chunks_done_count / num_chunks) * 70)

            _report(pct, f"Đã ghép xong chunk {k+1}/{num_chunks} ({chunks_done_count}/{num_chunks})...")
            return True, "", out_c

        effective_workers = min(active_workers, num_chunks)
        if effective_workers > 1 and num_chunks > 1:
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor(max_workers=effective_workers, thread_name_prefix="MergeWorker") as executor:
                futures = [executor.submit(_process_chunk_task, (k, plan)) for k, plan in enumerate(chunk_plans)]
                for fut in concurrent.futures.as_completed(futures):
                    if ctrl_ctx.is_stopped():
                        return False, "Tiến trình ghép audio đã bị dừng bởi người dùng.", job_dir / output_filename
                    if mix_error:
                        return False, mix_error, job_dir / output_filename
                    try:
                        ok_task, err_task, _ = fut.result()
                        if not ok_task and not ctrl_ctx.is_stopped():
                            return False, err_task or mix_error or "Lỗi ghép chunk.", job_dir / output_filename
                    except Exception as ex:
                        return False, f"Lỗi thực thi luồng ghép: {ex}", job_dir / output_filename
        else:
            for k, plan in enumerate(chunk_plans):
                if ctrl_ctx.is_stopped():
                    return False, "Tiến trình ghép audio đã bị dừng bởi người dùng.", job_dir / output_filename
                ok_task, err_task, _ = _process_chunk_task((k, plan))
                if not ok_task:
                    return False, err_task or "Lỗi ghép chunk.", job_dir / output_filename

        if any(c is None for c in completed_chunk_files):
            return False, "Không thể hoàn thành toàn bộ các chunk audio.", job_dir / output_filename

        if ctrl_ctx.is_stopped():
            return False, "Tiến trình đã bị dừng bởi người dùng.", job_dir / output_filename

        _report(90, f"Đang kết xuất và xác thực file {audio_format.upper()} ({active_workers} luồng)...")

        from TOOL.services.storage_service import StorageService
        output_dir = StorageService.get_output_dir()
        logger.info(f"[MERGE] Source folder: {job_dir.resolve()}")
        logger.info(f"[MERGE] Output directory: {output_dir.resolve()}")

        try:
            output_dir.mkdir(parents=True, exist_ok=True)
            if not os.access(output_dir, os.W_OK):
                err_msg = "Không thể ghi vào Download/KAGEVIETSUB. Hãy kiểm tra quyền truy cập bộ nhớ của Termux."
                logger.error(f"[MERGE] {err_msg}")
                return False, err_msg, output_dir / output_filename
        except Exception as ex:
            err_msg = f"Không thể ghi vào Download/KAGEVIETSUB. Hãy kiểm tra quyền truy cập bộ nhớ: {ex}"
            logger.error(f"[MERGE] {err_msg}")
            return False, err_msg, output_dir / output_filename

        output_path = get_safe_unique_filepath(output_dir, output_filename)
        logger.info(f"[MERGE] Final output target: {output_path.resolve()}")

        ok_fin, msg_fin, final_path = Finalizer.finalize(
            job_id=job_id,
            chunk_files=completed_chunk_files,
            output_path=output_path,
            job_dir=job_dir,
            audio_profile=audio_profile,
            audio_format=audio_format,
            keep_source=keep_source
        )

        t_elapsed = time.perf_counter() - t_start
        logger.info(f"PERF_LOG: Merge job '{job_id}' ({total_items} items, {max_timeline_ms/1000:.1f}s audio, {active_workers} workers, format={audio_format.upper()}) hoàn tất trong {t_elapsed:.2f}s.")

        return ok_fin, msg_fin, final_path

AudioMerger = TimelineAudioMerger
