#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB - AUTO UPDATER ENGINE (WINDOWS CMD/POWERSHELL + ANDROID TERMUX)
==============================================================================
- Nguồn kiểm tra duy nhất: file Update.txt trên GitHub repository
- Format Update.txt:
    VERSION=x.x.x
    URL=https://.../update.zip
    SHA256=... (tùy chọn)
- Cơ chế update theo cấu trúc file thực tế trong ZIP
- File có trong ZIP -> cập nhật và backup
- File không có trong ZIP -> bảo toàn 100%, không xóa
- File mới trong ZIP -> tạo mới sau khi kiểm tra an toàn
- Kiểm tra SHA256 nếu có trong Update.txt; nếu không có thì bỏ qua
- Chặn Path Traversal (../, absolute paths, /storage)
- Bảo vệ tuyệt đối: DATA/models, DATA/output, DATA/uploads, DATA/temp, Download/KAGEVIETSUB
- Transactional Rollback: nếu lỗi ở bất kỳ bước nào thì khôi phục nguyên trạng thái cũ
- Graceful check: không cập nhật khi hệ thống đang xử lý tác vụ
- Chỉ cập nhật version.json sau khi mọi file verify thành công
- Thông báo: 'Cập nhật thành công. Vui lòng khởi động lại KAGEVIETSUB.' (không tự restart)
==============================================================================
"""

import os
import sys
import json
import shutil
import zipfile
import hashlib
import urllib.request
import urllib.error
import re
import logging
from pathlib import Path
from typing import Dict, Any, Optional, Tuple, List

logger = logging.getLogger("kagevietsub.updater")

TOOL_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = TOOL_DIR.parent
DATA_DIR = PROJECT_ROOT / "DATA"
VERSION_FILE = PROJECT_ROOT / "version.json"

UPDATE_INFO_URL = os.getenv(
    "KAGE_UPDATE_URL",
    "https://raw.githubusercontent.com/nguyenducmanh2222011-oss/Update-tool/main/Update.txt"
)
UPDATE_TIMEOUT = 6                                  

PROTECTED_PATHS = [
    "DATA/models",
    "DATA/output",
    "DATA/uploads",
    "DATA/temp",
    "DATA/logs",
    "Download",
    "Download/KAGEVIETSUB",
    "storage",
    "/storage",
    ".env",
    ".env.local"
]

def parse_version_tuple(v_str: str) -> Tuple[int, ...]:
    """
    Chuyển chuỗi version 'v1.2.0', '1.10.0' thành tuple (1, 10, 0)
    để so sánh số học chính xác theo Semantic Versioning.
    """
    clean = re.sub(r'^[^\d]*', '', str(v_str).strip())
    parts = re.findall(r'\d+', clean)
    if not parts:
        return (0, 0, 0)
    return tuple(int(p) for p in parts[:4])

def get_local_version() -> str:
    """Đọc phiên bản hiện tại từ version.json ở thư mục gốc."""
    if VERSION_FILE.exists():
        try:
            with open(VERSION_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                return str(data.get("version", "1.0.0")).strip()
        except Exception:
            pass
    return "1.0.0"

def set_local_version(version: str):
    """Ghi phiên bản mới vào version.json."""
    try:
        data = {"version": version.lstrip("v").strip()}
        with open(VERSION_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
            f.write("\n")
    except Exception as ex:
        logger.error(f"Không thể ghi version.json: {ex}")

def parse_update_txt(raw_text: str) -> Dict[str, str]:
    """
    Phân tích nội dung Update.txt:
    Chỉ xử lý:
      VERSION=...
      URL=...
      SHA256=... (optional)
    """
    info: Dict[str, str] = {
        "version": "",
        "url": "",
        "sha256": ""
    }

    raw_text = raw_text.strip()
    if not raw_text:
        return info

    for line in raw_text.splitlines():
        line_s = line.strip()
        if not line_s or line_s.startswith("#"):
            continue

        if "=" in line_s:
            k, _, v = line_s.partition("=")
            key = k.strip().upper()
            val = v.strip().strip('"').strip("'")
            if key in ["VERSION", "VER", "TAG"]:
                info["version"] = val.lstrip("v")
            elif key in ["URL", "DOWNLOAD_URL", "LINK", "ZIP_URL"]:
                info["url"] = val
            elif key in ["SHA256", "HASH", "CHECKSUM"]:
                info["sha256"] = val
        elif ":" in line_s:
            k, _, v = line_s.partition(":")
            key = k.strip().upper()
            val = v.strip().strip('"').strip("'")
            if key in ["VERSION", "VER"]:
                info["version"] = val.lstrip("v")
            elif key in ["URL", "DOWNLOAD_URL", "LINK"]:
                info["url"] = val
            elif key in ["SHA256", "HASH"]:
                info["sha256"] = val

    return info

def check_for_update(update_url: str = UPDATE_INFO_URL, timeout: int = UPDATE_TIMEOUT) -> Tuple[bool, str, Dict[str, str]]:
    """
    Kiểm tra phiên bản mới từ file Update.txt.
    Trả về: (has_update: bool, latest_version_str: str, update_info: dict)
    Offline-safe: timeout nhanh, không gây treo START.py nếu mất mạng.
    """
    local_ver = get_local_version()
    local_tuple = parse_version_tuple(local_ver)

    req = urllib.request.Request(
        update_url,
        headers={
            "User-Agent": "KAGEVIETSUB-Updater/1.0",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache"
        }
    )

    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            if response.status == 200:
                content = response.read().decode("utf-8", errors="ignore")
                info = parse_update_txt(content)
                remote_ver = info.get("version", "").strip()

                if not remote_ver:
                    return False, local_ver, {}

                remote_tuple = parse_version_tuple(remote_ver)
                if remote_tuple > local_tuple:
                    return True, remote_ver, info
                else:
                    return False, remote_ver, info
    except Exception:
        return False, local_ver, {}

    return False, local_ver, {}

def is_system_busy() -> bool:
    """Kiểm tra xem hệ thống có đang bận xử lý tác vụ hay không."""
    try:
        from TOOL.services.task_service import job_manager
        return job_manager.has_active_jobs()
    except Exception:
        return False

def calculate_sha256(file_path: Path) -> str:
    """Tính mã SHA256 của file."""
    sha256_hash = hashlib.sha256()
    with open(file_path, "rb") as f:
        for byte_block in iter(lambda: f.read(65536), b""):
            sha256_hash.update(byte_block)
    return sha256_hash.hexdigest().lower()

def download_update_zip(url: str, destination: Path, expected_sha256: str = "", timeout: int = 60) -> Tuple[bool, str]:
    """
    Tải file ZIP update từ URL vào thư mục tạm chuyên dụng.
    Nếu expected_sha256 có giá trị -> kiểm tra tính toàn vẹn SHA256.
    Nếu expected_sha256 rỗng -> bỏ qua kiểm tra SHA256.
    Nếu SHA256 không khớp -> hủy update và báo lỗi.
    """
    try:
        destination.parent.mkdir(parents=True, exist_ok=True)
        req = urllib.request.Request(
            url,
            headers={
                "User-Agent": "KAGEVIETSUB-Updater/1.0",
                "Accept": "*/*"
            }
        )

        with urllib.request.urlopen(req, timeout=timeout) as response, open(destination, "wb") as out_file:
            total_size = int(response.headers.get("Content-Length", 0))
            block_size = 32768
            downloaded = 0

            while True:
                buffer = response.read(block_size)
                if not buffer:
                    break
                downloaded += len(buffer)
                out_file.write(buffer)
                if total_size > 0:
                    try:
                        from TOOL.cli_ui import print_progress_bar
                        print_progress_bar(downloaded, total_size, prefix="Đang tải gói cập nhật...")
                    except Exception:
                        pass

            if total_size > 0:
                sys.stdout.write("\n")
                sys.stdout.flush()

        if not destination.exists() or destination.stat().st_size == 0:
            return False, "File tải về rỗng hoặc không thể lưu."

        if not zipfile.is_zipfile(destination):
            return False, "File tải về không phải là file ZIP hợp lệ."

        clean_expected_hash = expected_sha256.strip().lower()
        if clean_expected_hash:
            calc_hash = calculate_sha256(destination)
            if calc_hash != clean_expected_hash:
                return False, f"Mã SHA256 không khớp! (Kỳ vọng: {clean_expected_hash}, Thực tế: {calc_hash})"

        return True, "Tải file thành công."

    except Exception as e:
        return False, f"Lỗi tải gói cập nhật: {str(e)}"

def is_path_safe_for_update(rel_path_str: str) -> Tuple[bool, str]:
    """
    Kiểm tra bảo mật nghiêm ngặt cho đường dẫn tương đối trong gói update:
    1. Chống Path Traversal (../, ..\\, hoặc chứa ..)
    2. Chặn đường dẫn tuyệt đối (bắt đầu bằng /, \\, ổ đĩa C:)
    3. Chặn can thiệp vào các đường dẫn dữ liệu người dùng được bảo vệ:
       - DATA/models
       - DATA/output
       - DATA/uploads
       - DATA/temp
       - Download/KAGEVIETSUB
       - /storage/ hoặc storage/
    4. Đảm bảo path khi resolve nằm hoàn toàn bên trong PROJECT_ROOT
    """
    p_str = rel_path_str.replace("\\", "/").strip()
    if not p_str:
        return False, "Đường dẫn rỗng"

    if p_str.startswith("/") or re.match(r'^[a-zA-Z]:', p_str):
        return False, f"Chặn đường dẫn tuyệt đối: {p_str}"

    parts = [part.strip() for part in p_str.split("/") if part.strip()]
    if ".." in parts:
        return False, f"Chặn Path Traversal chứa '..': {p_str}"

    for part in parts:
        if part.lower() in ["storage", "etc", "var", "usr", "bin"]:
            return False, f"Chặn đường dẫn hệ thống/storage cấm: {p_str}"

    norm = "/".join(parts)
    norm_lower = norm.lower()
    for protected in PROTECTED_PATHS:
        prot_norm = protected.replace("\\", "/").strip("/").lower()
        if norm_lower == prot_norm or norm_lower.startswith(prot_norm + "/"):
            return False, f"Chặn can thiệp vùng dữ liệu được bảo vệ: {norm}"

    try:
        resolved = (PROJECT_ROOT / norm).resolve()
        project_root_resolved = PROJECT_ROOT.resolve()
        if not (resolved == project_root_resolved or project_root_resolved in resolved.parents):
            return False, f"Đường dẫn resolve nằm ngoài project root: {p_str}"
    except Exception as ex:
        return False, f"Lỗi kiểm tra resolve path: {ex}"

    return True, "Hợp lệ"

def inspect_and_extract_zip(
    zip_path: Path,
    extract_dir: Path
) -> Tuple[bool, str, List[Tuple[Path, str]]]:
    """
    Kiểm tra cấu trúc và giải nén file ZIP vào thư mục tạm chuyên dụng.
    - Kiểm tra CRC toàn vẹn
    - Kiểm tra từng member chống Path Traversal và bảo vệ dữ liệu
    - Trích xuất ra DATA/temp/updater/extracted/
    - Trả về danh sách: [(đường_dẫn_file_giải_nén, đường_dẫn_tương_đối_project)]
    Nếu phát hiện bất kỳ file nào không an toàn: HỦY TOÀN BỘ NGAY LẬP TỨC.
    """
    if extract_dir.exists():
        shutil.rmtree(extract_dir, ignore_errors=True)
    extract_dir.mkdir(parents=True, exist_ok=True)

    try:
        with zipfile.ZipFile(zip_path, "r") as zip_ref:
                             
            crc_err = zip_ref.testzip()
            if crc_err is not None:
                return False, f"File ZIP bị lỗi CRC ở mục: {crc_err}", []

            namelist = zip_ref.namelist()
            if not namelist:
                return False, "File ZIP cập nhật rỗng.", []

            strip_prefix = ""
            non_empty_names = [n for n in namelist if n.strip("/")]
            if non_empty_names:
                first_parts = [n.replace("\\", "/").split("/")[0] for n in non_empty_names]
                common_top = first_parts[0]
                if all(p == common_top for p in first_parts):
                                                                                                              
                    if common_top not in ["TOOL", "tests", "DATA", "Download"]:
                        strip_prefix = common_top + "/"

            for name in namelist:
                                
                if name.endswith("/") or name.endswith("\\"):
                    continue

                rel_name = name
                if strip_prefix and rel_name.startswith(strip_prefix):
                    rel_name = rel_name[len(strip_prefix):]

                rel_name = rel_name.replace("\\", "/").strip()
                if not rel_name:
                    continue

                is_safe, reason = is_path_safe_for_update(rel_name)
                if not is_safe:
                    return False, f"Gói ZIP chứa đường dẫn nguy hiểm hoặc không được phép ({name}): {reason}", []

            zip_ref.extractall(extract_dir)

    except Exception as e:
        return False, f"Lỗi giải nén gói ZIP: {str(e)}", []

    source_root = extract_dir
    if strip_prefix:
        candidate_root = extract_dir / strip_prefix.strip("/")
        if candidate_root.is_dir():
            source_root = candidate_root

    extracted_files: List[Tuple[Path, str]] = []
    for root, _, files in os.walk(source_root):
        for file_name in files:
            full_src = Path(root) / file_name
            rel_proj = str(full_src.relative_to(source_root)).replace("\\", "/")

            is_safe, reason = is_path_safe_for_update(rel_proj)
            if not is_safe:
                return False, f"Phát hiện file không an toàn sau giải nén ({rel_proj}): {reason}", []

            extracted_files.append((full_src, rel_proj))

    if not extracted_files:
        return False, "Không tìm thấy file nào cần cập nhật trong gói ZIP.", []

    return True, "Thành công", extracted_files

def apply_transactional_update(
    extracted_files: List[Tuple[Path, str]],
    expected_version: str
) -> Tuple[bool, str]:
    """
    Áp dụng cập nhật Transactional với cơ chế Rollback toàn vẹn:
    1. Backup các file cũ sắp bị ghi đè sang DATA/temp/updater/backup/
    2. Copy từng file mới vào project
    3. Verify từng file sau khi copy
    4. Nếu có bất kỳ lỗi nào xảy ra:
       - Khôi phục tất cả file đã bị thay thế từ backup
       - Xóa tất cả file mới vừa được tạo
       - Giữ nguyên phiên bản trong version.json
       - Báo lỗi chi tiết
    5. Chỉ khi toàn bộ thành công 100%:
       - Ghi version mới vào version.json
       - Dọn dẹp backup và extracted
    """
    updater_dir = DATA_DIR / "temp" / "updater"
    backup_dir = updater_dir / "backup"

    if backup_dir.exists():
        shutil.rmtree(backup_dir, ignore_errors=True)
    backup_dir.mkdir(parents=True, exist_ok=True)

    files_to_backup: List[str] = []
    files_to_add: List[str] = []

    for _, rel_proj_path in extracted_files:
        target_file = PROJECT_ROOT / rel_proj_path
        if target_file.exists():
            files_to_backup.append(rel_proj_path)
        else:
            files_to_add.append(rel_proj_path)

    try:
        for rel_path in files_to_backup:
            src = PROJECT_ROOT / rel_path
            dst = backup_dir / rel_path
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
    except Exception as e:
        return False, f"Không thể tạo bản sao lưu an toàn cho các file hiện tại: {str(e)}"

    modified_files: List[str] = []
    added_files: List[str] = []
    added_dirs: List[Path] = []

    try:
        for src_path, rel_proj_path in extracted_files:
            dst_file = PROJECT_ROOT / rel_proj_path

            if not dst_file.parent.exists():
                cur = dst_file.parent
                chain = []
                while not cur.exists() and cur != PROJECT_ROOT and cur.is_relative_to(PROJECT_ROOT):
                    chain.append(cur)
                    cur = cur.parent
                for d in reversed(chain):
                    d.mkdir(parents=True, exist_ok=True)
                    added_dirs.append(d)
            else:
                dst_file.parent.mkdir(parents=True, exist_ok=True)

            is_new = not dst_file.exists()
            shutil.copy2(src_path, dst_file)

            if is_new:
                added_files.append(rel_proj_path)
            else:
                modified_files.append(rel_proj_path)

            if not dst_file.exists() or dst_file.stat().st_size != src_path.stat().st_size:
                raise RuntimeError(f"Xác thực file thất bại sau khi copy: {rel_proj_path}")

        set_local_version(expected_version)

        shutil.rmtree(updater_dir, ignore_errors=True)

        return True, "Cập nhật thành công. Vui lòng khởi động lại KAGEVIETSUB."

    except Exception as ex:
                                                                                
        logger.error(f"[UPDATER ROLLBACK] Lỗi cập nhật: {ex}. Bắt đầu khôi phục...")

        for rel_path in modified_files:
            orig_backup = backup_dir / rel_path
            target_file = PROJECT_ROOT / rel_path
            if orig_backup.exists():
                try:
                    target_file.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(orig_backup, target_file)
                except Exception as restore_err:
                    logger.error(f"Lỗi khôi phục file {rel_path}: {restore_err}")

        for rel_path in added_files:
            target_file = PROJECT_ROOT / rel_path
            if target_file.exists():
                try:
                    target_file.unlink()
                except Exception as del_err:
                    logger.error(f"Lỗi xóa file mới {rel_path}: {del_err}")

        for d in reversed(added_dirs):
            if d.exists():
                try:
                    if not any(d.iterdir()):
                        d.rmdir()
                except Exception:
                    pass

        return False, f"Lỗi trong quá trình cập nhật: {str(ex)}. Đã rollback toàn bộ về trạng thái ban đầu."

def apply_update_process(zip_path: Path, expected_version: str) -> Tuple[bool, str]:
    """
    Quy trình cập nhật chuẩn xác:
    1. Kiểm tra Server/Task -> Dừng nếu hệ thống bận
    2. Kiểm tra và giải nén ZIP an toàn
    3. Áp dụng cập nhật Transactional có Rollback
    """
                                     
    if is_system_busy():
        return False, "Không thể cập nhật lúc này. KAGEVIETSUB đang có tác vụ đang chạy. Hãy chờ tác vụ hoàn tất rồi cập nhật."

    updater_temp = DATA_DIR / "temp" / "updater"
    extract_dir = updater_temp / "extracted"

    ok_ext, ext_msg, extracted_files = inspect_and_extract_zip(zip_path, extract_dir)
    if not ok_ext:
        return False, ext_msg

    ok_apply, apply_msg = apply_transactional_update(extracted_files, expected_version)
    return ok_apply, apply_msg

def print_update_available_banner(current_ver: str, new_ver: str):
    """Hiển thị thông báo có bản cập nhật theo đúng format."""
    from TOOL.cli_ui import Colors
    C = Colors

    print()
    print(f"{C.CYAN}╔══════════════════════════════════════════╗{C.RESET}")
    print(f"{C.CYAN}║{C.BRIGHT_YELLOW}{C.BOLD}       KAGEVIETSUB UPDATE AVAILABLE       {C.RESET}{C.CYAN}║{C.RESET}")
    print(f"{C.CYAN}╚══════════════════════════════════════════╝{C.RESET}")
    print()
    print(f" {C.WHITE}Phiên bản hiện tại : {C.BRIGHT_CYAN}v{current_ver.lstrip('v')}{C.RESET}")
    print(f" {C.WHITE}Phiên bản mới      : {C.BRIGHT_GREEN}v{new_ver.lstrip('v')}{C.RESET}")
    print()

def print_update_success_banner(old_ver: str, new_ver: str):
    """Hiển thị thông báo cập nhật thành công theo đúng format."""
    from TOOL.cli_ui import Colors
    C = Colors

    print()
    print(f"{C.GREEN}╔══════════════════════════════════════════╗{C.RESET}")
    print(f"{C.GREEN}║{C.BRIGHT_GREEN}{C.BOLD}       KAGEVIETSUB UPDATE SUCCESS         {C.RESET}{C.GREEN}║{C.RESET}")
    print(f"{C.GREEN}╚══════════════════════════════════════════╝{C.RESET}")
    print()
    print(f" {C.GREEN}✓{C.RESET} {C.WHITE}Phiên bản cũ: {C.GRAY}v{old_ver.lstrip('v')}{C.RESET}")
    print(f" {C.GREEN}✓{C.RESET} {C.WHITE}Phiên bản mới: {C.BRIGHT_GREEN}v{new_ver.lstrip('v')}{C.RESET}")
    print(f" {C.GREEN}✓{C.RESET} {C.WHITE}Code đã được cập nhật{C.RESET}")
    print(f" {C.GREEN}✓{C.RESET} {C.WHITE}Dữ liệu người dùng được giữ nguyên{C.RESET}")
    print()
    print(f" {C.BRIGHT_GREEN}{C.BOLD}Cập nhật thành công. Vui lòng khởi động lại KAGEVIETSUB.{C.RESET}")
    print(f" {C.GRAY}Lệnh khởi chạy: {C.CYAN}python START.py{C.RESET}")
    print()

def run_cli_update_flow(prompt_user: bool = True) -> bool:
    """
    Quy trình kiểm tra và cập nhật hoàn chỉnh khi chạy qua CLI / START.py:
    1. Kiểm tra Update.txt trên GitHub
    2. Có bản mới -> Hiển thị banner update và hỏi [Y/N]
    3. Nếu N -> bỏ qua và tiếp tục chạy KAGEVIETSUB
    4. Nếu Y -> kiểm tra job đang chạy -> tải zip -> verify SHA256 (nếu có) -> extract -> backup -> apply -> exit
    """
    from TOOL.cli_ui import Colors, Icons, print_error, print_info

    has_update, remote_ver, update_info = check_for_update()

    if not has_update or not update_info:
        return False

    current_ver = get_local_version()
    new_ver = remote_ver

    print_update_available_banner(current_ver, new_ver)

    if prompt_user:
        try:
            prompt_msg = f" {Colors.BRIGHT_WHITE}Bạn có muốn cập nhật không? [Y/N]: {Colors.RESET}"
            choice = input(prompt_msg).strip().lower()
        except (KeyboardInterrupt, EOFError):
            print()
            return False

        if choice not in ["y", "yes", "có", "c"]:
            print(f" {Colors.GRAY}Bỏ qua cập nhật. KAGEVIETSUB tiếp tục khởi động...{Colors.RESET}\n")
            return False

    if is_system_busy():
        print()
        print(f" {Colors.YELLOW}{Icons.WARN} Không thể cập nhật lúc này.{Colors.RESET}")
        print(f"   {Colors.WHITE}KAGEVIETSUB đang có tác vụ đang chạy.{Colors.RESET}")
        print(f"   {Colors.GRAY}Hãy chờ tác vụ hoàn tất rồi cập nhật.{Colors.RESET}")
        print()
        return False

    download_url = update_info.get("url", "").strip()
    if not download_url:
        print_error("Không tìm thấy link tải ZIP trong Update.txt.")
        return False

    expected_sha256 = update_info.get("sha256", "").strip()
    updater_dir = DATA_DIR / "temp" / "updater"
    updater_dir.mkdir(parents=True, exist_ok=True)
    temp_zip = updater_dir / f"kagevietsub_update_v{new_ver.lstrip('v')}.zip"

    print_info(f"Đang chuẩn bị tải gói cập nhật v{new_ver.lstrip('v')}...")

    success_dl, dl_msg = download_update_zip(download_url, temp_zip, expected_sha256=expected_sha256)
    if not success_dl:
        print_error("Tải bản cập nhật thất bại", reason=dl_msg)
        return False

    print_info("Đang kiểm tra gói cập nhật và áp dụng code mới...")
    success_apply, apply_msg = apply_update_process(temp_zip, new_ver)

    if not success_apply:
        print_error("Cập nhật thất bại", reason=apply_msg)
        return False

    print_update_success_banner(current_ver, new_ver)
    sys.exit(0)

if __name__ == "__main__":
    run_cli_update_flow(prompt_user=True)
