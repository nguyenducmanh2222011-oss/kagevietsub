#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
KAGEVIETSUB - TEST SUITE: 5 BÀI TEST TTS WORKERS + 10 BÀI TEST AUTO UPDATE
==============================================================================
Thực hiện kiểm thử toàn diện:
- 5 bài test TTS Concurrency & Speed Pipeline
- 10 bài test Auto Update (ZIP structure, SHA256, Path Traversal, Backup, Rollback)
==============================================================================
"""

import os
import sys
import time
import json
import shutil
import zipfile
import hashlib
from pathlib import Path
from typing import Dict, Any, List

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from TOOL.config import TEMP_DIR, DATA_DIR, KAGE_DOWNLOAD_DIR
from TOOL.engines.tts_engine import TTSEngine, WorkerTracker, JobStateTracker
from TOOL.services.task_service import job_manager
from TOOL.updater import (
    parse_update_txt, calculate_sha256, download_update_zip,
    is_path_safe_for_update, inspect_and_extract_zip,
    apply_transactional_update, apply_update_process,
    get_local_version, set_local_version, is_system_busy
)


# ==============================================================================
# PHẦN 1: 5 BÀI TEST TTS WORKER CONCURRENCY KHI SPEED != 1.0x
# ==============================================================================

def run_tts_worker_test(test_num: int, req_workers: int, speed: float):
    print(f"\n[TTS TEST {test_num}] Workers = {req_workers}, Speed = {speed}x...")
    job_id = f"test_tts_w{req_workers}_s{int(speed*100)}_{int(time.time()*1000)}"

    # Tạo 2 câu phụ đề mẫu đã có sẵn file raw để test nhanh tốc độ worker
    job_dir = TEMP_DIR / "tts" / f"job_{job_id}"
    job_dir.mkdir(parents=True, exist_ok=True)

    subs = [
        {"id": "0001", "start": "00:00:01,000", "end": "00:00:03,000", "text": "Thử nghiệm câu 1."},
        {"id": "0002", "start": "00:00:04,000", "end": "00:00:06,000", "text": "Thử nghiệm câu 2."}
    ]

    # Tạo file raw giả lập để pass validation
    sample_mp3 = job_dir / "sample.mp3"
    import subprocess
    cmd = [
        "ffmpeg", "-y", "-f", "lavfi",
        "-i", "sine=frequency=440:sample_rate=44100",
        "-t", "1.0",
        "-vn", "-ar", "44100", "-ac", "2", "-b:a", "192k",
        str(sample_mp3), "-loglevel", "error"
    ]
    subprocess.run(cmd, check=True)
    shutil.copy(sample_mp3, job_dir / "raw_0001.mp3")
    shutil.copy(sample_mp3, job_dir / "raw_0002.mp3")

    # Bắt output stdout để kiểm tra định dạng log bắt buộc
    import io
    from contextlib import redirect_stdout
    f_out = io.StringIO()
    with redirect_stdout(f_out):
        job = TTSEngine.process_tts_job(
            job_id=job_id,
            subtitles=subs,
            voice="BV421_vivn_streaming",
            speed=speed,
            threads=req_workers
        )

    output_str = f_out.getvalue()
    res = job["result"]

    # Kiểm tra log bắt buộc
    expected_req_line = f"Requested TTS workers: {req_workers}"
    expected_act_line = f"Actual TTS workers: {req_workers}"
    speed_fmt = f"{speed:.2f}".rstrip("0").rstrip(".") + "x"
    expected_spd_line = f"Speed: {speed_fmt}"

    assert expected_req_line in output_str, f"Missing log line: '{expected_req_line}' in output:\n{output_str}"
    assert expected_act_line in output_str, f"Missing log line: '{expected_act_line}' in output:\n{output_str}"
    assert expected_spd_line in output_str, f"Missing log line: '{expected_spd_line}' in output:\n{output_str}"

    # Kiểm tra kết quả trạng thái
    assert res["requested_workers"] == req_workers, f"Requested: {res['requested_workers']} != {req_workers}"
    assert res["actual_workers"] == req_workers, f"Actual: {res['actual_workers']} != {req_workers}"
    assert res["tts_workers"] == req_workers, f"TTS workers: {res['tts_workers']} != {req_workers}"
    assert res["completed"] == 2, f"Expected 2 completed, got {res['completed']}"

    print(f" -> Logged correctly:\n    {expected_req_line}\n    {expected_act_line}\n    {expected_spd_line}")
    print(f" [✓] TTS TEST {test_num} PASS")
    shutil.rmtree(job_dir, ignore_errors=True)


def run_all_tts_tests():
    print("=" * 70)
    print("KIỂM THỬ 5 BÀI TEST TTS WORKER CONCURRENCY (SPEED != 1.0x)")
    print("=" * 70)

    # 1. Workers = 5, Speed = 1.0x -> Requested = 5, Actual = 5
    run_tts_worker_test(1, 5, 1.0)

    # 2. Workers = 5, Speed = 1.5x -> Requested = 5, Actual = 5
    run_tts_worker_test(2, 5, 1.5)

    # 3. Workers = 10, Speed = 1.5x -> Requested = 10, Actual = 10
    run_tts_worker_test(3, 10, 1.5)

    # 4. Workers = 20, Speed = 0.75x -> Requested = 20, Actual = 20
    run_tts_worker_test(4, 20, 0.75)

    # 5. Workers = 30, Speed = 2.0x -> Requested = 30, Actual = 30
    run_tts_worker_test(5, 30, 2.0)

    print("\n" + "=" * 70)
    print("TẤT CẢ 5 BÀI TEST TTS WORKER ĐÃ HOÀN THÀNH 100% THÀNH CÔNG!")
    print("=" * 70)


# ==============================================================================
# PHẦN 2: 10 BÀI TEST AUTO UPDATE MECHANISM
# ==============================================================================

def make_dummy_zip(zip_path: Path, files_dict: Dict[str, str]) -> Path:
    """Tạo file zip mẫu với nội dung chỉ định."""
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for arcname, content in files_dict.items():
            z.writestr(arcname, content)
    return zip_path


def run_all_update_tests():
    print("\n" + "=" * 70)
    print("KIỂM THỬ 10 BÀI TEST AUTO UPDATE THEO CƠ CHẾ ZIP VÀ ROLLBACK")
    print("=" * 70)

    orig_ver = get_local_version()
    test_env_dir = TEMP_DIR / "updater_unit_tests"
    if test_env_dir.exists():
        shutil.rmtree(test_env_dir, ignore_errors=True)
    test_env_dir.mkdir(parents=True, exist_ok=True)

    try:
        # TEST 1: Update bình thường có SHA256 hợp lệ
        print("\n[UPDATE TEST 1] Update bình thường có SHA256 hợp lệ...")
        raw_txt = (
            "VERSION=3.2.4\n"
            "URL=http://mock/update.zip\n"
            "SHA256=abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890\n"
        )
        info1 = parse_update_txt(raw_txt)
        assert info1["version"] == "3.2.4"
        assert info1["sha256"] == "abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890"

        # Tạo file zip thật và tính sha256
        z1_path = test_env_dir / "update1.zip"
        target_file1 = ROOT / "TOOL" / "temp_update_test1.txt"
        make_dummy_zip(z1_path, {"TOOL/temp_update_test1.txt": "update content 1"})
        real_sha = calculate_sha256(z1_path)

        # Apply update
        ok, msg = apply_update_process(z1_path, "3.2.4")
        assert ok, f"Expected success, got: {msg}"
        assert target_file1.exists()
        assert target_file1.read_text(encoding="utf-8") == "update content 1"
        assert get_local_version() == "3.2.4"
        print(" [✓] UPDATE TEST 1 PASS")
        target_file1.unlink()

        # TEST 2: Update bình thường không có SHA256 (bỏ qua kiểm tra SHA256)
        print("\n[UPDATE TEST 2] Update bình thường không có SHA256 (bỏ qua)...")
        raw_txt_no_sha = (
            "VERSION=3.2.5\n"
            "URL=http://mock/update.zip\n"
            "SHA256=\n"
        )
        info2 = parse_update_txt(raw_txt_no_sha)
        assert info2["version"] == "3.2.5"
        assert info2["sha256"] == ""

        z2_path = test_env_dir / "update2.zip"
        target_file2 = ROOT / "TOOL" / "temp_update_test2.txt"
        make_dummy_zip(z2_path, {"TOOL/temp_update_test2.txt": "update content 2 without sha"})

        ok2, msg2 = apply_update_process(z2_path, "3.2.5")
        assert ok2, f"Expected success, got: {msg2}"
        assert target_file2.exists()
        assert target_file2.read_text(encoding="utf-8") == "update content 2 without sha"
        assert get_local_version() == "3.2.5"
        print(" [✓] UPDATE TEST 2 PASS")
        target_file2.unlink()

        # TEST 3: Update thất bại do SHA256 sai -> hủy update, không đổi file, không đổi version
        print("\n[UPDATE TEST 3] Update thất bại do SHA256 sai -> hủy update...")
        z3_path = test_env_dir / "update3.zip"
        make_dummy_zip(z3_path, {"TOOL/temp_update_test3.txt": "should not be applied"})
        target_file3 = ROOT / "TOOL" / "temp_update_test3.txt"

        wrong_sha = "0000000000000000000000000000000000000000000000000000000000000000"
        curr_ver = get_local_version()

        # Giả lập tải với SHA256 sai
        ok_dl, dl_msg = download_update_zip(z3_path.as_uri(), test_env_dir / "dl_fail.zip", expected_sha256=wrong_sha)
        assert not ok_dl, "Download should have failed due to SHA256 mismatch"
        assert "Mã SHA256 không khớp" in dl_msg
        assert not target_file3.exists()
        assert get_local_version() == curr_ver
        print(f" -> Correctly aborted: {dl_msg}")
        print(" [✓] UPDATE TEST 3 PASS")

        # TEST 4: Update có file mới -> tạo file mới thành công
        print("\n[UPDATE TEST 4] Update có file mới -> tạo file mới thành công...")
        new_file_path = ROOT / "TOOL" / "test_new_feature_created.txt"
        if new_file_path.exists():
            new_file_path.unlink()
        z4_path = test_env_dir / "update4.zip"
        make_dummy_zip(z4_path, {"TOOL/test_new_feature_created.txt": "brand new module"})

        ok4, msg4 = apply_update_process(z4_path, "3.2.6")
        assert ok4
        assert new_file_path.exists()
        assert new_file_path.read_text(encoding="utf-8") == "brand new module"
        assert get_local_version() == "3.2.6"
        print(" [✓] UPDATE TEST 4 PASS")
        new_file_path.unlink()

        # TEST 5: Update chỉ có 1 file -> chỉ đổi đúng 1 file, các file khác không bị xóa
        print("\n[UPDATE TEST 5] Update chỉ có 1 file -> các file khác giữ nguyên 100%...")
        file_to_change = ROOT / "TOOL" / "single_file_target.txt"
        file_to_keep = ROOT / "TOOL" / "other_file_untouched.txt"
        file_to_change.write_text("old content", encoding="utf-8")
        file_to_keep.write_text("keep this content", encoding="utf-8")

        z5_path = test_env_dir / "update5.zip"
        make_dummy_zip(z5_path, {"TOOL/single_file_target.txt": "updated content"})

        ok5, msg5 = apply_update_process(z5_path, "3.2.7")
        assert ok5
        assert file_to_change.read_text(encoding="utf-8") == "updated content"
        assert file_to_keep.exists()
        assert file_to_keep.read_text(encoding="utf-8") == "keep this content"
        print(" [✓] UPDATE TEST 5 PASS (Không có file nào bị xóa ngoài zip)")
        file_to_change.unlink()
        file_to_keep.unlink()

        # TEST 6: Update có path traversal ../ -> hủy toàn bộ ngay lập tức
        print("\n[UPDATE TEST 6] Update có path traversal ../ -> hủy toàn bộ...")
        z6_path = test_env_dir / "update_traversal.zip"
        make_dummy_zip(z6_path, {
            "../escaped.txt": "malicious",
            "TOOL/safe.txt": "safe"
        })
        safe_target = ROOT / "TOOL" / "safe.txt"
        escaped_target = ROOT.parent / "escaped.txt"

        ver_before = get_local_version()
        ok6, msg6 = apply_update_process(z6_path, "3.2.8")
        assert not ok6, "Should fail on path traversal"
        assert "nguy hiểm" in msg6 or "Path Traversal" in msg6
        assert not safe_target.exists(), "Safe target should not be created if package is unsafe"
        assert not escaped_target.exists()
        assert get_local_version() == ver_before
        print(f" -> Correctly blocked: {msg6}")
        print(" [✓] UPDATE TEST 6 PASS")

        # TEST 7: Update can thiệp DATA/models hoặc Download/KAGEVIETSUB -> hủy toàn bộ
        print("\n[UPDATE TEST 7] Update can thiệp DATA/models hoặc Download/KAGEVIETSUB -> hủy toàn bộ...")
        z7_path = test_env_dir / "update_protected.zip"
        make_dummy_zip(z7_path, {
            "DATA/models/whisper.bin": "overwrite model",
            "Download/KAGEVIETSUB/my_video.mp4": "overwrite user video"
        })
        user_model = DATA_DIR / "models" / "whisper.bin"
        user_video = KAGE_DOWNLOAD_DIR / "my_video.mp4"

        ok7, msg7 = apply_update_process(z7_path, "3.2.9")
        assert not ok7, "Should reject update targeting protected data"
        assert "vùng dữ liệu" in msg7 or "bảo vệ" in msg7
        assert not user_model.exists()
        assert not user_video.exists()
        print(f" -> Correctly blocked protected access: {msg7}")
        print(" [✓] UPDATE TEST 7 PASS")

        # TEST 8: Update gặp lỗi giữa chừng -> rollback về trạng thái ban đầu
        print("\n[UPDATE TEST 8] Update gặp lỗi giữa chừng -> rollback về trạng thái ban đầu...")
        target_f_old = ROOT / "TOOL" / "rollback_target_old.txt"
        target_f_old.write_text("ORIGINAL CONTENT BEFORE ROLLBACK", encoding="utf-8")
        target_f_new = ROOT / "TOOL" / "rollback_target_new.txt"
        if target_f_new.exists():
            target_f_new.unlink()

        # Giả lập danh sách extracted files nhưng file thứ 2 bị lỗi khi copy hoặc size mismatch
        dummy_src_old = test_env_dir / "dummy_src_old.txt"
        dummy_src_old.write_text("NEW CONTENT ATTEMPT", encoding="utf-8")
        dummy_src_new = test_env_dir / "dummy_src_new.txt"
        dummy_src_new.write_text("NEW FILE ATTEMPT", encoding="utf-8")

        # File thứ 3 không tồn tại ở nguồn để gây crash giữa chừng
        non_existent_src = test_env_dir / "does_not_exist.txt"

        broken_extracted = [
            (dummy_src_old, "TOOL/rollback_target_old.txt"),
            (dummy_src_new, "TOOL/rollback_target_new.txt"),
            (non_existent_src, "TOOL/crash_trigger.txt")
        ]

        old_ver = get_local_version()
        ok8, msg8 = apply_transactional_update(broken_extracted, "9.9.9")
        assert not ok8, "Should fail due to missing source file"
        assert "rollback" in msg8.lower()

        # Kiểm tra trạng thái đã được khôi phục nguyên vẹn
        assert target_f_old.read_text(encoding="utf-8") == "ORIGINAL CONTENT BEFORE ROLLBACK", "Old file was not restored!"
        assert not target_f_new.exists(), "New file was not removed during rollback!"
        assert get_local_version() == old_ver, "Version was prematurely changed!"
        print(f" -> Rollback verified successfully: {msg8}")
        print(" [✓] UPDATE TEST 8 PASS")
        target_f_old.unlink()

        # TEST 9: Update khi server bận -> từ chối update
        print("\n[UPDATE TEST 9] Update khi server bận -> từ chối update...")
        # Tạo 1 job đang processing
        busy_job_id = job_manager.create_job("tts_generation")
        job_manager.update_job(busy_job_id, status="processing")
        assert is_system_busy()

        z9_path = test_env_dir / "update9.zip"
        make_dummy_zip(z9_path, {"TOOL/dummy9.txt": "dummy"})

        ok9, msg9 = apply_update_process(z9_path, "3.3.0")
        assert not ok9
        assert "tác vụ đang chạy" in msg9
        print(f" -> Correctly rejected when system is busy: {msg9}")
        print(" [✓] UPDATE TEST 9 PASS")

        # Dọn dẹp job test
        job_manager.update_job(busy_job_id, status="completed")

        # TEST 10: Update thành công -> thông báo 'Cập nhật thành công. Vui lòng khởi động lại KAGEVIETSUB.'
        print("\n[UPDATE TEST 10] Update thành công -> thông báo 'Cập nhật thành công. Vui lòng khởi động lại KAGEVIETSUB.'...")
        z10_path = test_env_dir / "update10.zip"
        final_test_file = ROOT / "TOOL" / "final_success_file.txt"
        make_dummy_zip(z10_path, {"TOOL/final_success_file.txt": "final test ok"})

        ok10, msg10 = apply_update_process(z10_path, "3.3.0")
        assert ok10
        assert "Cập nhật thành công. Vui lòng khởi động lại KAGEVIETSUB." in msg10
        assert not (DATA_DIR / "temp" / "updater").exists(), "Temporary updater directory should be cleaned up on success"
        print(f" -> Message returned: '{msg10}'")
        print(" [✓] UPDATE TEST 10 PASS")
        final_test_file.unlink()

    finally:
        # Khôi phục lại version.json ban đầu
        set_local_version(orig_ver)
        shutil.rmtree(test_env_dir, ignore_errors=True)

    print("\n" + "=" * 70)
    print("TẤT CẢ 10 BÀI TEST AUTO UPDATE ĐÃ HOÀN THÀNH 100% THÀNH CÔNG!")
    print("=" * 70)


if __name__ == "__main__":
    run_all_tts_tests()
    run_all_update_tests()
